import networkx as nx
import util
from itertools import islice
import numpy as np
from collections import defaultdict

def baseline_algorithm(prob_info, timelimit=60):
    def loading_heuristic(p, node_allocations, rehandling_demands):
        K_load = {idx: r for idx, ((o,d),r) in enumerate(K) if o == p}
        if len(rehandling_demands) > 0:
            for k in rehandling_demands:
                if k in K_load:
                    K_load[k] += 1
                else:
                    K_load[k] = 1
        route_list = []
        last_rehandling_demands = []

        total_loading_demands = sum([r for k,r in K_load.items()])
        reachable_nodes, reachable_node_distances = util.bfs(G, node_allocations)

        # Get not occupied nodes
        available_nodes = util.get_available_nodes(node_allocations)
        if len(available_nodes) < total_loading_demands:
            raise Exception("Not enough available nodes to load demand!!! This must not happen!!!")

        if len(reachable_nodes) < total_loading_demands:

            available_but_not_reachable = [n for n in available_nodes if n not in reachable_nodes]

            while len(reachable_nodes) < total_loading_demands:
                if len(available_but_not_reachable) == 0:
                    raise Exception("Not enough available_but_not_reachable nodes to rehandle. This must not happen!!!")
                
                # Pick a node from the available but not reachable nodes
                n = available_but_not_reachable.pop(0)

                # Get the shortest path to the node from the gate
                distances, previous_nodes = util.dijkstra(G, node_allocations=None)

                path = util.path_backtracking(previous_nodes, 0, n)

                # Roll-off blocking demands on the path by order of distance from the gate. (and push to last_rehandling_demands list for the later reloading)
                for idx, i in enumerate(path[:-1]):
                    if node_allocations[i] != -1:
                        # Node i is occupied by demand node_allocations[i]
                        last_rehandling_demands.append(node_allocations[i])
                        node_allocations[i] = -1

                        # Rehandling route (from the blocking node to the gate)
                        route_list.append((path[:idx+1][::-1], node_allocations[i]))

                        # Increasing the number demands to load
                        total_loading_demands += 1

                # Check if the number of reachable nodes is enough to load the demand
                reachable_nodes, reachable_node_distances = util.bfs(G, node_allocations)

            # print(f'After rehandling, we have {len(reachable_nodes)} reachable nodes now! (but have to rehandle {len(last_rehandling_demands)} demands)')


        # Merge the rehandling demands with the loading demands
        for k in last_rehandling_demands:
            if k in K_load:
                K_load[k] += 1
            else:
                K_load[k] = 1
        if total_loading_demands > 0:
            loading_nodes = reachable_nodes[-total_loading_demands:][::-1]

            grouped_by_dest = defaultdict(list)
            for k, r in K_load.items():
                d = K[k][0][1]
                grouped_by_dest[d].extend([k]*r)

            flattened_K_load = []
            for d in sorted(grouped_by_dest.keys(), reverse=True):
                flattened_K_load.extend(grouped_by_dest[d])


            assert(len(flattened_K_load) == len(loading_nodes))
            distances, previous_nodes = util.dijkstra(G, node_allocations)
            for n, k in zip(loading_nodes, flattened_K_load):
                node_allocations[n] = k

                path = util.path_backtracking(previous_nodes, 0, n)

                route_list.append((path, k))
        return route_list, node_allocations

    def unloading_heuristic(p, node_allocations):

        K_unload = {idx: r for idx, ((o,d),r) in enumerate(K) if d == p}
        route_list = []
        rehandling_demands = []

        for k, r in K_unload.items():
            unloading_nodes = sorted([n for n in range(N) if node_allocations[n] == k])

            for n in unloading_nodes:

                if node_allocations[n] == -1:
                    continue
                num_blocking_nodes = []
                for path in shortest_paths[n]:
                    blocking_nodes = [i for i in path[:-1] if node_allocations[i] != -1]
                    num_blocking_nodes.append((len(blocking_nodes), blocking_nodes, path))
                min_blocking_nodes = sorted(num_blocking_nodes, key=lambda x: (x[0], len(x[2])))[0]

                if min_blocking_nodes[0] == 0:
                    path = min_blocking_nodes[2]
                    route_list.append((path[::-1], k))
                    node_allocations[n] = -1
                else:
                    blocking_nodes = min_blocking_nodes[1]
                    path = min_blocking_nodes[2]
                    num_blocking = 0
                    for bn in blocking_nodes:
                        unload_route = []
                        for i in path:
                            unload_route.append(i)
                            if bn == i:
                                break
                        route_list.append((unload_route[::-1], node_allocations[bn]))
                        if node_allocations[bn] not in K_unload:
                            rehandling_demands.append(node_allocations[bn])
                            num_blocking += 1
                        node_allocations[bn] = -1
                        
                    route_list.append((path[::-1], k))
                    node_allocations[n] = -1
        return route_list, rehandling_demands
    N = prob_info['N']
    E = prob_info['E']
    E = set([(u,v) for (u,v) in E])
    K = prob_info['K']
    P = prob_info['P']
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(E)
    shortest_distances = np.zeros(N, dtype=int)
    max_num_paths = 5
    shortest_paths = [[]] 
    for i in range(1, N):
        sp_i = list(islice(nx.shortest_simple_paths(G, 0, i), max_num_paths))
        shortest_paths.append(sp_i)
        shortest_distances[i] = len(sp_i[0]) - 1
    shortest_paths_array = [[]] 
    for i in range(1, N):
        sp_i_array = []
        for p in shortest_paths[i]:
            path_array = np.zeros(N, dtype=int)
            path_array[p[:-1]] = 1
            sp_i_array.append(path_array)
        shortest_paths_array.append(sp_i_array)

    # Current status of nodes
    # -1 means available (i.e. empty)
    # otherwise means occupied with a demand
    node_allocations = np.ones(N, dtype=int) * -1

    # Solution dictionary
    solution = {
        p: []
        for p in range(P)
    }
    for p in range(P):
        # print(f"Port {p} ==============================")
        if p > 0:
            # Unloading heuristic
            route_list_unload, rehandling_demands = unloading_heuristic(p, node_allocations)

            solution[p].extend(route_list_unload)
        else:
            rehandling_demands = []
        if p < P-1:
            # Loading heuristic
            route_list_load, node_allocations = loading_heuristic(p, node_allocations, rehandling_demands)

            solution[p].extend(route_list_load)
    return solution

def compute_baseline_obj(prob_info, sol):
    F = prob_info["F"]
    LB = prob_info["LB"]
    total = 0.0
    for _, routes in sol.items():
        for route, k in routes:
            total += F + len(route) - 1
    return (int)(total - LB)   # check_feasibility와 동일한 정의