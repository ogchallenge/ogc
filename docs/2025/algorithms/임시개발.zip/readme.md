Shared Object 파일 컴파일을 위해, Linux/Ubuntu 24.04 환경에서 다음 0-3단계의 사전 수행이 필요합니다.

## 0. python3 설치 (미설치 시)

sudo apt install python3 python3-dev python3-pip

## 1. pybind11 라이브러리 설치

pip install pybind11
python3 -m pybind11 --includes

## 2. GUROBI_HOME 환경변수 설정(Gurobi 12.0.1 설치 후)

export GUROBI_HOME=/home/{사용자명}/gurobi1201/linux64

## 3. so파일 컴파일

g++ -O2 -Wall -shared -std=c++17 -fPIC \
    $(python3 -m pybind11 --includes) \
    -I${GUROBI_HOME}/include \
    engine.cpp model.cpp network_utils.cpp \
    -L${GUROBI_HOME}/lib -lgurobi_c++ -lgurobi120 \
    -o engine$(python3-config --extension-suffix)

## 4. myalgorithm.py 파일 실행(컴파일된 engine.cpython-311-x86_64-linux-gnu.so 파일을 import하여 사용합니다.)
