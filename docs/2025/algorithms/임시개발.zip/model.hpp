#ifndef MODEL_HPP
#define MODEL_HPP

#include <unordered_map>
#include <vector>
#include <string>
#include <utility>
#include <optional>
#include <set>
#include <unordered_set>
#include <map>
#include <tuple>
#include <iostream>
#include <cassert>
#include <algorithm>
#include <queue>
#include <deque>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "gurobi_c++.h"
#include "network_utils.hpp"

using namespace std;

struct M1Start {
  std::map<std::tuple<int,int,int>, double> xpp;  // (p1,p2,i)
  std::map<std::tuple<int,int>,     double> x;    // (p,i)
  std::map<std::tuple<int,int,int>, double> t;    // (i,k,j)
};

GRBModel build_model(const ModelContext& ctx, ModelVars& vars, GRBEnv env, int model_level);

GRBModel build_shortest_model(const ModelContext& ctx, ModelVars& vars, GRBEnv env);

GRBModel build_shortestz_model(const ModelContext& ctx, ModelVars& vars, GRBEnv env);

GRBModel build_y_model(const ModelContext& ctx, ModelVars& vars, GRBEnv env);

// Extract solution from basic model (Model 1)
FullSolution extract_solution(const ModelContext& ctx, const ModelVars& vars, int model_level);

void apply_warm_start_from_m1_to_m2(const ModelVars& from, ModelVars& to);

// Reorder port_paths into unload, rehandling, load
// unordered_map<int, vector<pair<vector<int>, int>>>
// reorder_solution_paths(const unordered_map<int, vector<pair<vector<int>, int>>>& raw);

#endif // MODEL_HPP

