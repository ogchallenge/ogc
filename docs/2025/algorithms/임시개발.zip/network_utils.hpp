#ifndef NETWORK_UTILS_HPP
#define NETWORK_UTILS_HPP

#include <vector>
#include <set>
#include <map>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <optional>

#include "gurobi_c++.h"

using namespace std;

struct FullSolution {
    unordered_map<int, vector<pair<vector<int>, int>>> port_paths;
};

struct GraphInfo {
    map<int, vector<int>> approaching_map;
    map<int, vector<int>> receding_map;
    map<int, vector<int>> same_level_map;
    map<int, int> depth;
    map<int, vector<int>> path_to_root;
    unordered_map<int, unordered_set<int>> path_contains;
    vector<pair<int, int>> ijSet;
    bool isTree;
};

struct ModelContext {
    GraphInfo tree;
    unordered_map<string, int> prob_info;
    vector<pair<pair<int, int>, int>> K;
    set<pair<int, int>> arcs;

    optional<FullSolution> warm_start;

    const auto& depth() const { return tree.depth; }
    const auto& path_contains() const { return tree.path_contains; }
    const auto& path_to_root() const { return tree.path_to_root; }
    const auto& approaching_map() const { return tree.approaching_map; }
    const auto& receding_map() const { return tree.receding_map; }
    const auto& same_level_map() const { return tree.same_level_map; }
    const auto& ijSet() const { return tree.ijSet; }
    const auto& isTree() const { return tree.isTree; }

    void apply_warm_start(GRBModel& model, GRBVar*** xpp, GRBVar*** t,
                          GRBVar*** xL = nullptr, GRBVar*** xU = nullptr,
                          GRBVar*** fL = nullptr, GRBVar*** fU = nullptr) const;
};

// Variable holder for a model instance
struct ModelVars {
    map<tuple<int, int, int>, GRBVar> xpp;
    map<tuple<int, int, int>, GRBVar> t;
    map<tuple<int, int>, GRBVar> x;
    map<tuple<int, int>, GRBVar> z;
    map<tuple<int, int>, GRBVar> d, dL, dU;
    map<tuple<int, int>, GRBVar> xL, xU;
    map<tuple<int, int, int>, GRBVar> y;
    map<tuple<int, int, int, int>, GRBVar> fL, fU;
    GRBModel* model = nullptr;
};

// Custom hash for pair
struct pair_hash {
    template <typename T1, typename T2>
    size_t operator()(const pair<T1, T2>& p) const {
        return hash<T1>()(p.first) ^ (hash<T2>()(p.second) << 1);
    }
};

GraphInfo get_graph_info(const set<pair<int, int>>& arcs, const vector<int>& nodes);

using PortSolution = vector<pair<vector<int>, int>>;

#endif