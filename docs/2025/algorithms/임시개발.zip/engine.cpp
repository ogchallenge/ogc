#include <numeric>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <chrono>
#include <fstream>

#include "gurobi_c++.h"
#include "network_utils.hpp"
#include "model.hpp"

namespace py = pybind11;
using namespace std;
namespace std {
    template <>
    struct hash<std::pair<int, int>> {
        std::size_t operator()(const std::pair<int, int>& key) const {
            size_t h1 = std::hash<int>()(key.first);
            size_t h2 = std::hash<int>()(key.second);
            return h1 ^ (h2 << 1);  // or use boost::hash_combine if available
        }
    };

    template <>
    struct hash<std::tuple<int, int>> {
        std::size_t operator()(const std::tuple<int, int>& key) const {
            size_t h1 = std::hash<int>()(std::get<0>(key));
            size_t h2 = std::hash<int>()(std::get<1>(key));
            return h1 ^ (h2 << 1);
        }
    };

    template <>
    struct hash<std::tuple<int, int, int>> {
        std::size_t operator()(const std::tuple<int, int, int>& key) const {
            size_t h1 = std::hash<int>()(std::get<0>(key));
            size_t h2 = std::hash<int>()(std::get<1>(key));
            size_t h3 = std::hash<int>()(std::get<2>(key));
            return ((h1 ^ (h2 << 1)) >> 1) ^ (h3 << 1);
        }
    };
}
using namespace chrono;
using pii = std::pair<int,int>;

py::dict convert_to_py(const FullSolution& sol) {
    py::dict py_sol;

    if (sol.port_paths.empty()) {
        return py_sol;
    }
    std::vector<int> sorted_ports;
    for (const auto& [port, _] : sol.port_paths) {
        sorted_ports.push_back(port);
    }
    std::sort(sorted_ports.begin(), sorted_ports.end());
    for (int port : sorted_ports) {
        const auto& routes = sol.port_paths.at(port);
        // py::print("port:", port, "routes size:", routes.size());
        py::list py_routes;
        for (const auto& [path, k] : routes) {
            py_routes.append(py::make_tuple(path, k));
        }
        py_sol[py::int_(port)] = py_routes;
    }

    return py_sol;
}

py::dict run_cpp(const py::dict& prob_info, double timelimit, int baseline_obj) {
    using Clock = std::chrono::steady_clock;

    try {
        auto t0 = Clock::now();

        // ----- read inputs -----
        int N = prob_info["N"].cast<int>();
        int P = prob_info["P"].cast<int>();
        int F = prob_info["F"].cast<int>();
        int LB = prob_info["LB"].cast<int>();
        std::vector<pair<int,int>> E = prob_info["E"].cast<std::vector<pair<int,int>>>();
        std::vector<std::pair<pair<int,int>, int>> K =
            prob_info["K"].cast<std::vector<std::pair<pair<int,int>, int>>>();

        std::set<pair<int,int>> arcs;
        for (auto [u,v] : E) {
            arcs.insert({u,v});
            arcs.insert({v,u});
        }
        std::vector<int> nodes(N); std::iota(nodes.begin(), nodes.end(), 0);

        GraphInfo tree_info = get_graph_info(arcs, nodes);
        std::unordered_map<std::string,int> prob_info_map{{"N",N},{"P",P},{"F",F},{"LB",LB}};
        ModelContext ctx{tree_info, prob_info_map, K, arcs};

        GRBEnv env = GRBEnv(true);
        env.start();

        // ====== m1: 강화 모델 (빠른 모델) ======
        ModelVars vars1;
        GRBModel m1 = build_model(ctx, vars1, env, 10);
        m1.set(GRB_IntParam_Method, 1);
        m1.set(GRB_IntParam_Threads, 4);
        m1.set(GRB_IntParam_Cuts, 0);
        m1.set(GRB_IntParam_OutputFlag, 0);

        const double BUFFER = 1.0;
        double elapsed = std::chrono::duration<double>(Clock::now() - t0).count();
        double time_left = timelimit - elapsed;
        if (time_left <= 0.0) { return py::dict(); }
        m1.set(GRB_DoubleParam_TimeLimit, std::max(0.0, time_left - BUFFER));

        m1.optimize();

        if (m1.get(GRB_IntAttr_SolCount) <= 0) {
            return py::dict();
        }

        const double obj1 = m1.get(GRB_DoubleAttr_ObjVal);

        // baseline보다 안 좋으면: 상위에서 baseline 쓰도록 빈 dict 반환
        if (obj1 >= static_cast<double>(baseline_obj) - 1e-6) {
            return py::dict();
        }

        // m1 해 추출(강화 모델 기준)
        FullSolution sol1 = extract_solution(ctx, vars1, 10);
        py::dict sol1_py = convert_to_py(sol1);

        // ====== m2 실행 여부 판단 ======
        const double RESERVE_FOR_M2 = 10.0;
        elapsed = std::chrono::duration<double>(Clock::now() - t0).count();
        time_left = timelimit - elapsed;
        if (time_left < RESERVE_FOR_M2 + BUFFER) {
            return sol1_py;  // m1 해 사용
        }

        // ====== m2: 원래 기능 포함 모델 ======
        ModelVars vars2;
        GRBModel m2 = build_model(ctx, vars2, env, 4);

        // m1 해를 그대로 Warm Start로 복사
        apply_warm_start_from_m1_to_m2(vars1, vars2);
        m2.update();

        // m1보다 좋은 해만 찾으면 종료
        m2.set(GRB_IntParam_Method, 1);
        m2.set(GRB_IntParam_Threads, 4);
        m2.set(GRB_IntParam_Cuts, 0);
        m2.set(GRB_IntParam_OutputFlag, 0);

        // 남은 시간 부여
        elapsed = std::chrono::duration<double>(Clock::now() - t0).count();
        time_left = timelimit - elapsed;
        m2.set(GRB_DoubleParam_TimeLimit, std::max(0.0, time_left - BUFFER));
        m2.optimize();

        if (m2.get(GRB_IntAttr_SolCount) > 0) {
            const double obj2 = m2.get(GRB_DoubleAttr_ObjVal);
            // py::print("m2 obj =", obj2, " (m1 obj =", obj1, ")");

            if (obj2 < obj1 - 1e-6) {
                // 개선됨 → m2 해 반환
                FullSolution sol2 = extract_solution(ctx, vars2, 4);
                return convert_to_py(sol2);
            } else {
                // 개선 없음 → m1 해 반환
                return sol1_py;
            }
        } else {
            // 해 없음 → m1 해 반환
            return sol1_py;
        }
    }
    catch (...) {
        return py::dict();
    }
}

PYBIND11_MODULE(engine, m) {
    m.def("run", [](const py::dict& prob_info, double timelimit, int baseline_obj) {
        return run_cpp(prob_info, timelimit, baseline_obj);
    });
}