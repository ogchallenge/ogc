#include <vector>
#include <queue>
#include <set>
#include <unordered_set>
#include <numeric>
#include <iostream>
#include <algorithm>
#include <cassert>

#include "gurobi_c++.h"
#include "network_utils.hpp"

using namespace std;

GraphInfo get_graph_info(const set<pair<int,int>>& arcs, const vector<int>& nodes) {
    int root = 0;
    GraphInfo info;
    info.isTree = true;
    info.depth[root] = 0;
    info.path_to_root[root] = {root};

    // adjacency
    unordered_map<int, vector<int>> nbr;
    nbr.reserve(nodes.size());
    for (int n : nodes) nbr[n] = {};
    for (auto [u, v] : arcs) nbr[u].push_back(v);

    unordered_set<int> visited;
    visited.reserve(nodes.size());
    queue<int> q;
    visited.insert(root);
    q.push(root);

    while (!q.empty()) {
        int cur = q.front(); q.pop();
        for (int nxt : nbr[cur]) {
            if (!visited.count(nxt)) {
                // 처음 발견: 트리 간선
                visited.insert(nxt);
                info.depth[nxt] = info.depth[cur] + 1;
                info.path_to_root[nxt] = info.path_to_root[cur];
                info.path_to_root[nxt].push_back(nxt);
                info.approaching_map[nxt].push_back(cur);  // parent
                info.receding_map[cur].push_back(nxt);     // child
                // 트리 판정용 ijSet 등 필요시 여기서만 추가
                if (cur != root) info.ijSet.push_back({nxt, cur});
                q.push(nxt);
            } else {
                // 이미 방문한 노드와의 간선: 레벨 관계로 분류 (중복 방지 주의)
                int gap = info.depth[nxt] - info.depth[cur];
                if (gap < 0) {
                    // cur가 더 깊고 nxt가 더 얕음: nxt는 cur의 조상/상위
                    // approaching_map[cur].push_back(nxt);  // 필요하면 사용
                    // receding_map[nxt].push_back(cur);
                    info.isTree = false;
                } else if (gap == 0) {
                    // 같은 레벨
                    info.isTree = false;
                    auto& a = info.same_level_map[cur];
                    auto& b = info.same_level_map[nxt];
                    if (a.empty() || a.back() != nxt) a.push_back(nxt);
                    if (b.empty() || b.back() != cur) b.push_back(cur);
                } else { // gap > 0
                    // cur -> 더 깊은 nxt (병행 간선)
                    info.isTree = false;
                    auto& up  = info.approaching_map[nxt];
                    auto& down= info.receding_map[cur];
                    // 중복 방지(간단한 O(1) 가드; 필요시 unordered_set로 관리)
                    if (up.empty()  || up.back()  != cur)  up.push_back(cur);
                    if (down.empty()|| down.back() != nxt) down.push_back(nxt);
                }
            }
        }
    }
    // path_contains 채우기
    for (const auto& [i, path] : info.path_to_root) {
        for (int j : path) if (i != j && j != root) info.path_contains[i].insert(j);
    }
    return info;
}