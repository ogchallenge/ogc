#include <unordered_map>
#include <vector>
#include <string>
#include <utility>
#include <optional>
#include <set>
#include <iostream>
#include <cassert>
#include <algorithm>
#include <queue>
#include <deque>
#include <numeric>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "gurobi_c++.h"
#include "network_utils.hpp"
#include "model.hpp"
using namespace std;
namespace py = pybind11;

GRBModel build_model(const ModelContext& ctx, ModelVars& vars, GRBEnv env, int model_level){
    if (model_level == 2)
        return build_shortest_model(ctx, vars, env);
    else if (model_level == 4)
        return build_y_model(ctx, vars, env);
    else //10
        return build_shortestz_model(ctx, vars, env);
}

GRBModel build_shortest_model(const ModelContext& ctx, ModelVars& vars, GRBEnv env) {
    GRBModel model = GRBModel(env);

    int P = ctx.prob_info.at("P");
    int N = ctx.prob_info.at("N");
    int F = ctx.prob_info.at("F");
    int LB = ctx.prob_info.at("LB");

    vector<int> cargonodes;
    for (int i = 1; i < N; ++i) cargonodes.push_back(i);

    for (int p2 = 1; p2 < P; ++p2) {
        for (int p1 = 0; p1 < p2; ++p1) {
            for (int i : cargonodes) { //GRB_BINARY
                vars.xpp[{p1, p2, i}] = model.addVar(0.0, 1.0, 0.0, GRB_BINARY, "xpp_" + to_string(p1) + "_" + to_string(p2) + "_" + to_string(i));
            }
        }
    }

    for (int p = 1; p < P-1; ++p) {
        for (int i : cargonodes) {
            vars.x[{p, i}] = model.addVar(0.0, 1.0, 0.0, GRB_BINARY, "x_" + to_string(p) + "_" + to_string(i));
        }
    }

    for (int i = 0; i < P - 2; ++i) {
        for (int k = i + 1; k < P - 1; ++k) {
            for (int j = k + 1; j < P; ++j) {
                vars.t[{i, k, j}] = model.addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "t_" + to_string(i) + "_" + to_string(j) + "_" + to_string(k));
            }
        }
    }

    //contraints 1
    for (int i : cargonodes) { //xpp
        for (int p = 1; p < P; ++p) {
            GRBLinExpr expr = 0;
            for (int p0 = 0; p0 < p; ++p0) {
                for (int p1 = p; p1 < P; ++p1) {
                    auto key = tuple(p0, p1, i);
                    if (vars.xpp.count(key)) expr += vars.xpp.at(key);
                }
            }
            model.addConstr(expr <= 1, "occupy0_" + to_string(i) + "_port" + to_string(p));
        }
    }

    //constraints 2
    for (int i : cargonodes) { //x rooted_tree
        for (int p = 1; p < P-1; ++p) {
            GRBLinExpr lhs1 = 0, lhs2 = 0;
            for (int pl = 0; pl < p; ++pl) {
                auto key = tuple(pl, p, i);
                if (vars.xpp.count(key)) lhs1 += vars.xpp.at(key);
            }
            for (int pr = p+1; pr < P; ++pr) {
                auto key = tuple(p, pr, i);
                if (vars.xpp.count(key)) lhs2 += vars.xpp.at(key);
            }
            model.addConstr(lhs1 <= vars.x[{p, i}], "occupy1_" + to_string(i) + "_port" + to_string(p));
            model.addConstr(lhs2 <= vars.x[{p, i}], "occupy2_" + to_string(i) + "_port" + to_string(p));
        }
    }

    //contraints 3
    for (int i : cargonodes) { //x-xpp
        for (int p = 1; p < P-1; ++p) {
            GRBLinExpr expr = vars.x[{p,i}];
            for (int p0 = 0; p0 < p; ++p0) {
                for (int p1 = p+1; p1 < P; ++p1) {
                    auto key = tuple(p0, p1, i);
                    if (vars.xpp.count(key)) expr += vars.xpp.at(key);
                }
            }
            model.addConstr(expr <= 1, "occupy3_" + to_string(i) + "_port" + to_string(p));
        }
    }

    //contraints 4
    for (int i : cargonodes) { //x-rooted_tree2
        auto it = ctx.approaching_map().find(i);
        if (it == ctx.approaching_map().end() || ctx.depth().at(i) <= 1) continue;
        for (int p = 1; p < P - 1; ++p) {
            GRBLinExpr rhs = 0;
            for (int j : it->second) {
                rhs += vars.x[{p, j}];
            }
            model.addConstr(vars.x[{p, i}] <= rhs, "path_sts_" + to_string(p) + "_" + to_string(i));
        }
    }

    //contraints 5
    for (int i = 0; i < P - 1; ++i) {
        for (int j = i + 1; j < P; ++j) {
            int dvol = 0;
            for (const auto& [od, r] : ctx.K) {
                if (od.first == i && od.second == j) {
                    dvol = r;
                    break;
                }
            }
            GRBLinExpr flow = 0;
            for (int n : cargonodes) {
                auto key = tuple(i, j, n);
                if (vars.xpp.count(key)) flow += vars.xpp.at(key);
            }
            GRBLinExpr inflow = 0, outflow = 0, inflater = 0;
            for (int k = 0; k < i; ++k) inflow += vars.t.at({k,i,j});
            for (int k = i + 1; k < j; ++k) inflater += vars.t.at({i,k,j});
            for (int k = j + 1; k < P; ++k) outflow += vars.t.at({i,j,k});

            model.addConstr(flow == dvol + inflow + outflow - inflater, "demand_" + to_string(i) + "_" + to_string(j));
        }
    }

    GRBLinExpr obj = 0;
    for (int p2 = 1; p2 < P; ++p2) {
        for (int p1 = 0; p1 < p2; ++p1) {
            for (int i : cargonodes) {
                auto key = tuple(p1, p2, i);
                if (vars.xpp.count(key)) obj += 2 * (F + ctx.depth().at(i)) * vars.xpp.at(key);
            }
        }
    }
    model.setObjective(obj - LB, GRB_MINIMIZE);
    model.update();
    vars.model = &model;
    return model;
}

GRBModel build_shortestz_model(const ModelContext& ctx, ModelVars& vars, GRBEnv env) {
    GRBModel model = GRBModel(env);

    int P = ctx.prob_info.at("P");
    int N = ctx.prob_info.at("N");
    int F = ctx.prob_info.at("F");
    int LB = ctx.prob_info.at("LB");

    vector<int> cargonodes;
    for (int i = 1; i < N; ++i) cargonodes.push_back(i);

    for (int p2 = 1; p2 < P; ++p2) {
        for (int p1 = 0; p1 < p2; ++p1) {
            for (int i : cargonodes) { //GRB_BINARY
                vars.xpp[{p1, p2, i}] = model.addVar(0.0, 1.0, 0.0, GRB_BINARY);//, "xpp_" + to_string(p1) + "_" + to_string(p2) + "_" + to_string(i));
            }
        }
    }

    for (int p = 1; p < P-1; ++p) {
        for (int i : cargonodes) {
            vars.x[{p, i}] = model.addVar(0.0, 1.0, 0.0, GRB_BINARY);//, "x_" + to_string(p) + "_" + to_string(i));
            vars.z[{p, i}] = model.addVar(0.0, 1.0, 0.0, GRB_CONTINUOUS);
        }
    }

    for (int i = 0; i < P - 2; ++i) {
        for (int k = i + 1; k < P - 1; ++k) {
            for (int j = k + 1; j < P; ++j) {
                vars.t[{i, k, j}] = model.addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS);//, "t_" + to_string(i) + "_" + to_string(j) + "_" + to_string(k));
            }
        }
    }

    //contraints 1
    for (int i : cargonodes) { //xpp
        for (int p = 1; p < P; ++p) {
            GRBLinExpr expr = 0;
            for (int p0 = 0; p0 < p; ++p0) {
                for (int p1 = p; p1 < P; ++p1) {
                    auto key = tuple(p0, p1, i);
                    if (vars.xpp.count(key)) expr += vars.xpp.at(key);
                }
            }
            model.addConstr(expr <= 1);//, "occupy0_" + to_string(i) + "_port" + to_string(p));
        }
    }

    //constraints 2
    for (int i : cargonodes) { //x rooted_tree
        for (int p = 1; p < P-1; ++p) {
            GRBLinExpr lhs1 = 0, lhs2 = 0;
            for (int pl = 0; pl < p; ++pl) {
                auto key = tuple(pl, p, i);
                if (vars.xpp.count(key)) lhs1 += vars.xpp.at(key);
            }
            for (int pr = p+1; pr < P; ++pr) {
                auto key = tuple(p, pr, i);
                if (vars.xpp.count(key)) lhs2 += vars.xpp.at(key);
            }
            model.addConstr(lhs1 <= vars.x[{p, i}]);//, "occupy1_" + to_string(i) + "_port" + to_string(p));
            model.addConstr(lhs2 <= vars.x[{p, i}]);//, "occupy2_" + to_string(i) + "_port" + to_string(p));
        }
    }

    //contraints 3
    for (int i : cargonodes) { //x-xpp
        for (int p = 1; p < P-1; ++p) {
            GRBLinExpr expr = vars.x[{p,i}];
            for (int p0 = 0; p0 < p; ++p0) {
                for (int p1 = p+1; p1 < P; ++p1) {
                    auto key = tuple(p0, p1, i);
                    if (vars.xpp.count(key)) expr += vars.xpp.at(key);
                }
            }
            model.addConstr(expr <= 1 + vars.z[{p, i}]);//, "occupy2_" + to_string(i) + "_port" + to_string(p));
        }
    }

    //contraints 4
    for (int i : cargonodes) { //x-rooted_tree2
        auto it = ctx.approaching_map().find(i);
        if (it == ctx.approaching_map().end() || ctx.depth().at(i) <= 1) continue;
        for (int p = 1; p < P - 1; ++p) {
            GRBLinExpr rhs = 0;
            for (int j : it->second) {
                rhs += vars.x[{p, j}];
            }
            model.addConstr(vars.x[{p, i}] <= rhs);//, "path_sts_" + to_string(p) + "_" + to_string(i));
        }
    }

    //contraints 5
    for (int i = 0; i < P - 1; ++i) {
        for (int j = i + 1; j < P; ++j) {
            int dvol = 0;
            for (const auto& [od, r] : ctx.K) {
                if (od.first == i && od.second == j) {
                    dvol = r;
                    break;
                }
            }
            GRBLinExpr flow = 0;
            for (int n : cargonodes) {
                auto key = tuple(i, j, n);
                if (vars.xpp.count(key)) flow += vars.xpp.at(key);
            }
            GRBLinExpr inflow = 0, outflow = 0, inflater = 0;
            for (int k = 0; k < i; ++k) inflow += vars.t.at({k,i,j});
            for (int k = i + 1; k < j; ++k) inflater += vars.t.at({i,k,j});
            for (int k = j + 1; k < P; ++k) outflow += vars.t.at({i,j,k});

            model.addConstr(flow == dvol + inflow + outflow - inflater);//,
                            //"demand_" + to_string(i) + "_" + to_string(j));
        }
    }

    GRBLinExpr obj = 0;
    for (int p2 = 1; p2 < P; ++p2) {
        for (int p1 = 0; p1 < p2; ++p1) {
            for (int i : cargonodes) {
                auto key = tuple(p1, p2, i);
                if (vars.xpp.count(key)) obj += 2 * (F + ctx.depth().at(i)) * vars.xpp.at(key);
            }
        }
    }
    for (int p = 1; p < P-1; ++p) {
        for (int i : cargonodes) {
            auto key = tuple(p, i);
            if (vars.z.count(key)) obj += 2 * (F + ctx.depth().at(i)) * vars.z.at(key);
        }
    }
    model.setObjective(obj - LB, GRB_MINIMIZE);
    model.update();
    vars.model = &model;
    return model;
}

GRBModel build_y_model(const ModelContext& ctx, ModelVars& vars, GRBEnv env) {
    int N = ctx.prob_info.at("N");
    int P = ctx.prob_info.at("P");
    int F = ctx.prob_info.at("F");
    int LB = ctx.prob_info.at("LB");
    const auto& arcs = ctx.arcs;

    vector<int> nodes(N);
    iota(nodes.begin(), nodes.end(), 0);
    vector<int> cargonodes(nodes.begin() + 1, nodes.end());
    GRBModel model = GRBModel(env);

    for (int p = 0; p < P - 1; ++p) {
        for (int p1 = p + 1; p1 < P; ++p1) {
            for (int i : cargonodes) {
                vars.xpp[{p, p1, i}] = model.addVar(0.0, 1.0, 0.0, GRB_BINARY, "xpp_" + std::to_string(p) + "_" + std::to_string(p1) + "_" + std::to_string(i));
            }
        }
    }

    for (int p = 1; p < P-1; ++p) {
        for (int i : cargonodes) {
            vars.x[{p, i}] = model.addVar(0.0, 1.0, 0.0, GRB_BINARY, "x_" + to_string(p) + "_" + to_string(i));
            vars.z[{p, i}] = model.addVar(0.0, 1.0, 0.0, GRB_CONTINUOUS);
            // if (ctx.depth().at(i) <= 1) continue;
            vars.d[{p, i}] = model.addVar(0.0, N-1, 0.0, GRB_CONTINUOUS, "d_" + to_string(p) + "_" + to_string(i));
            // vars.dL[{p, i}] = model.addVar(0.0, N-1, 0.0, GRB_CONTINUOUS, "dL_" + to_string(p) + "_" + to_string(i)); //approx
            // vars.dU[{p, i}] = model.addVar(0.0, N-1, 0.0, GRB_CONTINUOUS, "dU_" + to_string(p) + "_" + to_string(i)); //approx
        }
    }

    std::set<std::tuple<int, int, int>> y_keys;
    for (int p = 1; p < P - 1; ++p) {
        for (int i : cargonodes) {
            auto it = ctx.depth().find(i);
            if (it == ctx.depth().end() || it->second <= 1) continue;
            if (ctx.receding_map().count(i)) {
                for (int j : ctx.receding_map().at(i)) {
                    vars.y[{p, i, j}] = model.addVar(0.0, 1.0, 0.0, GRB_BINARY,
                                                    "y_" + std::to_string(p) + "_" + std::to_string(i) + "_" + std::to_string(j));
                    y_keys.insert({p, i, j});
                }
            }
            if (ctx.same_level_map().count(i)) {
                for (int j : ctx.same_level_map().at(i)) {
                    vars.y[{p, i, j}] = model.addVar(0.0, 1.0, 0.0, GRB_BINARY,
                                                    "y_" + std::to_string(p) + "_" + std::to_string(i) + "_" + std::to_string(j));
                    y_keys.insert({p, i, j});
                }
            }
        }
    }

    for (int i = 0; i < P - 2; ++i) {
        for (int k = i + 1; k < P - 1; ++k) {
            for (int j = k + 1; j < P; ++j) {
                vars.t[{i, k, j}] = model.addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "t_" + std::to_string(i) + "_" + std::to_string(k) + "_" + std::to_string(j));
            }
        }
    }

    for (int p = 1; p < P-1; ++p) {
        for (int i : cargonodes) {
            if (ctx.depth().at(i)==1){
                model.addConstr(vars.d[{p, i}] == GRBLinExpr(0));
            }
        }
    }

    for (int i = 0; i < P - 1; ++i) {
        for (int j = i + 1; j < P; ++j) {
            int dvol = 0;
            for (const auto& [od, r] : ctx.K) {
                if (od.first == i && od.second == j) {
                    dvol = r;
                    break;
                }
            }
            GRBLinExpr flow = 0;
            for (int n : cargonodes) {
                auto key = tuple(i, j, n);
                if (vars.xpp.count(key)) flow += vars.xpp.at(key);
            }
            GRBLinExpr inflow = 0, outflow = 0, inflater = 0;
            for (int k = 0; k < i; ++k) inflow += vars.t.at({k,i,j});
            for (int k = i + 1; k < j; ++k) inflater += vars.t.at({i,k,j});
            for (int k = j + 1; k < P; ++k) outflow += vars.t.at({i,j,k});

            model.addConstr(flow == dvol + inflow + outflow - inflater);//,
                            //"demand_" + to_string(i) + "_" + to_string(j));
        }
    }

    for (int i : cargonodes) { //xpp
        for (int p = 1; p < P; ++p) {
            GRBLinExpr expr = 0;
            for (int p0 = 0; p0 < p; ++p0) {
                for (int p1 = p; p1 < P; ++p1) {
                    auto key = tuple(p0, p1, i);
                    if (vars.xpp.count(key)) expr += vars.xpp.at(key);
                }
            }
            model.addConstr(expr <= 1);//, "occupy0_" + to_string(i) + "_port" + to_string(p));
        }
    }

    //constraints 2
    for (int i : cargonodes) { //x rooted_tree
        for (int p = 1; p < P-1; ++p) {
            GRBLinExpr lhs1 = 0, lhs2 = 0;
            for (int pl = 0; pl < p; ++pl) {
                auto key = tuple(pl, p, i);
                if (vars.xpp.count(key)) lhs1 += vars.xpp.at(key);
            }
            for (int pr = p+1; pr < P; ++pr) {
                auto key = tuple(p, pr, i);
                if (vars.xpp.count(key)) lhs2 += vars.xpp.at(key);
            }
            model.addConstr(lhs1 <= vars.x[{p, i}]);//, "occupy1_" + to_string(i) + "_port" + to_string(p));
            model.addConstr(lhs2 <= vars.x[{p, i}]);//, "occupy2_" + to_string(i) + "_port" + to_string(p));
        }
    }

    //contraints 3
    for (int i : cargonodes) { //x-xpp
        for (int p = 1; p < P-1; ++p) {
            GRBLinExpr expr = vars.x[{p,i}];
            for (int p0 = 0; p0 < p; ++p0) {
                for (int p1 = p+1; p1 < P; ++p1) {
                    auto key = tuple(p0, p1, i);
                    if (vars.xpp.count(key)) expr += vars.xpp.at(key);
                }
            }
            model.addConstr(expr <= 1 + vars.z[{p, i}]);//, "occupy2_" + to_string(i) + "_port" + to_string(p));
        }
    }



    for (int p = 1; p < P-1; ++p) {
        for (auto [i,j] : arcs) {//yij <= xi, yij <= xj
            if(y_keys.count({p, i, j})) {
                model.addConstr(vars.y[{p, i, j}] <= vars.x[{p, i}], "iji_" + to_string(p) + "_"+ to_string(i) + "_" + to_string(j));
                model.addConstr(vars.y[{p, i, j}] <= vars.x[{p, j}], "ijj_" + to_string(p) + "_"+ to_string(i) + "_" + to_string(j));
            }
        }
        for(int i : cargonodes){//sum yi* <= 1
            if (ctx.depth().at(i) <= 1) continue;
            GRBLinExpr lhs = 0;
            for(auto [i1, j] : arcs){
                if(i1==i && y_keys.count({p, i, j})){
                    lhs += vars.y[{p, i, j}];
                }
            }
            model.addConstr(lhs <= 1, "ijs_" + to_string(p) + "_" + to_string(i));
        }
    }

    for (int i : cargonodes) { //x-rooted_tree2 x i <= sum y i*
        auto it = ctx.approaching_map().find(i);
        if (it == ctx.approaching_map().end() || ctx.depth().at(i) <= 1) {
            continue;
        }
        for (int p = 1; p < P - 1; ++p) {
            GRBLinExpr lhs, rhs = 0;
            lhs += vars.x[{p, i}];
            for (int j : ctx.approaching_map().at(i)) {
                rhs += vars.x[{p, j}];
                for(int k: ctx.receding_map().at(j)){
                    if(y_keys.count({p, j, k})) lhs += vars.y[{p, j, k}];
                }
            }
            if(ctx.receding_map().count(i)){
                for (int j : ctx.receding_map().at(i)) {
                    rhs += vars.y[{p, i, j}];
                }
            }
            if(ctx.same_level_map().count(i)){
                for (int j : ctx.same_level_map().at(i)) {
                    rhs += vars.y[{p, i, j}];
                }
            }
            model.addConstr(lhs <= rhs, "rooted_" + to_string(p) + "_" + to_string(i));
        }
    }

    for (int p = 1; p < P-1; ++p) {
        for (int i : cargonodes) { //d-shortest
            int depth_i = ctx.depth().at(i);
            if (depth_i <= 1) continue;
            if(ctx.receding_map().count(i)){
                for(int j : ctx.receding_map().at(i)){
                    model.addConstr(vars.d[{p, i}] + 2 <= vars.d[{p, j}] + (N + 1 - depth_i) * (1-vars.y[{p, i, j}]), "dd2_" + to_string(i) + "_" + to_string(j) + "_p" + to_string(p));
                }
            }
            if(ctx.same_level_map().count(i)){
                for(int j : ctx.same_level_map().at(i)){
                    model.addConstr(vars.d[{p, i}] + 1<= vars.d[{p, j}] + (N - depth_i) * (1-vars.y[{p, i, j}]), "dd1_" + to_string(i) + "_" + to_string(j) + "_p" + to_string(p));
                }
            }
            if(ctx.approaching_map().count(i)){
                for(int j : ctx.approaching_map().at(i)){ //root 제외
                    if(y_keys.count({p, i, j})){
                        model.addConstr(vars.d[{p, i}] - (N - 1 - depth_i) * (vars.y[{p, i, j}]) <= vars.d[{p, j}], "dd0_" + to_string(i) + "_" + to_string(j) + "_p" + to_string(p));
                    }
                }
            }
            // GRBLinExpr xL = 0; //d-dL, d-dU
            // GRBLinExpr xU = 0;
            // for (int p2 = p + 1; p2 < P; ++p2) xL += vars.xpp.at({p, p2, i});
            // for (int p1 = 0; p1 < p; ++p1) xU += vars.xpp.at({p1, p, i});
            // model.addConstr(vars.d[{p, i}] <= vars.dL[{p, i}] + (N - 1 - depth_i) * (1-xL), "ddL_" + to_string(i) + "_port" + to_string(p));
            // model.addConstr(vars.d[{p, i}] <= vars.dU[{p, i}] + (N - 1 - depth_i) * (1-xU), "ddU_" + to_string(i) + "_port" + to_string(p));
        }
    }

    // obj
    GRBLinExpr obj = 0;
    for (int p2 = 1; p2 < P; ++p2) {
        for (int p1 = 0; p1 < p2; ++p1) {
            for (int i : cargonodes) {
                auto key = tuple(p1, p2, i);
                if (vars.xpp.count(key)) obj += 2 * (F + ctx.depth().at(i)) * vars.xpp.at(key);
            }
        }
    }
    for (int p = 1; p < P-1; ++p) {
        for (int i : cargonodes) {
            auto key = tuple(p, i);
            if (vars.z.count(key)) obj += 2 * (F + ctx.depth().at(i)) * vars.z.at(key);
        }
    }
    for (int p = 1; p < P-1; ++p) {
        for (int i : cargonodes) {
            if(ctx.depth().at(i) <= 1) continue;
            obj += 2*vars.d[{p, i}];//vars.dL[{p, i}] + vars.dU[{p, i}];
        }
    }
    model.setObjective(obj - LB, GRB_MINIMIZE);
    model.update();
    vars.model = &model;
    return model;
}

map<int, map<int, int>> getParentNodeMap(const ModelContext& ctx, ModelVars vars, int model_level) {
    map<int, map<int, int>> ret;
    if(model_level==4){
        std::unordered_map<int, std::unordered_set<int>>      y_nodes_used_as_i;
        // 1) y>0 간선 반영 (+ y 사용 노드 기록)
        for (const auto& [ykey, yval] : vars.y) {
            auto [p, i, j] = ykey;
            if (yval.get(GRB_DoubleAttr_X) > 1e-1) {
                ret[p].insert({i, j});
                y_nodes_used_as_i[p].insert(i);
            }
        }
        // 2) p별 활성 노드 수집
        std::map<int, std::vector<int>> retx_vec;
        for (const auto& [xkey, xval] : vars.x) {
            auto [p, i] = xkey;
            if (xval.get(GRB_DoubleAttr_X) > 1e-1) {
                retx_vec[p].push_back(i);
            }
        }

        const auto& amap = ctx.approaching_map();
        for (auto& [p, nodes] : retx_vec) {
            // retx_vec[p]에 속하는 노드만 허용
            std::unordered_set<int> nodeset(nodes.begin(), nodes.end());

            // y가 이미 사용한 노드 집합 (없으면 자동으로 빈 집합)
            const auto& yseti = y_nodes_used_as_i[p];

            for (int i : nodes) {
                // i가 y에 쓰인 노드면 스킵
                if (yseti.count(i)) continue;

                // rmap[i] 후보들 중에서 첫 j 고르기
                auto it = amap.find(i);
                if (it == amap.end()) continue;

                for (int j : it->second) {
                    // retx_vec[p]에 속하는 j만 허용
                    if (!nodeset.count(j)) continue;

                    // j도 y_nodes_used[p]에 속하면 제외
                    if (yseti.count(j)) continue;

                    // 조건 만족하는 "첫" j 채택
                    ret[p].insert({i, j});
                    break; // i에 대해 하나만 추가
                }
            }
        }
    }
    else if(model_level<=2 || model_level >= 10){
        const auto& rmap = ctx.receding_map();
        for (const auto& [xkey, xval] : vars.x) {
            auto [p, i] = xkey;
            if (xval.get(GRB_DoubleAttr_X) > 1e-5) {
                auto it = rmap.find(i);
                if (it != rmap.end()) {  // 키가 존재할 때만 접근
                    for (int j : it->second) {
                        ret[p].insert({j, i});
                    }
                }
            }
        }
    }
    return ret;
}

struct PairHash {
    size_t operator()(const pair<int,int>& p) const noexcept {
        return (static_cast<size_t>(p.first) << 32) ^ static_cast<size_t>(p.second);
    }
};

struct Step {
    vector<int> path;   // route nodes
    int idx;            // demand index
    enum Type { Load, Unload, Reloc } type;
    int pf, pb;         // path.front(), path.back()
};

using PortPlan = vector<Step>;

static vector<vector<int>> build_adj_from_edges(const vector<pair<int,int>>& edges, int N) {
    vector<vector<int>> adj(N);
    for (auto [u,v] : edges) {
        if (u>=0 && u<N && v>=0 && v<N && u!=v) {
            adj[u].push_back(v);
            adj[v].push_back(u);
        }
    }
    return adj;
}

// BFS shortest path from s to t, only traversing allowed nodes (except s,t are allowed even if not in allowed set if caller wants).
// forbid node 0 in relocation (both as intermediate and target).
static vector<int> bfs_path_relocation(const vector<vector<int>>& adj,
                                       int s, int t,
                                       const unordered_set<int>& allowed_nodes) {
    if (s == t) return {s};
    const int N = (int)adj.size();
    vector<int> prev(N, -1);
    queue<int> q;
    auto can_use = [&](int x)->bool {
        if (x == 0) return false;        // do not traverse 0 in relocation
        if (x == s || x == t) return true;
        return allowed_nodes.count(x) > 0;
    };
    if (!can_use(s) || !can_use(t)) {
        // s는 점유 노드일 수 있으니 통과, 위에서 true 처리. 여기선 t만 체크.
        if (t != s && !can_use(t)) return {};
    }
    q.push(s);
    prev[s] = s;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v : adj[u]) {
            if (prev[v] != -1) continue;
            if (!can_use(v)) continue;
            prev[v] = u;
            if (v == t) {
                // reconstruct
                vector<int> path;
                for (int x=t; x!=s; x=prev[x]) path.push_back(x);
                path.push_back(s);
                reverse(path.begin(), path.end());
                return path;
            }
            q.push(v);
        }
    }
    return {};
}

// count edges in path
static inline int path_length(const vector<int>& path) {
    if (path.size() < 2) return 0;
    return (int)path.size() - 1;
}

// simulate occupancy up to (but not including) step 'upto'.
// occ[node] = idx, or -1 if empty (node 0 is always empty & not stored).
static unordered_map<int,int> simulate_occ_until(const unordered_map<int,int>& initial_occ,
                                                 const PortPlan& plan,
                                                 int upto) {
    unordered_map<int,int> occ = initial_occ; // copy
    for (int i=0; i<upto; ++i) {
        const auto& st = plan[i];
        if (st.type == Step::Unload) {
            int node = st.pf; // from node to 0
            auto it = occ.find(node);
            // assume feasible current plan
            if (it != occ.end() && it->second == st.idx) {
                occ.erase(it);
            }
        } else if (st.type == Step::Load) {
            int node = st.pb; // 0 to node
            // assume empty
            occ[node] = st.idx;
        } else { // Reloc
            int s = st.pf, t = st.pb;
            auto it = occ.find(s);
            if (it != occ.end() && it->second == st.idx) {
                occ.erase(it);
                occ[t] = st.idx;
            }
        }
    }
    return occ;
}

// collect union of nodes used by remaining unload paths after position 'pos' (inclusive)
// If we relocate a car to a node in this set, later unloads would be blocked. So avoid targets in this set.
static unordered_set<int> union_future_unload_path_nodes(const PortPlan& plan, int pos) {
    unordered_set<int> U;
    for (int i=pos; i<(int)plan.size(); ++i) {
        if (plan[i].type == Step::Unload) {
            for (int v : plan[i].path) U.insert(v);
        }
    }
    return U;
}

inline bool path_contains(const vector<int>& path, int v) {
    return find(path.begin(), path.end(), v) != path.end();
}

bool try_idx_swap_with_reorder(int p,
                               int fixed_cost,
                               const vector<vector<int>>& adj,
                               const unordered_map<int, pair<int, int>> & original_k_to_od,
                               PortPlan& plan,
                               const unordered_map<int,int>& initial_occ,
                               int idx) {
    // 1) u, r 찾기
    int u = -1, r = -1;
    for (int i=0;i<(int)plan.size();++i){
        if (plan[i].idx != idx) continue;
        if (plan[i].type == Step::Unload) {
            int D = original_k_to_od.at(idx).second;
            if (D != p) u = i; // last temp unload: 계속 갱신
        }
    }
    if (u==-1) return false;
    for (int i=0;i<(int)plan.size();++i){
        if (plan[i].idx != idx) continue;
        if (plan[i].type == Step::Load) {
            int O = original_k_to_od.at(idx).first;
            if (O != p && i > u) { r = i; break; }
        }
    }
    if (r==-1) return false;

    // 2) s, pb
    int s  = plan[u].pf; // unload path: s -> ... -> 0
    int pb = plan[r].pb; // reload path: 0 -> ... -> pb

    // 3) u..r-1 사이에서 pb를 지나는 Load 들(A)의 마지막 tA, s를 지나는 경로(B)의 존재 여부
    int tA = -1;
    bool s_used_in_between = false;
    for (int i=u+1;i<r;++i){
        if (path_contains(plan[i].path, s)) s_used_in_between = true;
        if (plan[i].type == Step::Load && path_contains(plan[i].path, pb)) tA = i;
    }

    // 4) 리로케이션 시점 t* 결정
    int tstar = (tA==-1 ? u : (tA+1));

    // 5) 충돌 케이스: A≠∅ && B≠∅ → 단일 치환 불가 (2-리로케이션 fallback 후보)
    if (tA!=-1 && s_used_in_between) {
        return false; // 필요시 여기서 2-reloc 시도 로직 분기 가능
    }

    // 6) t* 직전 점유/빈노드로 경로 검증 및 비용 이득 확인
    auto occ_before_t = simulate_occ_until(initial_occ, plan, tstar);
    // s가 idx로 점유돼 있어야 함
    auto it = occ_before_t.find(s);
    if (it==occ_before_t.end() || it->second!=idx) return false;

    int N = (int)adj.size();
    vector<char> occFlag(N,0);
    for (auto& kv: occ_before_t) if (kv.first>=0 && kv.first<N) occFlag[kv.first]=1;
    unordered_set<int> allowed; allowed.reserve(N);
    for (int v=1; v<N; ++v) if (!occFlag[v]) allowed.insert(v); // 0 제외

    // pb가 t* 이후의 언로드 경로를 막지 않게 가드
    auto future_unload_nodes = union_future_unload_path_nodes(plan, tstar);
    if (future_unload_nodes.count(pb)) return false;

    // s->pb 경로 (빈노드만)
    auto reloc_path = bfs_path_relocation(adj, s, pb, allowed);
    if (reloc_path.empty()) return false;

    // 비용 이득: 원래 u의 s->0 거리, r의 0->pb 거리 vs s->pb
    // int dist_s0  = path_length(plan[u].path);
    // int dist_0pb = path_length(plan[r].path);
    // int dist_spb = path_length(reloc_path);
    // int delta    = fixed_cost + dist_s0 + dist_0pb - dist_spb;
    // if (delta <= 0) return false;

    // 7) 플랜 수정: u의 임시하역 제거, r의 재적재 제거, t* 위치에 리로케이션 삽입
    // 인덱스 보정 주의: u < r, 그리고 삽입 지점이 u,r 상대 위치에 따라 바뀜
    // 먼저 r 제거 → 그 다음 u 제거 → 그 다음 삽입 순으로 가면 인덱스 계산이 단순
    plan.erase(plan.begin()+r);           // r 제거
    plan.erase(plan.begin()+u);           // u 제거
    // u와 r가 빠지면서 tstar가 이동:
    // - 만약 tstar > r  : tstar' = tstar - 2
    // - elif r < tstar <= ? 등 케이스를 나눠 안전 처리
    int tprime = tstar;
    if (tprime > r) tprime -= 1;
    if (tprime > u) tprime -= 1;

    Step reloc;
    reloc.idx  = idx;
    reloc.type = Step::Reloc;
    reloc.path = reloc_path;
    reloc.pf   = s;
    reloc.pb   = pb;

    plan.insert(plan.begin()+tprime, reloc); 
    return true;
}

// Try all idx in the port plan until no improvement
void relocate_temp_unloads_to_first_reload_node(int p,
                                                int fixed_cost,
                                                const vector<pair<int,int>>& edges,
                                                const unordered_map<int, pair<int, int>> & original_k_to_od,
                                                PortPlan& plan,
                                                const unordered_map<int,int>& initial_occ) {
    int maxNode = 0;
    for (auto& e : edges) maxNode = max(maxNode, max(e.first, e.second));
    vector<vector<int>> adj = build_adj_from_edges(edges, maxNode+1);

    unordered_set<int> candidate_idx;
    for (auto& st : plan) {
        if (st.type == Step::Unload) {
            int D = original_k_to_od.at(st.idx).second;
            if (D != p) candidate_idx.insert(st.idx);
        } else if (st.type == Step::Load) {
            int O = original_k_to_od.at(st.idx).first;
            if (O != p) candidate_idx.insert(st.idx);
        }
    }

    // ✅ 포트당 딱 1건만 시도: 첫 성공 시 즉시 return
    for (int idx : candidate_idx) {
        if (try_idx_swap_with_reorder(p, fixed_cost, adj, original_k_to_od, plan, initial_occ, idx)) {
            return;
        }
    }
}

template <typename T>
using SolutionPaths = vector<pair<vector<int>, T>>;

template <typename T> unordered_map<int,SolutionPaths<T>>
reorder_solution_paths(const unordered_map<int,SolutionPaths<T>>& raw) {
    unordered_map<int,SolutionPaths<T>> result;

    for (const auto& [p, paths] : raw) {
        SolutionPaths<T> unloading, loading;

        for (const auto& [path, idx] : paths) {
            if (path.front() == 0 && path.back() != 0)
                loading.emplace_back(path, idx);
            else if (path.back() == 0 && path.front() != 0)
                unloading.emplace_back(path, idx);
        }

        sort(unloading.begin(), unloading.end(),
                  [](const auto& a, const auto& b) { return a.first.size() < b.first.size(); });

        sort(loading.begin(), loading.end(),
                  [](const auto& a, const auto& b) { return a.first.size() > b.first.size(); });

        SolutionPaths<T> merged;
        merged.insert(merged.end(), unloading.begin(), unloading.end());
        merged.insert(merged.end(), loading.begin(), loading.end());

        result[p] = move(merged);
    }
    return result;
}

FullSolution extract_solution(const ModelContext& ctx, const ModelVars& vars, int model_level){
    int P = ctx.prob_info.at("P");
    int F = ctx.prob_info.at("F");
    // read K - od_to_k set
    unordered_map<pair<int, int>, deque<int>, pair_hash> od_to_k;
    unordered_map<pair<int, int>, int, pair_hash> original_od_to_k;
    unordered_map<int, pair<int, int>> original_k_to_od;
    for (size_t idx = 0; idx < ctx.K.size(); ++idx) {
        auto [od, r] = ctx.K[idx];
        for (int i = 0; i < r; ++i) od_to_k[od].push_back(idx);
        original_od_to_k[od] = idx;
        original_k_to_od[idx] = od;
    }

    // xpp_unassigned: od → [n 리스트]
    map<tuple<int, int, int>, int> xpp_assignment;     // 쪼갠 xpp도 여기에 반영
    map<pair<int, int>, deque<int>> xpp_assignment2;
    map<pair<int, int>, int> xpp_count;                // (p1,p2) 구간별 개수

    // >>> 추가: 이후 체크용으로, "활성화된(쪼갠) xpp 키" 집합
    // tuple<int,int,int> = (p1, p2, i)
    std::set<std::tuple<int,int,int>> active_xpp;

    if(model_level <= 10){
        // rehandling from t
        double total_t = 0;
        vector<tuple<int, int, int>> t_keys;
        for (const auto& [key, var] : vars.t)
            if (var.get(GRB_DoubleAttr_X) > 1e-5)
                t_keys.push_back(key);
        std::sort(t_keys.begin(), t_keys.end(), [](const auto& a, const auto& b) {
            auto [i1, k1, j1] = a;
            auto [i2, k2, j2] = b;
            if (i1 != i2) return i1 < i2;          // i 오름차순
            if (j1 != j2) return j1 > j2;          // k 내림차순
            return k1 > k2;                        // j 내림차순
        });
        for (const auto& [i, k, j] : t_keys) {
            double tikj = vars.t.at({i, k, j}).get(GRB_DoubleAttr_X);
            total_t += tikj;
            auto& list_ij = od_to_k[{i, j}];
            int need = static_cast<int>(std::round(tikj));
            if ((int)list_ij.size() < need) {
                // 로깅/예외 처리
                // py::print("list_ij, need:", (int)list_ij.size(), need);
                need = list_ij.size(); // 또는 그냥 가능한 만큼만
            }
            for (int l = 0; l < need; ++l) {
                int demand_idx = list_ij.back();
                list_ij.pop_back();
                od_to_k[{i, k}].push_front(demand_idx);
                od_to_k[{k, j}].push_front(demand_idx);
            }
        }
    }

    for (const auto& [key, var] : vars.xpp) {
        auto [p0, p1, n] = key;
        double xv = var.get(GRB_DoubleAttr_X);
        if (xv <= 1e-5) continue;

        if (model_level >= 10 || model_level == 4) {
            // p0<p<p1 에서 x[p,n]==1 지점 모두 수집
            std::vector<int> cuts;
            for (int p = p0 + 1; p < p1; ++p) {
                auto itx = vars.x.find({p, n});
                if (itx != vars.x.end() && itx->second.get(GRB_DoubleAttr_X) > 0.5)
                    cuts.push_back(p);
            }

            if (!cuts.empty()) {
                std::sort(cuts.begin(), cuts.end());

                // 1) 분할 구간 목록: [p0,q1], [q1,q2], ..., [qk,p1]
                std::vector<std::pair<int,int>> segs;
                int left = p0;
                for (int q : cuts) { segs.emplace_back(left, q); left = q; }
                segs.emplace_back(left, p1);

                // py::print(p0, p1, ":", segs);
                // 2) xpp 분할 반영 (count/assignment/활성체크)
                for (auto [a, b] : segs) {
                    xpp_count[{a, b}]++;
                    xpp_assignment[{a, b, n}] = 1;
                    active_xpp.insert(std::make_tuple(a, b, n));
                }

                // 3) od_to_k 재분배:
                //    {p0,p1}에서 "한 번만 pop" → 분할된 각 seg에 "1개씩만 push"
                auto& src = od_to_k[{p0, p1}];
                if (!src.empty()) {
                    int demand_idx = src.back();
                    src.pop_back();
                    for (auto [a, b] : segs) {
                        od_to_k[{a, b}].push_front(demand_idx);
                    }
                } else {
                    // 필요시 방어 로깅/보정
                    // py::print("warn: od_to_k[{", p0, ",", p1, "}] empty while splitting");
                }

                continue;  // 원본 (p0,p1,n)은 사용하지 않음
            }
        }

        // (model_level<10) 또는 겹침 없음 → 원본 구간 그대로 사용
        xpp_count[{p0, p1}]++;
        xpp_assignment[{p0, p1, n}] = 1;
        active_xpp.insert(std::make_tuple(p0, p1, n));
    }
    
    // py::print("xpp assignment");
    for (auto& [od, cnt] : xpp_count) {
        if(cnt==0) continue;
        auto& klist = od_to_k[od];
        auto& [i0, j0] = od;
        for (int a = 0; a < cnt; ++a) {
            int demand_idx = klist.back(); klist.pop_back();
            xpp_assignment2[std::make_pair(i0,j0)].push_back(demand_idx);
        }
        xpp_count[od] -= cnt;
    }

    unordered_map<int, vector<pair<vector<int>, pair<int,int>>>> temp_solution;
    for (int p = 0; p < P; ++p) temp_solution[p] = {};
    if(model_level==0){
        int N = ctx.prob_info.at("N");
        for (int p1 = 0; p1 < P; ++p1) {
            for (int p2 = p1 + 1; p2 < P; ++p2) {
                pair<int, int> pp = {p1,p2};
                for (int i = 1; i < N; ++i) {
                    if (active_xpp.count({p1,p2,i})) {
                        auto pathL = ctx.path_to_root().at(i);
                        auto pathU = pathL; reverse(pathU.begin(), pathU.end());

                        // int k = xpp_assignment.count({p1,p2,i}) ? xpp_assignment[{p1,p2,i}] : -1;;

                        temp_solution[p1].emplace_back(pathL, pp);
                        temp_solution[p2].emplace_back(pathU, pp);
                    }
                }
            }
        }
    }
    else{
        py::print("parentNode start");
        const auto& parentNodeMap = getParentNodeMap(ctx, vars, model_level);
        for (const auto& [p1, p2, i] : active_xpp) {
            // pair<int,int> pp = {p1,p2};
            vector<int> pathL = {0};
            if(p1==0){
                pathL = ctx.path_to_root().at(i);
            }
            else{
                auto it1 = parentNodeMap.find(p1);
                if (it1 == parentNodeMap.end()) continue;
                const std::map<int,int>& parentL = it1->second;
                vector<int> rev_pathL;
                int node = i;
                int steps = 0, MAX_STEPS = 2000;
                while (node != 0) {
                    rev_pathL.push_back(node);
                    if (++steps > MAX_STEPS) { // 사이클/과도 깊이
                        break;
                    }
                    auto pit = parentL.find(node);
                    if (pit == parentL.end()) { // 부모 정보 없음
                        break;
                    }
                    node = parentL.at(node);
                }
                reverse(rev_pathL.begin(), rev_pathL.end());
                pathL.insert(pathL.end(), rev_pathL.begin(), rev_pathL.end());
            }
            vector<int> pathU;
            if(p2==P-1){
                pathU = ctx.path_to_root().at(i);
                reverse(pathU.begin(), pathU.end());
            }
            else{
                auto it2 = parentNodeMap.find(p2);
                if (it2 == parentNodeMap.end()) continue;
                const std::map<int,int>& parentU = it2->second;
                int node = i;
                int steps = 0, MAX_STEPS = 2000;
                while (node != 0) {
                    pathU.push_back(node);
                    if (++steps > MAX_STEPS) break;
                    auto pit = parentU.find(node);
                    if (pit == parentU.end()) break;
                    node = pit->second;
                }
                pathU.push_back(0);
            }
            temp_solution[p1].emplace_back(pathL, pair{p1,p2});
            temp_solution[p2].emplace_back(pathU, pair{p1,p2});
        }
    }
    temp_solution = reorder_solution_paths(temp_solution);

    unordered_map<int,int> occ;

    unordered_map<int, vector<pair<vector<int>, int>>> solution; //port-> <path,demand_idx>
    for (int p = 0; p < P; ++p) solution[p] = {};
    vector<pair<int,int>> edges(ctx.arcs.begin(), ctx.arcs.end());
    unordered_map<int, unordered_map<int, int>> port_node_idx_map;
    for (int p = 0; p < P; ++p) {
        PortPlan plan;
        unordered_map<int,int> node_idx_map = occ;
        for(auto& [path, pp] : temp_solution[p]){
            int pf = path.front();
            int pb = path.back();
            Step st;
            st.path = path;
            st.pf = pf;
            st.pb = pb;
            if (pf == 0) {              // Load: 0 -> pb
                int idx = xpp_assignment2[pp].front();
                xpp_assignment2[pp].pop_front();
                st.type = Step::Load;
                st.idx  = idx;
                plan.push_back(st);
                node_idx_map[pb] = idx; // 로컬 매핑 갱신 (시뮬 전용)
            } else if (pb == 0) {       // Unload: pf -> 0
                st.type = Step::Unload;
                if(!node_idx_map.count(pf)){
                    py::print("not count", path, pp, node_idx_map);
                }
                st.idx  = node_idx_map.at(pf); // 존재 가정(feasible)
                plan.push_back(st);
                node_idx_map.erase(pf);
            }
        }
        relocate_temp_unloads_to_first_reload_node(
            p, F, edges, original_k_to_od, plan, occ
        );
        for(auto& st : plan){
            solution[p].emplace_back(st.path, st.idx);
        }
        for (auto& st : plan) {
            if (st.type == Step::Unload) {
                // pf 에 st.idx가 있어야 함
                auto it = occ.find(st.pf);
                if (it != occ.end() && it->second == st.idx) occ.erase(it);
            } else if (st.type == Step::Load) {
                // pb 가 비어있어야 함
                occ[st.pb] = st.idx;
            } else { // Reloc
                auto it = occ.find(st.pf);
                if (it != occ.end() && it->second == st.idx) {
                    occ.erase(it);
                    occ[st.pb] = st.idx;
                }
            }
        }
    }

    FullSolution result;
    result.port_paths = solution;
    return result;
}

static inline double snap01(double v, double eps=1e-6) {
    if (v <= eps) return 0.0;
    if (v >= 1.0 - eps) return 1.0;
    return v; // fractional은 그대로 두면 Gurobi가 repair
}

void apply_warm_start_from_m1_to_m2(const ModelVars& from, ModelVars& to) {
    // xpp (binary)
    for (auto& [k_to, v_to] : to.xpp) {
        double val = 0.0;
        if (auto it = from.xpp.find(k_to); it != from.xpp.end())
            val = it->second.get(GRB_DoubleAttr_X);
        val = snap01(val);
        v_to.set(GRB_DoubleAttr_Start, val);
    }

    // x (binary)
    for (auto& [k_to, v_to] : to.x) {
        double val = 0.0;
        if (auto it = from.x.find(k_to); it != from.x.end())
            val = it->second.get(GRB_DoubleAttr_X);
        val = snap01(val);
        v_to.set(GRB_DoubleAttr_Start, val);
    }

    // z (continuous)
    for (auto& [k_to, v_to] : to.z) {
        double val = 0.0;
        if (auto it = from.z.find(k_to); it != from.z.end())
            val = it->second.get(GRB_DoubleAttr_X);
        v_to.set(GRB_DoubleAttr_Start, val);
    }

    // t (continuous)
    for (auto& [k_to, v_to] : to.t) {
        double val = 0.0;
        if (auto it = from.t.find(k_to); it != from.t.end())
            val = it->second.get(GRB_DoubleAttr_X);
        v_to.set(GRB_DoubleAttr_Start, val);
    }

    // m2에 새로 추가된 변수들: y, d → 0으로
    for (auto& [k_to, v_to] : to.y) {
        v_to.set(GRB_DoubleAttr_Start, 0.0);
    }
    for (auto& [k_to, v_to] : to.d) {
        v_to.set(GRB_DoubleAttr_Start, 0.0);
    }

    // 모델 포인터가 세팅돼 있으면 업데이트
    if (to.model) to.model->update();
}