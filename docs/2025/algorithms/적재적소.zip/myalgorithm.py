import time
import util
import networkx as nx
from itertools import islice
import numpy as np
import sys


def algorithm(prob_info, timelimit=60):
    import time
    start_time = time.time()

    # Input data parsing
    Num_N = prob_info['N']
    Edge = prob_info['E']
    LB = int(prob_info["LB"])
    Num_H = prob_info['P']
    Dem = prob_info['K']
    solution = {
        p: []
        for p in range(Num_H)
    }
    Fixed_Cost = prob_info['F']
    Cost = 0
    
    # Create adjacency matrix
    Conn = [[0 for _ in range(Num_N)] for _ in range(Num_N)]
    for e in Edge:
        Conn[e[0]][e[1]] = 1
        Conn[e[1]][e[0]] = 1
    
    # Create a list of connected nodes for each node to speed up searches
    Conn_Node = [[] for _ in range(Num_N)]
    for i in range(Num_N):
        for j in range(Num_N):
            if Conn[i][j] == 1:
                Conn_Node[i].append(j)
    Check = [0 for _ in range(Num_N)]


    
    # Identify and configure main path nodes
    # Main_Path[i]: Stores the order (depth) if node i is on the main path, otherwise 0
    Main_Path = [0 for _ in range(Num_N)]
    Check = [0 for _ in range(Num_N)]  # Track visit status: 0: unvisited, 1: adjacent, 2: confirmed main path
    Order = 1
    Main_Path[0] = Order # Node 0 (gate) is the first main path node
    Check[0] = 2
    for i in range(Num_N):
        if Conn[i][0] == 1:
            Check[i] = 1 # Mark nodes adjacent to the gate as 'adjacent'

    # Create Main_Path: Similar to BFS, prioritizing nodes with the most connections
    while(1):
        Order += 1
        Check_End = 1
        Near_Main = []
        for i in range(Num_N):
            if Check[i] == 0:
                Check_End = 0
        if Check_End:
            break
        for i in range(Num_N):
            if Check[i] == 1:
                Cnt = 0
                for j in range(Num_N):
                    if(Conn[i][j] == 1 and Check[j] == 0):
                        Cnt += 1
                Near_Main.append([i, Cnt])
        Near_Main = sorted(Near_Main, key = lambda x : -x[1])
        Check[Near_Main[0][0]] = 2
        Main_Path[Near_Main[0][0]] = Order
        for i in range(Num_N):
            if (Conn[i][Near_Main[0][0]] == 1 and Check[i] == 0):
                Check[i] = 1

    
    # Create a set of main path nodes
    Main_Path_Node = []
    Order = 2
    for i in range(Num_N):
        for j in range(Num_N):
            if(Main_Path[j] == Order):
                Order += 1
                Main_Path_Node.append(j)
    Cnt = 0
    for i in range(Num_N):
        if Main_Path[i] != 0:
            Cnt += 1
    
    # Create a set of edges consisting only of main path nodes
    Main_Edges = []
    for e in Edge:
        if e[0] == 0 and e[1] in Main_Path_Node:
            Main_Edges.append(e)
        if e[0] in Main_Path_Node and e[1] in Main_Path_Node:
            Main_Edges.append(e)

    Main_Road = [[] for _ in range(Num_N)]
    
            
    # Create the main path graph
    G2 = nx.Graph()
    G2.add_edges_from(Main_Edges)

    # Store the shortest path from each main path node to the gate node
    for node in Main_Path_Node:
        path = nx.shortest_path(G2, source=node, target=0)
        Main_Road[node] = list(reversed(path))  # 예: [4, 3, 2, 1, 0]

    # Sort main nodes by shortest path length
    Path_Sorted = sorted(Main_Path_Node, key=lambda x: len(Main_Road[x]))

    # Identify the closest main path node for each node
    # Near_Main[i]: Stores the closest main path node to node i (in the direction of node 0)
    Near_Main = [-1 for _ in range(Num_N)]
    for i in range(Num_N):
        if True: 
            for j in Conn_Node[i]:
                if(Main_Path[j] != 0 and len(Main_Road[j]) < len(Main_Road[i])):
                    Near_Main[i] = j
    for j in Conn_Node[0]: # Nodes directly connected to the gate have Near_Main as 0
        Near_Main[j] = 0
    for i in Path_Sorted:
        for j in Conn_Node[i]:
            if Near_Main[j] == -1:
                Near_Main[j] = i # Set Near_Main for non-main path nodes connected to main path nodes
    
    # Create a graph with all nodes and edges
    G = nx.Graph()

    G.add_nodes_from(range(Num_N))
    G.add_edges_from(Edge)
    
    # Compare initial Near_Main path with actual shortest path and update Near_Main to the shorter one
    for n in range(Num_N):
        Node = n
        path = [n]
        while Node != 0:
            Node = Near_Main[Node]
            path.append(Node)
        sp = list(nx.shortest_path(G, source=n, target=0))
        if len(sp) < len(path):
            Near_Main[n] = sp[1] # Update Near_Main to the next node on the shortest path

    # Reconstruct the main path nodes
    New_Main = []
    for n in range(1, Num_N):
        for c in Conn_Node[n]:
            if Near_Main[c] == n and n not in New_Main:
                New_Main.append(n)
                break
    Main_Path_Node = New_Main.copy()
    
    # Calculate the 'depth' of each node (following the Near_Main path)
    Path_depth = [0 for _ in range(Num_N)]
    for n in range(Num_N):
        Node = n
        path = [n]
        while Node != 0:
            Node = Near_Main[Node]
            path.append(Node)
        Path_depth[n] = len(path)
    
    # Sorting nodes: by depth and prioritizing main path nodes
    Path_Sorted = sorted(Main_Path_Node, key=lambda x: Path_depth[x])
    Node_Sorted = []
    for j in Conn_Node[0]:
        if j !=0 and j not in Main_Path_Node and j not in Node_Sorted:
            Node_Sorted.append(j)
    for i in Path_Sorted:
        Node_Sorted.append(i)
        for j in Conn_Node[i]:
            if j !=0 and Near_Main[j] == i and j not in Node_Sorted and j not in Path_Sorted:
                Node_Sorted.append(j)
    Node_Sorted_wz = [0] + Node_Sorted
    Main_First = []
    for i in Path_Sorted:
        Main_First.append(i)
    for i in Path_Sorted:
        for j in Conn_Node[i]:
            if j !=0 and j not in Main_First and j not in Main_Path_Node:
                Main_First.append(j)
    if len(Node_Sorted) == 0:
        for i in Conn_Node[0]:
            Node_Sorted.append(i)
    if len(Main_First) == 0:
        for i in Conn_Node[0]:
            Main_First.append(i)
    Cnt = 0
    for i in range(Num_N):
        if Main_Path[i] != 0:
            Cnt += 1
    
    # Create a set of sub-nodes for each node where it is the Near_Main
    Subset_Nodes = [[] for _ in range(Num_N)]
    
    for r in Conn_Node[0]:
        if Near_Main[r] == 0:
            Subset_Nodes[0].append(r)
    
    for n in Main_Path_Node:
        for r in Conn_Node[n]:
            if Near_Main[r] == n:
                Subset_Nodes[n].append(r)
    
    for n in [0] + Path_Sorted:
        temp = []
        for r in Subset_Nodes[n]:
            if r not in Main_Path_Node:
                temp.append(r)
                Subset_Nodes[n].remove(r)
        Subset_Nodes[n] = temp + Subset_Nodes[n]
    
    # Identify Junction nodes: child nodes that are also main path nodes
    Junction_Node = [[] for _ in range(Num_N)]
    for n in Main_Path_Node + [0]:
        for r in Subset_Nodes[n]:
            if r in Main_Path_Node:
                Junction_Node[n].append(r)

    # Subset_Depth: Stores the paths where each node is the 'deepest' node   
    Subset_Depth = [[] for _ in range(Num_N)]
    for n in Main_Path_Node:
        Node = n
        p_path = [Node]
        while(Node != 0):
            Node = Near_Main[Node]
            p_path.append(Node)
        for p in p_path:
            Subset_Depth[p].append(n)

    # Sorting Junction_Node: based on the length (depth) of sub-paths
    for n in Main_Path_Node + [0]:
        if len(Junction_Node[n]) >1:
            Junction_Node[n] = sorted(Junction_Node[n], key= lambda x: len(Subset_Depth[x]))
    
    # Vertex_Node: The deepest main path nodes without sub-paths (no junctions)
    Vertex_Node = []
    for n in Main_Path_Node + [0]:
        if len(Junction_Node[n]) > 1:
            for r in Junction_Node[n]:
                if all(len(Junction_Node[x]) <= 1 for x in Subset_Depth[r]):
                    Vertex_Node.append(r)
    Vertex_Node = sorted(Vertex_Node, key=lambda x: Path_depth[x])
    
    # Low_subsets: Junction nodes located deeper (more distant) in each Junction node's sub-path
    Low_subsets = [[] for _ in range(Num_N)]
    for n in Vertex_Node:
        Node = n
        last_jc = n
        while Node != 0:
            Node = Near_Main[Node]
            if len(Junction_Node[Node]) > 1 and last_jc not in Low_subsets[Node]:
                Low_subsets[Node].append(last_jc)
            if len(Junction_Node[Node]) > 1:
                last_jc = Node
    for n in [0] + Main_Path_Node:
        if len(Low_subsets[n]) >0:
            Low_subsets[n] = sorted(Low_subsets[n], key= lambda x: len(Subset_Depth[x]))

    # Subset_Head: The top-level node of each subset
    Subset_Head = [0]
    for n in [0]+Main_Path_Node:
        if len(Low_subsets[n]) >0:
            Subset_Head.append(n)
            for r in Low_subsets[n]:
                Subset_Head.append(r)
    
    # High_subsets: The higher-level (shallower) Subset_Head node for each node
    High_subsets = [0 for _ in range(Num_N)]
    for n in Main_Path_Node+[0]:
        if len(Low_subsets[n]) > 0:
            for r in Low_subsets[n]:
                High_subsets[r] = n 
    for n in Node_Sorted:
        Node = n
        while Node != 0:
            Node = Near_Main[Node]
            if Node in Subset_Head:
                High_subsets[n] = Node
                break
    
    # Reconstruct Subset_Depth
    for n in [0]+Main_Path_Node:
        for j in Subset_Depth[n]:
            for r in Subset_Nodes[j]:
                if r not in Main_Path_Node:
                    Subset_Depth[n].append(r)
        Subset_Depth[n] = sorted(Subset_Depth[n], key=lambda x: Node_Sorted_wz.index(x))
    
    # Create New_Subset_Depth and New_Node_Sorted
    # Change Subset_Depth sorting order: from node depth (original) to subset depth
    New_Subset_Depth = [[] for _ in range(Num_N)]
    for n in Node_Sorted_wz:
        New_Subset_Depth[n].append(n)
        for c in Conn_Node[n]:
            if Near_Main[c] == n and c not in Main_Path_Node and c != 0:
                New_Subset_Depth[n].append(c)
    for v in Vertex_Node:
        for n in Subset_Depth[v]:
            if n not in New_Subset_Depth[Near_Main[v]]:
                New_Subset_Depth[Near_Main[v]].append(n)
    for n in reversed(Node_Sorted_wz):
        if len(Junction_Node[n]) >=1:
            for j in Junction_Node[n]:
                if j not in New_Subset_Depth[n]:
                    for s in New_Subset_Depth[j]:
                        New_Subset_Depth[n].append(s)
    
    
    New_Node_Sorted_wz = New_Subset_Depth[0].copy()
    
    New_Subset_Depth = Subset_Depth.copy()
    for n in [0]+Main_Path_Node:
        New_Subset_Depth[n] = sorted(New_Subset_Depth[n], key=lambda x: New_Node_Sorted_wz.index(x))
    New_Node_Sorted = New_Node_Sorted_wz.copy()
    New_Node_Sorted.remove(0)
    
    
    # Store car information to be loaded and unloaded at each port
    # In_Boat_2[i] is a list of cars loaded at port i
    # Each element is [destination port, demand number]
    In_Boat_2 = [[] for _ in range(Num_H)]
    
    for pair in Dem:
        for i in range(pair[1]):
            In_Boat_2[pair[0][0]].append([pair[0][1], Cnt])
        Cnt += 1
    
    # Store destination information for demands originating from each port
    origin_dest = [[] for _ in range(Num_H)]
    for pair in Dem:
        origin_dest[pair[0][0]].append(pair[0][1])
    
    # Store the port where the first unloading occurs
    first_arrival = min(origin_dest[0])
    for p in range(Num_H-1):
        if len(origin_dest[p]) > 0:
            if min(origin_dest[p]) < first_arrival:
                first_arrival = min(origin_dest[p])

    # If the first arrival is before 1/3 of the total ports, set it to 1/3    
    if first_arrival < round((Num_H-1)/3):
        first_arrival = round((Num_H-1)/3)

    # Store destination information for demands loaded before 'first_arrival'
    Only_on = []
    for p in range(first_arrival):
        if len(origin_dest[p]) > 0:
            for r in origin_dest[p]:
                if r not in Only_on:
                    Only_on.append(r)
    
    Only_on = sorted(Only_on)
    
    
    Colist = [0 for _ in range(Num_H)] # List to store costs for each combination
    Frequency = [0 for _ in range(Num_N)] # Number of times each node is traversed

    # Simulation: Loop to set the initial cri (shipping threshold)
    # cri: Loading criteria for demand. If (destination port) - (current port) > cri,
    # cars are loaded from the back. If smaller, they are loaded from the front.
    # Calculate costs by varying the cri value for each port from 0 to Num_H-1
    for cri in range(Num_H):
        # Store car information to be loaded and unloaded at each port
        # In_Boat_2[i] is a list of cars loaded at port i
        # Each element is [destination port, demand number]
        In_Boat_2 = [[] for _ in range(Num_H)]
        In_Boat_3 = [[] for _ in range(Num_H)]
        
        Cnt = 0
        for pair in Dem:
            for i in range(pair[1]):
                In_Boat_2[pair[0][0]].append([pair[0][1], Cnt])
            Cnt += 1

        # Now_onset: Which subset node a car with a specific destination port is currently loaded on
        Now_onset = [-1 for _ in range(Num_H)]
        # End_Boat_2: The destination port of the car loaded on each node
        End_Boat_2 = [-1 for _ in range(Num_N)]
        # Num_Boat_2: The demand number of the car loaded on each node
        Num_Boat_2 = [-1 for _ in range(Num_N)]
        # Unload_Boat, Unload_Boat_2: Unloading target cars/nodes
        Unload_Boat = [-1 for _ in range(Num_N)]
        Unload_Boat_2 = [-1 for _ in range(Num_N)]
        
        for i in range(Num_H):
            List_Out = []
            reh = 0 # Rehandling count
            
            Out_queue = []
            # Unloading algorithm

            # Find 'Head' nodes for unloading
            # A node is a Head if the node directly in front of it is not an unloading target
            Unload_Head = []
            for n in Node_Sorted:
                if End_Boat_2[n] == i:
                    if End_Boat_2[Near_Main[n]] != i:
                        Unload_Head.append(n)
            Unload_Head = sorted(Unload_Head, key = lambda x : Node_Sorted.index(x))
            if True:
                for j in Path_Sorted:
                    # Cars that have reached their destination port are unloaded immediately
                    if Unload_Boat_2[j] == 3:
                        Node = j
                        Colist[cri] += Fixed_Cost
                        while(Node != 0):
                            Check = 0
                            Colist[cri] += 1
                            Node = Near_Main[Node]
                            Frequency[Node] += 1
                        In_Boat_2[i].append([End_Boat_2[j], Num_Boat_2[j]])
                        End_Boat_2[j] = -1
                        Num_Boat_2[j] = -1
                        Unload_Boat[j] = -1
                        Unload_Boat_2[j] = -1

            # Unloading/Rehandling logic
            for u in Unload_Head:
                Node = u
                # Store the unloading path of the Head
                unload_path = []
                while(Node != 0):
                    Node = Near_Main[Node]
                    unload_path.append(Node)
                unload_path.remove(0)
                # If there's a car blocking the unloading path, temporarily unload or rehandle it
                for j in reversed(unload_path):
                    # If there's a car at node 'j' and its destination (`End_Boat_2[j]`) is at or after the current port (`i`),
                    # it's considered a car blocking the path.
                    if End_Boat_2[j] >= i and End_Boat_2[j] != -1:
                        Node = j
                        Check = 0
                        # Add fixed cost for rehandling.
                        Colist[cri] += Fixed_Cost
                        while(Node != 0):
                            # Add variable cost for car movement.        
                            Colist[cri] += 1
                           # Search for a re-staging spot in the sub-nodes of `Near_Main[Node]`
                            for k in Subset_Nodes[Near_Main[Node]]:
                                # Re-staging condition 1: k is not a main path node, is empty, and is not the gate node.
                                if(k not in Main_Path_Node and End_Boat_2[k] == -1 and k != 0) :
                                    # Add re-staging movement cost.
                                    Colist[cri] += 1
                                    Check = 1
                                    # Transfer the car's destination and demand number to the new node `k`.
                                    End_Boat_2[k] = End_Boat_2[j]
                                    Num_Boat_2[k] = Num_Boat_2[j]
                                    break
                                # Re-staging condition 2: k is a main path node and empty.
                                if k in Main_Path_Node and k != 0  and End_Boat_2[k] == -1 and k != Node:
                                    onset_c = 0
                                    # Check if a car with an earlier destination set `k` as its onset point.
                                    for p in range(i+1, Num_H):
                                        if Now_onset[p] == k and p < End_Boat_2[j]:
                                            onset_c = 1
                                            break
                                    for p in Subset_Depth[k]:
                                        if p != k and End_Boat_2[p] != -1 and End_Boat_2[p]< End_Boat_2[j]:
                                            onset_c = 1
                                            break
                                    # If `onset_c` is 1, find a re-staging spot in the sub-nodes of `k` that are not on the main path.
                                    if onset_c == 1:
                                        for r in reversed(Subset_Depth[k]):
                                            if r not in Main_Path_Node and End_Boat_2[r] == -1 and r!= 0:
                                                Check = 1 
                                                End_Boat_2[r] = End_Boat_2[j]
                                                Num_Boat_2[r] = Num_Boat_2[j]
                                                Node_s = r
                                                
                                                while Node_s != Near_Main[Node]:
                                                    Colist[cri] += 1
                                                    Node_s = Near_Main[Node_s]
                                                    Frequency[Node_s] += 1
                                                break
                                    # If `onset_c` is 0, find a re-staging spot in the sub-nodes of `k`.
                                    if onset_c ==0:
                                        for r in reversed(Subset_Depth[k]):
                                            if End_Boat_2[r] == -1 and r!= 0:
                                                Check = 1
                                                End_Boat_2[r] = End_Boat_2[j]
                                                Num_Boat_2[r] = Num_Boat_2[j]
                                                Node_s = r
                                                
                                                while Node_s != Near_Main[Node]:
                                                    Colist[cri] += 1
                                                    Node_s = Near_Main[Node_s]
                                                    Frequency[Node_s] += 1
                                                break
                                    if(Check == 1):
                                        break
                            if(Check == 1):
                                break
                            # Update node and visit frequency.
                            Node = Near_Main[Node]
                            Frequency[Node] += 1
                         # If no re-staging spot is found, temporarily unload.
                        if Check == 0:
                            In_Boat_2[i].append([End_Boat_2[j], Num_Boat_2[j]]) # Include in In_Boat_2 for reloading
                            reh += 1
                        # Reset the car info on the original node.
                        End_Boat_2[j] = -1
                        Num_Boat_2[j] = -1
                        Unload_Boat[j] = -1
                # Unload Unload_Head that are not on the main path
                if u not in Main_Path_Node and End_Boat_2[u] == i :
                    j = u
                    Node = j
                    Colist[cri] += Fixed_Cost
                    while(Node != 0):
                        Check = 0
                        Colist[cri] += 1
                        Node = Near_Main[Node]
                        Frequency[Node] += 1

                    End_Boat_2[j] = -1
                    Num_Boat_2[j] = -1
                    Unload_Boat[j] = -1
                # Unload from main path nodes.
                if u in Main_Path_Node:
                    for j in Subset_Depth[u]:
                        # Unload only if the target node is a main path node and its parent node is empty  
                        if End_Boat_2[j] == i and j!= 0 and Num_Boat_2[j] > -1 and End_Boat_2[Near_Main[j]] == -1 :
                            Node = j
                            Colist[cri] += Fixed_Cost
                            while(Node != 0):
                                Check = 0
                                Colist[cri] += 1
                                Node = Near_Main[Node]
                                Frequency[Node] += 1
                            End_Boat_2[j] = -1
                            Num_Boat_2[j] = -1
                            Unload_Boat[j] = -1
            

                        
            # Sort the In_Boat_2 list, including rehandled cars, by destination port
            In_Boat_2[i] = sorted(In_Boat_2[i], key = lambda x : x[0])
            Cnt = 0

            # Count the number of cars destined for the next port (`i+1`)
            for j in In_Boat_2[i]:
                if(j[0] == i+1):
                    Cnt += 1
            # Initialize the `Unload_Boat` array
            Unload_Boat = [-1 for _ in range(Num_N)]
            
                
            # Store demands where (destination port) - (current port) is greater than cri in In_Boat_3
            In_Boat_3 = [[] for _ in range(Num_H)]
            for pair in In_Boat_2[i]:
                if pair[0] - i >= cri and pair[0] != i+1:
                    In_Boat_3[i].append(pair)
            In_Boat_3[i] = sorted(In_Boat_3[i], key = lambda x : x[0])
            
            # Reset Now_Onset if temporary unloading occurred
            if reh >0:
                Now_onset = [-1 for _ in range(Num_H)]
                
                for h in range(Num_H):
                    for n in reversed(Node_Sorted):
                        if End_Boat_2[n] == h and End_Boat_2[Near_Main[n]] == -1:
                            Now_onset[h] = High_subsets[n]
                            break
            
            Now_onset[i] = -1
            
            # Car loading logic
            if True:
                Loaded = [-1 for _ in range(len(In_Boat_2[i]))]
                # Load cars from the back first, for which the destination is not the next port
                for k in reversed(range(len(In_Boat_2[i]) - len(In_Boat_3[i]), len(In_Boat_2[i]))):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1:
                        # Check if a subset node for a car with the same destination is already stored in `Now_Onset`
                        if Now_onset[In_Boat_2[i][k][0]] != -1 :   
                            tempset = Now_onset[In_Boat_2[i][k][0]]
                            # Search for an empty space in the sub-nodes of `tempset` in reverse
                            for r in reversed(Subset_Depth[tempset]):
                                if End_Boat_2[r] == -1 and r !=0:
                                    # If the loading target node is the same as `tempset` and `tempset` is not 0.
                                    if r == tempset and tempset != 0:
                                        # If the parent node of `r` is not the High_subset of `tempset` -> assign Now_onset as the front node of r
                                        if Near_Main[r] != High_subsets[tempset]:
                                            Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                        else:
                                            # Search for a sub-subset within the High_subset of `tempset
                                            for h in Low_subsets[High_subsets[tempset]]:
                                                # If the sub-subset `h` is not `r` and is empty -> assign Now_onset as h
                                                if h != r and End_Boat_2[h] == -1:
                                                    Now_onset[In_Boat_2[i][k][0]] = h
                                                    break
                                            # If all sub-subsets are full, assign `Now_Onset` to the parent node of `tempset` 
                                            if Now_onset[In_Boat_2[i][k][0]] == tempset:
                                                Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                    else:
                                        Now_onset[In_Boat_2[i][k][0]] = tempset
                                    # Load the car onto node `r` and calculate the cost
                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                    Node = r
                                    Colist[cri] += Fixed_Cost
                                    while(Node != 0):
                                        Check = 0
                                        Colist[cri] += 1
                                        Node = Near_Main[Node]
                                        Frequency[Node] += 1
                                    Loaded[k] = 0
                                    break
                        # If there's no car with the same destination in `Now_Onset`
                        if Now_onset[In_Boat_2[i][k][0]] == -1 :
                            # Search from the deepest subset (`Vertex_Node`)
                            for v in reversed(Vertex_Node):
                                # If all sub-nodes of `v` are empty, load from the innermost
                                if all(End_Boat_2[x] == -1 for x in Subset_Depth[v]):
                                    Now_onset[In_Boat_2[i][k][0]] = v
                                    r = Subset_Depth[v][-1]
                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                    Node = r
                                    Colist[cri] += Fixed_Cost
                                    while(Node != 0):
                                        Check = 0
                                        Colist[cri] += 1
                                        Node = Near_Main[Node]
                                        Frequency[Node] += 1
                                    Loaded[k] = 0
                                    break
                                # If sub-nodes of `v` are not all empty, and `v` itself is empty
                                if not all(End_Boat_2[x] == -1 for x in Subset_Depth[v]) and End_Boat_2[v] == -1:
                                    temp_end = Num_H - 1
                                    if True:
                                        for r in reversed(Subset_Depth[v]):
                                            # Search for a re-staging spot in the sub-nodes of `v`
                                            if End_Boat_2[r] == -1:
                                                if r == v:
                                                   if Near_Main[r] != High_subsets[v]:
                                                       Now_onset[In_Boat_2[i][k][0]] = Near_Main[v]
                                                   else:
                                                       for h in Low_subsets[High_subsets[v]]:
                                                           if h != r and End_Boat_2[h] == -1:
                                                               Now_onset[In_Boat_2[i][k][0]] = h
                                                               break
                                                       if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                           Now_onset[In_Boat_2[i][k][0]] = High_subsets[v]
                                    
                                                else:
                                                    Now_onset[In_Boat_2[i][k][0]] = v
                                                Now_onset[temp_end] = -1
                                                End_Boat_2[r] = In_Boat_2[i][k][0]
                                                Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                Node = r
                                                Colist[cri] += Fixed_Cost
                                                while(Node != 0):
                                                    Check = 0
                                                    Colist[cri] += 1
                                                    Node = Near_Main[Node]
                                                    Frequency[Node] += 1
                                                Loaded[k] = 0
                                                break
                                    if Loaded[k] == 0:
                                        break
                            # If unable to load in a Vertex node
                            if Loaded[k] == -1:
                                # Load into a space occupied by a car with a later destination
                                for s in range(In_Boat_2[i][k][0], Num_H):
                                    if Now_onset[s] != -1:
                                        passes = 0
                                        temp_end = s
                                        tempset = Now_onset[s]
                                        # Load if the occupying car has a later destination and there are no demands for the same destination from later ports.
                                        for d in range(In_Boat_2[i][k][1], len(Dem)):
                                            if Dem[d][0][1] == temp_end:
                                                passes = 1
                                                break
                                        if passes == 0:
                                            if End_Boat_2[tempset] == -1:
                                                for r in reversed(Subset_Depth[tempset]):
                                                    if End_Boat_2[r] == -1 and r!=0:
                                                        if r == tempset and tempset != 0:
                                                            if Near_Main[r] != High_subsets[tempset]:
                                                                Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                                            else:
                                                                for h in Low_subsets[High_subsets[tempset]]:
                                                                    if h != r and End_Boat_2[h] == -1:
                                                                        Now_onset[In_Boat_2[i][k][0]] = h
                                                                        break
                                                                if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                                    Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                                        else:
                                                            Now_onset[In_Boat_2[i][k][0]] = tempset
                                                        Now_onset[s] = -1
                                                        End_Boat_2[r] = In_Boat_2[i][k][0]
                                                        Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                        Node = r
                                                        Colist[cri] += Fixed_Cost
                                                        while(Node != 0):
                                                            Check = 0
                                                            Colist[cri] += 1
                                                            Node = Near_Main[Node]
                                                            Frequency[Node] += 1
                                                        Loaded[k] = 0
                                                        break
                                        if Loaded[k] == 0:
                                            break
                            # If still unable to load
                            if Loaded[k] == -1:
                                # Load if the occupying car has a later destination 
                                for s in range(In_Boat_2[i][k][0], Num_H):
                                    if Now_onset[s] != -1:
                                        temp_end = s
                                        tempset = Now_onset[s]
                                        if End_Boat_2[tempset] == -1:
                                            for r in reversed(Subset_Depth[tempset]):
                                                if End_Boat_2[r] == -1 and r !=0:
                                                    if r == tempset and tempset != 0:
                                                        if Near_Main[r] != High_subsets[tempset]:
                                                            Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                                        else:
                                                            for h in Low_subsets[High_subsets[tempset]]:
                                                                if h != r and End_Boat_2[h] == -1:
                                                                    Now_onset[In_Boat_2[i][k][0]] = h
                                                                    break
                                                            if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                                Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                                    else:
                                                        Now_onset[In_Boat_2[i][k][0]] = tempset
                                                    Now_onset[s] = -1
                                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                    Node = r
                                                    Colist[cri] += Fixed_Cost
                                                    while(Node != 0):
                                                        Check = 0
                                                        Colist[cri] += 1
                                                        Node = Near_Main[Node]
                                                        Frequency[Node] += 1
                                                    Loaded[k] = 0
                                                    break
                                        if Loaded[k] == 0:
                                            break
                                # If still unable to load, temporarily load at the back
                                if Now_onset[In_Boat_2[i][k][0]] == -1:
                                    for s in reversed(range(0, In_Boat_2[i][k][0])):
                                        if Now_onset[s] != -1:
                                            temp_end = s
                                            tempset = Now_onset[s]
                                            if End_Boat_2[tempset] == -1:
                                                for r in reversed(Subset_Depth[tempset]):
                                                    if End_Boat_2[r] == -1 and r !=0:
                                                        if r == tempset and tempset != 0:
                                                            if Near_Main[r] != High_subsets[tempset]:
                                                                Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                                            else:
                                                                for h in Low_subsets[High_subsets[tempset]]:
                                                                    if h != r and End_Boat_2[h] == -1:
                                                                        Now_onset[In_Boat_2[i][k][0]] = h
                                                                        break
                                                                if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                                    Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                                                
                                                        else:
                                                            Now_onset[In_Boat_2[i][k][0]] = tempset
                                                        Now_onset[s] = -1
                                                        End_Boat_2[r] = In_Boat_2[i][k][0]
                                                        Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                        Node = r
                                                        Colist[cri] += Fixed_Cost
                                                        while(Node != 0):
                                                            Check = 0
                                                            Colist[cri] += 1
                                                            Node = Near_Main[Node]
                                                            Frequency[Node] += 1
                                                        Loaded[k] = 0
                                                        break
                                            if Loaded[k] == 0:
                                                break
                
                
                        
                
                Node_queue_2 = []
                Node_queue_3 = []
                # Load cars destined for the next port from the front.
                if Cnt > 0:
                    for k in range(Cnt):
                        if Loaded[k] == 0:
                            continue
                        if Loaded[k] == -1:
                            for r in Node_Sorted:
                                if End_Boat_2[r] == -1:
                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                    Node = r
                                    Colist[cri] += Fixed_Cost
                                    while(Node != 0):
                                        Check = 0
                                        Colist[cri] += 1
                                        Node = Near_Main[Node]
                                        Frequency[Node] += 1
                                    Loaded[k] = 0
                                    Unload_Boat[r] = 0
                                    break

                # Load cars from the front, into a group of cars with the same destination, if possible.
                for k in reversed(range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i]))):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1: 
                        if Now_onset[In_Boat_2[i][k][0]] != -1 :   
                            tempset = Now_onset[In_Boat_2[i][k][0]]
                            for r in reversed(Subset_Depth[tempset]):
                                if End_Boat_2[r] == -1 and r!= 0:
                                    if r == tempset and tempset != 0:
                                        if Near_Main[r] != High_subsets[tempset]:
                                            Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                        else:
                                            for h in Low_subsets[High_subsets[tempset]]:
                                                if h != r and End_Boat_2[h] == -1:
                                                    Now_onset[In_Boat_2[i][k][0]] = h
                                                    break
                                            if Now_onset[In_Boat_2[i][k][0]] == tempset:
                                                Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                    else:
                                        Now_onset[In_Boat_2[i][k][0]] = tempset
                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                    Node = r
                                    Colist[cri] += Fixed_Cost
                                    while(Node != 0):
                                        Check = 0
                                        Colist[cri] += 1
                                        Node = Near_Main[Node]
                                        Frequency[Node] += 1
                                    Loaded[k] = 0
                                    break
                                    
                # Count the number of cars that still need to be loaded from the front.        
                needs = 0
                for k in range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i]) ):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1: 
                        needs += 1
                
                # `Front_in`: List of nodes for cars to be loaded from the front.
                Front_in = []
                Front_vertex = []
                Node = 0
                toend = 0
                # Pre-allocate nodes for remaining cars that couldn't be loaded next to similar destinations.
                while len(Front_in) < needs:
                    # If all search paths are exhausted and not enough nodes are found,
                    # assign cars sequentially to empty nodes from the front.
                    if toend == 1 and len(Front_in) < needs:
                        for r in Node_Sorted:
                            if End_Boat_2[r] == -1 and r not in Front_in:
                                # `End_Boat_2[r] = -Num_H` is a marker for temporary loading.
                                End_Boat_2[r] = -Num_H
                                Front_in.append(r)
                                Unload_Boat[r] = 0
                                Unload_Boat_2[r] = 3 # Must be unloaded on the next port if loaded on this node
                                if len(Front_in) == needs:
                                    break
                        if len(Front_in) == needs:
                            break
                        break
                    for r in Subset_Nodes[Node]:
                        # Find and assign non-main path empty nodes.
                        if r not in Main_Path_Node and End_Boat_2[r] == -1 and r != 0:
                            End_Boat_2[r] = -Num_H
                            Front_in.append(r)
                            if len(Front_in) == needs:
                                break
                        # Find and assign empty main path nodes that meet conditions.
                        if r in Main_Path_Node and End_Boat_2[r] == -1 and r != 0:
                            okc = 0
                            for r2 in Conn_Node[r]:
                                kk = len(In_Boat_2[i]) - len(In_Boat_3[i])
                                # Check if a neighbor node `r2` has a car with an earlier destination. -> If not, assign.
                                if End_Boat_2[r2] < In_Boat_2[i][kk-1][0] and End_Boat_2[r2] != -2   and Near_Main[r2] == r:
                                    okc = 1
                                    break
                            if okc == 0:
                                End_Boat_2[r] = -Num_H
                                Front_in.append(r)
                            if len(Front_in) == needs:
                                break
                    if len(Front_in) == needs:
                        break
                    # If `Node` is on a single path.
                    if len(Junction_Node[Node]) <= 1:
                        Node = Junction_Node[Node][0]
                        empty_cnt = 0
                        for s in Subset_Depth[Node]:
                            if End_Boat_2[s] == -1 and s !=0 :
                                empty_cnt += 1
                        # If the number of empty nodes is less than or equal to the needed cars, assign to all nodes in the sub-set
                        if empty_cnt <= needs - len(Front_in):
                            for r in reversed(Subset_Depth[Node]):
                                if r!= 0 and End_Boat_2[r] == -1:
                                    End_Boat_2[r] = -Num_H
                                    Front_in.append(r)
                                if len(Front_in) == needs:
                                    break
                        if len(Front_in) == needs:
                            break
                    # If `Node` is a junction
                    elif len(Junction_Node[Node]) >1 :
                        for n in Junction_Node[Node]:
                            # If the junction is full, skip
                            if all(End_Boat_2[x] != -1 for x in Subset_Depth[n]):
                                if  n == Junction_Node[Node][-1]:
                                    toend = 1
                                    break
                            else:
                                empty_cnt = 0
                                for s in Subset_Depth[n]:
                                    if End_Boat_2[s] == -1 and s !=0 :
                                        empty_cnt += 1
                                # If the junction is empty and has enough space, move to that junction
                                if empty_cnt > needs - len(Front_in) and n not in Vertex_Node:
                                    Node = n
                                    break
                                # If the junction is empty, has enough space, but is a Vertex, load from the inside
                                elif empty_cnt > needs - len(Front_in) and n in Vertex_Node:
                                    Front_vertex.append(n)
                                    for r in reversed(Subset_Depth[n]):
                                        if r!= 0 and End_Boat_2[r] == -1:
                                            End_Boat_2[r] = -Num_H
                                            Front_in.append(r)
                                        if len(Front_in) == needs:
                                            break
                                # If the junction is empty and has just enough or not enough space, load all cars into its sub-nodes.
                                elif empty_cnt <= needs - len(Front_in):
                                    Front_vertex.append(n)
                                    if empty_cnt < needs - len(Front_in) and n == Junction_Node[Node][-1]:
                                        toend = 1
                                    for r in reversed(Subset_Depth[n]):
                                        if r!= 0 and End_Boat_2[r] == -1:
                                            End_Boat_2[r] = -Num_H
                                            Front_in.append(r)
                                        if len(Front_in) == needs:
                                            break
                            if len(Front_in) == needs:
                                break
                                    
                # Sort the `Front_in` list by the index in `Node_Sorted`
                Front_in = sorted(Front_in, key= lambda x: Node_Sorted.index(x))
                # Classify cars with small demand (1 or 2) separately to load them first
                Small_amount = []
                for k in range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i])):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1: 
                        if Dem[In_Boat_2[i][k][1]][1] <= 2:
                            Small_amount.append([In_Boat_2[i][k][0], In_Boat_2[i][k][1]])
                            Loaded[k] = 0
                Small_amount = sorted(Small_amount, key = lambda x : x[0])
                # Load small demand cars into `Front_in` nodes
                for k in Small_amount:
                    for r in Front_in:
                        if -End_Boat_2[r] >= k[0] :
                            End_Boat_2[r] = k[0]
                            Num_Boat_2[r] = k[1]
                            Node = r
                            Colist[cri] += Fixed_Cost
                            while(Node != 0):
                                Check = 0
                                Colist[cri] += 1
                                Node = Near_Main[Node]
                                Frequency[Node] += 1
                            break

                # Load the rest of the cars from the front into the nodes reserved in `Front_in`
                for k in reversed(range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i]))):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1: 
                        for r in reversed(Front_in):
                            if -End_Boat_2[r] >= In_Boat_2[i][k][0] :
                                End_Boat_2[r] = In_Boat_2[i][k][0]
                                Num_Boat_2[r] = In_Boat_2[i][k][1]
                                Node = r
                                Colist[cri] += Fixed_Cost
                                while(Node != 0):
                                    Check = 0
                                    Colist[cri] += 1
                                    Node = Near_Main[Node]
                                    Frequency[Node] += 1
                                Loaded[k] = 0
                                break
                # Load any remaining cars after all previous logic
                for k in range(len(In_Boat_2[i])):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1:
                        for r in Node_Sorted:
                            if End_Boat_2[r] == -1:
                                End_Boat_2[r] = In_Boat_2[i][k][0]
                                Num_Boat_2[r] = In_Boat_2[i][k][1]
                                Node = r
                                Colist[cri] += Fixed_Cost
                                while(Node != 0):
                                    Check = 0
                                    Colist[cri] += 1
                                    Node = Near_Main[Node]
                                    Frequency[Node] += 1
                                Loaded[k] = 0
                                Unload_Boat[r] = 0
                                Unload_Boat_2[r] = 3  # Include in the unloading target for the next port
                                break               

                for k in reversed(Node_Sorted):
                    if End_Boat_2[k] == i+1:
                        Unload_Boat[k] = 0
                    if Unload_Boat[k] == 0:
                        Node = k
                        p_path = [Node]
                        while(Node != 0):
                            Node = Near_Main[Node]
                            p_path.append(Node)
                        for pp in p_path:
                            if End_Boat_2[pp] != -1 and pp != 0:
                                Unload_Boat[pp] = 0
                            
        print(f"{cri} : Cost - {Colist[cri] - LB}")
    # Assign the cri value that minimizes the total cost.
    cri = Colist.index(min(Colist))
    
    # Update Near_Main based on node frequency from simulation
    for n in Node_Sorted:
        for c in Conn_Node[n]:
            if Frequency[Near_Main[n]] < Frequency[c] and Path_depth[Near_Main[n]] >= Path_depth[c]:
                Near_Main[n] = c
    
    # Re-sort node sets and main paths based on the updated Near_Main
    Node_Sorted = []
    for j in Conn_Node[0]:
        if j !=0 and j not in Main_Path_Node and j not in Node_Sorted:
            Node_Sorted.append(j)
    for i in Path_Sorted:
        Node_Sorted.append(i)
        for j in Conn_Node[i]:
            if j !=0 and Near_Main[j] == i and j not in Node_Sorted and j not in Path_Sorted:
                Node_Sorted.append(j)
    Node_Sorted_wz = [0] + Node_Sorted
    Main_First = []
    for i in Path_Sorted:
        Main_First.append(i)
    for i in Path_Sorted:
        for j in Conn_Node[i]:
            if j !=0 and j not in Main_First and j not in Main_Path_Node:
                Main_First.append(j)
    if len(Node_Sorted) == 0:
        for i in Conn_Node[0]:
            Node_Sorted.append(i)
    if len(Main_First) == 0:
        for i in Conn_Node[0]:
            Main_First.append(i)
    Cnt = 0
    for i in range(Num_N):
        if Main_Path[i] != 0:
            Cnt += 1
    Subset_Nodes = [[] for _ in range(Num_N)]
    
    for r in Conn_Node[0]:
        if Near_Main[r] == 0:
            Subset_Nodes[0].append(r)
    
    for n in Main_Path_Node:
        for r in Conn_Node[n]:
            if Near_Main[r] == n:
                Subset_Nodes[n].append(r)
    
    for n in [0] + Path_Sorted:
        temp = []
        for r in Subset_Nodes[n]:
            if r not in Main_Path_Node:
                temp.append(r)
                Subset_Nodes[n].remove(r)
        Subset_Nodes[n] = temp + Subset_Nodes[n]
    
    Junction_Node = [[] for _ in range(Num_N)]
    for n in Main_Path_Node + [0]:
        for r in Subset_Nodes[n]:
            if r in Main_Path_Node:
                Junction_Node[n].append(r)
    
            
                
    Subset_Depth = [[] for _ in range(Num_N)]

    for n in Main_Path_Node:
        Node = n
        p_path = [Node]
        while(Node != 0):
            Node = Near_Main[Node]
            p_path.append(Node)
        for p in p_path:
            Subset_Depth[p].append(n)

    for n in Main_Path_Node + [0]:
        if len(Junction_Node[n]) >1:
            Junction_Node[n] = sorted(Junction_Node[n], key= lambda x: len(Subset_Depth[x]))
            
    Vertex_Node = []
    for n in Main_Path_Node + [0]:
        if len(Junction_Node[n]) > 1:
            for r in Junction_Node[n]:
                if all(len(Junction_Node[x]) <= 1 for x in Subset_Depth[r]):
                    Vertex_Node.append(r)
    Vertex_Node = sorted(Vertex_Node, key=lambda x: Path_depth[x])
        
    Low_subsets = [[] for _ in range(Num_N)]
    for n in Vertex_Node:
        Node = n
        last_jc = n
        while Node != 0:
            Node = Near_Main[Node]
            if len(Junction_Node[Node]) > 1 and last_jc not in Low_subsets[Node]:
                Low_subsets[Node].append(last_jc)
            if len(Junction_Node[Node]) > 1:
                last_jc = Node


    
    for n in [0] + Main_Path_Node:
        if len(Low_subsets[n]) >0:
            Low_subsets[n] = sorted(Low_subsets[n], key= lambda x: len(Subset_Depth[x]))
    
    Subset_Head = [0]
    for n in [0]+Main_Path_Node:
        if len(Low_subsets[n]) >0:
            Subset_Head.append(n)
            for r in Low_subsets[n]:
                Subset_Head.append(r)
    
    
    High_subsets = [0 for _ in range(Num_N)]
    for n in Main_Path_Node+[0]:
        if len(Low_subsets[n]) > 0:
            for r in Low_subsets[n]:
                High_subsets[r] = n 

    
    for n in Node_Sorted:
        Node = n
        while Node != 0:
            Node = Near_Main[Node]
            if Node in Subset_Head:
                High_subsets[n] = Node
                break
    
    
    for n in [0]+Main_Path_Node:
        for j in Subset_Depth[n]:
            for r in Subset_Nodes[j]:
                if r not in Main_Path_Node:
                    Subset_Depth[n].append(r)
        Subset_Depth[n] = sorted(Subset_Depth[n], key=lambda x: Node_Sorted_wz.index(x))
    
    
    New_Subset_Depth = [[] for _ in range(Num_N)]
    for n in Node_Sorted_wz:
        New_Subset_Depth[n].append(n)
        for c in Conn_Node[n]:
            if Near_Main[c] == n and c not in Main_Path_Node and c != 0:
                New_Subset_Depth[n].append(c)
    for v in Vertex_Node:
        for n in Subset_Depth[v]:
            if n not in New_Subset_Depth[Near_Main[v]]:
                New_Subset_Depth[Near_Main[v]].append(n)
    for n in reversed(Node_Sorted_wz):
        if len(Junction_Node[n]) >=1:
            for j in Junction_Node[n]:
                if j not in New_Subset_Depth[n]:
                    for s in New_Subset_Depth[j]:
                        New_Subset_Depth[n].append(s)
    
    
    New_Node_Sorted_wz = New_Subset_Depth[0].copy()
    
    New_Subset_Depth = Subset_Depth.copy()
    for n in [0]+Main_Path_Node:
        New_Subset_Depth[n] = sorted(New_Subset_Depth[n], key=lambda x: New_Node_Sorted_wz.index(x))
    New_Node_Sorted = New_Node_Sorted_wz.copy()
    New_Node_Sorted.remove(0)
    
    # Simulated Annealing execution function.
    # cri_values: A list of rehandling thresholds for each port.
    # onset_values: A pre-assigned list of loading sets for demand loaded before 'first_arrival'.
    # Node_Sorted: The newly sorted list of nodes.
    # Subset_Depth: The newly sorted list of sub-node sets.
    def Cri_Simul(cri_values, onset_values, Node_Sorted, Subset_Depth):
        Colist = 0
        In_Boat_2 = [[] for _ in range(Num_H)]
        In_Boat_3 = [[] for _ in range(Num_H)]
        
        Cnt = 0
        for pair in Dem:
            for i in range(pair[1]):
                In_Boat_2[pair[0][0]].append([pair[0][1], Cnt])
            Cnt += 1
        
        Now_onset = [-1 for _ in range(Num_H)]
        # Assign pre-designated loading sets to Now_onset
        for o in range(len(Only_on)):
            Now_onset[Only_on[o]] = Vertex_Node[onset_values[o]]
        End_Boat_2 = [-1 for _ in range(Num_N)]
        Num_Boat_2 = [-1 for _ in range(Num_N)]
        Unload_Boat = [-1 for _ in range(Num_N)]
        Unload_Boat_2 = [-1 for _ in range(Num_N)]
        
        for i in range(Num_H):
            List_Out = []
            reh = 0
            
            Out_queue = []
            # Unloading Algorithm
            Unload_Head = []
            for n in Node_Sorted:
                if End_Boat_2[n] == i:
                    if End_Boat_2[Near_Main[n]] != i:
                        Unload_Head.append(n)
            Unload_Head = sorted(Unload_Head, key = lambda x : Node_Sorted.index(x))
            if True:
                for j in Node_Sorted:
                    if Unload_Boat_2[j] == 3:
                        Node = j
                        Colist += Fixed_Cost
                        while(Node != 0):
                            Check = 0
                            Colist += 1
                            Node = Near_Main[Node]
                        In_Boat_2[i].append([End_Boat_2[j], Num_Boat_2[j]])
                        End_Boat_2[j] = -1
                        Num_Boat_2[j] = -1
                        Unload_Boat[j] = -1
                        Unload_Boat_2[j] = -1
            
            for u in Unload_Head:
                Node = u
                unload_path = []
                while(Node != 0):
                    Node = Near_Main[Node]
                    unload_path.append(Node)
                unload_path.remove(0)
                for j in reversed(unload_path):
                    if End_Boat_2[j] >= i and End_Boat_2[j] != -1:
                        Node = j
                        Check = 0
                        Colist += Fixed_Cost
                        while(Node != 0):        
                            Colist += 1
                            for k in Subset_Nodes[Near_Main[Node]]:
                                if(k not in Main_Path_Node and End_Boat_2[k] == -1 and k != 0) :
                                    Check = 1
                                    Colist += 1
                                    End_Boat_2[k] = End_Boat_2[j]
                                    Num_Boat_2[k] = Num_Boat_2[j]
                                    break
                                if k in Main_Path_Node and k != 0  and End_Boat_2[k] == -1 and k != Node:
                                    onset_c = 0
                                    for p in range(i+1, Num_H):
                                        if Now_onset[p] == k and p < End_Boat_2[j]:
                                            onset_c = 1
                                            break
                                    for p in Subset_Depth[k]:
                                        if p != k and End_Boat_2[p] != -1 and End_Boat_2[p]< End_Boat_2[j]:
                                            onset_c = 1
                                            break
                                    if onset_c == 1:
                                        for r in reversed(Subset_Depth[k]):
                                            if r not in Main_Path_Node and End_Boat_2[r] == -1 and r!= 0:
                                                Check = 1 
                                                Node_s = r
                                                End_Boat_2[r] = End_Boat_2[j]
                                                Num_Boat_2[r] = Num_Boat_2[j]
                                               
                                                while Node_s != Near_Main[Node]:
                                                    Colist += 1
                                                    Node_s = Near_Main[Node_s]
                                                break
                                    if onset_c ==0:
                                        for r in reversed(Subset_Depth[k]):
                                            if End_Boat_2[r] == -1 and r!= 0:
                                                Check = 1
                                                End_Boat_2[r] = End_Boat_2[j]
                                                Num_Boat_2[r] = Num_Boat_2[j]
                                                Node_s = r
                                            
                                                while Node_s != Near_Main[Node]:
                                                    Colist += 1
                                                    Node_s = Near_Main[Node_s]
                                                break
                                    if(Check == 1):
                                        break
                            if(Check == 1):
                                break
                            Node = Near_Main[Node]
                        if Check == 0:
                            In_Boat_2[i].append([End_Boat_2[j], Num_Boat_2[j]])
                            reh += 1
                        End_Boat_2[j] = -1
                        Num_Boat_2[j] = -1
                        Unload_Boat[j] = -1
                if u not in Main_Path_Node and End_Boat_2[u] == i :
                    j = u
                    Node = j
                    Colist += Fixed_Cost
                    while(Node != 0):
                        Check = 0
                        Colist += 1
                        Node = Near_Main[Node]
                    End_Boat_2[j] = -1
                    Num_Boat_2[j] = -1
                    Unload_Boat[j] = -1
                if u in Main_Path_Node:
                    for j in Subset_Depth[u]:
                        if End_Boat_2[j] == i and j!= 0 and Num_Boat_2[j] > -1 and End_Boat_2[Near_Main[j]] == -1 :
                            Node = j
                            Colist += Fixed_Cost
                            while(Node != 0):
                                Check = 0
                                Colist += 1
                                Node = Near_Main[Node]
                            End_Boat_2[j] = -1
                            Num_Boat_2[j] = -1
                            Unload_Boat[j] = -1
                        
            for k in Out_queue:
                List_Out.append(k)


            In_Boat_2[i] = sorted(In_Boat_2[i], key = lambda x : x[0])
            Cnt = 0
            for j in In_Boat_2[i]:
                if(j[0] == i+1):
                    Cnt += 1

            Unload_Boat = [-1 for _ in range(Num_N)]

            In_Boat_3 = [[] for _ in range(Num_H)]
            for pair in In_Boat_2[i]:
                if pair[0] - i >= cri_values[i] and pair[0] != i+1:
                    In_Boat_3[i].append(pair)
            In_Boat_3[i] = sorted(In_Boat_3[i], key = lambda x : x[0])
            
            if reh >0:
                Now_onset = [-1 for _ in range(Num_H)]
                
                for h in range(Num_H):
                    for n in reversed(Node_Sorted):
                        if End_Boat_2[n] == h and End_Boat_2[Near_Main[n]] == -1:
                            Now_onset[h] = High_subsets[n]
                            break
            
            Now_onset[i] = -1
            # Loading Algorithm
            if True:
                Loaded = [-1 for _ in range(len(In_Boat_2[i]))]
                for k in reversed(range(len(In_Boat_2[i]) - len(In_Boat_3[i]), len(In_Boat_2[i]))):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1:
                        # A demand that's loaded first occupies a pre-assigned loading set
                        if End_Boat_2[Now_onset[In_Boat_2[i][k][0]]] != -1:
                            # Reset the pre-assigned set
                            Now_onset[In_Boat_2[i][k][0]] = -1
                        if Now_onset[In_Boat_2[i][k][0]] != -1 :   
                            tempset = Now_onset[In_Boat_2[i][k][0]]
                            for r in reversed(Subset_Depth[tempset]):
                                if End_Boat_2[r] == -1 and r !=0:
                                    if r == tempset and tempset != 0:
                                        if Near_Main[r] != High_subsets[tempset]:
                                            Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                        else:
                                            for h in Low_subsets[High_subsets[tempset]]:
                                                if h != r and End_Boat_2[h] == -1:
                                                    Now_onset[In_Boat_2[i][k][0]] = -1
                                                    for s in Subset_Depth[h]:
                                                        if s in Main_Path_Node:
                                                            if all(End_Boat_2[x] == -1 for x in Subset_Depth[s]):
                                                                Now_onset[In_Boat_2[i][k][0]] = s
                                                                break
                                                    break
                                            if Now_onset[In_Boat_2[i][k][0]] == tempset:
                                                Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                    else:
                                        Now_onset[In_Boat_2[i][k][0]] = tempset
                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                    Node = r
                                    Colist += Fixed_Cost
                                    while(Node != 0):
                                        Check = 0
                                        Colist += 1
                                        Node = Near_Main[Node]
                                    Loaded[k] = 0
                                    break
                        if Loaded[k] == 0:
                            continue
                        if Now_onset[In_Boat_2[i][k][0]] == -1 :
                            for v in reversed(Vertex_Node):
                                if all(End_Boat_2[x] == -1 for x in Subset_Depth[v]):
                                    Now_onset[In_Boat_2[i][k][0]] = v
                                    r = Subset_Depth[v][-1]
                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                    Node = r
                                    Colist += Fixed_Cost
                                    while(Node != 0):
                                        Check = 0
                                        Colist += 1
                                        Node = Near_Main[Node]
                                    Loaded[k] = 0
                                    break
                                if not all(End_Boat_2[x] == -1 for x in Subset_Depth[v]) and End_Boat_2[v] == -1:
                                    passes = 0
                                    temp_end = Num_H - 1
                                    for a in Subset_Depth[v]:
                                        if End_Boat_2[a] != -1 and End_Boat_2[a] < In_Boat_2[i][k][0]:
                                            passes = 1
                                            break
                                    if passes == 0:
                                        for r in reversed(Subset_Depth[v]):
                                            if End_Boat_2[r] == -1:
                                                if r == v:
                                                   if Near_Main[r] != High_subsets[v]:
                                                       Now_onset[In_Boat_2[i][k][0]] = Near_Main[v]
                                                   else:
                                                       for h in Low_subsets[High_subsets[v]]:
                                                           if h != r and End_Boat_2[h] == -1:
                                                               for ss in reversed(Subset_Depth[h]):
                                                                   if End_Boat_2[ss] == -1 and ss in Main_Path_Node:
                                                                       Now_onset[In_Boat_2[i][k][0]] = ss
                                                                       break
                                                               break
                                                       if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                           Now_onset[In_Boat_2[i][k][0]] = High_subsets[v]
                                    
                                                else:
                                                    Now_onset[In_Boat_2[i][k][0]] = v
                                                Now_onset[temp_end] = -1
                                                End_Boat_2[r] = In_Boat_2[i][k][0]
                                                Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                Node = r
                                                Colist += Fixed_Cost
                                                while(Node != 0):
                                                    Check = 0
                                                    Colist += 1
                                                    Node = Near_Main[Node]
                                                Loaded[k] = 0
                                                break
                                    if Loaded[k] == 0:
                                        break
                            if Loaded[k] == -1:
                                for s in range(In_Boat_2[i][k][0], Num_H):
                                    if Now_onset[s] != -1:
                                        passes = 0
                                        temp_end = s
                                        tempset = Now_onset[s]
                                        for d in range(In_Boat_2[i][k][1], len(Dem)):
                                            if Dem[d][0][1] == temp_end:
                                                passes = 1
                                                break
                                        if passes == 0:
                                            if End_Boat_2[tempset] == -1:
                                                for r in reversed(Subset_Depth[tempset]):
                                                    if End_Boat_2[r] == -1 and r!=0:
                                                        if r == tempset and tempset != 0:
                                                            if Near_Main[r] != High_subsets[tempset]:
                                                                Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                                            else:
                                                                for h in Low_subsets[High_subsets[tempset]]:
                                                                    if h != r and End_Boat_2[h] == -1:
                                                                        for ss in reversed(Subset_Depth[h]):
                                                                            if End_Boat_2[ss] == -1 and ss in Main_Path_Node:
                                                                                Now_onset[In_Boat_2[i][k][0]] = ss
                                                                                break
                                                                        break
                                                                if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                                    Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                                        else:
                                                            Now_onset[In_Boat_2[i][k][0]] = tempset
                                                        Now_onset[temp_end] = -1
                                                        End_Boat_2[r] = In_Boat_2[i][k][0]
                                                        Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                        Node = r
                                                        Colist += Fixed_Cost
                                                        while(Node != 0):
                                                            Check = 0
                                                            Colist += 1
                                                            Node = Near_Main[Node]
                                                        Loaded[k] = 0
                                                        break
                                        if Loaded[k] == 0:
                                            break
                            if Loaded[k] == -1:
                                for s in range(In_Boat_2[i][k][0], Num_H):
                                    if Now_onset[s] != -1:
                                        temp_end = s
                                        tempset = Now_onset[s]
                                        if End_Boat_2[tempset] == -1:
                                            for r in reversed(Subset_Depth[tempset]):
                                                if End_Boat_2[r] == -1 and r !=0:
                                                    if r == tempset and tempset != 0:
                                                        if Near_Main[r] != High_subsets[tempset]:
                                                            Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                                        else:
                                                            for h in Low_subsets[High_subsets[tempset]]:
                                                                if h != r and End_Boat_2[h] == -1:
                                                                    for ss in reversed(Subset_Depth[h]):
                                                                        if End_Boat_2[ss] == -1 and ss in Main_Path_Node:
                                                                            Now_onset[In_Boat_2[i][k][0]] = ss
                                                                            break
                                                                    break
                                                            if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                                Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                                    else:
                                                        Now_onset[In_Boat_2[i][k][0]] = tempset
                                                    Now_onset[s] = -1
                                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                    Node = r
                                                    Colist += Fixed_Cost
                                                    while(Node != 0):
                                                        Check = 0
                                                        Colist += 1
                                                        Node = Near_Main[Node]
                                                    Loaded[k] = 0
                                                    break
                                        if Loaded[k] == 0:
                                            break
                                if Now_onset[In_Boat_2[i][k][0]] == -1:
                                    for s in reversed(range(0, In_Boat_2[i][k][0])):
                                        if Now_onset[s] != -1:
                                            temp_end = s
                                            tempset = Now_onset[s]
                                            if End_Boat_2[tempset] == -1:
                                                for r in reversed(Subset_Depth[tempset]):
                                                    if End_Boat_2[r] == -1 and r !=0:
                                                        if r == tempset and tempset != 0:
                                                            if Near_Main[r] != High_subsets[tempset]:
                                                                Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                                            else:
                                                                for h in Low_subsets[High_subsets[tempset]]:
                                                                    if h != r and End_Boat_2[h] == -1:
                                                                        for ss in reversed(Subset_Depth[h]):
                                                                            if End_Boat_2[ss] == -1 and ss in Main_Path_Node:
                                                                                Now_onset[In_Boat_2[i][k][0]] = ss
                                                                                break
                                                                        break
                                                                if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                                    Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                                                
                                                        else:
                                                            Now_onset[In_Boat_2[i][k][0]] = tempset
                                                        Now_onset[s] = -1
                                                        End_Boat_2[r] = In_Boat_2[i][k][0]
                                                        Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                        Node = r
                                                        Colist += Fixed_Cost
                                                        while(Node != 0):
                                                            Check = 0
                                                            Colist += 1
                                                            Node = Near_Main[Node]
                                                        Loaded[k] = 0
                                                        break
                                            if Loaded[k] == 0:
                                                break
                
                
    
                if Cnt > 0:
                    for k in range(Cnt):
                        if Loaded[k] == 0:
                            continue
                        if Loaded[k] == -1:
                            for r in Node_Sorted:
                                if End_Boat_2[r] == -1:
                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                    Node = r
                                    Colist += Fixed_Cost
                                    while(Node != 0):
                                        Check = 0
                                        Colist += 1
                                        Node = Near_Main[Node]
                                    Loaded[k] = 0
                                    Unload_Boat[r] = 0
                                    break
                if i < first_arrival:
                    for k in range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i])):
                        if End_Boat_2[Now_onset[In_Boat_2[i][k][0]]] != -1:
                            Now_onset[In_Boat_2[i][k][0]] = -1

                # Simulation and modifications (for cars loaded from the front when a loading set already exists or is pre-designated).
                # `front_needs`: The number of cars needed for loading from the front, by destination.
                front_needs = [0 for _ in range(Num_H)]  
                # Iterate in reverse through the cars in `In_Boat_2` from the back (non-rehandled cars).         
                for k in reversed(range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i]))):
                    if Loaded[k] == 0:
                        continue
                    # For cars not yet loaded, check if their destination is already registered in `Now_onset`.
                    if Loaded[k] == -1: 
                        if Now_onset[In_Boat_2[i][k][0]] != -1 :
                            # Increment the count for that destination in `front_needs`.
                            front_needs[In_Boat_2[i][k][0]] += 1
                
                # Iterate through ports in reverse order.
                for p in reversed(range(Num_H)):
                    if front_needs[p] > 0:
                        onset_in = []
                       # If the node designated in `Now_onset[p]` is already occupied, reset `Now_onset[p]`.
                        if End_Boat_2[Now_onset[p]] != -1:
                            Now_onset[p] = -1
                        # If `Now_onset[p]` is not empty.
                        if Now_onset[p] != -1:
                            # Search the sub-nodes of `Now_onset[p]` in reverse to find loading spaces.
                            for r in reversed(Subset_Depth[Now_onset[p]]):
                                if End_Boat_2[r] == -1:
                                    onset_in.append(r)
                                if len(onset_in) == front_needs[p]:
                                    break
                            Node = Near_Main[Now_onset[p]]
                            go_forward = 0
                            # If the parent node of `Now_onset` is a junction, set the flag.
                            if len(Junction_Node[Node]) >1:
                                go_forward = 1
                            toend = 0
                            # Loop until `onset_in` is filled with the required number of nodes.
                            while len(onset_in) < front_needs[p]:
                                if toend == 1:
                                    Now_onset[p] = -1
                                    break
                                for r in Subset_Nodes[Node]:
                                    # Assign to empty non-main path nodes.
                                    if r not in Main_Path_Node and End_Boat_2[r] == -1 and r != 0:
                                        onset_in.append(r)
                                        if len(onset_in) == front_needs[p]:
                                            break
                                    # Assign to an empty main path node if `go_forward` is 0.
                                    if r in Main_Path_Node and go_forward == 0:
                                        onset_in.append(r)
                                        if len(onset_in) == front_needs[p]:
                                            break
                                if len(onset_in) == front_needs[p]:
                                    break
                                # If `Node` is on a single path.
                                if len(Junction_Node[Node]) <= 1:
                                    # Proceed to the parent node if `go_forward` is 0.
                                    if go_forward == 0:
                                        Node = Near_Main[Node]
                                        Now_onset[p] = Node
                                    # If `go_forward` is 1, proceed to the child node.
                                    else:
                                        Node = Junction_Node[Node][0]
                                        empty_cnt = 0
                                        for s in Subset_Depth[Node]:
                                            if End_Boat_2[s] == -1 and s !=0 :
                                                empty_cnt += 1
                                        # If the number of empty sub-nodes is less than or equal to the remaining `front_needs`, assign all
                                        if empty_cnt <= front_needs[p] - len(onset_in):
                                            for r in reversed(Subset_Depth[Node]):
                                                if r!= 0 and End_Boat_2[r] == -1:
                                                    onset_in.append(r)
                                                if len(onset_in) == front_needs[p]:
                                                    break
                                            if len(onset_in) == front_needs[p]:
                                                break
                                # If `Node` is a junction
                                elif len(Junction_Node[Node]) >1 :
                                    for n in Junction_Node[Node]:
                                        # If all sub-nodes are occupied, skip
                                        if all(End_Boat_2[x] != -1 for x in Subset_Depth[n]):
                                            if  n == Junction_Node[Node][-1]:
                                                toend = 1
                                                break
                                        else:
                                            empty_cnt = 0
                                            for s in Subset_Depth[n]:
                                                if End_Boat_2[s] == -1 and s !=0 :
                                                    empty_cnt += 1
                                            # If `empty_cnt` is greater than the remaining `front_needs`, proceed down this branch
                                            if empty_cnt > front_needs[p] - len(onset_in):
                                                Node = n
                                                go_forward = 1 # the flag that says proceeding toward inner nodes
                                                break
                                            # If `empty_cnt` is less than or equal to the remaining `front_needs`, assign all to the sub-nodes
                                            elif empty_cnt <= front_needs[p] - len(onset_in):
                                                Now_onset[p] = Node
                                                if empty_cnt < front_needs[p] - len(onset_in) and n == Junction_Node[Node][-1]:
                                                    toend = 1
                                                for r in reversed(Subset_Depth[n]):
                                                    if r!= 0 and End_Boat_2[r] == -1:
                                                        onset_in.append(r)
                                                    if len(onset_in) == front_needs[p]:
                                                        break
                                        if len(onset_in) == front_needs[p]:
                                            break
                            # Load the cars into the allocated nodes in `onset_in`
                            for k in reversed(range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i]))):
                                if p == In_Boat_2[i][k][0]:
                                    for r in onset_in:
                                        if End_Boat_2[r] == -1 and r != 0:
                                            End_Boat_2[r] = In_Boat_2[i][k][0]
                                            Num_Boat_2[r] = In_Boat_2[i][k][1]
                                            Node = r
                                            Colist += Fixed_Cost
                                            while(Node != 0):
                                                Check = 0
                                                Colist += 1
                                                Node = Near_Main[Node]
                                            Loaded[k] = 0
                                            break
                # End of the changed section

                needs = 0
                for k in range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i]) ):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1: 
                        needs += 1
                
                
                Front_in = []
                Front_vertex = []
                Node = 0
                toend = 0
                while len(Front_in) < needs:
                    if toend == 1 and len(Front_in) < needs:
                        for r in Node_Sorted:
                            if End_Boat_2[r] == -1 and r not in Front_in:
                                End_Boat_2[r] = -Num_H
                                Front_in.append(r)
                                Unload_Boat[r] = 0
                                Unload_Boat_2[r] = 3
                                if len(Front_in) == needs:
                                    break
                        if len(Front_in) == needs:
                            break
                        break
                    for r in Subset_Nodes[Node]:
                        if r not in Main_Path_Node and End_Boat_2[r] == -1 and r != 0:
                            End_Boat_2[r] = -Num_H
                            Front_in.append(r)
                            if len(Front_in) == needs:
                                break
                        if r in Main_Path_Node and End_Boat_2[r] == -1 and r != 0:
                            okc = 0
                            for r2 in Conn_Node[r]:
                                kk = len(In_Boat_2[i]) - len(In_Boat_3[i])
                                if End_Boat_2[r2] < In_Boat_2[i][kk-1][0] and End_Boat_2[r2] != -2   and Near_Main[r2] == r:
                                    okc = 1
                                    break
                            if okc == 0:
                                End_Boat_2[r] = -Num_H
                                Front_in.append(r)
                            if len(Front_in) == needs:
                                break
                    if len(Front_in) == needs:
                        break
                    if len(Junction_Node[Node]) <= 1:
                        Node = Junction_Node[Node][0]
                        empty_cnt = 0
                        Front_vertex.append(Node)
                        for s in Subset_Depth[Node]:
                            if End_Boat_2[s] == -1 and s !=0 :
                                empty_cnt += 1
                        if empty_cnt <= needs - len(Front_in):
                            for r in reversed(Subset_Depth[Node]):
                                if r!= 0 and End_Boat_2[r] == -1:
                                    End_Boat_2[r] = -Num_H
                                    Front_in.append(r)
                                if len(Front_in) == needs:
                                    break
                        if len(Front_in) == needs:
                            break
                    elif len(Junction_Node[Node]) >1 :
                        for n in Junction_Node[Node]:
                            if all(End_Boat_2[x] != -1 for x in Subset_Depth[n]):
                                if  n == Junction_Node[Node][-1]:
                                    toend = 1
                                    break
                            else:
                                empty_cnt = 0
                                for s in Subset_Depth[n]:
                                    if End_Boat_2[s] == -1 and s !=0 :
                                        empty_cnt += 1
                                if empty_cnt > needs - len(Front_in):
                                    Node = n
                                    break
                                elif empty_cnt <= needs - len(Front_in):
                                    Front_vertex.append(n)
                                    if empty_cnt < needs - len(Front_in) and n == Junction_Node[Node][-1]:
                                        toend = 1
                                    for r in reversed(Subset_Depth[n]):
                                        if r!= 0 and End_Boat_2[r] == -1:
                                            End_Boat_2[r] = -Num_H
                                            Front_in.append(r)
                                        if len(Front_in) == needs:
                                            break
                            if len(Front_in) == needs:
                                break
                                    
                            
                Front_in = sorted(Front_in, key= lambda x: Node_Sorted.index(x))
                
                Small_amount = []
                for k in range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i])):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1: 
                        if Dem[In_Boat_2[i][k][1]][1] <= 2:
                            Small_amount.append([In_Boat_2[i][k][0], In_Boat_2[i][k][1]])
                            Loaded[k] = 0
                Small_amount = sorted(Small_amount, key = lambda x : x[0])
                for k in Small_amount:
                    for r in Front_in:
                        if -End_Boat_2[r] >= k[0]:
                            End_Boat_2[r] = k[0]
                            Num_Boat_2[r] = k[1]
                            Node = r
                            Colist += Fixed_Cost
                            while(Node != 0):
                                Check = 0
                                Colist += 1
                                Node = Near_Main[Node]
                            break
                
                for k in reversed(range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i]))):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1: 
                        for r in reversed(Front_in):
                            if -End_Boat_2[r] >= In_Boat_2[i][k][0] :
                                End_Boat_2[r] = In_Boat_2[i][k][0]
                                Num_Boat_2[r] = In_Boat_2[i][k][1]
                                Node = r
                                Colist += Fixed_Cost
                                while(Node != 0):
                                    Check = 0
                                    Colist += 1
                                    Node = Near_Main[Node]
                                Loaded[k] = 0
                                break

                for k in range(len(In_Boat_2[i])):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1:
                        for r in Node_Sorted:
                            if End_Boat_2[r] == -1:
                                End_Boat_2[r] = In_Boat_2[i][k][0]
                                Num_Boat_2[r] = In_Boat_2[i][k][1]
                                Node = r
                                Colist += Fixed_Cost
                                while(Node != 0):
                                    Check = 0
                                    Colist += 1
                                    Node = Near_Main[Node]
                                Loaded[k] = 0
                                Unload_Boat_2[r] = 3
                                break               

                for k in reversed(Node_Sorted):
                    if End_Boat_2[k] == i+1:
                        Unload_Boat[k] = 0
                    if Unload_Boat[k] == 0:
                        Node = k
                        p_path = [Node]
                        while(Node != 0):
                            Node = Near_Main[Node]
                            p_path.append(Node)
                        for pp in p_path:
                            if End_Boat_2[pp] != -1 and pp != 0:
                                Unload_Boat[pp] = 0
        return Colist - LB
    
    # Simulated Annealing Execution

    import random
    import math
    
    # 1) SA Core (Simultaneous Optimization of `cri` and `onset`)
    def run_sa(initial_params):
        initial_cri   = initial_params['initial_cri']                 # list[int], 0..Num_H-1
        initial_onset = initial_params['Onset_designator'][:]         # list[int], each element 0..vertex_count-1
        temp          = float(initial_params['initial_temp'])
        alpha         = float(initial_params['alpha'])
        max_iter      = int(initial_params['max_iter'])
        Num_H         = int(initial_params['Num_H'])
        origin_dest   = initial_params['origin_dest']
        vertex_count  = int(initial_params['vertex_count'])           # = len(Vertex_Node)
        onset_len     = int(initial_params['onset_len'])              # = len(Only_on)
        seed          = initial_params.get('seed', None)
        pid           = initial_params.get('process_id', -1)
        node_sorted   = initial_params['Node_Sorted']
        subset_depth   = initial_params['Subset_Depth']

        if seed is not None:
            random.seed(seed)

        # --- Determine if duplicates are allowed ---
        allow_dup = (onset_len > vertex_count)

        cri_min, cri_max = 0, Num_H - 1
        onset_min, onset_max = 0, max(0, vertex_count - 1)

        # Movable ports (only ports with demand)
        movable_cri = [i for i in range(Num_H) if len(origin_dest[i]) > 0] or list(range(Num_H))

        # Cost evaluation: Cri_Simul accepts both `cri` and `onset`
        def eval_cost(cri_vec, onset_vec):
            return Cri_Simul(cri_vec, onset_vec, node_sorted, subset_depth)

       # ---- Generate `onset` neighbors (separate implementation for allowed/disallowed duplicates) ----
        def propose_onset_perm(on_cur):
            on_new = on_cur[:]
            L = len(on_new)
            used = set(on_new)
            unused = [v for v in range(vertex_count) if v not in used]

            r = random.random()
            if r < 0.50 and L >= 2:
                # 1) Swap
                a, b = random.sample(range(L), 2)
                on_new[a], on_new[b] = on_new[b], on_new[a]

            elif r < 0.70 and L >= 2:
                # 2) Insert (fine-tuning the order)
                a, b = random.sample(range(L), 2)
                val = on_new.pop(a)
                on_new.insert(b, val)

            elif r < 0.95 and len(unused) > 0:
                # 3) Replace with an unused value (exploring outside the initial set)
                a = random.randrange(L)
                newval = random.choice(unused)
                # No duplicates after replacement (removed from `used`, added from `unused`)
                on_new[a] = newval

            else:
                # 4) Scramble a small segment
                if L >= 3:
                    start = random.randrange(L-2)
                    end   = min(L, start + random.choice([3,4,5]))
                    seg = on_new[start:end]
                    random.shuffle(seg)
                    on_new[start:end] = seg
            return on_new

        # Duplicates allowed mode: randomly jump or slightly change a value (domain 0..vertex_count-1).
        def propose_onset_dup(on_cur):
            on_new = on_cur[:]
            j = random.randrange(len(on_new))
            explore_ratio = 0.30 if random.random() < 0.5 else 0.10
            old = on_new[j]
            if random.random() < explore_ratio and vertex_count > 1:
                on_new[j] = random.randrange(vertex_count)
            else:
                step = 1 if random.random() < 0.5 else -1
                on_new[j] = max(onset_min, min(onset_max, old + step))
            return on_new

        # Generate neighbors: modify either `cri` or `onset`
        def propose(cri_cur, on_cur, it):
            cri_new = cri_cur[:]
            on_new  = on_cur[:]

            # Change `onset` more often in the early stages, less later.
            tweak_onset_prob = 0.7 if it < int(0.5 * max_iter) else 0.7

            if random.random() < tweak_onset_prob and onset_len > 0 and vertex_count > 0:
                 # ---- `onset` modification ----
                if allow_dup:
                    on_new = propose_onset_dup(on_cur)
                else:
                    on_new = propose_onset_perm(on_cur)
            else:
                # ---- `cri` modification ----
                i = random.choice(movable_cri)
                explore_ratio = 0.30 if it < int(0.3 * max_iter) else 0.10
                old = cri_new[i]
                if random.random() < explore_ratio and Num_H > 1:
                    val = random.randrange(Num_H - 1)
                    if val >= old:
                        val += 1
                else:
                    step = 1 if random.random() < 0.5 else -1
                    val = max(cri_min, min(cri_max, old + step))
                    if val == old and Num_H > 1:
                        step = -step
                        val = max(cri_min, min(cri_max, old + step))
                        if val == old:
                            val = random.randrange(Num_H - 1)
                            if val >= old:
                                val += 1
                cri_new[i] = val

            return cri_new, on_new

        # === SA Main Loop ===
        current_cri   = initial_cri[:]
        current_onset = initial_onset[:]
        current_cost  = eval_cost(current_cri, current_onset)

        best_cri, best_onset, best_cost = current_cri[:], current_onset[:], current_cost

        for it in range(1, max_iter + 1):
            n_cri, n_on = propose(current_cri, current_onset, it)
            n_cost = eval_cost(n_cri, n_on)

            delta = n_cost - current_cost
            if delta < 0 or random.random() < math.exp(-delta / max(1e-12, temp)):
                current_cri, current_onset, current_cost = n_cri, n_on, n_cost
                if current_cost < best_cost:
                    best_cri, best_onset, best_cost = current_cri[:], current_onset[:], current_cost
            temp *= alpha

        return best_cri, best_onset, best_cost, pid, node_sorted, subset_depth


    # 2) Initial Solution Generation (Simultaneous `cri` + `onset`)

    vertex_count = len(Vertex_Node)
    onset_len    = len(Only_on)
    allow_dup    = (onset_len > vertex_count)

    # --- Utilities for generating initial onset solutions ---
    def random_onset(vertex_count, onset_len, allow_dup):
        if allow_dup:
            # Duplicates allowed: freely choose from range 0..vertex_count-1.
            return [random.randrange(vertex_count) for _ in range(onset_len)]
        else:
            # Duplicates not allowed: slice from a permutation.
            return random.sample(range(vertex_count), onset_len)

    def jitter_onset(base_on, vertex_count, allow_dup, p=0.5):
        out = base_on[:]
        if allow_dup:
            # Reassign values to some positions (duplicates allowed)
            for j in range(len(out)):
                if random.random() < p:
                    out[j] = random.randrange(vertex_count)
        else:
            # Duplicates not allowed: shuffle with a few swaps (maintains permutation)
            swaps = max(1, int(p * len(out)))
            for _ in range(swaps):
                if len(out) >= 2:
                    a, b = random.sample(range(len(out)), 2)
                    out[a], out[b] = out[b], out[a]
        return out

    # (A) `cri` = uniform, `onset` = base (following duplicate rules)
    uniform_cri_value = cri
    Onset_designator_base = random_onset(vertex_count, onset_len, allow_dup)

    initial_params_list = []
    initial_params_list.append({
        'process_id': 0,
        'initial_cri': [uniform_cri_value for _ in range(Num_H)],
        'Onset_designator': Onset_designator_base[:],
        'initial_temp': 100, 'alpha': 0.999, 'max_iter': 2500,
        'Num_H': Num_H, 'origin_dest': origin_dest,
        'vertex_count': vertex_count, 'onset_len': onset_len,
        'Node_Sorted' : New_Node_Sorted, 'Subset_Depth' :New_Subset_Depth,
        'seed': 1234,
    })

    # (B) `cri` = uniform±1, `onset` = jittered from base
    init_B_cri = [max(0, min(Num_H-1, uniform_cri_value + (1 if random.random()<0.5 else -1)))
                  for _ in range(Num_H)]
    initial_params_list.append({
        'process_id': 1,
        'initial_cri': init_B_cri,
        'Onset_designator': jitter_onset(Onset_designator_base, vertex_count, allow_dup, p=0.6),
        'initial_temp': 100, 'alpha': 0.999, 'max_iter': 2500,
        'Num_H': Num_H, 'origin_dest': origin_dest,
        'vertex_count': vertex_count, 'onset_len': onset_len,
        'Node_Sorted' : New_Node_Sorted, 'Subset_Depth' : New_Subset_Depth,
        'seed': 5678,
    })

    # (C) `cri` = completely random, `onset` = completely random (following duplicate rules)
    init_C_cri = [random.randint(0, Num_H-1) for _ in range(Num_H)]
    init_C_on  = random_onset(vertex_count, onset_len, allow_dup)
    initial_params_list.append({
        'process_id': 2,
        'initial_cri': init_C_cri,
        'Onset_designator': init_C_on,
        'initial_temp': 100, 'alpha': 0.999, 'max_iter': 2500,
        'Num_H': Num_H, 'origin_dest': origin_dest,
        'vertex_count': vertex_count, 'onset_len': onset_len,
        'Node_Sorted' : New_Node_Sorted, 'Subset_Depth' : New_Subset_Depth,
        'seed': 9012,
    })
    
    # (D) `cri` = ramp, `onset` = shifted from base by one position (maintaining permutation)
    ramp_cri = [max(0, min(Num_H-1, uniform_cri_value + (1 if j < Num_H//2 else -1)))
                for j in range(Num_H)]
    if allow_dup:
        # If duplicates are allowed, reassign some positions.
        init_D_on = jitter_onset(Onset_designator_base, vertex_count, allow_dup, p=0.4)
    else:
        # If duplicates are not allowed, safely rotate the permutation by a shift
        shift = 1 if random.random() < 0.5 else -1
        init_D_on = Onset_designator_base[-shift:] + Onset_designator_base[:-shift]

    initial_params_list.append({
        'process_id': 3,
        'initial_cri': ramp_cri,
        'Onset_designator': init_D_on,
        'initial_temp': 100, 'alpha': 0.999, 'max_iter': 2500,
        'Num_H': Num_H, 'origin_dest': origin_dest,
        'vertex_count': vertex_count, 'onset_len': onset_len,
        'Node_Sorted' : New_Node_Sorted, 'Subset_Depth' :New_Subset_Depth,
        'seed': 3456,
    })
    
    # Add two more initial solutions with similar logic to types A and C
    initial_params_list.append({
        'process_id': 4,
        'initial_cri': [uniform_cri_value for _ in range(Num_H)],
        'Onset_designator': Onset_designator_base[:],
        'initial_temp': 100, 'alpha': 0.999, 'max_iter': 2500,
        'Num_H': Num_H, 'origin_dest': origin_dest,
        'vertex_count': vertex_count, 'onset_len': onset_len,
        'Node_Sorted' : New_Node_Sorted, 'Subset_Depth' :New_Subset_Depth,
        'seed': 134,
    })
    
    
    init_C_cri = [random.randint(0, Num_H-1) for _ in range(Num_H)]
    init_C_on  = random_onset(vertex_count, onset_len, allow_dup)
    initial_params_list.append({
        'process_id': 5,
        'initial_cri': init_C_cri,
        'Onset_designator': init_C_on,
        'initial_temp': 100, 'alpha': 0.999, 'max_iter': 2500,
        'Num_H': Num_H, 'origin_dest': origin_dest,
        'vertex_count': vertex_count, 'onset_len': onset_len,
        'Node_Sorted' : New_Node_Sorted, 'Subset_Depth' :New_Subset_Depth,
        'seed': 912,
    })



    print("SA searching starts...")

    # Sequential execution
    results = [run_sa(param) for param in initial_params_list]

    print("\n --- Searching Completed ---")

    best_overall_cost = float('inf')
    best_overall_cri  = None
    best_overall_onset = None

    for cr, onset, costt, pid, node, depth in results:
        print(f"Process {pid}의 최적 비용: {costt:.4f}")
        if costt < best_overall_cost:
            best_overall_cost   = costt
            best_overall_cri    = cr
            best_overall_onset  = onset
            best_node_sorted = node
            best_subset_depth = depth

    print("\n--- 최종 결과 ---")
    print(f"전체 최적 비용: {best_overall_cost:.4f}")
    print(f"전체 최적 cri: {best_overall_cri}")
    print(f"전체 최적 onset_designator: {best_overall_onset}")

    # Select the best SA result
    best_cri = best_overall_cri
    best_designator = best_overall_onset
    Node_Sorted = best_node_sorted
    Subset_Depth = best_subset_depth

    

    Cnt = 0
    In_Boat_2 = [[] for _ in range(Num_H)]
    In_Boat_3 = [[] for _ in range(Num_H)]

    
    for pair in Dem:
        for i in range(pair[1]):
            In_Boat_2[pair[0][0]].append([pair[0][1], Cnt])
        Cnt += 1
 
    # Final loop to execute with the confirmed `cri` and `onset_value` combination, and to save the loading and unloading paths.
    # The logic is the same as in `Cri_Simul`
    Ceh = 0
    Cost = 0
    if True :
        print(f'Parameter: {best_cri}')
        
        Now_onset = [-1 for _ in range(Num_H)]
        for o in range(len(Only_on)):
            Now_onset[Only_on[o]] = Vertex_Node[best_designator[o]]
        End_Boat_2 = [-1 for _ in range(Num_N)]
        Num_Boat_2 = [-1 for _ in range(Num_N)]
        Unload_Boat = [-1 for _ in range(Num_N)]
        Unload_Boat_2 = [-1 for _ in range(Num_N)]
        
        for i in range(Num_H):
            List_Out = []
            reh = 0
            
            Out_queue = []
            # Unloading Algorithm
            Unload_Head = []
            for n in Node_Sorted:
                if End_Boat_2[n] == i:
                    if End_Boat_2[Near_Main[n]] != i:
                        Unload_Head.append(n)
            Unload_Head = sorted(Unload_Head, key = lambda x : Node_Sorted.index(x))
            if True:
                for j in Node_Sorted:
                    if Unload_Boat_2[j] == 3:
                        Node = j
                        queue = [Num_Boat_2[j]]
                        Node_queue = [[j]]
                        Cost += Fixed_Cost
                        while(Node != 0):
                            Check = 0
                            Cost += 1
                            Node = Near_Main[Node]
                            Node_queue[0].append(Node)
                        Node_queue.append(queue[0])
                        Out_queue.append(Node_queue)
                        Ceh += 1
                        print(f"Demand {Num_Boat_2[j]} in node {j} temporarily unloaded in Port {i}")
                        In_Boat_2[i].append([End_Boat_2[j], Num_Boat_2[j]])
                        End_Boat_2[j] = -1
                        Num_Boat_2[j] = -1
                        Unload_Boat[j] = -1
                        Unload_Boat_2[j] = -1
            
            for u in Unload_Head:
                Node = u
                unload_path = []
                while(Node != 0):
                    Node = Near_Main[Node]
                    unload_path.append(Node)
                unload_path.remove(0)
                for j in reversed(unload_path):
                    if End_Boat_2[j] >= i and End_Boat_2[j] != -1:
                        Node = j
                        Node_queue = [[j]]
                        queue = [Num_Boat_2[j]]
                        Check = 0
                        Cost += Fixed_Cost
                        while(Node != 0):        
                            Cost += 1
                            for k in Subset_Nodes[Near_Main[Node]]:
                                if(k not in Main_Path_Node and End_Boat_2[k] == -1 and k != 0) :
                                    print(f"Demand {Num_Boat_2[j]} in node {j} rehandled to node {k} in Port {i}")
                                    Node_queue[0].append(Near_Main[Node])
                                    Node_queue[0].append(k)
                                    Check = 1
                                    End_Boat_2[k] = End_Boat_2[j]
                                    Num_Boat_2[k] = Num_Boat_2[j]
                                    break
                                if k in Main_Path_Node and k != 0  and End_Boat_2[k] == -1 and k != Node:
                                    onset_c = 0
                                    
                                    for p in range(i+1, Num_H):
                                        if Now_onset[p] == k and p < End_Boat_2[j]:
                                            onset_c = 1
                                            break
                                    for p in Subset_Depth[k]:
                                        if p != k and End_Boat_2[p] != -1 and End_Boat_2[p]< End_Boat_2[j]:
                                            onset_c = 1
                                            break
                                    if onset_c == 1:
                                        for r in reversed(Subset_Depth[k]):
                                            if r not in Main_Path_Node and End_Boat_2[r] == -1 and r!= 0:
                                                print(f"Demand {Num_Boat_2[j]} in node {j} rehandled to node {r} in Port {i}")
                                                Check = 1 
                                                End_Boat_2[r] = End_Boat_2[j]
                                                Num_Boat_2[r] = Num_Boat_2[j]
                                                sub_queue = [r]
                                                Node_s = r
                                                Cost += 1
                                                while Node_s != Near_Main[Node]:
                                                    Cost += 1
                                                    Node_s = Near_Main[Node_s]
                                                    sub_queue.append(Node_s)
                                                sub_queue.reverse()
                                                for s in sub_queue:
                                                    Node_queue[0].append(s)
                                                break
                                    if onset_c ==0:
                                        for r in reversed(Subset_Depth[k]):
                                            if End_Boat_2[r] == -1 and r!= 0:
                                                print(f"Demand {Num_Boat_2[j]} in node {j} rehandled to node {r} in Port {i}")
                                                Check = 1
                                                End_Boat_2[r] = End_Boat_2[j]
                                                Num_Boat_2[r] = Num_Boat_2[j]
                                                sub_queue = [r]
                                                Node_s = r
                                                Cost += 1
                                                while Node_s != Near_Main[Node]:
                                                    Cost += 1
                                                    Node_s = Near_Main[Node_s]
                                                    sub_queue.append(Node_s)
                                                sub_queue.reverse()
                                                for s in sub_queue:
                                                    Node_queue[0].append(s)
                                                break
                                    if(Check == 1):
                                        break
                            if(Check == 1):
                                break
                            Node = Near_Main[Node]
                            Node_queue[0].append(Node)
                        Node_queue.append(queue[0])
                        Out_queue.append(Node_queue)
                        if Check == 0:
                            print(f"Demand {Num_Boat_2[j]} in node {j} temporarily unloaded in Port {i}")
                            In_Boat_2[i].append([End_Boat_2[j], Num_Boat_2[j]])
                            Ceh += 1
                            reh += 1
                        End_Boat_2[j] = -1
                        Num_Boat_2[j] = -1
                        Unload_Boat[j] = -1
                if u not in Main_Path_Node and End_Boat_2[u] == i :
                    j = u
                    Node = j
                    queue = [Num_Boat_2[j]]
                    Node_queue = [[j]]
                    Cost += Fixed_Cost
                    while(Node != 0):
                        Check = 0
                        Cost += 1
                        Node = Near_Main[Node]
                        Node_queue[0].append(Node)
                    Node_queue.append(queue[0])
                    Out_queue.append(Node_queue)
                    End_Boat_2[j] = -1
                    Num_Boat_2[j] = -1
                    Unload_Boat[j] = -1
                if u in Main_Path_Node:
                    for j in Subset_Depth[u]:
                        if End_Boat_2[j] == i and j!= 0 and Num_Boat_2[j] > -1 and End_Boat_2[Near_Main[j]] == -1 :
                            Node = j
                            queue = [Num_Boat_2[j]]
                            Node_queue = [[j]]
                            Cost += Fixed_Cost
                            while(Node != 0):
                                Check = 0
                                Cost += 1
                                Node = Near_Main[Node]
                                Node_queue[0].append(Node)
                            Node_queue.append(queue[0])
                            Out_queue.append(Node_queue)
                            End_Boat_2[j] = -1
                            Num_Boat_2[j] = -1
                            Unload_Boat[j] = -1
            

                        
            for k in Out_queue:
                List_Out.append(k)


            In_Boat_2[i] = sorted(In_Boat_2[i], key = lambda x : x[0])
            Cnt = 0
            for j in In_Boat_2[i]:
                if(j[0] == i+1):
                    Cnt += 1
            Node_queue = []
            queue = []
            Unload_Boat = [-1 for _ in range(Num_N)]
            
                
            
            In_Boat_3 = [[] for _ in range(Num_H)]
            for pair in In_Boat_2[i]:
                if pair[0] - i >= best_cri[i] and pair[0] != i+1:
                    In_Boat_3[i].append(pair)
            In_Boat_3[i] = sorted(In_Boat_3[i], key = lambda x : x[0])
            
            if reh >0:
                Now_onset = [-1 for _ in range(Num_H)]
                
                for h in range(Num_H):
                    for n in reversed(Node_Sorted):
                        if End_Boat_2[n] == h and End_Boat_2[Near_Main[n]] == -1:
                            Now_onset[h] = High_subsets[n]
                            break
            
            Now_onset[i] = -1


            # Loading Algorithm 
            if True:
                Loaded = [-1 for _ in range(len(In_Boat_2[i]))]
                for k in reversed(range(len(In_Boat_2[i]) - len(In_Boat_3[i]), len(In_Boat_2[i]))):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1:
                        if End_Boat_2[Now_onset[In_Boat_2[i][k][0]]] != -1:
                            Now_onset[In_Boat_2[i][k][0]] = -1
                        if Now_onset[In_Boat_2[i][k][0]] != -1 :   
                            tempset = Now_onset[In_Boat_2[i][k][0]]
                            for r in reversed(Subset_Depth[tempset]):
                                if End_Boat_2[r] == -1 and r !=0:
                                    if r == tempset and tempset != 0:
                                        if Near_Main[r] != High_subsets[tempset]:
                                            Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                        else:
                                            for h in Low_subsets[High_subsets[tempset]]:
                                                if h != r and End_Boat_2[h] == -1:
                                                    Now_onset[In_Boat_2[i][k][0]] = -1
                                                    for s in Subset_Depth[h]:
                                                        if s in Main_Path_Node:
                                                            if all(End_Boat_2[x] == -1 for x in Subset_Depth[s]):
                                                                Now_onset[In_Boat_2[i][k][0]] = s
                                                                break
                                                    break
                                            if Now_onset[In_Boat_2[i][k][0]] == tempset:
                                                Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                    else:
                                        Now_onset[In_Boat_2[i][k][0]] = tempset
                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                    Node = r
                                    Node_queue_1 = [[r]]
                                    Cost += Fixed_Cost
                                    while(Node != 0):
                                        Check = 0
                                        Cost += 1
                                        Node = Near_Main[Node]
                                        Node_queue_1[0].append(Node)
                                    Loaded[k] = 0
                                    Node_queue_1[0].reverse()
                                    Node_queue_1.append(In_Boat_2[i][k][1])
                                    Node_queue.append(Node_queue_1)
                                    break
                        if Loaded[k] == 0:
                            continue
                        if Now_onset[In_Boat_2[i][k][0]] == -1 :
                            for v in reversed(Vertex_Node):
                                if all(End_Boat_2[x] == -1 for x in Subset_Depth[v]):
                                    Now_onset[In_Boat_2[i][k][0]] = v
                                    r = Subset_Depth[v][-1]
                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                    Node = r
                                    Node_queue_1 = [[r]]
                                    Cost += Fixed_Cost
                                    while(Node != 0):
                                        Check = 0
                                        Cost += 1
                                        Node = Near_Main[Node]
                                        Node_queue_1[0].append(Node)
                                    Loaded[k] = 0
                                    Node_queue_1[0].reverse()
                                    Node_queue_1.append(In_Boat_2[i][k][1])
                                    Node_queue.append(Node_queue_1)
                                    break
                                if not all(End_Boat_2[x] == -1 for x in Subset_Depth[v]) and End_Boat_2[v] == -1:
                                    passes = 0
                                    temp_end = Num_H - 1
                                    for a in Subset_Depth[v]:
                                        if End_Boat_2[a] != -1 and End_Boat_2[a] < In_Boat_2[i][k][0]:
                                            passes = 1
                                            break
                                    if passes == 0:
                                        for r in reversed(Subset_Depth[v]):
                                            if End_Boat_2[r] == -1:
                                                if r == v:
                                                   if Near_Main[r] != High_subsets[v]:
                                                       Now_onset[In_Boat_2[i][k][0]] = Near_Main[v]
                                                   else:
                                                       for h in Low_subsets[High_subsets[v]]:
                                                           if h != r and End_Boat_2[h] == -1:
                                                               for ss in reversed(Subset_Depth[h]):
                                                                   if End_Boat_2[ss] == -1 and ss in Main_Path_Node:
                                                                       Now_onset[In_Boat_2[i][k][0]] = ss
                                                                       break
                                                               break
                                                       if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                           Now_onset[In_Boat_2[i][k][0]] = High_subsets[v]
                                    
                                                else:
                                                    Now_onset[In_Boat_2[i][k][0]] = v
                                                Now_onset[temp_end] = -1
                                                End_Boat_2[r] = In_Boat_2[i][k][0]
                                                Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                Node = r
                                                Node_queue_1 = [[r]]
                                                Cost += Fixed_Cost
                                                while(Node != 0):
                                                    Check = 0
                                                    Cost += 1
                                                    Node = Near_Main[Node]
                                                    Node_queue_1[0].append(Node)
                                                Loaded[k] = 0
                                                Node_queue_1[0].reverse()
                                                Node_queue_1.append(In_Boat_2[i][k][1])
                                                Node_queue.append(Node_queue_1)
                                                break
                                    if Loaded[k] == 0:
                                        break
                            if Loaded[k] == -1:
                                for s in range(In_Boat_2[i][k][0], Num_H):
                                    if Now_onset[s] != -1:
                                        passes = 0
                                        temp_end = s
                                        tempset = Now_onset[s]
                                        for d in range(In_Boat_2[i][k][1], len(Dem)):
                                            if Dem[d][0][1] == temp_end:
                                                passes = 1
                                                break
                                        if passes == 0:
                                            if End_Boat_2[tempset] == -1:
                                                for r in reversed(Subset_Depth[tempset]):
                                                    if End_Boat_2[r] == -1 and r!=0:
                                                        if r == tempset and tempset != 0:
                                                            if Near_Main[r] != High_subsets[tempset]:
                                                                Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                                            else:
                                                                for h in Low_subsets[High_subsets[tempset]]:
                                                                    if h != r and End_Boat_2[h] == -1:
                                                                        for ss in reversed(Subset_Depth[h]):
                                                                            if End_Boat_2[ss] == -1 and ss in Main_Path_Node:
                                                                                Now_onset[In_Boat_2[i][k][0]] = ss
                                                                                break
                                                                        break
                                                                if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                                    Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                                        else:
                                                            Now_onset[In_Boat_2[i][k][0]] = tempset
                                                        Now_onset[temp_end] = -1
                                                        End_Boat_2[r] = In_Boat_2[i][k][0]
                                                        Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                        Node = r
                                                        Node_queue_1 = [[r]]
                                                        Cost += Fixed_Cost
                                                        while(Node != 0):
                                                            Check = 0
                                                            Cost += 1
                                                            Node = Near_Main[Node]
                                                            Node_queue_1[0].append(Node)
                                                        Loaded[k] = 0
                                                        Node_queue_1[0].reverse()
                                                        Node_queue_1.append(In_Boat_2[i][k][1])
                                                        Node_queue.append(Node_queue_1)
                                                        break
                                        if Loaded[k] == 0:
                                            break
                            if Loaded[k] == -1:
                                for s in range(In_Boat_2[i][k][0], Num_H):
                                    if Now_onset[s] != -1:
                                        temp_end = s
                                        tempset = Now_onset[s]
                                        if End_Boat_2[tempset] == -1:
                                            for r in reversed(Subset_Depth[tempset]):
                                                if End_Boat_2[r] == -1 and r !=0:
                                                    if r == tempset and tempset != 0:
                                                        if Near_Main[r] != High_subsets[tempset]:
                                                            Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                                        else:
                                                            for h in Low_subsets[High_subsets[tempset]]:
                                                                if h != r and End_Boat_2[h] == -1:
                                                                    for ss in reversed(Subset_Depth[h]):
                                                                        if End_Boat_2[ss] == -1 and ss in Main_Path_Node:
                                                                            Now_onset[In_Boat_2[i][k][0]] = ss
                                                                            break
                                                                    break
                                                            if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                                Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                                    else:
                                                        Now_onset[In_Boat_2[i][k][0]] = tempset
                                                    Now_onset[s] = -1
                                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                    Node = r
                                                    Node_queue_1 = [[r]]
                                                    Cost += Fixed_Cost
                                                    while(Node != 0):
                                                        Check = 0
                                                        Cost += 1
                                                        Node = Near_Main[Node]
                                                        Node_queue_1[0].append(Node)
                                                    Loaded[k] = 0
                                                    Node_queue_1[0].reverse()
                                                    Node_queue_1.append(In_Boat_2[i][k][1])
                                                    Node_queue.append(Node_queue_1)
                                                    break
                                        if Loaded[k] == 0:
                                            break
                                if Now_onset[In_Boat_2[i][k][0]] == -1:
                                    for s in reversed(range(0, In_Boat_2[i][k][0])):
                                        if Now_onset[s] != -1:
                                            temp_end = s
                                            tempset = Now_onset[s]
                                            if End_Boat_2[tempset] == -1:
                                                for r in reversed(Subset_Depth[tempset]):
                                                    if End_Boat_2[r] == -1 and r !=0:
                                                        if r == tempset and tempset != 0:
                                                            if Near_Main[r] != High_subsets[tempset]:
                                                                Now_onset[In_Boat_2[i][k][0]] = Near_Main[tempset]
                                                            else:
                                                                for h in Low_subsets[High_subsets[tempset]]:
                                                                    if h != r and End_Boat_2[h] == -1:
                                                                        for ss in reversed(Subset_Depth[h]):
                                                                            if End_Boat_2[ss] == -1 and ss in Main_Path_Node:
                                                                                Now_onset[In_Boat_2[i][k][0]] = ss
                                                                                break
                                                                        break
                                                                if Now_onset[In_Boat_2[i][k][0]] == -1:
                                                                    Now_onset[In_Boat_2[i][k][0]] = High_subsets[tempset]
                                                                
                                                        else:
                                                            Now_onset[In_Boat_2[i][k][0]] = tempset
                                                        Now_onset[s] = -1
                                                        End_Boat_2[r] = In_Boat_2[i][k][0]
                                                        Num_Boat_2[r] = In_Boat_2[i][k][1]
                                                        Node = r
                                                        Node_queue_1 = [[r]]
                                                        Cost += Fixed_Cost
                                                        while(Node != 0):
                                                            Check = 0
                                                            Cost += 1
                                                            Node = Near_Main[Node]
                                                            Node_queue_1[0].append(Node)
                                                        Loaded[k] = 0
                                                        Node_queue_1[0].reverse()
                                                        Node_queue_1.append(In_Boat_2[i][k][1])
                                                        Node_queue.append(Node_queue_1)
                                                        break
                                            if Loaded[k] == 0:
                                                break
                
                
                        
                
                Node_queue_2 = []
                Node_queue_3 = []
                if Cnt > 0:
                    for k in range(Cnt):
                        if Loaded[k] == 0:
                            continue
                        if Loaded[k] == -1:
                            for r in Node_Sorted:
                                if End_Boat_2[r] == -1:
                                    End_Boat_2[r] = In_Boat_2[i][k][0]
                                    Num_Boat_2[r] = In_Boat_2[i][k][1]
                                    Node = r
                                    Node_queue_1 = [[r]]
                                    Cost += Fixed_Cost
                                    while(Node != 0):
                                        Check = 0
                                        Cost += 1
                                        Node = Near_Main[Node]
                                        Node_queue_1[0].append(Node)
                                    Loaded[k] = 0
                                    Node_queue_1[0].reverse()
                                    Node_queue_1.append(In_Boat_2[i][k][1])
                                    Node_queue_2.append(Node_queue_1)
                                    Unload_Boat[r] = 0
                                    break
                if i < first_arrival:
                    for k in range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i])):
                        if End_Boat_2[Now_onset[In_Boat_2[i][k][0]]] != -1:
                            Now_onset[In_Boat_2[i][k][0]] = -1


                            
                
                front_needs = [0 for _ in range(Num_H)]                
                for k in reversed(range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i]))):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1: 
                        if Now_onset[In_Boat_2[i][k][0]] != -1 :
                            front_needs[In_Boat_2[i][k][0]] += 1
                
                for p in reversed(range(Num_H)):
                    if front_needs[p] > 0:
                        onset_in = []
                        if End_Boat_2[Now_onset[p]] != -1:
                            Now_onset[p] = -1
                        if Now_onset[p] != -1:
                            for r in reversed(Subset_Depth[Now_onset[p]]):
                                if End_Boat_2[r] == -1:
                                    onset_in.append(r)
                                if len(onset_in) == front_needs[p]:
                                    break
                            Node = Near_Main[Now_onset[p]]
                            go_forward = 0
                            if len(Junction_Node[Node]) >1:
                                go_forward = 1
                            toend = 0
                            while len(onset_in) < front_needs[p]:
                                if toend == 1:
                                    Now_onset[p] = -1
                                    break
                                for r in Subset_Nodes[Node]:
                                    if r not in Main_Path_Node and End_Boat_2[r] == -1 and r != 0:
                                        onset_in.append(r)
                                        if len(onset_in) == front_needs[p]:
                                            break
                                    if r in Main_Path_Node and go_forward == 0:
                                        onset_in.append(r)
                                        if len(onset_in) == front_needs[p]:
                                            break
                                if len(onset_in) == front_needs[p]:
                                    break
                                if len(Junction_Node[Node]) <= 1:
                                    if go_forward == 0:
                                        Node = Near_Main[Node]
                                        Now_onset[p] = Node
                                    else:
                                        Node = Junction_Node[Node][0]
                                        empty_cnt = 0
                                        for s in Subset_Depth[Node]:
                                            if End_Boat_2[s] == -1 and s !=0 :
                                                empty_cnt += 1
                                        if empty_cnt <= front_needs[p] - len(onset_in):
                                            for r in reversed(Subset_Depth[Node]):
                                                if r!= 0 and End_Boat_2[r] == -1:
                                                    onset_in.append(r)
                                                if len(onset_in) == front_needs[p]:
                                                    break
                                            if len(onset_in) == front_needs[p]:
                                                break
                                elif len(Junction_Node[Node]) >1 :
                                    for n in Junction_Node[Node]:
                                        if all(End_Boat_2[x] != -1 for x in Subset_Depth[n]):
                                            if  n == Junction_Node[Node][-1]:
                                                toend = 1
                                                break
                                        else:
                                            empty_cnt = 0
                                            for s in Subset_Depth[n]:
                                                if End_Boat_2[s] == -1 and s !=0 :
                                                    empty_cnt += 1
                                            if empty_cnt > front_needs[p] - len(onset_in):
                                                Node = n
                                                go_forward = 1
                                                break
                                            elif empty_cnt <= front_needs[p] - len(onset_in):
                                                Now_onset[p] = Node
                                                if empty_cnt < front_needs[p] - len(onset_in) and n == Junction_Node[Node][-1]:
                                                    toend = 1
                                                for r in reversed(Subset_Depth[n]):
                                                    if r!= 0 and End_Boat_2[r] == -1:
                                                        onset_in.append(r)
                                                    if len(onset_in) == front_needs[p]:
                                                        break
                                        if len(onset_in) == front_needs[p]:
                                            break
                            for k in reversed(range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i]))):
                                if p == In_Boat_2[i][k][0]:
                                    for r in onset_in:
                                        if End_Boat_2[r] == -1 and r != 0:
                                            End_Boat_2[r] = In_Boat_2[i][k][0]
                                            Num_Boat_2[r] = In_Boat_2[i][k][1]
                                            Node = r
                                            Node_queue_1 = [[r]]
                                            Cost += Fixed_Cost
                                            while(Node != 0):
                                                Check = 0
                                                Cost += 1
                                                Node = Near_Main[Node]
                                                Node_queue_1[0].append(Node)
                                            Loaded[k] = 0
                                            Node_queue_1[0].reverse()
                                            Node_queue_1.append(In_Boat_2[i][k][1])
                                            Node_queue.append(Node_queue_1)
                                            break
              
                needs = 0
                for k in range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i])):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1: 
                        needs += 1
                
                
                Front_in = []
                Front_vertex = []
                Node = 0
                toend = 0
                while len(Front_in) < needs:
                    if toend == 1 and len(Front_in) < needs:
                        print(f'port{i} loop oh no')
                        for r in Node_Sorted:
                            if End_Boat_2[r] == -1 and r not in Front_in:
                                End_Boat_2[r] = -Num_H
                                Front_in.append(r)
                                Unload_Boat[r] = 0
                                Unload_Boat_2[r] = 3
                                if len(Front_in) == needs:
                                    break
                        if len(Front_in) == needs:
                            break
                        break
                    for r in Subset_Nodes[Node]:
                        if r not in Main_Path_Node and End_Boat_2[r] == -1 and r != 0:
                            End_Boat_2[r] = -Num_H
                            Front_in.append(r)
                            if len(Front_in) == needs:
                                break
                        if r in Main_Path_Node and End_Boat_2[r] == -1 and r != 0:
                            okc = 0
                            for r2 in Conn_Node[r]:
                                kk = len(In_Boat_2[i]) - len(In_Boat_3[i])
                                if End_Boat_2[r2] < In_Boat_2[i][kk-1][0] and End_Boat_2[r2] != -2   and Near_Main[r2] == r:
                                    okc = 1
                                    break
                            if okc == 0:
                                End_Boat_2[r] = -Num_H
                                Front_in.append(r)
                            if len(Front_in) == needs:
                                break
                    if len(Front_in) == needs:
                        break
                    if len(Junction_Node[Node]) <= 1:
                        Node = Junction_Node[Node][0]
                        empty_cnt = 0
                        Front_vertex.append(Node)
                        for s in Subset_Depth[Node]:
                            if End_Boat_2[s] == -1 and s !=0 :
                                empty_cnt += 1
                        if empty_cnt <= needs - len(Front_in):
                            for r in reversed(Subset_Depth[Node]):
                                if r!= 0 and End_Boat_2[r] == -1:
                                    End_Boat_2[r] = -Num_H
                                    Front_in.append(r)
                                if len(Front_in) == needs:
                                    break
                        if len(Front_in) == needs:
                            break
                    elif len(Junction_Node[Node]) >1 :
                        for n in Junction_Node[Node]:
                            if all(End_Boat_2[x] != -1 for x in Subset_Depth[n]):
                                if  n == Junction_Node[Node][-1]:
                                    toend = 1
                                    break
                            else:
                                empty_cnt = 0
                                for s in Subset_Depth[n]:
                                    if End_Boat_2[s] == -1 and s !=0 :
                                        empty_cnt += 1
                                if empty_cnt > needs - len(Front_in):
                                    Node = n
                                    break
                                elif empty_cnt <= needs - len(Front_in):
                                    Front_vertex.append(n)
                                    if empty_cnt < needs - len(Front_in) and n == Junction_Node[Node][-1]:
                                        toend = 1
                                    for r in reversed(Subset_Depth[n]):
                                        if r!= 0 and End_Boat_2[r] == -1:
                                            End_Boat_2[r] = -Num_H
                                            Front_in.append(r)
                                        if len(Front_in) == needs:
                                            break
                            if len(Front_in) == needs:
                                break
                                    
                            
                Front_in = sorted(Front_in, key= lambda x: Node_Sorted.index(x))
                
                Small_amount = []
                for k in range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i])):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1: 
                        if Dem[In_Boat_2[i][k][1]][1] <= 2:
                            Small_amount.append([In_Boat_2[i][k][0], In_Boat_2[i][k][1]])
                            Loaded[k] = 0
                Small_amount = sorted(Small_amount, key = lambda x : x[0])
                for k in Small_amount:
                    for r in Front_in:
                        if -End_Boat_2[r] >= k[0]:
                            End_Boat_2[r] = k[0]
                            Num_Boat_2[r] = k[1]
                            Node = r
                            Node_queue_1 = [[r]]
                            Cost += Fixed_Cost
                            while(Node != 0):
                                Check = 0
                                Cost += 1
                                Node = Near_Main[Node]
                                Node_queue_1[0].append(Node)
                            Node_queue_1[0].reverse()
                            Node_queue_1.append(k[1])
                            Node_queue_2.append(Node_queue_1)
                            break
                
                for k in reversed(range(Cnt, len(In_Boat_2[i]) - len(In_Boat_3[i]))):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1: 
                        for r in reversed(Front_in):
                            if -End_Boat_2[r] >= In_Boat_2[i][k][0] :
                                End_Boat_2[r] = In_Boat_2[i][k][0]
                                Num_Boat_2[r] = In_Boat_2[i][k][1]
                                Node = r
                                Node_queue_1 = [[r]]
                                Cost += Fixed_Cost
                                while(Node != 0):
                                    Check = 0
                                    Cost += 1
                                    Node = Near_Main[Node]
                                    Node_queue_1[0].append(Node)
                                Loaded[k] = 0
                                Node_queue_1[0].reverse()
                                Node_queue_1.append(In_Boat_2[i][k][1])
                                Node_queue_2.append(Node_queue_1)
                                break
                for k in range(len(In_Boat_2[i])):
                    if Loaded[k] == 0:
                        continue
                    if Loaded[k] == -1:
                        for r in Node_Sorted:
                            if End_Boat_2[r] == -1:
                                End_Boat_2[r] = In_Boat_2[i][k][0]
                                Num_Boat_2[r] = In_Boat_2[i][k][1]
                                Node = r
                                Node_queue_1 = [[r]]
                                Cost += Fixed_Cost
                                while(Node != 0):
                                    Check = 0
                                    Cost += 1
                                    Node = Near_Main[Node]
                                    Node_queue_1[0].append(Node)
                                Loaded[k] = 0
                                Node_queue_1[0].reverse()
                                Node_queue_1.append(In_Boat_2[i][k][1])
                                Node_queue_2.append(Node_queue_1)
                                Unload_Boat[r] = 0
                                Unload_Boat_2[r] = 3
                                break               
                for k in reversed(Node_Sorted):
                    if End_Boat_2[k] == i+1:
                        Unload_Boat[k] = 0
                    if Unload_Boat[k] == 0:
                        Node = k
                        p_path = [Node]
                        while(Node != 0):
                            Node = Near_Main[Node]
                            p_path.append(Node)
                        for pp in p_path:
                            if End_Boat_2[pp] != -1 and pp != 0:
                                Unload_Boat[pp] = 0
                
                Node_queue = sorted(Node_queue, key = lambda x : Node_Sorted.index(x[0][-1]), reverse=True)
                Node_queue_Total = []
                for k in Node_queue:
                    Node_queue_Total.append(k)
                for k in reversed(Node_queue_3):
                    Node_queue_Total.append(k)
                for k in reversed(Node_queue_2):
                    Node_queue_Total.append(k)
                Node_queue_Total = sorted(Node_queue_Total, key = lambda x : Node_Sorted.index(x[0][-1]), reverse=True)
                for k in Node_queue_Total:
                    List_Out.append(k)
        
            solution[i].extend(List_Out)  
        
    
    return solution

if __name__ == "__main__":
    # You can run this file to test your algorithm from terminal.

    import json
    import os
    import sys
    import jsbeautifier
    


    def numpy_to_python(obj):
        if isinstance(obj, np.int64) or isinstance(obj, np.int32):
            return int(obj)  
        if isinstance(obj, np.float64) or isinstance(obj, np.float32):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        
        raise TypeError(f"Type {type(obj)} not serializable")
    
    
    # Arguments list should be problem_name, problem_file, timelimit (in seconds)
    if len(sys.argv) == 4:
        prob_name = sys.argv[1]
        prob_file = sys.argv[2]
        timelimit = int(sys.argv[3])

        with open(prob_file, 'r') as f:
            prob_info = json.load(f)

        exception = None
        solution = None

        try:

            alg_start_time = time.time()

            # Run algorithm!
            solution = algorithm(prob_info, timelimit)

            alg_end_time = time.time()


            checked_solution = util.check_feasibility(prob_info, solution)

            checked_solution['time'] = alg_end_time - alg_start_time
            checked_solution['timelimit_exception'] = (alg_end_time - alg_start_time) > timelimit + 2 # allowing additional 2 second!
            checked_solution['exception'] = exception

            checked_solution['prob_name'] = prob_name
            checked_solution['prob_file'] = prob_file


            with open('results.json', 'w') as f:
                opts = jsbeautifier.default_options()
                opts.indent_size = 2
                f.write(jsbeautifier.beautify(json.dumps(checked_solution, default=numpy_to_python), opts))
                print(f'Results are saved as file results.json')
                
            sys.exit(0)

        except Exception as e:
            print(f"Exception: {repr(e)}")
            sys.exit(1)

    else:
        print("Usage: python myalgorithm.py <problem_name> <problem_file> <timelimit_in_seconds>")
        sys.exit(2)

