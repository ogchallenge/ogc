import time
import util
import numpy as np

from two_stage_model import two_stage_optimize_rolling_final


def algorithm(prob_info, timelimit=60):
    """
    This is a template for the custom algorithm.
    The algorithm should return a solution that is a list of (route, k) pairs.
    Each route is a list of node indices, and k is the index of the demand that is moved by the route.
    You CANNOT change or remove this function signature.
    But it is fine to define extra functions or mudules that are used in this function.
    """


    # ------------- begin of custom algorithm code --------------#

    return two_stage_optimize_rolling_final(prob_info, timelimit)



if __name__ == "__main__":
    # You can run this file to test your algorithm from terminal.

    import json
    import sys
    import jsbeautifier


    def numpy_to_python(obj):
        if isinstance(obj, np.int64) or isinstance(obj, np.int32):
            return int(obj)
        if isinstance(obj, np.float64) or isinstance(obj, np.float32):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()

        raise TypeError(f"Type {type(obj)} not serializable")


    # Arguments list should be problem_name, problem_file, timelimit (in seconds)
    if len(sys.argv) == 4:
        prob_name = sys.argv[1]
        prob_file = sys.argv[2]
        timelimit = int(sys.argv[3])

        with open(prob_file, 'r') as f:
            prob_info = json.load(f)

        exception = None
        solution = None

        try:

            alg_start_time = time.time()

            # Run algorithm!
            solution = algorithm(prob_info, timelimit)

            alg_end_time = time.time()

            checked_solution = util.check_feasibility(prob_info, solution)

            checked_solution['time'] = alg_end_time - alg_start_time
            checked_solution['timelimit_exception'] = (
                                                              alg_end_time - alg_start_time) > timelimit + 2  # allowing additional 2 second!
            checked_solution['exception'] = exception

            checked_solution['prob_name'] = prob_name
            checked_solution['prob_file'] = prob_file

            with open('results.json', 'w') as f:
                opts = jsbeautifier.default_options()
                opts.indent_size = 2
                f.write(jsbeautifier.beautify(json.dumps(checked_solution, default=numpy_to_python), opts))
                print(f'Results are saved as file results.json')

            sys.exit(0)

        except Exception as e:
            print(f"Exception: {repr(e)}")
            sys.exit(1)

    else:
        print("Usage: python myalgorithm.py <problem_name> <problem_file> <timelimit_in_seconds>")
        sys.exit(2)
