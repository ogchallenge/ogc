import heapq
import time
from collections import deque
from typing import Tuple
import gurobipy as gp
import numpy as np
from gurobipy import GRB



def pack_pair(a: int, b: int) -> int:
    if a > b:
        a, b = b, a
    return ((a & 0xFFFFFFFF) << 32) | (b & 0xFFFFFFFF)


def unpack(k: int) -> Tuple[int, int]:
    return ((k >> 32) & 0xFFFFFFFF, k & 0xFFFFFFFF)


class NodeInform:
    def __init__(self, n, route):
        self.pos = n
        self.route: list[int] = route


class Node:
    def __init__(self, pos, dist, score):
        self.pos = pos
        self.dist = dist
        self.score = score

    def __repr__(self):
        return f"pos_{self.pos} dist_{self.dist} score_{self.score}"


class DemandInform:
    def __init__(self, id, interval, qty):
        self.id = id
        self.in_p = interval[0]
        self.out_p = interval[1]
        self.s = 2 * interval[0]
        self.e = 2 * interval[1] - 1
        self.duration = interval[1] - interval[0]
        self.pos = []
        self.qty = qty
        self.num = qty
        self.check = False

    def __repr__(self):
        return f"id_{self.id} in_{self.in_p} out_{self.out_p} num_{self.num} qty_{self.qty}"


def bfs(edge, N):
    cost = [0] * N  # 방문한 노드 기록
    pred = [0] * N
    queue = deque([0])  # BFS는 큐 사용
    cost[0] = 1
    while queue:
        node = queue.popleft()
        for n_node in edge[node]:
            if not cost[n_node]:
                pred[n_node] = node
                cost[n_node] = cost[node] + 1
                queue.extend([n_node])  # 인접 노드 큐에 추가
    return cost, pred


def search_avail_node(rm2, edge, visit_map, t):
    queue = deque()  # BFS는 큐 사용
    queue.append(0)
    rm2[0, t] = -2
    while queue:
        node = queue.popleft()
        for n_node in edge[node]:
            if rm2[n_node, t] >= 0:
                if rm2[n_node, t] > 0:
                    visit_map[(n_node, t)] = 1
                rm2[n_node, t] = -2
                queue.append(n_node)  # 인접 노드 큐에 추가


def search_necessary_block(bm, edge, cost, visit_map, s_sol, start, t, p):
    queue = deque()  # BFS는 큐 사용
    queue.append(start)
    bm[start, t] = -2
    while queue:
        node = queue.popleft()
        for n_node in edge[node]:
            if (n_node, p) in s_sol and cost[n_node] < cost[node]:
                if bm[n_node, t] == -3:
                    continue
                s_sol[(n_node, p)] = 1
                bm[n_node, t] = -3
                queue.append(n_node)

            if bm[n_node, t] >= 0:
                if bm[n_node, t] > 0:
                    visit_map[(n_node, t)] = 1
                bm[n_node, t] = -2
                queue.append(n_node)  # 인접 노드 큐에 추가


def p_to_in(p):
    return 2 * p


def p_to_out(p):
    return 2 * p - 1


def in_to_p(t):
    return t // 2


def out_to_p(t):
    return (t + 1) // 2


def get_port_qty(dl, P):
    port_qty = [0] * P
    in_port_qty = [0] * P
    out_port_qty = [0] * P

    for d in dl:
        in_port_qty[d.in_p] += d.num
        out_port_qty[d.out_p] += d.num
    for p in range(P):
        port_qty[p] = in_port_qty[p] + out_port_qty[p]

    return port_qty


class Optimize_Model:
    def __init__(self, prob_info, dl, cost, pred):
        self.N = prob_info['N']
        self.E = prob_info['E']
        self.D = prob_info['K']
        self.P = prob_info['P']
        self.F = prob_info['F']
        self.dl = dl
        self.dl_n = [[] for _ in range(self.N)]
        self.out_mat = np.zeros((self.P, self.P), dtype=int)
        self.out_count_mat = np.zeros((self.P, self.P), dtype=int)
        self.pre_qty = [0] * self.P
        for d in dl:
            self.out_mat[d.duration, d.out_p] += d.qty

        self.duration_sum = np.sum(self.out_mat, axis=1)
        self.cost = cost
        self.E_ = []
        self.adj = [[] for _ in range(self.N)]
        self.in_edge = [[] for _ in range(self.N)]
        self.out_edge = [[] for _ in range(self.N)]
        self.state_mat = np.zeros((self.N, self.P), dtype=int)
        self.empty_mat = np.zeros((self.N, self.P), dtype=int)
        self.sol_mat = np.zeros((self.N, self.P), dtype=int)
        self._reduced_graph()

    def _reduced_graph(self):
        for i, j in self.E:
            if j:
                self.adj[i].append(j)
            self.adj[j].append(i)

            if self.cost[i] < self.cost[j]:
                self.in_edge[j].append(i)
                self.out_edge[i].append(j)
                self.E_.append((i, j))
            else:
                self.in_edge[i].append(j)
                self.out_edge[j].append(i)
                self.E_.append((j, i))

    def is_insert_feasible(self, i, p):
        if not self.out_edge[i]:
            return True
        cnt = 0
        visit = [0] * self.N
        for j in self.out_edge[i]:
            if self.state_mat[j, p] >= 0:
                visit[j] = -1
                cnt += 1

        queue = deque()
        for j in self.in_edge[i]:
            if self.state_mat[j, p] >= 0:
                visit[j] = 2
                queue.append(j)

        visit[i] = 1
        target = 0
        while queue:
            current_node = queue.popleft()
            for next_node in self.out_edge[current_node]:
                if self.state_mat[next_node, p] >= 0 and visit[next_node] < 1:
                    if visit[next_node] == -1:
                        target += 1
                    visit[next_node] = visit[current_node] + 1
                    if visit[next_node] <= 8:
                        queue.append(next_node)

        if cnt == target:
            return True
        else:
            return False

    def solve_relax(self, d_list, opt_range):
        s_mat = np.full((self.N, self.P), 1)
        s_range = []
        for p in opt_range:
            queue = deque([0])
            s_mat[0, p] = 0
            while queue:
                current_node = queue.popleft()
                for next_node in self.out_edge[current_node]:
                    if self.state_mat[next_node, p] >= 0 and s_mat[next_node, p]:
                        s_mat[next_node, p] = 0
                        queue.append(next_node)
        for d in self.dl:
            for i in d.pos:
                for p in range(d.in_p, d.out_p):
                    if not s_mat[i, p]:
                        s_mat[i, p] = 1

        for i in range(self.N):
            for p in opt_range:
                if s_mat[i, p]:
                    s_range.append((i, p))

        y_list = [(d.id, i) for d in d_list for i in range(1, self.N)]

        model = gp.Model()
        s = model.addVars(s_range, vtype=GRB.BINARY, name='s')
        y = model.addVars(y_list, vtype=GRB.BINARY, name='y')

        for i in range(1, self.N):
            for p in opt_range:
                if s_mat[i, p]:
                    model.addConstr(
                        gp.quicksum(y[d.id, i] for d in d_list if d.in_p <= p < d.out_p) <= s[i, p])
                else:
                    model.addConstr(
                        gp.quicksum(y[d.id, i] for d in d_list if d.in_p <= p < d.out_p) <= 1)

        model.addConstrs(
            gp.quicksum(y[d.id, i] for i in range(1, self.N)) == d.num for d
            in d_list)
        model.setObjective(
            gp.quicksum(self.cost[i] * y[d, i] for d, i in y_list) + gp.quicksum(self.F * s[i, p] for i, p in s_range))
        model.setParam("OutputFlag", 0)
        model.optimize()
        if model.status != GRB.status.INFEASIBLE:
            # ss = [(i, p) for i, p in s_range if s[i, p].X > 0.5]
            # print("@@@@@@@@@@", len(ss), ss)
            # if len(ss):
            #     print(len(ss), ss)
            return [(d, i) for d, i in y_list if y[d, i].X > 0.5], [(i, p) for i, p in s_range if s[i, p].X > 0.5]
        else:
            print("RELAX 모델 에러")
            quit()

    def solve_sub_model(self, _d_list, y_start, port_qty, opt_range, time_limit):
        d_list = [d for d in _d_list if d.num]
        y_list = []
        s_range = []
        for i in range(1, self.N):
            for d in d_list:
                if self.empty_mat[i, d.in_p] > d.duration:
                    y_list.append((d.id, i))

            for p in opt_range:
                if self.state_mat[i, p] >= 0:
                    s_range.append((i, p))

        f_range = [(i, j, p) for i, j in self.E_ for p in opt_range if
                   self.state_mat[i, p] >= 0 and self.state_mat[j, p] >= 0]
        model = gp.Model()
        f = model.addVars(f_range, vtype=GRB.INTEGER, name='f')
        y = model.addVars(y_list, vtype=GRB.BINARY, name='y')
        for d, i in y_start:
            if (d, i) in y_list:
                y[d, i].Start = 1

        s = model.addVars(s_range, vtype=GRB.BINARY, name='s')

        for d in d_list:
            qty_base = gp.quicksum(y[d.id, i] for i in range(1, self.N) if self.empty_mat[i, d.in_p] > d.duration)
            model.addConstr(qty_base == d.num)

        model.addConstrs(
            gp.quicksum(
                y[d.id, i] for d in d_list if d.in_p <= p < d.out_p and self.empty_mat[i, d.in_p] > d.duration) <= 1
            for i in
            range(1, self.N) for p in
            opt_range)
        model.addConstrs(
            gp.quicksum(y[d.id, i] for i in range(1, self.N) if self.empty_mat[i, d.in_p] > d.duration) == d.num for d
            in d_list)

        for i in range(1, self.N):
            for p in opt_range:
                if self.state_mat[i, p] < 0:
                    continue

                in_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (p == d.in_p) and self.empty_mat[i, d.in_p] > d.duration)
                out_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (p == d.out_p) and self.empty_mat[i, d.in_p] > d.duration)

                pre = self.state_mat[i, p]
                model.addConstr(
                    gp.quicksum(f[j, i, p] for j in self.in_edge[i] if self.state_mat[j, p] >= 0) - gp.quicksum(
                        f[i, j, p] for j in self.out_edge[i] if self.state_mat[j, p] >= 0) == in_pos + out_pos + pre)
                block_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (d.in_p < p < d.out_p) and self.empty_mat[i, d.in_p] > d.duration)
                model.addConstr(
                    gp.quicksum(f[j, i, p] for j in self.in_edge[i] if self.state_mat[j, p] >= 0) <= (
                            port_qty[p] + self.pre_qty[p]) * (
                            1 - block_pos + s[i, p]))

        model.addConstrs(
            gp.quicksum(f[0, j, p] for j in self.out_edge[0] if self.state_mat[j, p] >= 0) == (
                    port_qty[p] + self.pre_qty[p]) for p in
            opt_range)
        model.setObjective(gp.quicksum(f[i, j, p] for i, j, p in f_range) + gp.quicksum(
            2 * self.F * s[i, p] for i, p in s_range))
        model.setParam('TimeLimit', time_limit)
        model.Params.MIPGap = 0.05
        model.setParam("OutputFlag", 0)
        model.optimize()
        if model.Status != GRB.status.INFEASIBLE:
            s_sol = {(i, p): 0 for i, p in s_range if s[i, p].X > 0.5}
            y_sol = [(d, i) for d, i in y_list if y[d, i].X > 0.5]
            return True, y_sol, s_sol
        else:
            print("SUB 불가")
            return False, [], []

    def solve_relax_max_model(self, d_list):
        y_list = [(d.id, i) for d in d_list for i in range(1, self.N)]
        model = gp.Model()
        y = model.addVars(y_list, vtype=GRB.BINARY, name='y')
        s = model.addVars(range(1, self.N), range(self.P), vtype=GRB.BINARY, name='s')
        model.addConstrs(
            gp.quicksum(y[d.id, i] for d in d_list if d.in_p <= p < d.out_p) <= 1 + s[i, p]
            for i in
            range(1, self.N) for p in range(self.P))
        model.addConstrs(
            gp.quicksum(y[d.id, i] for i in range(1, self.N)) == d.qty for d in d_list)
        model.setObjective(
            gp.quicksum(-self.cost[i] * y[d, i] for d, i in y_list) + 2 * self.F * gp.quicksum(
                s[i, p] for i in range(1, self.N) for p in range(self.P)))
        model.setParam("OutputFlag", 0)
        model.optimize()
        if model.status == GRB.OPTIMAL:
            # print([(i, p) for i in range(1, self.N) for p in range(self.P) if s[i, p].X > 0.5])
            return [(d, i) for d, i in y_list if y[d, i].X > 0.5]
        else:
            raise IOError("relax 불가")

    def solve_max_model(self, d_list, y_start, port_qty):
        y_list = [(d.id, i) for d in d_list for i in range(1, self.N)]
        f_range = [(i, j, p) for i, j in self.E_ for p in range(self.P)]
        model = gp.Model()
        f = model.addVars(f_range, vtype=GRB.INTEGER, name='f')
        y = model.addVars(y_list, vtype=GRB.BINARY, name='y')
        for d, i in y_start:
            if (d, i) in y_list:
                y[d, i].Start = 1
        s = model.addVars(range(1, self.N), range(self.P), vtype=GRB.BINARY, name='s')

        for d in d_list:
            qty_base = gp.quicksum(y[d.id, i] for i in range(1, self.N))
            model.addConstr(qty_base == d.qty)

        model.addConstrs(
            gp.quicksum(y[d.id, i] for d in d_list if d.in_p <= p < d.out_p) <= 1 for i in
            range(1, self.N) for p in
            range(self.P))
        model.addConstrs(
            gp.quicksum(y[d.id, i] for i in range(1, self.N)) == d.qty for d in d_list)

        for i in range(1, self.N):
            for p in range(self.P):
                # 가능한 지점에 대해 생성(rehandling 없음)
                in_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (p == d.in_p))
                out_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (p == d.out_p))
                model.addConstr(gp.quicksum(f[j, i, p] for j in self.in_edge[i]) - gp.quicksum(
                    f[i, j, p] for j in self.out_edge[i]) == in_pos + out_pos)
                block_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (d.in_p < p < d.out_p))
                model.addConstr(
                    gp.quicksum(f[j, i, p] for j in self.in_edge[i]) <= port_qty[p] * (1 - block_pos + s[i, p]))

        model.addConstrs(gp.quicksum(f[0, j, p] for j in self.out_edge[0]) == port_qty[p] for p in range(self.P))
        model.setObjective(-gp.quicksum(f[i, j, p] for i, j, p in f_range) + gp.quicksum(
            2 * self.F * s[i, p] for i in range(1, self.N) for p in range(self.P)))
        model.Params.MIPGap = 0.05
        model.setParam("OutputFlag", 0)
        model.optimize()
        y_sol = [(d, i) for d, i in y_list if y[d, i].X > 0.5]
        return y_sol

    def solve_long_duration(self):
        acc = 0
        bound = 0
        max_ = (self.P // 2)
        for p in range(self.P - 1, max_ - 1, -1):
            acc += self.duration_sum[p]
            bound = p
            if acc >= 150:
                break

        if not acc:
            return 0

        d_list = [d for d in self.dl if d.duration >= bound and d.num]
        port_qty = get_port_qty(d_list, self.P)
        y_start = self.solve_relax_max_model(d_list)
        y_sol = self.solve_max_model(d_list, y_start, port_qty)

        if bound > max_ and self.duration_sum[max_: bound]:
            d_list = [d for d in self.dl if d.duration >= max_]
            port_qty = get_port_qty(d_list, self.P)
            y_sol = self.solve_max_model(d_list, y_sol, port_qty)
        d_list.sort(key=lambda x: x.duration)

        if len(d_list) > 2:
            criteria = d_list[2].duration
        else:
            criteria = d_list[0].duration

        for d, i in y_sol:
            if self.dl[d].duration >= criteria:
                self.add_mat(d, i)

        self.remove_block()

    def remove_block(self):
        penalty = 1000
        for p in range(self.P):
            dist = [999999] * self.N
            prev = [0] * self.N  # i노드 전 노드 기록
            dist[0] = 0
            pq = [(0, 0)]
            while pq:
                current_dist, u = heapq.heappop(pq)

                # 이미 더 짧은 경로로 처리된 경우 스킵
                if current_dist > dist[u]:
                    continue

                # 이웃 노드 확인
                for v in self.out_edge[u]:
                    weight = 1 if self.state_mat[v, p] >= 0 else (penalty + 1)
                    alt = current_dist + weight
                    if alt < dist[v]:
                        dist[v] = alt
                        prev[v] = u
                        heapq.heappush(pq, (alt, v))

            block_list = [i for i in range(1, self.N) if dist[i] >= penalty and self.state_mat[i, p] > 0]
            if block_list:
                boundary_blocked = []
                for v in block_list:
                    for i in self.in_edge[v]:
                        if self.state_mat[i, p] < 0:
                            boundary_blocked.append(v)
                            break

                visit_b = [0] * self.N
                for v in boundary_blocked:
                    pre_ = prev[v]
                    while pre_:
                        if visit_b[pre_]:
                            break
                        if self.state_mat[pre_, p] < 0:
                            self.remove_mat(pre_, p)
                        visit_b[pre_] = 1
                        pre_ = prev[pre_]

    def remove_block2(self):
        penalty = 1000
        for p in range(self.P):
            dist = [999999] * self.N
            prev = [0] * self.N  # i노드 전 노드 기록
            dist[0] = 0
            pq = [(0, 0)]
            while pq:
                current_dist, u = heapq.heappop(pq)

                # 이미 더 짧은 경로로 처리된 경우 스킵
                if current_dist > dist[u]:
                    continue

                # 이웃 노드 확인
                for v in self.out_edge[u]:
                    weight = 1 if self.state_mat[v, p] >= 0 else (penalty + 1)
                    alt = current_dist + weight
                    if alt < dist[v]:
                        dist[v] = alt
                        prev[v] = u
                        heapq.heappush(pq, (alt, v))

            block_list = [i for i in range(1, self.N) if dist[i] >= penalty and self.state_mat[i, p] >= 0]
            if block_list:
                boundary_blocked = []
                for v in block_list:
                    for i in self.in_edge[v]:
                        if self.state_mat[i, p] < 0:
                            boundary_blocked.append(v)
                            break

                visit_b = [0] * self.N
                for v in boundary_blocked:
                    pre_ = prev[v]
                    while pre_:
                        if visit_b[pre_]:
                            break
                        if self.state_mat[pre_, p] < 0:
                            self.remove_mat(pre_, p)
                        visit_b[pre_] = 1
                        pre_ = prev[pre_]

    def update_empty(self):
        self.empty_mat[:] = 0
        for i in range(1, self.N):
            self.update_empty_row(i)

    def update_empty_row(self, i):
        self.empty_mat[i, self.P - 1] = 1
        for p in range(self.P - 2, -1, -1):
            if self.state_mat[i, p] > 0 and self.state_mat[i, p + 1] == 0:
                self.empty_mat[i, p] = self.empty_mat[i, p + 1] + 1
            elif self.state_mat[i, p] > 0:
                self.empty_mat[i, p] = 1
            elif self.state_mat[i, p] == 0:
                self.empty_mat[i, p] = self.empty_mat[i, p + 1] + 1
            elif self.state_mat[i, p] == -1:
                self.empty_mat[i, p] = 0
            else:
                print(self.empty_mat[i, p])
                raise IOError("empty 에러")

    def remove_demand(self, d, i):
        self.remove_mat(i, d.in_p + 1)
        self.update_empty_row(i)

    def remove_mat(self, i, p):
        if self.state_mat[i, p] == 0:
            return

        if self.state_mat[i, p] == 2:
            a, b = unpack(self.sol_mat[i, p])
            if self.dl[a - 1].in_p <= p < self.dl[a - 1].out_p:
                self.remove_update(i, a - 1)
            if self.dl[b - 1].in_p <= p < self.dl[b - 1].out_p:
                self.remove_update(i, b - 1)
        elif self.state_mat[i, p]:
            _, b = unpack(self.sol_mat[i, p])
            d = b - 1
            self.remove_update(i, d)

    def remove_update(self, i, d):
        self.dl[d].pos.remove(i)
        self.pre_qty[self.dl[d].in_p] -= 1
        self.pre_qty[self.dl[d].out_p] -= 1
        self.dl[d].num += 1
        self.dl_n[i].remove(d)
        self.state_mat[i, self.dl[d].in_p] -= 1
        self.state_mat[i, self.dl[d].out_p] -= 1
        self.state_mat[i, self.dl[d].in_p + 1:self.dl[d].out_p] = 0
        self.sol_mat[i, self.dl[d].in_p + 1: self.dl[d].out_p] = 0

        a, b = unpack(self.sol_mat[i, self.dl[d].in_p])
        c = a if b - 1 == d else b
        self.sol_mat[i, self.dl[d].in_p] = c
        a, b = unpack(self.sol_mat[i, self.dl[d].out_p])
        c = a if b - 1 == d else b
        self.sol_mat[i, self.dl[d].out_p] = c

    def add_mat(self, d, i):
        self.pre_qty[self.dl[d].in_p] += 1
        self.pre_qty[self.dl[d].out_p] += 1
        self.dl_n[i].append(d)
        self.dl[d].pos.append(i)
        self.dl[d].num -= 1
        self.state_mat[i, self.dl[d].in_p] += 1
        self.state_mat[i, self.dl[d].out_p] += 1
        self.state_mat[i, self.dl[d].in_p + 1:self.dl[d].out_p] = -1
        self.sol_mat[i, self.dl[d].in_p + 1: self.dl[d].out_p] = d + 1
        if self.sol_mat[i, self.dl[d].in_p]:
            d1, d2 = unpack(self.sol_mat[i, self.dl[d].in_p])
            self.sol_mat[i, self.dl[d].in_p] = pack_pair(d2, d + 1)
        else:
            self.sol_mat[i, self.dl[d].in_p] = pack_pair(d + 1, 0)

        if self.sol_mat[i, self.dl[d].out_p]:
            d1, d2 = unpack(self.sol_mat[i, self.dl[d].out_p])
            self.sol_mat[i, self.dl[d].out_p] = pack_pair(d2, d + 1)
        else:
            self.sol_mat[i, self.dl[d].out_p] = pack_pair(d + 1, 0)

    def calc_out_mat(self, k):
        self.out_mat[:] = 0
        self.out_count_mat[:] = 0
        for d in self.dl:
            if d.duration <= k:
                if d.num:
                    self.out_mat[d.duration, d.out_p] = d.num
                    self.out_count_mat[d.duration, d.out_p] = 1
            else:
                self.out_mat[d.duration, d.out_p] = d.qty
                self.out_count_mat[d.duration, d.out_p] = 1
        self.out_count_mat = np.cumsum(self.out_count_mat, axis=0)
        self.out_mat = np.cumsum(self.out_mat, axis=0)

    def get_optimize_point(self, dur, e):
        break_flag = False
        s = cur_dur = 0
        for i in range(dur, self.P):
            for j in range(i + e, self.P - 1):
                if self.out_count_mat[i, j]:
                    if np.sum(self.out_count_mat[i, j - i:j + 1]) >= 3 and np.sum(self.out_mat[i, j - i:j + 1]) >= 40:
                        s = j - i
                        e = j
                        cur_dur = i
                        if all(d.check for d in self.dl if s <= d.in_p <= d.out_p < e and d.duration <= cur_dur):
                            continue

                        break_flag = True
                        break
            if break_flag:
                break
            e = 0
        if not break_flag:
            return 0, self.P, self.P

        return s, e, cur_dur

    def optimize_flow2(self, d_list, opt_range):
        while True:
            while True:
                y_start, s_sol = self.solve_relax(d_list, opt_range)
                if s_sol:
                    for i, p in s_sol:
                        self.remove_mat(i, p)
                    self.remove_block2()
                    self.update_empty()
                    d_list = [d for d in self.dl if d.num]
                else:
                    break

            port_qty = get_port_qty(d_list, self.P)
            s_flag, y_sol, s_sol = self.solve_sub_model(d_list, y_start, port_qty, opt_range, 30)
            if s_flag:
                return y_sol, s_sol
            print("재시작")
            self.remove_block2()
            self.update_empty()

    def optimize_flow(self, d_list, opt_range):
        while True:
            y_start, s_sol = self.solve_relax(d_list, opt_range)
            if s_sol:
                for i, p in s_sol:
                    self.remove_mat(i, p)
                self.remove_block2()
                self.update_empty()

            port_qty = get_port_qty(d_list, self.P)
            s_flag, y_sol, s_sol = self.solve_sub_model(d_list, y_start, port_qty, opt_range, 30)
            if s_flag:
                return y_sol, s_sol
            print("재시작")
            self.remove_block2()
            self.update_empty()

    def solve_model(self, d_list, y_start, port_qty, time_limit):
        y_list = [(d.id, i) for d in d_list for i in range(1, self.N)]
        opt_range = range(self.P)
        f_range = [(i, j, p) for i, j in self.E_ for p in opt_range]
        model = gp.Model()
        f = model.addVars(f_range, vtype=GRB.INTEGER, name='f')
        y = model.addVars(y_list, vtype=GRB.BINARY, name='y')
        for d, i in y_start:
            y[d, i].Start = 1
        s = model.addVars(range(1, self.N), range(self.P), vtype=GRB.BINARY, name='s')

        model.addConstrs(
            gp.quicksum(y[d.id, i] for i in range(1, self.N)) == d.qty for d in d_list)
        model.addConstrs(
            gp.quicksum(y[d.id, i] for d in d_list if d.in_p <= p < d.out_p) <= 1 for i in
            range(1, self.N) for p in
            opt_range)

        for i in range(1, self.N):
            for p in opt_range:
                # 가능한 지점에 대해 생성(rehandling 없음)
                in_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (p == d.in_p))
                out_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (p == d.out_p))
                model.addConstr(gp.quicksum(f[j, i, p] for j in self.in_edge[i]) - gp.quicksum(
                    f[i, j, p] for j in self.out_edge[i]) == in_pos + out_pos)

                block_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (d.in_p < p < d.out_p))
                model.addConstr(
                    gp.quicksum(f[j, i, p] for j in self.in_edge[i]) <= port_qty[p] * (1 - block_pos + s[i, p]))
        model.addConstrs(gp.quicksum(f[0, j, p] for j in self.out_edge[0]) == port_qty[p] for p in opt_range)
        model.setObjective(gp.quicksum(f[i, j, p] for i, j, p in f_range) + gp.quicksum(
            2 * self.F * s[i, p] for i in range(1, self.N) for p in opt_range))
        model.setParam('TimeLimit', time_limit)
        model.setParam("OutputFlag", 0)
        model.optimize()
        s_sol = {(i, t): 0 for i in range(1, self.N) for t in opt_range if s[i, t].X > 0.5}
        y_sol = [(d, i) for d, i in y_list if y[d, i].X > 0.5]
        return y_sol, s_sol

    def run(self, timelimit):
        sst = time.time()
        self.solve_long_duration()
        self.update_empty()
        p_half = self.P // 2
        ite = 0
        dur = 3
        e = 0
        # 초기 위치 설정
        self.calc_out_mat(dur)
        s, e, cur_dur = self.get_optimize_point(dur, e)
        time_flag = timelimit // 2

        while True:
            if timelimit - (time.time() - sst) < time_flag:
                break

            horizon_size = min(cur_dur, self.P // 2)
            d_list = [d for d in self.dl if s <= d.in_p <= d.out_p < e + horizon_size and d.duration <= cur_dur + 2]
            sum_num = sum(d.num for d in d_list)
            while sum_num > 250:
                d1 = d_list.pop()
                sum_num -= d1.num
            for d in d_list:
                if not d.check and d.duration >= p_half and d.pos:
                    for i in d.pos:
                        self.remove_demand(d, i)

            et = min(e + horizon_size, self.P)
            opt_range = range(s, et)
            y_sol, s_sol = self.optimize_flow(d_list, opt_range)

            for d, i in y_sol:
                if et == self.P or self.dl[d].duration <= cur_dur and s <= self.dl[d].in_p <= self.dl[
                    d].out_p <= e:
                    self.dl[d].check = True
                    self.add_mat(d, i)

            for i, p in s_sol:
                self.remove_mat(i, p)

            if s == 0 and et == self.P and cur_dur == self.P:
                self.remove_block()
                self.update_empty()
                self.calc_out_mat(cur_dur)
                break
            else:
                self.remove_block()
                self.update_empty()
                self.calc_out_mat(cur_dur)
            ite += 1
            s, e, cur_dur = self.get_optimize_point(cur_dur, e + cur_dur + 1)

        d_list = [d for d in self.dl if d.num]
        while d_list:
            print("Last ====================")
            opt_range = range(self.P)
            y_sol, _ = self.optimize_flow2(d_list, opt_range)
            for d, i in y_sol:
                self.dl[d].check = True
                self.add_mat(d, i)
            d_list = [d for d in self.dl if d.num]
            if d_list:
                print("QQ", d_list)
                self.remove_block2()
                self.update_empty()
            else:
                break

        port_qty = [0] * self.P
        in_port_qty = [0] * self.P
        out_port_qty = [0] * self.P

        for d in self.dl:
            in_port_qty[d.in_p] += d.qty
            out_port_qty[d.out_p] += d.qty
        for p in range(self.P):
            port_qty[p] = in_port_qty[p] + out_port_qty[p]

        y_start = []
        for i in range(1, self.N):
            visit = [0] * len(self.dl)
            for p in range(self.P):
                a, b = unpack(self.sol_mat[i, p])
                if a > 0 and not visit[a - 1]:
                    y_start.append((a - 1, i))
                    visit[a - 1] = 1
                if b > 0 and not visit[b - 1]:
                    y_start.append((b - 1, i))
                    visit[b - 1] = 1

        port_qty = get_port_qty2(self.dl, self.P)

        s_start = self.optimize_s2(port_qty, y_start)
        y_sol, s_sol = self.solve_main_model(self.dl, y_start, s_start, port_qty, timelimit - (time.time() - sst) - 1)
        elapsed = round(time.time() - sst, 2)
        print(f"elapsed : {elapsed}")
        return y_sol, s_sol

    def optimize_s2(self, port_qty, y_start):
        opt_range = range(self.P)
        fm = np.zeros((self.N, self.P), dtype=int)
        for d, i in y_start:
            fm[i, self.dl[d].in_p] += 1
            fm[i, self.dl[d].out_p] += 1
            fm[i, self.dl[d].in_p + 1:self.dl[d].out_p] = -1

        s_range = [(i, p) for i in range(1, self.N) for p in opt_range]
        f_range = [(i, j, p) for i, j in self.E for p in range(self.P) if i and j] + [(j, i, p) for i, j in self.E for p
                                                                                      in range(self.P) if
                                                                                      i and j]
        f_range += [(0, i, p) for i in self.adj[0] for p in range(self.P)]
        model = gp.Model()
        f = model.addVars(f_range, vtype=GRB.INTEGER, name='f')
        s = model.addVars(s_range, vtype=GRB.BINARY, name='s')

        for i in range(1, self.N):
            for p in range(self.P):
                model.addConstr(gp.quicksum(f[j, i, p] for j in self.adj[i]) - gp.quicksum(
                    f[i, j, p] for j in self.adj[i] if j) == max(fm[i, p], 0))  # 2, 1 또는 0
        model.addConstrs(
            gp.quicksum(f[j, i, p] for j in self.adj[i]) <= port_qty[p] * s[i, p] for i, p in s_range)
        model.addConstrs(gp.quicksum(f[0, j, p] for j in self.adj[0]) == port_qty[p] for p in range(self.P))
        model.setObjective(2 * self.F * gp.quicksum(s[i, p] for i, p in s_range))
        model.setParam("OutputFlag", 0)
        model.setParam('TimeLimit', 3)
        model.optimize()
        s_sol = [(i, p) for i, p in s_range if s[i, p].X > 0.5]
        return s_sol

    def solve_sub_model_direct(self, d_list, y_start, port_qty, opt_range, time_limit):
        y_list = [(d.id, i) for d in d_list for i in range(1, self.N)]
        f_range = [(i, j, p) for i, j in self.E_ for p in opt_range]
        model = gp.Model()
        f = model.addVars(f_range, vtype=GRB.INTEGER, name='f')
        y = model.addVars(y_list, vtype=GRB.BINARY, name='y')
        for d, i in y_start:
            if (d, i) in y_list:
                y[d, i].Start = 1
        s = model.addVars(range(1, self.N), opt_range, vtype=GRB.BINARY, name='s')

        for d in d_list:
            qty_base = gp.quicksum(y[d.id, i] for i in range(1, self.N))
            model.addConstr(qty_base == d.qty)

        model.addConstrs(
            gp.quicksum(y[d.id, i] for d in d_list if d.in_p <= p < d.out_p) <= 1 for i in
            range(1, self.N) for p in
            opt_range)
        model.addConstrs(
            gp.quicksum(y[d.id, i] for i in range(1, self.N)) == d.qty for d in d_list)

        for i in range(1, self.N):
            for p in opt_range:
                # 가능한 지점에 대해 생성(rehandling 없음)
                in_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (p == d.in_p))
                out_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (p == d.out_p))
                model.addConstr(gp.quicksum(f[j, i, p] for j in self.in_edge[i]) - gp.quicksum(
                    f[i, j, p] for j in self.out_edge[i]) == in_pos + out_pos)
                block_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (d.in_p < p < d.out_p))
                model.addConstr(
                    gp.quicksum(f[j, i, p] for j in self.in_edge[i]) <= port_qty[p] * (1 - block_pos + s[i, p]))

        model.addConstrs(gp.quicksum(f[0, j, p] for j in self.out_edge[0]) == port_qty[p] for p in opt_range)
        # model.setObjective(-gp.quicksum(f[i, j, p] for i, j, p in f_range) + gp.quicksum(
        #     2 * self.F * s[i, p] for i in range(1, self.N) for p in opt_range))
        model.setObjective(gp.quicksum(f[i, j, p] for i, j, p in f_range) + gp.quicksum(
            2 * self.F * s[i, p] for i in range(1, self.N) for p in opt_range))
        model.setParam('TimeLimit', time_limit)

        model.optimize()
        s_sol = {(i, t): 0 for i in range(1, self.N) for t in opt_range if s[i, t].X > 0.5}
        y_sol = [(d, i) for d, i in y_list if y[d, i].X > 0.5]
        return y_sol, s_sol

    def solve_main_model(self, d_list, y_start, s_start, port_qty, time_limit):
        opt_range = range(self.P)
        y_list = [(d, i) for i in range(1, self.N) for d in range(len(self.dl))]
        s_range = [(i, p) for i in range(1, self.N) for p in opt_range]
        f_range = [(i, j, p) for i, j in self.E for p in range(self.P) if i and j] + [(j, i, p) for i, j in self.E for p
                                                                                      in range(self.P) if
                                                                                      i and j]
        f_range += [(0, i, p) for i in self.adj[0] for p in range(self.P)]
        model = gp.Model()
        f = model.addVars(f_range, vtype=GRB.INTEGER, name='f')
        y = model.addVars(y_list, vtype=GRB.BINARY, name='y')
        s = model.addVars(s_range, vtype=GRB.BINARY, name='s')
        for d, i in y_start:
            y[d, i].Start = 1

        for i, p in s_start:
            s[i, p].Start = 1

        for d in d_list:
            qty_base = gp.quicksum(y[d.id, i] for i in range(1, self.N))
            model.addConstr(qty_base == d.qty)

        model.addConstrs(
            gp.quicksum(
                y[d.id, i] for d in d_list if d.in_p <= p < d.out_p) <= 1
            for i in
            range(1, self.N) for p in
            opt_range)
        model.addConstrs(
            gp.quicksum(y[d.id, i] for i in range(1, self.N)) == d.qty for d
            in d_list)

        for i in range(1, self.N):
            for p in opt_range:
                in_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (p == d.in_p))
                out_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (p == d.out_p))

                model.addConstr(
                    gp.quicksum(f[j, i, p] for j in self.adj[i]) - gp.quicksum(
                        f[i, j, p] for j in self.adj[i] if j) == in_pos + out_pos)
                block_pos = gp.quicksum(
                    y[d.id, i] for d in d_list if (d.in_p < p < d.out_p))
                model.addConstr(
                    gp.quicksum(f[j, i, p] for j in self.adj[i]) <= (
                        port_qty[p]) * (
                            1 - block_pos + s[i, p]))

        model.addConstrs(
            gp.quicksum(f[0, j, p] for j in self.adj[0]) == (
                port_qty[p]) for p in
            opt_range)
        model.setObjective(gp.quicksum(f[i, j, p] for i, j, p in f_range) + gp.quicksum(
            2 * self.F * s[i, p] for i, p in s_range))
        model.setParam('TimeLimit', time_limit)
        model.setParam("OutputFlag", 0)
        model.optimize()

        s_sol = {(i, p): 0 for i, p in s_range if s[i, p].X > 0.5}
        y_sol = [(d, i) for d, i in y_list if y[d, i].X > 0.5]
        return y_sol, s_sol


def get_port_qty2(dl, P):
    port_qty = [0] * P
    in_port_qty = [0] * P
    out_port_qty = [0] * P

    for d in dl:
        in_port_qty[d.in_p] += d.qty
        out_port_qty[d.out_p] += d.qty
    for p in range(P):
        port_qty[p] = in_port_qty[p] + out_port_qty[p]

    return port_qty


def optimize_s(N, E, P, F, dl, adj_list, port_qty, y_sol, start_time, timelimit):
    fm = np.zeros((N, P), dtype=int)
    for d, i in y_sol:
        fm[i, dl[d].in_p] += 1
        fm[i, dl[d].out_p] += 1
        fm[i, dl[d].in_p + 1:dl[d].out_p] = -1

    s_range = []
    for p in range(P):
        for i in range(N):
            if fm[i, p] == -1:
                s_range.append((i, p))

    f_range = [(i, j, p) for i, j in E for p in range(P) if i and j] + [(j, i, p) for i, j in E for p in range(P) if
                                                                        i and j]
    f_range += [(0, i, p) for i in adj_list[0] for p in range(P)]
    model = gp.Model()
    f = model.addVars(f_range, vtype=GRB.INTEGER, name='f')
    s = model.addVars(s_range, vtype=GRB.BINARY, name='s')

    for i in range(1, N):
        for p in range(P):
            model.addConstr(gp.quicksum(f[j, i, p] for j in adj_list[i]) - gp.quicksum(
                f[i, j, p] for j in adj_list[i] if j) == max(fm[i, p], 0))  # 2, 1 또는 0
    model.addConstrs(
        gp.quicksum(f[j, i, p] for j in adj_list[i]) <= port_qty[p] * s[i, p] for i, p in s_range)
    model.addConstrs(gp.quicksum(f[0, j, p] for j in adj_list[0]) == port_qty[p] for p in range(P))
    model.setObjective(
        gp.quicksum(f[i, j, t] for i, j, t in f_range) + 2 * F * gp.quicksum(s[i, p] for i, p in s_range))
    # model.setObjective(gp.quicksum(s[i, p] for i, p in s_range))
    model.setParam("OutputFlag", 0)
    model.setParam('TimeLimit', timelimit + 1 - (time.time() - start_time))
    model.optimize()
    s_sol = [(i, p) for i, p in s_range if s[i, p].X > 0.5]
    return s_sol


def encoding_sol2(N, P, s_sol, y_sol, dl, adj_list):
    T = 2 * P - 2
    rm = np.zeros((N, T), dtype=int)
    for d, p in y_sol:
        rm[p, dl[d].s] = d + 1
        rm[p, dl[d].e] = d + 1
        rm[p, dl[d].s + 1:dl[d].e] = -1

        for i, t in s_sol:
            if dl[d].s < p_to_in(t) < dl[d].e and i == p:
                rm[p, p_to_in(t)] = d + 1
                rm[p, p_to_out(t)] = d + 1

    pre_sol = {
        t: []
        for t in range(T)
    }

    for t in range(T):
        # 0은 지나다닐 수 있음, -1 막혀있음, 1 이상은 수요
        queue = deque([NodeInform(0, [0])])
        rm[0, t] = -1
        while queue:
            node = queue.popleft()
            for n_node in adj_list[node.pos]:
                if rm[n_node, t] >= 0:
                    n_route = node.route.copy() + [n_node]
                    if rm[n_node, t] >= 1:
                        if t % 2:
                            # tt = (t + 1) / 2
                            pre_sol[t].append([list(reversed(n_route)), int(rm[n_node, t] - 1)])
                        elif not t % 2:
                            # tt = t / 2
                            pre_sol[t].append([n_route, int(rm[n_node, t] - 1)])
                    rm[n_node, t] = -1
                    queue.extend([NodeInform(n_node, n_route)])  # 인접 노드 큐에 추가
        if not t % 2:
            pre_sol[t].reverse()
    solution = {
        p: []
        for p in range(P)
    }

    for p in range(P):
        if p == P - 1:
            solution[p] = pre_sol[p_to_out(p)]
        elif p == 0:
            solution[p] = pre_sol[p_to_in(p)]
        else:
            solution[p] = pre_sol[p_to_out(p)] + pre_sol[p_to_in(p)]
    return solution


def encoding_sol(N, P, E, F, cost, port_qty, s_sol, y_sol, dl, adj_list, start_time, timelimit):
    T = 2 * P - 2

    rehandle_pos = optimize_s(N, E, P, F, dl, adj_list, port_qty, y_sol, start_time, timelimit)

    rm = np.zeros((N, T), dtype=int)
    for d, p in y_sol:
        rm[p, dl[d].s] = d + 1
        rm[p, dl[d].e] = d + 1
        rm[p, dl[d].s + 1:dl[d].e] = -1

        for i, t in rehandle_pos:
            if dl[d].s < p_to_in(t) < dl[d].e and i == p:
                rm[p, p_to_in(t)] = d + 1
                rm[p, p_to_out(t)] = d + 1

    pre_sol = {
        t: []
        for t in range(T)
    }

    for t in range(T):
        # 0은 지나다닐 수 있음, -1 막혀있음, 1 이상은 수요
        queue = deque([NodeInform(0, [0])])
        rm[0, t] = -1
        while queue:
            node = queue.popleft()
            for n_node in adj_list[node.pos]:
                if rm[n_node, t] >= 0:
                    n_route = node.route.copy() + [n_node]
                    if rm[n_node, t] >= 1:
                        if t % 2:
                            # tt = (t + 1) / 2
                            pre_sol[t].append([list(reversed(n_route)), int(rm[n_node, t] - 1)])
                        elif not t % 2:
                            # tt = t / 2
                            pre_sol[t].append([n_route, int(rm[n_node, t] - 1)])
                    rm[n_node, t] = -1
                    queue.extend([NodeInform(n_node, n_route)])  # 인접 노드 큐에 추가
        if not t % 2:
            pre_sol[t].reverse()
    solution = {
        p: []
        for p in range(P)
    }

    for p in range(P):
        if p == P - 1:
            solution[p] = pre_sol[p_to_out(p)]
        elif p == 0:
            solution[p] = pre_sol[p_to_in(p)]
        else:
            solution[p] = pre_sol[p_to_out(p)] + pre_sol[p_to_in(p)]
    return solution


"""
    submit4 코드 정리
"""


def two_stage_optimize_rolling_final(prob_info, timelimit=60):
    N = prob_info['N']
    E = prob_info['E']
    D = prob_info['K']
    F = prob_info['F']
    P = prob_info['P']

    adj_list = [[] for _ in range(N)]
    for i, j in E:
        adj_list[j].append(i)
        adj_list[i].append(j)
    cost, pred = bfs(adj_list, N)
    dl = [DemandInform(i, d[0], d[1]) for i, d in enumerate(D)]

    opt_model = Optimize_Model(prob_info, dl, cost, pred)
    y_sol, s_sol = opt_model.run(timelimit)

    return encoding_sol2(N, P, s_sol, y_sol, dl, adj_list)
