## 팀명
Wirtz

## 사용한 Python 라이브러리
* gurobipy
* deque, heapq, Tuple, time
* numpy

## 알고리즘 파일
two_stage_model.py

시스템에 제출하는 파일들이 모두 소스코드이고 그 자체로 OGC2025 환경에서 구동되는 데 문제가 없습니다.