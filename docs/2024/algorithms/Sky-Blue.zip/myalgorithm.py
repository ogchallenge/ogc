from util import *
import time
from collections import Counter
import gurobipy as gp
from gurobipy import GRB
import numpy as np
from sklearn.cluster import BisectingKMeans, KMeans
import warnings
import gc
from tools import generate_reduction_edges, BCDP
from scipy.sparse import coo_matrix
warnings.filterwarnings("ignore")


class double_clustering_algorithm():
    def __init__(self, K, denom, sub_denom, order_coords):
        self.K = K
        self.denom = denom
        self.sub_denom = sub_denom
        self.order_coords = order_coords
        self.num_clusters_bik = np.inf
        self.num_clusters_k = np.inf
        self.toggle = True

    def extend_zones(self):
        self.denom += 10
        self.sub_denom += 10

    def get_cluster(self, front_first = True, max_iter = 300):
        n_cluster = int((self.K // self.denom) + 1)
        bik_clusters = np.zeros(self.K)
        k_clusters = np.zeros(self.K)
        bikmeans = BisectingKMeans(n_clusters=n_cluster, bisecting_strategy="largest_cluster", max_iter = max_iter)
        kmeans = KMeans(n_clusters=n_cluster, max_iter = max_iter)
        if front_first:
            biklabels = bikmeans.fit(self.order_coords[:, :2]).labels_
            klabels = kmeans.fit(self.order_coords[:, :2]).labels_
        else:
            biklabels = bikmeans.fit(self.order_coords[:, 2:]).labels_
            klabels = kmeans.fit(self.order_coords[:, 2:]).labels_
        num_biklabels = dict(Counter(biklabels))
        num_klabels = dict(Counter(klabels))
        bik_idx = 0
        k_idx = 0

        for i in num_biklabels.keys():
            n_sub_biklabels = (num_biklabels[i] // self.sub_denom) + 1
            sub_bik_clusters = 0

            if front_first:
                if n_sub_biklabels > 1:
                    bikmeans = BisectingKMeans(n_clusters=n_sub_biklabels, bisecting_strategy="largest_cluster", max_iter = max_iter)
                    sub_bik_clusters = bikmeans.fit(self.order_coords[np.where(biklabels == i)[0], 2:],
                                                    n_sub_biklabels).labels_
            else:
                if n_sub_biklabels > 1:
                    bikmeans = BisectingKMeans(n_clusters=n_sub_biklabels, bisecting_strategy="largest_cluster", max_iter = max_iter)
                    sub_bik_clusters = bikmeans.fit(self.order_coords[np.where(biklabels == i)[0], :2],
                                                    n_sub_biklabels).labels_
            bik_clusters[np.where(biklabels == i)[0]] = sub_bik_clusters + bik_idx
            bik_idx += n_sub_biklabels

        for i in num_klabels.keys():
            n_sub_klabels = (num_klabels[i] // self.sub_denom) + 1
            sub_k_clusters = 0
            if front_first:
                if n_sub_klabels > 1:
                    kmeans = KMeans(n_clusters=n_sub_klabels, max_iter = max_iter)
                    sub_k_clusters = kmeans.fit(self.order_coords[np.where(klabels == i)[0], 2:], n_sub_klabels).labels_
            else:
                if n_sub_klabels > 1:
                    kmeans = KMeans(n_clusters=n_sub_klabels, max_iter = max_iter)
                    sub_k_clusters = kmeans.fit(self.order_coords[np.where(klabels == i)[0], :2], n_sub_klabels).labels_
            k_clusters[np.where(klabels == i)[0]] = sub_k_clusters + k_idx
            k_idx += n_sub_klabels

        self.num_clusters_bik = len(np.unique(bik_clusters))
        return [k_clusters, bik_clusters], self.num_clusters_bik

def get_search_time(K):
    return 0.9055 - 1.613e-4 * K + 4.232e-8 * (K ** 2)

def algorithm(K, all_orders, all_riders, dist_mat, timelimit=60):
    gc.disable()
    start_time = time.time()
    solve_time = timelimit * get_search_time(K)
    out_time = timelimit * 0.990

    for r in all_riders:
        r.T = np.round(dist_mat / r.speed + r.service_time)

    # A solution is a list of bundles
    solution = []

    # ------------- Custom algorithm code starts from here --------------#
    r_types = {}
    for idx, r in enumerate(all_riders):
        r_types[idx] = r.type

    coords = np.array([[o.shop_lat, o.shop_lon, o.dlv_lat, o.dlv_lon] for o in all_orders])

    num_rider_types = len(all_riders)

    graphs = generate_reduction_edges(K, all_orders, all_riders)
    bcdp = BCDP(K, dist_mat, graphs, all_orders, all_riders)

    DC = double_clustering_algorithm(K=K, denom=10, sub_denom=10, order_coords=coords)
    while time.time() - start_time < solve_time:
        clusters, n_cluster = DC.get_cluster(front_first=True)
        if timelimit >= 60:
            b_clusters, b_n_cluster = DC.get_cluster(front_first=False)
            clusters = clusters + b_clusters
            n_cluster = min(n_cluster, b_n_cluster)

        for c_methods in clusters:
            for c in set(c_methods):
                nodes = np.where(c_methods == c)[0]
                for r_type in r_types.keys():
                    bcdp.run(r_type, nodes, start_time, timelimit=solve_time)

        if n_cluster == 1:
            break
        DC.extend_zones()

    sols_distance = bcdp.get_sols_distance()
    sols_route = bcdp.get_sols_route()

    var_cost = np.array([all_riders[r_type].var_cost for r_type in range(num_rider_types)])
    fix_cost = np.array([all_riders[r_type].fixed_cost for r_type in range(num_rider_types)])
    num_avail_riders = np.array([all_riders[r_type].available_number for r_type in range(num_rider_types)])

    customer_to_paths = dict(zip(range(K), [[] for _ in range(K)]))
    num_paths_per_rider = [len(sols_distance[r_type]) for r_type in range(num_rider_types)]
    num_total_routes = sum(num_paths_per_rider)

    total_paths = []
    total_cost = np.empty(num_total_routes)
    start_idx = 0
    for r_type in range(num_rider_types):
        total_paths.extend(sols_route[r_type].values())
        total_cost[start_idx:start_idx+num_paths_per_rider[r_type]] = \
            np.array(list(sols_distance[r_type].values())) * var_cost[r_type] / 100.0 + fix_cost[r_type]
        start_idx += num_paths_per_rider[r_type]

    path_idx = 0
    for r_type, visit_nodes in enumerate(sols_route):
        for nodes in visit_nodes.keys():
            for node in nodes:
                customer_to_paths[node].append(path_idx)
            path_idx += 1

    total_order_elements = sum(len(paths) for paths in customer_to_paths.values())
    row_indices = np.zeros(total_order_elements, dtype=int)
    col_indices = np.zeros(total_order_elements, dtype=int)
    data = np.ones(total_order_elements, dtype=int)

    start_idx = 0
    for customer_idx, paths in customer_to_paths.items():
        num_paths = len(paths)
        row_indices[start_idx:start_idx + num_paths] = customer_idx
        col_indices[start_idx:start_idx + num_paths] = paths
        start_idx += num_paths

    A_customer_coo = coo_matrix((data, (row_indices, col_indices)), shape=(K, num_total_routes))
    A_customer_csr = A_customer_coo.tocsr()

    total_rider_types = np.zeros(num_total_routes, dtype=int)
    col_indices = np.arange(num_total_routes, dtype=int)
    data = np.ones(num_total_routes, dtype=int)  # 모든 값은 1로 설정

    start_idx = 0
    for rider_type, num_paths in enumerate(num_paths_per_rider):
        total_rider_types[start_idx:start_idx + num_paths] = rider_type
        start_idx += num_paths

    A_rider_coo = coo_matrix((data, (total_rider_types, col_indices)), shape=(num_rider_types, num_total_routes))
    A_rider_csr = A_rider_coo.tocsr()

    # Integer Programming
    model = gp.Model("MILP")

    y = model.addMVar(num_total_routes, vtype=GRB.BINARY, name="y")

    model.setObjective(total_cost @ y, GRB.MINIMIZE)
    model.addMConstr(A_customer_csr, y, '=', np.ones(K), name="customer_constrs")
    model.addMConstr(A_rider_csr, y, '<=', num_avail_riders, name="rider_constrs")

    model.Params.OutputFlag = 0
    model.Params.Presolve = 0
    model.Params.MIPFocus = 1
    model.Params.Cuts = 2
    model.Params.Sifting = 0
    model.Params.TimeLimit = out_time - (time.time() - start_time)

    model.optimize()

    y_opt = np.array(model.getAttr('x', model.getVars()))
    y_opt = np.where(y_opt > 0.5)[0]

    solution = [[all_riders[total_rider_types[i]].type,
                 [int(x) for x in total_paths[i][:len(total_paths[i])//2]],
                 [int(x-K) for x in total_paths[i][len(total_paths[i])//2:]]] for i in y_opt]

    # ------------- End of custom algorithm code--------------#

    return solution
