Bidirectional Labeling Algorithm과 Network Reduction Algorithm을 포함한 최적화 알고리즘을 구현한 코드로, tools.pyx 파일에 포함되어 있습니다. 해당 코드는 Cython을 사용해 성능을 최적화했으며, 컴파일을 통해 .so 파일과 .c 파일을 생성할 수 있습니다. 이 프로젝트는 OGC2024 환경에서 실행되며, 외부 패키지 의존성 없이 동작합니다.

구성 요소
tools.c: tools.pyx 파일로부터 생성된 C 파일.
tools.cpython-310-x86_64-linux-gnu.so: tools.pyx 파일로부터 생성된 Python 확장 모듈 파일.
tools.pyx: Cython으로 작성된 소스 코드, Bidirectional Labeling Algorithm과 Network Reduction Algorithm이 포함되어 있음.
myalgorithm.py: 메인 알고리즘 파일, tools.pyx로부터 생성된 확장 모듈을 사용하여 최적화 알고리즘을 실행.
util.py: 보조 기능 및 유틸리티 함수 파일.
READ_ME.txt: 프로젝트 설명서 (현재 파일).

컴파일 방법
파일 위치: cython_setup.py와 tools.pyx 파일을 같은 디렉터리에 위치시킵니다.
컴파일 명령어: 터미널 또는 명령 프롬프트에서 아래 명령어를 실행하여 Cython 코드를 컴파일합니다.
python cython_setup.py build_ext --inplace
결과 파일: 컴파일 후, 아래의 두 가지 파일이 생성됩니다.
tools.c: Cython 코드로부터 생성된 C 파일.
tools.cpython-310-x86_64-linux-gnu.so: Python 확장 모듈 파일.

사용 방법
Cython 모듈 사용: 컴파일된 .so 파일을 Python에서 import하여 사용합니다. 
적용 예시는 myalgorithm.py에서 확인할 수 있습니다.
