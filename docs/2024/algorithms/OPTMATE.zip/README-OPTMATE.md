## 팀명
OPTMATE

## 사용한 Python 라이브러리
* gurobipy
* defaultdict
* numba
* util

## 추가 폴더
* __pycache__ 
    * numba로 만든 함수의 cache=True를 사용하면 자동 생성
    * 서버 환경과 동일한 linux에서 미리 import한 후 myalgorithm과 같이 압축 (import하는 시간 단축)
