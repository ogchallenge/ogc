from util import *
from collections import defaultdict

import gurobipy as gp
from gurobipy import GRB

import numba

numba.set_num_threads(4)
numba.config.CPU_NAME = 'generic'

#def cal_cost(dist, fixed_cost, var_cost):
#    return fixed_cost + dist / 100.0 * var_cost

@numba.jit(('(i4[:,:], i4)'),nopython=True, cache=True, fastmath=True)
def make_delete_order(DIST, K):
    return [np.array(sorted([(DIST[o][o2]+DIST[o+K][o2+K], o2) for o2 in range(K)]))[:,1] for o in range(K)]
    
#@numba.jit(('(i8, i8[:], i8[:], i8[:], f8[:,:,:], i8[:], i8[:,:], i8[:,:], i8[:], i8[:], i8, i8, i8)'), nopython=True, cache=True, fastmath=True)
@numba.jit(nopython=True, cache=True, fastmath=True)
def make_R2(K, rider_capas, order_volumes, order_ready_times, T, order_deadlines, DIST, delete_order, fixed_cost, var_cost, timelimit, prob_lon, prob_dt):
    r2_cut = K * 0.8
    if prob_lon == 2:
        if K > 1000:
            r2_cut = K * 0.3
    else:
        if prob_dt == 1:
            r2_cut = max(K * 0.15, 50)
            if K > 1000:
                r2_cut = K * 0.05
        else:
            r2_cut = max(K * 0.2, 60)
            if K > 1000:
                r2_cut = K * 0.05
    
    possible = np.zeros((K, K, 3))
    possible2 = np.zeros((K, K, 3))

    R2_add = [] #numba.typed.List()
    for o1 in range(K):
        for o2 in delete_order[o1][:int(r2_cut)]:
            if o1 == o2:
                continue
            for rider_idx in [0, 1, 2]:
                remain = rider_capas[rider_idx] - (order_volumes[o1] + order_volumes[o2])
                if remain < 0:
                    continue

                p1_p2 = order_ready_times[o1] + T[rider_idx][o1][o2]
                if p1_p2 < order_ready_times[o2]:
                    p1_p2 = order_ready_times[o2]

                if order_deadlines[o1] <= order_deadlines[o2]:
                    min_deadline = order_deadlines[o1]
                else:
                    min_deadline = order_deadlines[o2]

                if p1_p2 >= min_deadline:
                    continue

                p1_p2_d1 = p1_p2 + T[rider_idx][o2][o1 + K]
                if p1_p2_d1 <= min_deadline:
                    p1_p2_d1_d2 = p1_p2_d1 + T[rider_idx][o1 + K][o2 + K]
                    if p1_p2_d1_d2 <= order_deadlines[o2]:
                        d1 = DIST[o1][o2]
                        d2 = DIST[o1 + K][o2 + K]
                        d3 = DIST[o2][o1 + K]
                        R2_add.append(np.array([
                            remain,
                            p1_p2,
                            min_deadline,
                            d1,
                            d2,
                            d3,
                            rider_idx,
                            fixed_cost[rider_idx] + (d1 + d2 + d3) / 100 * var_cost[rider_idx],
                            o1,
                            o2,
                            o1,
                            o2
                        ], dtype='i4'))

                        possible[o1][o2][rider_idx] = 1
                        possible2[o1][o2][rider_idx] = 1

                p1_p2_d2 = p1_p2 + T[rider_idx][o2][o2 + K]
                if p1_p2_d2 <= min_deadline:
                    p1_p2_d2_d1 = p1_p2_d2 + T[rider_idx][o2 + K][o1 + K]
                    if p1_p2_d2_d1 <= order_deadlines[o1]:
                        d1 = DIST[o1][o2]
                        d2 = DIST[o2 + K][o1 + K]
                        d3 = DIST[o2][o2 + K]
                        R2_add.append(np.array([
                            remain,
                            p1_p2,
                            min_deadline,
                            d1,
                            d2,
                            d3,
                            rider_idx,
                            fixed_cost[rider_idx] + (d1 + d2 + d3) / 100 * var_cost[rider_idx],
                            o1,
                            o2,
                            o2,
                            o1
                        ], dtype='i4'))
                        possible[o1][o2][rider_idx] = 1
                        possible2[o1][o2][rider_idx] = 1

        for o2 in delete_order[o1][int(r2_cut):]:
            if o1 == o2:
                continue
            for rider_idx in [0, 1, 2]:
                remain = rider_capas[rider_idx] - (order_volumes[o1] + order_volumes[o2])
                if remain < 0:
                    continue

                p1_p2 = order_ready_times[o1] + T[rider_idx][o1][o2]
                if p1_p2 < order_ready_times[o2]:
                    p1_p2 = order_ready_times[o2]

                if order_deadlines[o1] <= order_deadlines[o2]:
                    min_deadline = order_deadlines[o1]
                else:
                    min_deadline = order_deadlines[o2]

                if p1_p2 >= min_deadline:
                    continue

                p1_p2_d1 = p1_p2 + T[rider_idx][o2][o1 + K]
                if p1_p2_d1 <= min_deadline:
                    p1_p2_d1_d2 = p1_p2_d1 + T[rider_idx][o1 + K][o2 + K]
                    if p1_p2_d1_d2 <= order_deadlines[o2]:
                        possible2[o1][o2][rider_idx] = 1

                p1_p2_d2 = p1_p2 + T[rider_idx][o2][o2 + K]
                if p1_p2_d2 <= min_deadline:
                    p1_p2_d2_d1 = p1_p2_d2 + T[rider_idx][o2 + K][o1 + K]
                    if p1_p2_d2_d1 <= order_deadlines[o1]:
                        possible2[o1][o2][rider_idx] = 1
                        
    
    P2R = round(possible2.sum()/(K*(K-1)*3), 2)
    cut = 30
    if K <= 300:
        if P2R < 0.1:
            cut = min(40 + (timelimit/3 * (1-P2R)), K-1)
        elif P2R < 0.2:
            cut = min(32 + (timelimit/3 * (1-P2R)), K-1)
        elif P2R < 0.3:
            cut = min(32 + (timelimit/3 * (1-P2R)), K-1)
        else:
            cut = min(20 + (timelimit/3 * (1-P2R)), K-1)
    elif K <= 500:
        if P2R < 0.1:
            cut = 40 + (timelimit/4 * (1-P2R))
        elif P2R < 0.2:
            cut = 25 + (timelimit/4 * (1-P2R))
        elif P2R < 0.3:
            cut = 25 + (timelimit/5 * (1-P2R))
        else:
            cut = 20 + (timelimit/5 * (1-P2R))
    elif K <= 750:
        if P2R < 0.1:
            cut = 40 + (timelimit/5 * (1-P2R))
        elif P2R < 0.2:
            cut = 20 + (timelimit/5 * (1-P2R))
        elif P2R < 0.3:
            cut = 20 + (timelimit/5 * (1-P2R))
        else:
            cut = 18 + (timelimit/6 * (1-P2R))
    elif K < 1000:
        if P2R < 0.05:
            cut = (40 * (1-P2R)) + (timelimit/6 * (1-P2R))
        elif P2R < 0.1:
            cut = (18 * (1-P2R)) + (timelimit/6 * (1-P2R))
        elif P2R < 0.2:
            cut = (15 * (1-P2R)) + (timelimit/6 * (1-P2R))
        else:
            cut = (15 * (1-P2R)) + (timelimit/7 * (1-P2R))
    elif K == 1000:
        if P2R < 0.05:
            cut = (60 * (1-P2R)) + (timelimit/6 * (1-P2R))
        elif P2R < 0.1:
            cut = (40 * (1-P2R)) + (timelimit/6 * (1-P2R))
        elif P2R < 0.2:
            cut = (40 * (1-P2R)) + (timelimit/6 * (1-P2R))
        else:
            cut = (25 * (1-P2R)) + (timelimit/7 * (1-P2R))
    else:
        if P2R < 0.05:
            cut = (10 * (1-P2R)) + (timelimit/9 * (1-P2R))
        elif P2R < 0.1:
            cut = (9 * (1-P2R)) + (timelimit/9 * (1-P2R))
        else:
            cut = (8 * (1-P2R)) + (timelimit/10 * (1-P2R))
          
    r3_cut_add = 0
    if K < 1000:
        if timelimit >= 30 and timelimit < 60:
            if K <= 500:
                cut += 10
            elif P2R < 0.2:
                cut += 40
        elif timelimit >= 60:
            if P2R < 0.2:
                cut += 60
                r3_cut_add = 10
    
    if K > 1000:
        if timelimit >= 480:
            cut += 60
            r3_cut_add = 10
            
    if K == 1000:
        if P2R < 0.1 and timelimit >= 60:
            r3_cut_add = 20
            
    if timelimit < 30:
        if K >= 500 and K < 1000:
            if P2R < 0.2:
                cut += 20
                r3_cut_add = -10
            else:
                r3_cut_add = -20
        elif K == 1000:
            cut -= 20
            r3_cut_add = -25
        
    for o in range(K):
        possible[o][delete_order[o][int(cut):]] = 0
                        
    return R2_add, possible, possible2, r3_cut_add
    
@numba.jit(nopython=True, cache=True, fastmath=True)
def make_R3(R2_add, min_volume, possible, possible2, order_volumes, order_ready_times, order_deadlines, T, DIST, fixed_cost, var_cost, K, r3_cut_add):
    add = []
    r3_cut = 30 + r3_cut_add
    for route_info in R2_add:
        if route_info[0] - min_volume < 0:
            continue
        cut_num = 0
        for o3_idx in np.where(possible[route_info[-3]][:, route_info[6]] != 0)[0]:
            if cut_num > r3_cut:
                break
            if possible2[route_info[-3]][o3_idx][route_info[6]] == 0:
                continue
            if possible[route_info[-4]][o3_idx][route_info[6]] == 0:
                continue
            if possible2[route_info[-4]][o3_idx][route_info[6]] == 0:
                continue
            remain = route_info[0] - order_volumes[o3_idx]
            if remain < 0:
                continue

            p_p3 = route_info[1] + T[route_info[6]][route_info[-3]][o3_idx]
            if p_p3 < order_ready_times[o3_idx]:
                p_p3 = order_ready_times[o3_idx]

            if route_info[2] <= order_deadlines[o3_idx]:
                min_deadline = route_info[2]
            else:
                min_deadline = order_deadlines[o3_idx]

            if p_p3 >= min_deadline:
                continue
                
            check = np.inf

            p_p3_d = p_p3 + T[route_info[6]][o3_idx][route_info[-2] + K]
            if p_p3_d <= min_deadline:
                p_p3_d_1 = p_p3_d + T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                if p_p3_d_1 <= order_deadlines[route_info[-1]]:
                    p_p3_d_d3 = p_p3_d_1 + T[route_info[6]][route_info[-1] + K][o3_idx + K]
                    if p_p3_d_d3 <= order_deadlines[o3_idx]:
                        cut_num+=1
                        d1 = route_info[3] + DIST[route_info[-3]][o3_idx]
                        d2 = route_info[4] + DIST[route_info[-1] + K][o3_idx + K]
                        d3 = DIST[o3_idx][route_info[-2] + K]
                        total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                        check = total_cost
                        add.append(np.array([remain,
                                                p_p3,
                                                min_deadline,
                                                d1,
                                                d2,
                                                d3,
                                                route_info[6],
                                                total_cost,
                                                route_info[-4],
                                                route_info[-3],
                                                o3_idx,
                                                route_info[-2],
                                                route_info[-1],
                                                o3_idx
                                                ], dtype='i4'))

                p_p3_d_2 = p_p3_d + T[route_info[6]][route_info[-2] + K][o3_idx + K]
                if p_p3_d_2 <= order_deadlines[o3_idx]:
                    p_p3_d_d3 = p_p3_d_2 + T[route_info[6]][o3_idx + K][route_info[-1] + K]
                    if p_p3_d_d3 <= order_deadlines[route_info[-1]]:
    #                            cut_num+=1
                        d1 = route_info[3] + DIST[route_info[-3]][o3_idx]
                        d2 = DIST[route_info[-2] + K][o3_idx + K] + DIST[o3_idx + K][route_info[-1] + K]
                        d3 = DIST[o3_idx][route_info[-2] + K]
                        total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                        if total_cost < check:
                            if check is not np.inf:
                                add[-1] = np.array([remain,
                                                p_p3,
                                                min_deadline,
                                                d1,
                                                d2,
                                                d3,
                                                route_info[6],
                                                total_cost,
                                                route_info[-4],
                                                route_info[-3],
                                                o3_idx,
                                                route_info[-2],
                                                o3_idx,
                                                route_info[-1]
                                                ], dtype='i4')
                            else:
                                cut_num += 1
                                add.append(np.array([remain,
                                                        p_p3,
                                                        min_deadline,
                                                        d1,
                                                        d2,
                                                        d3,
                                                        route_info[6],
                                                        total_cost,
                                                        route_info[-4],
                                                        route_info[-3],
                                                        o3_idx,
                                                        route_info[-2],
                                                        o3_idx,
                                                        route_info[-1]
                                                        ], dtype='i4'))
                                                        
                            check = total_cost

            p_p3_d3 = p_p3 + T[route_info[6]][o3_idx][o3_idx + K]
            if p_p3_d3 <= min_deadline:
                p_p3_d3_d = p_p3_d3 + T[route_info[6]][o3_idx + K][route_info[-2] + K]
                if p_p3_d3_d <= order_deadlines[route_info[-2]]:
                    p_p3_d3_d += T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                    if p_p3_d3_d <= order_deadlines[route_info[-1]]:
    #                            cut_num+=1
                        d1 = route_info[3] + DIST[route_info[-3]][o3_idx]
                        d2 = route_info[4] + DIST[o3_idx + K][route_info[-2] + K]
                        d3 = DIST[o3_idx][o3_idx + K]
                        total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                        if total_cost < check:
                            if check is not np.inf:
                                add[-1] = np.array([remain,
                                                        p_p3,
                                                        min_deadline,
                                                        d1,
                                                        d2,
                                                        d3,
                                                        route_info[6],
                                                        total_cost,
                                                        route_info[-4],
                                                        route_info[-3],
                                                        o3_idx,
                                                        o3_idx,
                                                        route_info[-2],
                                                        route_info[-1]
                                                        ], dtype='i4')
                            else:
                                cut_num+=1
                                add.append(np.array([remain,
                                                    p_p3,
                                                    min_deadline,
                                                    d1,
                                                    d2,
                                                    d3,
                                                    route_info[6],
                                                    total_cost,
                                                    route_info[-4],
                                                    route_info[-3],
                                                    o3_idx,
                                                    o3_idx,
                                                    route_info[-2],
                                                    route_info[-1]
                                                    ], dtype='i4'))
                                                    
    if len(add) == 0:
        add.append(np.array([0], dtype='i4'))
    return add

    
@numba.jit(nopython=True, cache=True, fastmath=True)
def make_R4(R3_add, min_volume, possible, possible2, order_volumes, order_ready_times, order_deadlines, T, DIST, fixed_cost, var_cost, K):
    add = []
    for route_info in R3_add:
        if route_info[0] < min_volume:
            continue
        cut_num = 0
        for o3_idx in np.where(possible[route_info[-4]][:, route_info[6]] != 0)[0]:
            if cut_num > 40:
                break
            if possible2[route_info[-4]][o3_idx][route_info[6]] == 0:
                continue
            if possible[route_info[-5]][o3_idx][route_info[6]] == 0:
                continue
            if possible[route_info[-6]][o3_idx][route_info[6]] == 0:
                continue
            if possible2[route_info[-5]][o3_idx][route_info[6]] == 0:
                continue
            if possible2[route_info[-6]][o3_idx][route_info[6]] == 0:
                continue

            remain = route_info[0] - order_volumes[o3_idx]
            if remain < 0:
                continue

            p_p3 = route_info[1] + T[route_info[6]][route_info[-4]][o3_idx]
            if p_p3 < order_ready_times[o3_idx]:
                p_p3 = order_ready_times[o3_idx]

            if route_info[2] <= order_deadlines[o3_idx]:
                min_deadline = route_info[2]
            else:
                min_deadline = order_deadlines[o3_idx]

            if p_p3 >= min_deadline:
                continue
                
            check = np.inf

            p_p3_d = p_p3 + T[route_info[6]][o3_idx][route_info[-3] + K]
            if p_p3_d <= min_deadline:
                p_p3_d_1 = p_p3_d + T[route_info[6]][route_info[-3] + K][route_info[-2] + K]
                if p_p3_d_1 <= order_deadlines[route_info[-2]]:
                    p_p3_d_1_1 = p_p3_d_1 + T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                    if p_p3_d_1_1 <= order_deadlines[route_info[-1]]:
                        p_p3_d_d3 = p_p3_d_1_1 + T[route_info[6]][route_info[-1] + K][o3_idx + K]
                        if p_p3_d_d3 <= order_deadlines[o3_idx]:
                            cut_num += 1
                            d1 = route_info[3] + DIST[route_info[-4]][o3_idx]
                            d2 = route_info[4] + DIST[route_info[-1] + K][o3_idx + K]
                            d3 = DIST[o3_idx][route_info[-3] + K]
                            total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                            check = total_cost
                            add.append(np.array([remain,
                                                    p_p3,
                                                    min_deadline,
                                                    d1,
                                                    d2,
                                                    d3,
                                                    route_info[6],
                                                    total_cost,
                                                    route_info[-6],
                                                    route_info[-5],
                                                    route_info[-4],
                                                    o3_idx,
                                                    route_info[-3],
                                                    route_info[-2],
                                                    route_info[-1],
                                                    o3_idx
                                                    ], dtype='i4'))

                    p_p3_d_3 = p_p3_d_1 + T[route_info[6]][route_info[-2] + K][o3_idx + K]
                    if p_p3_d_3 <= order_deadlines[o3_idx]:
                        p_p3_d_d3 = p_p3_d_3 + T[route_info[6]][o3_idx + K][route_info[-1] + K]
                        if p_p3_d_d3 <= order_deadlines[route_info[-1]]:
                            d1 = route_info[3] + DIST[route_info[-4]][o3_idx]
                            d2 = DIST[route_info[-3] + K][route_info[-2] + K] + DIST[route_info[-2] + K][o3_idx + K] + \
                                 DIST[o3_idx + K][route_info[-1] + K]
                            d3 = DIST[o3_idx][route_info[-3] + K]
                            total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                            if total_cost < check:
                                if check is not np.inf:
                                    add[-1] = np.array([remain,
                                                    p_p3,
                                                    min_deadline,
                                                    d1,
                                                    d2,
                                                    d3,
                                                    route_info[6],
                                                    total_cost,
                                                    route_info[-6],
                                                    route_info[-5],
                                                    route_info[-4],
                                                    o3_idx,
                                                    route_info[-3],
                                                    route_info[-2],
                                                    o3_idx,
                                                    route_info[-1]
                                                    ], dtype='i4')
                                else:
                                    cut_num += 1
                                    add.append(np.array([remain,
                                                p_p3,
                                                min_deadline,
                                                d1,
                                                d2,
                                                d3,
                                                route_info[6],
                                                total_cost,
                                                route_info[-6],
                                                route_info[-5],
                                                route_info[-4],
                                                o3_idx,
                                                route_info[-3],
                                                route_info[-2],
                                                o3_idx,
                                                route_info[-1]
                                                ], dtype='i4'))
                                check = total_cost
                                

                p_p3_d_2 = p_p3_d + T[route_info[6]][route_info[-3] + K][o3_idx + K]
                if p_p3_d_2 <= order_deadlines[o3_idx]:
                    p_p3_d_2 += T[route_info[6]][o3_idx + K][route_info[-2] + K]
                    if p_p3_d_2 <= order_deadlines[route_info[-2]]:
                        p_p3_d_d3 = p_p3_d_2 + T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                        if p_p3_d_d3 <= order_deadlines[route_info[-1]]:
                            cut_num +=1
                            d1 = route_info[3] + DIST[route_info[-4]][o3_idx]
                            d2 = DIST[route_info[-3] + K][o3_idx + K] + DIST[o3_idx + K][route_info[-2] + K] + \
                                 DIST[route_info[-2] + K][route_info[-1] + K]
                            d3 = DIST[o3_idx][route_info[-3] + K]
                            total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                            if total_cost < check:
                                if check is not np.inf:
                                    add[-1] = np.array([remain,
                                            p_p3,
                                            min_deadline,
                                            d1,
                                            d2,
                                            d3,
                                            route_info[6],
                                            total_cost,
                                            route_info[-6],
                                            route_info[-5],
                                            route_info[-4],
                                            o3_idx,
                                            route_info[-3],
                                            o3_idx,
                                            route_info[-2],
                                            route_info[-1]
                                        ], dtype='i4')
                                else:
                                    cut_num += 1
                                    add.append(np.array([remain,
                                                            p_p3,
                                                            min_deadline,
                                                            d1,
                                                            d2,
                                                            d3,
                                                            route_info[6],
                                                            total_cost,
                                                            route_info[-6],
                                                            route_info[-5],
                                                            route_info[-4],
                                                            o3_idx,
                                                            route_info[-3],
                                                            o3_idx,
                                                            route_info[-2],
                                                            route_info[-1]
                                                        ], dtype='i4'))
                                check = total_cost

            p_p3_d3 = p_p3 + T[route_info[6]][o3_idx][o3_idx + K]
            if p_p3_d3 <= min_deadline:
                p_p3_d3_d = p_p3_d3 + T[route_info[6]][o3_idx + K][route_info[-3] + K]
                if p_p3_d3_d <= order_deadlines[route_info[-3]]:
                    p_p3_d3_d += T[route_info[6]][route_info[-3] + K][route_info[-2] + K]
                    if p_p3_d3_d <= order_deadlines[route_info[-2]]:
                        p_p3_d3_d += T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                        if p_p3_d3_d <= order_deadlines[route_info[-1]]:
                            cut_num +=1
                            d1 = route_info[3] + DIST[route_info[-4]][o3_idx]
                            d2 = route_info[4] + DIST[o3_idx + K][route_info[-3] + K]
                            d3 = DIST[o3_idx][o3_idx + K]
                            total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                            if total_cost < check:
                                if check is not np.inf:
                                    add[-1] = np.array([remain,
                                                        p_p3,
                                                        min_deadline,
                                                        d1,
                                                        d2,
                                                        d3,
                                                        route_info[6],
                                                        total_cost,
                                                        route_info[-6],
                                                        route_info[-5],
                                                        route_info[-4],
                                                        o3_idx,
                                                        o3_idx,
                                                        route_info[-3],
                                                        route_info[-2],
                                                        route_info[-1]
                                                        ], dtype='i4')
                                else:
                                    cut_num += 1
                                    add.append(np.array([remain,
                                                            p_p3,
                                                            min_deadline,
                                                            d1,
                                                            d2,
                                                            d3,
                                                            route_info[6],
                                                            total_cost,
                                                            route_info[-6],
                                                            route_info[-5],
                                                            route_info[-4],
                                                            o3_idx,
                                                            o3_idx,
                                                            route_info[-3],
                                                            route_info[-2],
                                                            route_info[-1]
                                                            ], dtype='i4'))
                                                            
    if len(add) == 0:
        add.append(np.array([0], dtype='i4'))
    return add
    
@numba.jit(nopython=True, cache=True, fastmath=True)
def make_R5(R4_add, min_volume, possible, possible2, order_volumes, order_ready_times, order_deadlines, T, DIST, fixed_cost, var_cost, K):
    add = []
    for route_info in R4_add:
        if route_info[0] < min_volume:
            continue
        cut_num = 0
        for o3_idx in np.where(possible[route_info[-5]][:, route_info[6]] != 0)[0]:
            if cut_num > 50:
                break
            if possible2[route_info[-5]][o3_idx][route_info[6]] == 0:
                continue
            if possible[route_info[-6]][o3_idx][route_info[6]] == 0:
                continue
            if possible[route_info[-7]][o3_idx][route_info[6]] == 0:
                continue
            if possible[route_info[-8]][o3_idx][route_info[6]] == 0:
                continue
            if possible2[route_info[-6]][o3_idx][route_info[6]] == 0:
                continue
            if possible2[route_info[-7]][o3_idx][route_info[6]] == 0:
                continue
            if possible2[route_info[-8]][o3_idx][route_info[6]] == 0:
                continue

            remain = route_info[0] - order_volumes[o3_idx]
            if remain < 0:
                continue

            p_p3 = route_info[1] + T[route_info[6]][route_info[-5]][o3_idx]
            if p_p3 < order_ready_times[o3_idx]:
                p_p3 = order_ready_times[o3_idx]

            if route_info[2] <= order_deadlines[o3_idx]:
                min_deadline = route_info[2]
            else:
                min_deadline = order_deadlines[o3_idx]

            if p_p3 >= min_deadline:
                continue
                
            check = np.inf

            p_p3_d = p_p3 + T[route_info[6]][o3_idx][route_info[-4] + K]
            if p_p3_d <= min_deadline:
                p_p3_d_1 = p_p3_d + T[route_info[6]][route_info[-4] + K][route_info[-3] + K]
                if p_p3_d_1 <= order_deadlines[route_info[-3]]:
                    p_p3_d_1_1 = p_p3_d_1 + T[route_info[6]][route_info[-3] + K][route_info[-2] + K]
                    if p_p3_d_1_1 <= order_deadlines[route_info[-2]]:
                        p_p3_d_1_1_1 = p_p3_d_1_1 + T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                        if p_p3_d_1_1_1 <= order_deadlines[route_info[-1]]:
                            p_p3_d_d3 = p_p3_d_1_1_1 + T[route_info[6]][route_info[-1] + K][o3_idx + K]
                            if p_p3_d_d3 <= order_deadlines[o3_idx]:
                                cut_num +=1
                                d1 = route_info[3] + DIST[route_info[-5]][o3_idx]
                                d2 = route_info[4] + DIST[route_info[-1] + K][o3_idx + K]
                                d3 = DIST[o3_idx][route_info[-4] + K]
                                total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                                check = total_cost
                                # if total_cost <= dist_cut:
                                add.append(np.array([remain,
                                                        p_p3,
                                                        min_deadline,
                                                        d1,
                                                        d2,
                                                        d3,
                                                        route_info[6],
                                                        total_cost,
                                                        route_info[-8],
                                                        route_info[-7],
                                                        route_info[-6],
                                                        route_info[-5],
                                                        o3_idx,
                                                        route_info[-4],
                                                        route_info[-3],
                                                        route_info[-2],
                                                        route_info[-1],
                                                        o3_idx
                                                        ], dtype='i4'))

                        p_p3_d_4 = p_p3_d_1_1 + T[route_info[6]][route_info[-2] + K][o3_idx + K]
                        if p_p3_d_4 <= order_deadlines[o3_idx]:
                            p_p3_d_d3 = p_p3_d_4 + T[route_info[6]][o3_idx + K][route_info[-1] + K]
                            if p_p3_d_d3 <= order_deadlines[route_info[-1]]:
#                                    cut_num +=1
                                d1 = route_info[3] + DIST[route_info[-5]][o3_idx]
                                d2 = DIST[route_info[-4] + K][route_info[-3] + K] + DIST[route_info[-3] + K][
                                    route_info[-2] + K] + DIST[route_info[-2] + K][o3_idx + K] + DIST[o3_idx + K][
                                         route_info[-1] + K]
                                d3 = DIST[o3_idx][route_info[-4] + K]

                                total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                                if total_cost < check:
                                    if check is not np.inf:
                                        add[-1] = np.array([remain,
                                                                p_p3,
                                                                min_deadline,
                                                                d1,
                                                                d2,
                                                                d3,
                                                                route_info[6],
                                                                total_cost,
                                                                route_info[-8],
                                                                route_info[-7],
                                                                route_info[-6],
                                                                route_info[-5],
                                                                o3_idx,
                                                                route_info[-4],
                                                                route_info[-3],
                                                                route_info[-2],
                                                                o3_idx,
                                                                route_info[-1]
                                                                ], dtype='i4')
                                    else:
                                        cut_num += 1
                                        add.append(np.array([remain,
                                                                p_p3,
                                                                min_deadline,
                                                                d1,
                                                                d2,
                                                                d3,
                                                                route_info[6],
                                                                total_cost,
                                                                route_info[-8],
                                                                route_info[-7],
                                                                route_info[-6],
                                                                route_info[-5],
                                                                o3_idx,
                                                                route_info[-4],
                                                                route_info[-3],
                                                                route_info[-2],
                                                                o3_idx,
                                                                route_info[-1]
                                                                ], dtype='i4'))
                                                                
                                    check = total_cost

                    p_p3_d_3 = p_p3_d_1 + T[route_info[6]][route_info[-3] + K][o3_idx + K]
                    if p_p3_d_3 <= order_deadlines[o3_idx]:
                        p_p3_d_3 += T[route_info[6]][o3_idx + K][route_info[-2] + K]
                        if p_p3_d_3 <= order_deadlines[route_info[-2]]:
                            p_p3_d_d3 = p_p3_d_3 + T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                            if p_p3_d_d3 <= order_deadlines[route_info[-1]]:
                                cut_num +=1
                                d1 = route_info[3] + DIST[route_info[-5]][o3_idx]
                                d2 = DIST[route_info[-4] + K][route_info[-3] + K] + DIST[route_info[-3] + K][
                                    o3_idx + K] + DIST[o3_idx + K][route_info[-2] + K] + DIST[route_info[-2] + K][
                                         route_info[-1] + K]
                                d3 = DIST[o3_idx][route_info[-4] + K]
                                total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                                # if total_cost <= dist_cut:
                                if total_cost < check:
                                    if check is not np.inf:
                                        add[-1] = np.array([remain,
                                                                p_p3,
                                                                min_deadline,
                                                                d1,
                                                                d2,
                                                                d3,
                                                                route_info[6],
                                                                total_cost,
                                                                route_info[-8],
                                                                route_info[-7],
                                                                route_info[-6],
                                                                route_info[-5],
                                                                o3_idx,
                                                                route_info[-4],
                                                                route_info[-3],
                                                                o3_idx,
                                                                route_info[-2],
                                                                route_info[-1]
                                                                ], dtype='i4')
                                    else:
                                        cut_num += 1
                                        add.append(np.array([remain,
                                                                p_p3,
                                                                min_deadline,
                                                                d1,
                                                                d2,
                                                                d3,
                                                                route_info[6],
                                                                total_cost,
                                                                route_info[-8],
                                                                route_info[-7],
                                                                route_info[-6],
                                                                route_info[-5],
                                                                o3_idx,
                                                                route_info[-4],
                                                                route_info[-3],
                                                                o3_idx,
                                                                route_info[-2],
                                                                route_info[-1]
                                                                ], dtype='i4'))
                                    check = total_cost

                p_p3_d_2 = p_p3_d + T[route_info[6]][route_info[-4] + K][o3_idx + K]
                if p_p3_d_2 <= order_deadlines[o3_idx]:
                    p_p3_d_2 += T[route_info[6]][o3_idx + K][route_info[-3] + K]
                    if p_p3_d_2 <= order_deadlines[route_info[-3]]:
                        p_p3_d_2 += T[route_info[6]][route_info[-3] + K][route_info[-2] + K]
                        if p_p3_d_2 <= order_deadlines[route_info[-2]]:
                            p_p3_d_d3 = p_p3_d_2 + T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                            if p_p3_d_d3 <= order_deadlines[route_info[-1]]:
                                cut_num +=1
                                d1 = route_info[3] + DIST[route_info[-5]][o3_idx]
                                d2 = DIST[route_info[-4] + K][o3_idx + K] + DIST[o3_idx + K][route_info[-3] + K] + \
                                     DIST[route_info[-3] + K][route_info[-2] + K] + DIST[route_info[-2] + K][
                                         route_info[-1] + K]
                                d3 = DIST[o3_idx][route_info[-4] + K]
                                total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                                # if total_cost <= dist_cut:
                                if total_cost < check:
                                    if check is not np.inf:
                                        add[-1] = np.array([remain,
                                                                p_p3,
                                                                min_deadline,
                                                                d1,
                                                                d2,
                                                                d3,
                                                                route_info[6],
                                                                total_cost,
                                                                route_info[-8],
                                                                route_info[-7],
                                                                route_info[-6],
                                                                route_info[-5],
                                                                o3_idx,
                                                                route_info[-4],
                                                                o3_idx,
                                                                route_info[-3],
                                                                route_info[-2],
                                                                route_info[-1]
                                                                ], dtype='i4')
                                    else:
                                        cut_num += 1
                                        add.append(np.array([remain,
                                                                p_p3,
                                                                min_deadline,
                                                                d1,
                                                                d2,
                                                                d3,
                                                                route_info[6],
                                                                total_cost,
                                                                route_info[-8],
                                                                route_info[-7],
                                                                route_info[-6],
                                                                route_info[-5],
                                                                o3_idx,
                                                                route_info[-4],
                                                                o3_idx,
                                                                route_info[-3],
                                                                route_info[-2],
                                                                route_info[-1]
                                                                ], dtype='i4'))
                                    check = total_cost

            p_p3_d3 = p_p3 + T[route_info[6]][o3_idx][o3_idx + K]
            if p_p3_d3 <= min_deadline:
                p_p3_d3_d = p_p3_d3 + T[route_info[6]][o3_idx + K][route_info[-4] + K]
                if p_p3_d3_d <= order_deadlines[route_info[-4]]:
                    p_p3_d3_d += T[route_info[6]][route_info[-4] + K][route_info[-3] + K]
                    if p_p3_d3_d <= order_deadlines[route_info[-3]]:
                        p_p3_d3_d += T[route_info[6]][route_info[-3] + K][route_info[-2] + K]
                        if p_p3_d3_d <= order_deadlines[route_info[-2]]:
                            p_p3_d3_d += T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                            if p_p3_d3_d <= order_deadlines[route_info[-1]]:
                                cut_num += 1
                                d1 = route_info[3] + DIST[route_info[-5]][o3_idx]
                                d2 = route_info[4] + DIST[o3_idx + K][route_info[-4] + K]
                                d3 = DIST[o3_idx][o3_idx + K]
                                total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                                # if total_cost <= dist_cut:
                                if total_cost < check:
                                    if check is not np.inf:
                                        add[-1] = np.array([remain,
                                                                p_p3,
                                                                min_deadline,
                                                                d1,
                                                                d2,
                                                                d3,
                                                                route_info[6],
                                                                total_cost,
                                                                route_info[-8],
                                                                route_info[-7],
                                                                route_info[-6],
                                                                route_info[-5],
                                                                o3_idx,
                                                                o3_idx,
                                                                route_info[-4],
                                                                route_info[-3],
                                                                route_info[-2],
                                                                route_info[-1]
                                                                ], dtype='i4')
                                    else:
                                        cut_num += 1
                                        add.append(np.array([remain,
                                                                p_p3,
                                                                min_deadline,
                                                                d1,
                                                                d2,
                                                                d3,
                                                                route_info[6],
                                                                total_cost,
                                                                route_info[-8],
                                                                route_info[-7],
                                                                route_info[-6],
                                                                route_info[-5],
                                                                o3_idx,
                                                                o3_idx,
                                                                route_info[-4],
                                                                route_info[-3],
                                                                route_info[-2],
                                                                route_info[-1]
                                                                ], dtype='i4'))
                                                                
    if len(add) == 0:
        add.append(np.array([0], dtype='i4'))
    return add
    
@numba.jit(nopython=True, cache=True, fastmath=True)
def make_R6(R5_add, min_volume, possible, possible2, order_volumes, order_ready_times, order_deadlines, T, DIST, fixed_cost, var_cost, K):
    add = []
    for route_info in R5_add:
        if route_info[0] < min_volume:
            continue
        cut_num = 0

        for o3_idx in np.where(possible[route_info[-6]][:, route_info[6]] != 0)[0]:
            if cut_num > 60:
                break
            if possible2[route_info[-6]][o3_idx][route_info[6]] == 0:
                continue
            if possible[route_info[-7]][o3_idx][route_info[6]] == 0:
                continue
            if possible[route_info[-8]][o3_idx][route_info[6]] == 0:
                continue
            if possible[route_info[-9]][o3_idx][route_info[6]] == 0:
                continue
            if possible[route_info[-10]][o3_idx][route_info[6]] == 0:
                continue
            if possible2[route_info[-7]][o3_idx][route_info[6]] == 0:
                continue
            if possible2[route_info[-8]][o3_idx][route_info[6]] == 0:
                continue
            if possible2[route_info[-9]][o3_idx][route_info[6]] == 0:
                continue
            if possible2[route_info[-10]][o3_idx][route_info[6]] == 0:
                continue

            remain = route_info[0] - order_volumes[o3_idx]
            if remain < 0:
                continue

            p_p3 = route_info[1] + T[route_info[6]][route_info[-6]][o3_idx]
            if p_p3 < order_ready_times[o3_idx]:
                p_p3 = order_ready_times[o3_idx]

            if route_info[2] <= order_deadlines[o3_idx]:
                min_deadline = route_info[2]
            else:
                min_deadline = order_deadlines[o3_idx]

            if p_p3 >= min_deadline:
                continue
                
            check = np.inf

            p_p3_d = p_p3 + T[route_info[6]][o3_idx][route_info[-5] + K]
            if p_p3_d <= min_deadline:
                p_p3_d_1 = p_p3_d + T[route_info[6]][route_info[-5] + K][route_info[-4] + K]
                if p_p3_d_1 <= order_deadlines[route_info[-4]]:
                    p_p3_d_1_1 = p_p3_d_1 + T[route_info[6]][route_info[-4] + K][route_info[-3] + K]
                    if p_p3_d_1_1 <= order_deadlines[route_info[-3]]:
                        p_p3_d_1_1_1 = p_p3_d_1_1 + T[route_info[6]][route_info[-3] + K][route_info[-2] + K]
                        if p_p3_d_1_1_1 <= order_deadlines[route_info[-2]]:
                            p_p3_d_1_1_1_1 = p_p3_d_1_1_1 + T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                            if p_p3_d_1_1_1_1 <= order_deadlines[route_info[-1]]:
                                p_p3_d_d3 = p_p3_d_1_1_1_1 + T[route_info[6]][route_info[-1] + K][o3_idx + K]
                                if p_p3_d_d3 <= order_deadlines[o3_idx]:
                                    cut_num +=1
                                    d1 = route_info[3] + DIST[route_info[-6]][o3_idx]
                                    d2 = route_info[4] + DIST[route_info[-1] + K][o3_idx + K]
                                    d3 = DIST[o3_idx][route_info[-5] + K]
                                    total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                                    check = total_cost

                                    add.append(np.array([remain,
                                                            p_p3,
                                                            min_deadline,
                                                            d1,
                                                            d2,
                                                            d3,
                                                            route_info[6],
                                                            total_cost,
                                                            route_info[-10],
                                                            route_info[-9],
                                                            route_info[-8],
                                                            route_info[-7],
                                                            route_info[-6],
                                                            o3_idx,
                                                            route_info[-5],
                                                            route_info[-4],
                                                            route_info[-3],
                                                            route_info[-2],
                                                            route_info[-1],
                                                            o3_idx
                                                            ], dtype='i4'))  # route_info[4]+[o3_idx]

                            p_p3_d_5 = p_p3_d_1_1_1 + T[route_info[6]][route_info[-2] + K][o3_idx + K]
                            if p_p3_d_5 <= order_deadlines[o3_idx]:
                                p_p3_d_d3 = p_p3_d_5 + T[route_info[6]][o3_idx + K][route_info[-1] + K]
                                if p_p3_d_d3 <= order_deadlines[route_info[-1]]:
#                                        cut_num +=1
                                    d1 = route_info[3] + DIST[route_info[-6]][o3_idx]
                                    d2 = DIST[route_info[-5] + K][route_info[-4] + K] + DIST[route_info[-4] + K][
                                        route_info[-3] + K] + DIST[route_info[-3] + K][route_info[-2] + K] + \
                                         DIST[route_info[-2] + K][o3_idx + K] + DIST[o3_idx + K][route_info[-1] + K]
                                    d3 = DIST[o3_idx][route_info[-5] + K]
                                    total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                                    if total_cost < check:
                                        if check is not np.inf:
                                            add[-1] = np.array([remain,
                                                                    p_p3,
                                                                    min_deadline,
                                                                    d1,
                                                                    d2,
                                                                    d3,
                                                                    route_info[6],
                                                                    total_cost,
                                                                    route_info[-10],
                                                                    route_info[-9],
                                                                    route_info[-8],
                                                                    route_info[-7],
                                                                    route_info[-6],
                                                                    o3_idx,
                                                                    route_info[-5],
                                                                    route_info[-4],
                                                                    route_info[-3],
                                                                    route_info[-2],
                                                                    o3_idx,
                                                                    route_info[-1]
                                                                    ], dtype='i4')
                                        else:
                                            cut_num += 1
                                            add.append(np.array([remain,
                                                                    p_p3,
                                                                    min_deadline,
                                                                    d1,
                                                                    d2,
                                                                    d3,
                                                                    route_info[6],
                                                                    total_cost,
                                                                    route_info[-10],
                                                                    route_info[-9],
                                                                    route_info[-8],
                                                                    route_info[-7],
                                                                    route_info[-6],
                                                                    o3_idx,
                                                                    route_info[-5],
                                                                    route_info[-4],
                                                                    route_info[-3],
                                                                    route_info[-2],
                                                                    o3_idx,
                                                                    route_info[-1]
                                                                    ], dtype='i4'))
                                        check = total_cost

                        p_p3_d_4 = p_p3_d_1_1 + T[route_info[6]][route_info[-3] + K][o3_idx + K]
                        if p_p3_d_4 <= order_deadlines[o3_idx]:
                            p_p3_d_4 += T[route_info[6]][o3_idx + K][route_info[-2] + K]
                            if p_p3_d_4 <= order_deadlines[route_info[-2]]:
                                p_p3_d_d3 = p_p3_d_4 + T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                                if p_p3_d_d3 <= order_deadlines[route_info[-1]]:
#                                        cut_num +=1
                                    d1 = route_info[3] + DIST[route_info[-6]][o3_idx]
                                    d2 = DIST[route_info[-5] + K][route_info[-4] + K] + DIST[route_info[-4] + K][
                                        route_info[-3] + K] + DIST[route_info[-3] + K][o3_idx + K] + DIST[o3_idx + K][
                                             route_info[-2] + K] + DIST[route_info[-2] + K][route_info[-1] + K]
                                    d3 = DIST[o3_idx][route_info[-5] + K]
                                    total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                                    if total_cost < check:
                                        if check is not np.inf:
                                            add[-1] = np.array([remain,
                                                                    p_p3,
                                                                    min_deadline,
                                                                    d1,
                                                                    d2,
                                                                    d3,
                                                                    route_info[6],
                                                                    total_cost,
                                                                    route_info[-10],
                                                                    route_info[-9],
                                                                    route_info[-8],
                                                                    route_info[-7],
                                                                    route_info[-6],
                                                                    o3_idx,
                                                                    route_info[-5],
                                                                    route_info[-4],
                                                                    route_info[-3],
                                                                    o3_idx,
                                                                    route_info[-2],
                                                                    route_info[-1]
                                                                    ], dtype='i4')
                                        else:
                                            cut_num += 1
                                            add.append(np.array([remain,
                                                                    p_p3,
                                                                    min_deadline,
                                                                    d1,
                                                                    d2,
                                                                    d3,
                                                                    route_info[6],
                                                                    total_cost,
                                                                    route_info[-10],
                                                                    route_info[-9],
                                                                    route_info[-8],
                                                                    route_info[-7],
                                                                    route_info[-6],
                                                                    o3_idx,
                                                                    route_info[-5],
                                                                    route_info[-4],
                                                                    route_info[-3],
                                                                    o3_idx,
                                                                    route_info[-2],
                                                                    route_info[-1]
                                                                    ], dtype='i4'))
                                                                    
                                        check = total_cost

                    p_p3_d_3 = p_p3_d_1 + T[route_info[6]][route_info[-4] + K][o3_idx + K]
                    if p_p3_d_3 <= order_deadlines[o3_idx]:
                        p_p3_d_3 += T[route_info[6]][o3_idx + K][route_info[-3] + K]
                        if p_p3_d_3 <= order_deadlines[route_info[-3]]:
                            p_p3_d_3 += T[route_info[6]][route_info[-3] + K][route_info[-2] + K]
                            if p_p3_d_3 <= order_deadlines[route_info[-2]]:
                                p_p3_d_d3 = p_p3_d_3 + T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                                if p_p3_d_d3 <= order_deadlines[route_info[-1]]:
#                                        cut_num +=1
                                    d1 = route_info[3] + DIST[route_info[-6]][o3_idx]
                                    d2 = DIST[route_info[-5] + K][route_info[-4] + K] + DIST[route_info[-4] + K][
                                        o3_idx + K] + DIST[o3_idx + K][route_info[-3] + K] + DIST[route_info[-3] + K][
                                             route_info[-2] + K] + DIST[route_info[-2] + K][route_info[-1] + K]
                                    d3 = DIST[o3_idx][route_info[-5] + K]
                                    total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                                    if total_cost < check:
                                        if check is not np.inf:
                                            add[-1] = np.array([remain,
                                                                    p_p3,
                                                                    min_deadline,
                                                                    d1,
                                                                    d2,
                                                                    d3,
                                                                    route_info[6],
                                                                    total_cost,
                                                                    route_info[-10],
                                                                    route_info[-9],
                                                                    route_info[-8],
                                                                    route_info[-7],
                                                                    route_info[-6],
                                                                    o3_idx,
                                                                    route_info[-5],
                                                                    route_info[-4],
                                                                    o3_idx,
                                                                    route_info[-3],
                                                                    route_info[-2],
                                                                    route_info[-1]
                                                                    ], dtype='i4')
                                        else:
                                            cut_num += 1
                                            add.append(np.array([remain,
                                                                    p_p3,
                                                                    min_deadline,
                                                                    d1,
                                                                    d2,
                                                                    d3,
                                                                    route_info[6],
                                                                    total_cost,
                                                                    route_info[-10],
                                                                    route_info[-9],
                                                                    route_info[-8],
                                                                    route_info[-7],
                                                                    route_info[-6],
                                                                    o3_idx,
                                                                    route_info[-5],
                                                                    route_info[-4],
                                                                    o3_idx,
                                                                    route_info[-3],
                                                                    route_info[-2],
                                                                    route_info[-1]
                                                                    ], dtype='i4'))
                                        check = total_cost

                p_p3_d_2 = p_p3_d + T[route_info[6]][route_info[-5] + K][o3_idx + K]
                if p_p3_d_2 <= order_deadlines[o3_idx]:
                    p_p3_d_2 += T[route_info[6]][o3_idx + K][route_info[-4] + K]
                    if p_p3_d_2 <= order_deadlines[route_info[-4]]:
                        p_p3_d_2 += T[route_info[6]][route_info[-4] + K][route_info[-3] + K]
                        if p_p3_d_2 <= order_deadlines[route_info[-3]]:
                            p_p3_d_2 += T[route_info[6]][route_info[-3] + K][route_info[-2] + K]
                            if p_p3_d_2 <= order_deadlines[route_info[-2]]:
                                p_p3_d_d3 = p_p3_d_2 + T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                                if p_p3_d_d3 <= order_deadlines[route_info[-1]]:
#                                        cut_num += 1
                                    d1 = route_info[3] + DIST[route_info[-6]][o3_idx]
                                    d2 = DIST[route_info[-5] + K][o3_idx + K] + DIST[o3_idx + K][route_info[-4] + K] + \
                                         DIST[route_info[-4] + K][route_info[-3] + K] + DIST[route_info[-3] + K][
                                             route_info[-2] + K] + DIST[route_info[-2] + K][route_info[-1] + K]
                                    d3 = DIST[o3_idx][route_info[-5] + K]
                                    total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                                    if total_cost < check:
                                        if check is not np.inf:
                                            add[-1] = np.array([remain,
                                                                    p_p3,
                                                                    min_deadline,
                                                                    d1,
                                                                    d2,
                                                                    d3,
                                                                    route_info[6],
                                                                    total_cost,
                                                                    route_info[-10],
                                                                    route_info[-9],
                                                                    route_info[-8],
                                                                    route_info[-7],
                                                                    route_info[-6],
                                                                    o3_idx,
                                                                    route_info[-5],
                                                                    o3_idx,
                                                                    route_info[-4],
                                                                    route_info[-3],
                                                                    route_info[-2],
                                                                    route_info[-1]
                                                                    ], dtype='i4')
                                        else:
                                            cut_num += 1
                                            add.append(np.array([remain,
                                                                    p_p3,
                                                                    min_deadline,
                                                                    d1,
                                                                    d2,
                                                                    d3,
                                                                    route_info[6],
                                                                    total_cost,
                                                                    route_info[-10],
                                                                    route_info[-9],
                                                                    route_info[-8],
                                                                    route_info[-7],
                                                                    route_info[-6],
                                                                    o3_idx,
                                                                    route_info[-5],
                                                                    o3_idx,
                                                                    route_info[-4],
                                                                    route_info[-3],
                                                                    route_info[-2],
                                                                    route_info[-1]
                                                                    ], dtype='i4'))
                                        check = total_cost

            p_p3_d3 = p_p3 + T[route_info[6]][o3_idx][o3_idx + K]
            if p_p3_d3 <= min_deadline:
                p_p3_d3_d = p_p3_d3 + T[route_info[6]][o3_idx + K][route_info[-5] + K]
                if p_p3_d3_d <= order_deadlines[route_info[-5]]:
                    p_p3_d3_d += T[route_info[6]][route_info[-5] + K][route_info[-4] + K]
                    if p_p3_d3_d <= order_deadlines[route_info[-4]]:
                        p_p3_d3_d += T[route_info[6]][route_info[-4] + K][route_info[-3] + K]
                        if p_p3_d3_d <= order_deadlines[route_info[-3]]:
                            p_p3_d3_d += T[route_info[6]][route_info[-3] + K][route_info[-2] + K]
                            if p_p3_d3_d <= order_deadlines[route_info[-2]]:
                                p_p3_d3_d += T[route_info[6]][route_info[-2] + K][route_info[-1] + K]
                                if p_p3_d3_d <= order_deadlines[route_info[-1]]:
#                                        cut_num +=1
                                    d1 = route_info[3] + DIST[route_info[-6]][o3_idx]
                                    d2 = route_info[4] + DIST[o3_idx + K][route_info[-5] + K]
                                    d3 = DIST[o3_idx][o3_idx + K]
                                    total_cost = fixed_cost[route_info[6]] + (d1 + d2 + d3) / 100 * var_cost[route_info[6]]
                                    if total_cost < check:
                                        if check is not np.inf:
                                            add[-1] = np.array([remain,
                                                                    p_p3,
                                                                    min_deadline,
                                                                    d1,
                                                                    d2,
                                                                    d3,
                                                                    route_info[6],
                                                                    total_cost,
                                                                    route_info[-10],
                                                                    route_info[-9],
                                                                    route_info[-8],
                                                                    route_info[-7],
                                                                    route_info[-6],
                                                                    o3_idx,
                                                                    o3_idx,
                                                                    route_info[-5],
                                                                    route_info[-4],
                                                                    route_info[-3],
                                                                    route_info[-2],
                                                                    route_info[-1]
                                                                    ], dtype='i4')
                                        else:
                                            cut_num += 1
                                            add.append(np.array([remain,
                                                                    p_p3,
                                                                    min_deadline,
                                                                    d1,
                                                                    d2,
                                                                    d3,
                                                                    route_info[6],
                                                                    total_cost,
                                                                    route_info[-10],
                                                                    route_info[-9],
                                                                    route_info[-8],
                                                                    route_info[-7],
                                                                    route_info[-6],
                                                                    o3_idx,
                                                                    o3_idx,
                                                                    route_info[-5],
                                                                    route_info[-4],
                                                                    route_info[-3],
                                                                    route_info[-2],
                                                                    route_info[-1]
                                                                    ], dtype='i4'))  # route_info[4]+[o3.id]
    if len(add) == 0:
        add.append(np.array([0], dtype='i4'))
    return add
    
@numba.jit(nopython=True)
def init_list(nthreads):
    init_add = numba.typed.List()
    for _ in range(nthreads):
        a = []
        a.append(np.array([0], dtype='i4'))
        init_add.append(a)
    return init_add

#@numba.jit(nopython=True, cache=True, fastmath=True, parallel=True)
@numba.jit(('(i4, i4[:], i4[:], i4[:], i4[:,:,:], i4[:], i4[:,:], i4[:,:], i4[:], i4[:], i4, i4, i4, i4)'), nopython=True, cache=True, fastmath=True, parallel=True)
def make_bundles(K, rider_capas, order_volumes, order_ready_times, T, order_deadlines, DIST, delete_order, fixed_cost, var_cost, min_volume, timelimit, prob_lon, prob_dt):
    R2_add, possible, possible2, r3_cut_add = make_R2(K, rider_capas, order_volumes, order_ready_times, T, order_deadlines, DIST, delete_order, fixed_cost, var_cost, timelimit, prob_lon, prob_dt)
    
    nthreads = 4
    R3_add = init_list(nthreads)
    num_vals = len(R2_add)
    n_per_thread = int(num_vals / nthreads) + 1
    for i in numba.prange(0, nthreads):
        start = i * n_per_thread
        end = min((i + 1) * n_per_thread, num_vals)
        R3_add[i] = make_R3(R2_add[start:end], min_volume, possible, possible2, order_volumes, order_ready_times, order_deadlines, T, DIST, fixed_cost, var_cost, K, r3_cut_add)

#    R4_add = [[np.array([0])], [np.array([0])] , [np.array([0])] , [np.array([0])]]
    R4_add = init_list(nthreads)
    for i in numba.prange(0, nthreads):
        if len(R3_add[i][0]) != 1:
            R4_add[i] = make_R4(R3_add[i], min_volume, possible, possible2, order_volumes, order_ready_times, order_deadlines, T, DIST, fixed_cost, var_cost, K)
    
#    R5_add = [[np.array([0])], [np.array([0])] , [np.array([0])] , [np.array([0])]]
    R5_add = init_list(nthreads)
    for i in numba.prange(0, nthreads):
        if len(R4_add[i][0]) != 1:
            R5_add[i] = make_R5(R4_add[i], min_volume, possible, possible2, order_volumes, order_ready_times, order_deadlines, T, DIST, fixed_cost, var_cost, K)
            
#    R6_add = [[np.array([0])], [np.array([0])] , [np.array([0])] , [np.array([0])]]
    R6_add = init_list(nthreads)
    for i in numba.prange(0, nthreads):
        if len(R5_add[i][0]) != 1:
            R6_add[i] = make_R6(R5_add[i], min_volume, possible, possible2, order_volumes, order_ready_times, order_deadlines, T, DIST, fixed_cost, var_cost, K)
        
#    print('f')
    return R2_add, R3_add, R4_add, R5_add, R6_add

class Data:
    def __init__(self, K, all_orders, all_riders, dist_mat, timelimit, prob_lon, prob_dt):
        self.start_time = time.time()
        self.K = K
        self.ALL_ORDERS = all_orders
        self.ALL_RIDERS = all_riders
        self.DIST = dist_mat
        self.prob_timelimit = timelimit
        self.prob_lon = prob_lon
        self.prob_dt = prob_dt

        for r in self.ALL_RIDERS:
            r.T = np.round(self.DIST / r.speed + r.service_time)
            
        self.DIST = self.DIST.astype('i4')

        self.rider_idx_dic = {r: idx for idx, r in enumerate(self.ALL_RIDERS)}
        self.rider_type_idx_dic = {r.type: idx for idx, r in enumerate(self.ALL_RIDERS)}
        self.rider_type_rider_dic = {r.type: r for idx, r in enumerate(self.ALL_RIDERS)}

        self.rider_capas = np.array([r.capa for r in self.ALL_RIDERS], dtype='i4')
        self.rider_Ts = np.array([r.T for r in self.ALL_RIDERS], dtype='i4')
        self.rider_fixed_cost = np.array([r.fixed_cost for r in self.ALL_RIDERS], dtype='i4')
        self.rider_var_cost = np.array([r.var_cost for r in self.ALL_RIDERS], dtype='i4')

        self.order_volumes = np.array([o.volume for o in self.ALL_ORDERS], dtype='i4')
        self.order_ready_times = np.array([o.ready_time for o in self.ALL_ORDERS], dtype='i4')
        self.order_deadlines = np.array([o.deadline for o in self.ALL_ORDERS], dtype='i4')

        self.min_volume = np.min(self.order_volumes)
        self.delete_order = np.array(make_delete_order(self.DIST, np.int32(self.K)), dtype='i4')

        self.makeR()
#        print(time.time() - self.start_time)

        self.R = [(f"{idx}", r[0], self.R_all_dic[r][0]) for idx, r in enumerate(self.R_all_dic)]
        self.O = [o for o in range(self.K)]

        self.R_all_dic = None
#        print(time.time() - self.start_time)

        self.o_r_dic = {o: [] for o in self.O}
        self.r_o_dic = {route_idx: key for route_idx, key, v in self.R}
        self.RB = {0: [], 1: [], 2: []}
#        self.cost = {route_idx: v[7] for route_idx, key, v in self.R}

#        print(time.time() - self.start_time)
        for ele in self.R:
            route_idx, key, v = ele
            self.RB[int(v[6])].append(route_idx)
            for o in key:
                self.o_r_dic[int(o)].append(route_idx)
                
#        print(time.time() - self.start_time)

    def R_dic_update(self, R_dic, num):
        num1, num2, num3 = 40, 30, 20
        
        if len(R_dic) <= 20000:
            self.R_all_dic.update(R_dic)
        elif len(R_dic) <= 100000:
            R_dic_change = self.R_dic_change(R_dic, num1)
            self.R_all_dic.update(R_dic_change)
        elif len(R_dic) <= 300000:
            R_dic_change = self.R_dic_change(R_dic, num2)
            self.R_all_dic.update(R_dic_change)
        else:
            R_dic_change = self.R_dic_change(R_dic, num3)
            self.R_all_dic.update(R_dic_change)

    def R_dic_change(self, R_dic, num):
        test = {i: {j: [] for j in range(3)} for i in range(self.K)}
        for key, value in R_dic.items():
            for i in key[0]:
                test[int(i)][int(key[1])].append((value[0][7], key[0]))

        for i in range(self.K):
            for j in range(3):
                test[i][j].sort(key=lambda x: x[0])
        
        rider_idx = np.array([0,1,2], dtype='i4')
        keys = {(key, j) for i in range(self.K) for j in rider_idx for q, key in test[i][int(j)][:num]}
        R_dic_change = {(key[0], key[1]): R_dic[(key[0], key[1])] for key in keys}

        return R_dic_change

    def makeR(self):
        R1_dic = {
            (tuple([o1.id]), self.rider_idx_dic[rider]): [
                np.array([0, 0, 0, 0, 0, self.DIST[o1.id][o1.id + self.K], self.rider_idx_dic[rider],
                          rider.fixed_cost + self.DIST[o1.id][o1.id + self.K] / 100 * rider.var_cost, o1.id],
                         dtype='i4')]
            for rider in self.ALL_RIDERS
            for o1 in self.ALL_ORDERS
            if rider.capa - o1.volume >= 0 and o1.ready_time + rider.T[o1.id][o1.id + self.K] <= o1.deadline
        }
        

        R2_add, R3_add, R4_add, R5_add, R6_add = make_bundles(np.int32(self.K), self.rider_capas, self.order_volumes, self.order_ready_times,
                                          self.rider_Ts, self.order_deadlines, self.DIST, self.delete_order,
                                          self.rider_fixed_cost, self.rider_var_cost, self.min_volume, np.int32(self.prob_timelimit),  np.int32(self.prob_lon), np.int32(self.prob_dt))
#        print('f2')
        
#        self.cut = cut
        R2_dic = defaultdict(list)
        for add in R2_add:
            R2_dic[(tuple(sorted([add[8], add[9]])), add[6])].append(add)

        for k, v in R2_dic.items():
            R2_dic[k] = [min(v, key=lambda x: x[7])]

#        print(time.time() - self.start_time, len(R2_dic))

        R3_dic = defaultdict(list)
        for add_list in R3_add:
            for add in add_list:
                if len(add) == 1:
                    continue
                R3_dic[(tuple(sorted([add[8], add[9], add[10]])), add[6])].append(add)

        for k, v in R3_dic.items():
            R3_dic[k] = [min(v, key=lambda x: x[7])]

#        print(time.time() - self.start_time, len(R3_dic))

        R4_dic = defaultdict(list)
        for add_list in R4_add:
            for add in add_list:
                if len(add) == 1:
                    continue
                R4_dic[(tuple(sorted([add[8], add[9], add[10], add[11]])), add[6])].append(add)
                
        for k, v in R4_dic.items():
            # v.sort(key=lambda x: x[7])
            R4_dic[k] = [min(v, key=lambda x: x[7])]

#        print(time.time() - self.start_time, len(R4_dic))

        R5_dic = defaultdict(list)
        for add_list in R5_add:
            for add in add_list:
                if len(add) == 1:
                    continue
                R5_dic[(tuple(sorted([add[8], add[9], add[10], add[11], add[12]])), add[6])].append(add)

        for k, v in R5_dic.items():
            R5_dic[k] = [min(v, key=lambda x: x[7])]

#        print(time.time() - self.start_time, len(R5_dic))

        R6_dic = defaultdict(list)
        for add_list in R6_add:
            for add in add_list:
                if len(add) == 1:
                    continue
                R6_dic[(tuple(sorted([add[8], add[9], add[10], add[11], add[12], add[13]])), add[6])].append(add)

        for k, v in R6_dic.items():
            R6_dic[k] = [min(v, key=lambda x: x[7])]
        
        self.R_all_dic = {}
        self.R_all_dic.update(R1_dic)
        self.R_dic_update(R2_dic, 2)
        self.R_dic_update(R3_dic, 3)
        self.R_dic_update(R4_dic, 4)
        self.R_dic_update(R5_dic, 5)
        self.R_dic_update(R6_dic, 6)
        
        R2_add = None
        R3_add = None
        R4_add = None
        R5_add = None
        R6_add = None
        
        R2_dic = None
        R3_dic = None
        R4_dic = None
        R5_dic = None
        R6_dic = None

class Model:
    def __init__(self, data):
        start_time = time.time()

#        options = {
#            'WLSACCESSID':'3b1670e5-28e5-4d51-b148-467e29fc37e0',
#            'WLSSECRET':'9306284b-13b5-47f6-9738-fa06e1d0bcc9',
#            'LICENSEID':2531784,
#        }
#
#        env = gp.Env(params=options)
#        self.model = gp.Model(env=env)
        self.model = gp.Model()

        self.x = self.model.addVars([ele[0] for ele in data.R], vtype=GRB.BINARY)
        self.y = self.model.addVars([f"{r_idx}_{o}" for r_idx, key, v in data.R for o in key], vtype=GRB.BINARY)

        # print(time.time() - start_time)
        self.model.addConstrs((gp.quicksum(self.y[f"{r_idx}_{o}"] for o in data.r_o_dic[r_idx]) == len(data.r_o_dic[r_idx]) * self.x[f"{r_idx}"] for r_idx in data.r_o_dic))
        # print(time.time() - start_time)
        self.model.addConstrs((gp.quicksum(self.y[f"{r}_{o}"] for r in data.o_r_dic[o]) == 1 for o in data.O))
        # print(time.time() - start_time)
        self.model.addConstrs((gp.quicksum(self.x[f"{r}"] for r in data.RB[rider_idx]) <= data.ALL_RIDERS[rider_idx].available_number for rider_idx in [0,1,2]))
        self.model.setObjective(gp.quicksum(int(v[7]) * self.x[f"{r_idx}"] for r_idx, key, v in data.R)/data.K, GRB.MINIMIZE)
        # print(time.time() - start_time)
        # self.model.update()

    def solve(self, limit, R, all_riders):
#        print(limit)
        start_time = time.time()

        self.model.setParam("TimeLimit", limit)
#        self.model.setParam("TimeLimit", 10)

        self.model.update()
        # print(time.time() - start_time)
        self.model.optimize()
        
#        print(time.time() - start_time)

        sol_idx = [int(r_idx) for r_idx in self.x if self.x[f"{r_idx}"].x > 0.001]
        solution = [[all_riders[R[idx][2][6]].type, [int(R[idx][2][8])], [int(R[idx][2][8])]] if len(R[idx][1]) == 1
            else [all_riders[R[idx][2][6]].type, [int(R[idx][2][8]), int(R[idx][2][9])],
                  [int(R[idx][2][10]), int(R[idx][2][11])]] if len(R[idx][1]) == 2
            else [all_riders[R[idx][2][6]].type,
                  [int(R[idx][2][8]), int(R[idx][2][9]), int(R[idx][2][10])],
                  [int(R[idx][2][11]), int(R[idx][2][12]), int(R[idx][2][13])]] if len(R[idx][1]) == 3
            else [all_riders[R[idx][2][6]].type,
                  [int(R[idx][2][8]), int(R[idx][2][9]), int(R[idx][2][10]), int(R[idx][2][11])],
                  [int(R[idx][2][12]), int(R[idx][2][13]), int(R[idx][2][14]),
                   int(R[idx][2][15])]] if len(R[idx][1]) == 4
            else [all_riders[R[idx][2][6]].type,
                  [int(R[idx][2][8]), int(R[idx][2][9]), int(R[idx][2][10]), int(R[idx][2][11]),
                   int(R[idx][2][12])],
                  [int(R[idx][2][13]), int(R[idx][2][14]), int(R[idx][2][15]), int(R[idx][2][16]),
                   int(R[idx][2][17])]] if len(R[idx][1]) == 5
            else [all_riders[R[idx][2][6]].type,
                  [int(R[idx][2][8]), int(R[idx][2][9]), int(R[idx][2][10]), int(R[idx][2][11]),
                   int(R[idx][2][12]), int(R[idx][2][13])],
                  [int(R[idx][2][14]), int(R[idx][2][15]), int(R[idx][2][16]), int(R[idx][2][17]),
                   int(R[idx][2][18]), int(R[idx][2][19])]] if len(R[idx][1]) == 6
            else [all_riders[R[idx][2][6]].type,
                  [int(R[idx][2][8]), int(R[idx][2][9]), int(R[idx][2][10]), int(R[idx][2][11]),
                   int(R[idx][2][12]), int(R[idx][2][13]), int(R[idx][2][14])],
                  [int(R[idx][2][15]), int(R[idx][2][16]), int(R[idx][2][17]), int(R[idx][2][18]),
                   int(R[idx][2][19]), int(R[idx][2][20]), int(R[idx][2][21])]]
                        for idx in sol_idx]
                        
#        print(time.time() - start_time)

        return solution

def algorithm(K, all_orders, all_riders, dist_mat, timelimit=60):
    start_time = time.time()

    lons = [(o.shop_lon, o.dlv_lon) for o in all_orders]
    times = np.average([o.deadline-o.ready_time for o in all_orders])
    prob_lon = np.max(lons) - np.min(lons)
    
    if prob_lon <= 0.15:
        prob_num = 1
    else:
        prob_num = 2

    if times >= 2000:
        prob_num2 = 1
    else:
        prob_num2 = 2
    
    data = Data(K, all_orders, all_riders, dist_mat, timelimit, prob_num, prob_num2)
#    print('f3')
    model = Model(data)
    
    if timelimit <= 15:
        add = 0.8
    elif timelimit <= 60:
        add = 1
    elif timelimit <= 180:
        add = 2
    elif timelimit <= 300:
        add = 3
    else:
        add = 4
        
    if K > 1000:
        add += 3
    
#    print(time.time() - start_time)
    solution = model.solve((timelimit - (time.time() - start_time))-add, data.R, all_riders)
#    print(time.time() - start_time)
    
    return solution
