#ifndef HEAP_H
#define HEAP_H

#include <vector>
#include <stdexcept>
#include <variant>
#include <algorithm>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h> // std::vector에 대한 지원을 위해 필요
#include <pybind11/numpy.h> // NumPy array support

namespace py = pybind11;
using VariantType = std::variant<int, double, py::object>;

class Heap {
public:
    Heap() {}

    void heappush(std::vector<std::vector<VariantType>>& heap, const std::vector<VariantType>& item);
    std::vector<VariantType> heappop(std::vector<std::vector<VariantType>>& heap);
    void heapify(std::vector<std::vector<VariantType>>& heap, const std::vector<std::vector<VariantType>>& iterable);
    std::vector<VariantType> heappushpop(std::vector<std::vector<VariantType>>& heap, const std::vector<VariantType>& item);
    std::vector<VariantType> heapreplace(std::vector<std::vector<VariantType>>& heap, const std::vector<VariantType>& item);

private:
    void siftUp(std::vector<std::vector<VariantType>>& heap, int index);
    void siftDown(std::vector<std::vector<VariantType>>& heap, int index);
    double getValue(const std::vector<VariantType>& vec); // Helper function for comparisons
    int compareVectors(const std::vector<VariantType>& a, const std::vector<VariantType>& b);
};

#endif // HEAP_H
