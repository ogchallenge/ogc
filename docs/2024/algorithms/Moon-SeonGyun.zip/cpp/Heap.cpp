#include "Heap.h"
#include <variant>
#include <iostream>
#include <stdexcept>
#include <algorithm>

using VariantType = std::variant<int, double, py::object>;

void Heap::heappush(std::vector<std::vector<VariantType>>& heap, const std::vector<VariantType>& item) {
    heap.push_back(item);
    siftUp(heap, heap.size() - 1);
}

std::vector<VariantType> Heap::heappop(std::vector<std::vector<VariantType>>& heap) {
    if (heap.empty()) {
        // return {0};
        throw std::out_of_range("pop from empty heap");
    }
    
    std::vector<VariantType> minItem = heap[0]; // Save the minimum item
    std::vector<VariantType> lastItem = heap.back(); // Get the last item
    heap.pop_back(); // Remove the last item
    
    if (!heap.empty()) {
        heap[0] = lastItem; // Replace the root with the last item
        siftDown(heap, 0); // Restore the heap property
    }
    
    return minItem; // Return the minimum item
}

void Heap::heapify(std::vector<std::vector<VariantType>>& heap, const std::vector<std::vector<VariantType>>& iterable) {
    heap = iterable;
    int n = heap.size();
    for (int i = n / 2 - 1; i >= 0; --i) {
        siftDown(heap, i);
    }
}

std::vector<VariantType> Heap::heappushpop(std::vector<std::vector<VariantType>>& heap, const std::vector<VariantType>& item) {
    if (!heap.empty() && getValue(heap[0]) < getValue(item)) {
        std::vector<VariantType> returnItem = heap[0]; // Store the min item
        heap[0] = item; // Replace it with the new item
        siftDown(heap, 0); // Restore the heap property
        return returnItem; // Return the removed item
    } else {
        heappush(heap, item); // If the heap is empty or the item is smaller, just push
        return {}; // Return an empty vector
    }
}

std::vector<VariantType> Heap::heapreplace(std::vector<std::vector<VariantType>>& heap, const std::vector<VariantType>& item) {
    if (!heap.empty()) {
        std::vector<VariantType> returnItem = heap[0]; // Store the min item
        heap[0] = item; // Replace it with the new item
        siftDown(heap, 0); // Restore the heap property
        return returnItem; // Return the removed item
    } else {
        heap.push_back(item); // If heap is empty, just add the new item
        return {}; // Return an empty vector
    }
}

void Heap::siftUp(std::vector<std::vector<VariantType>>& heap, int index) {
    while (index > 0) {
        int parentIndex = (index - 1) / 2;
        if (compareVectors(heap[parentIndex], heap[index]) > 0) {
            std::swap(heap[parentIndex], heap[index]);
            index = parentIndex;
        } else {
            break;
        }
    }
}

void Heap::siftDown(std::vector<std::vector<VariantType>>& heap, int index) {
    int n = heap.size();
    while (index < n / 2) {
        int leftChildIndex = 2 * index + 1;
        int rightChildIndex = 2 * index + 2;
        int minChildIndex = leftChildIndex;

        // 가장 작은 자식 찾기
        if (rightChildIndex < n && compareVectors(heap[rightChildIndex], heap[leftChildIndex]) < 0) {
            minChildIndex = rightChildIndex;
        }

        // 현재 요소와 가장 작은 자식 비교
        if (compareVectors(heap[index], heap[minChildIndex]) > 0) {
            std::swap(heap[index], heap[minChildIndex]);
            index = minChildIndex;
        } else {
            break;
        }
    }
}

double Heap::getValue(const std::vector<VariantType>& vec) {
    // 이 함수는 벡터의 모든 요소를 기반으로 비교합니다.
    // 첫 번째 요소를 먼저 비교하고, 그 다음 두 번째 요소, 이렇게 진행합니다.
    
    for (size_t i = 0; i < vec.size(); ++i) {
        // 두 벡터의 크기를 초과하지 않도록 확인
        if (i >= vec.size()) {
            break; // 벡터가 짧으면 루프 종료
        }

        // 현재 값을 타입에 따라 가져오기
        double currentValue;
        if (std::holds_alternative<int>(vec[i])) {
            currentValue = static_cast<double>(std::get<int>(vec[i]));
        } else {
            currentValue = std::get<double>(vec[i]);
        }

        // 현재 값을 비교
        if (i == 0) {
            return currentValue; // 첫 번째 값을 기본 비교로 반환
        } else {
            // 추가 비교를 위한 로직이 필요할 경우 추가
        }
    }

    return 0; // 벡터가 비어 있는 경우 기본 반환 값
}

// 두 벡터를 비교하는 함수
int Heap::compareVectors(const std::vector<VariantType>& a, const std::vector<VariantType>& b) {
    size_t minSize = std::min(a.size(), b.size());
    for (size_t i = 0; i < minSize; i++) {
        if (std::holds_alternative<py::object>(a[i])) return 0;
        double valA = std::holds_alternative<int>(a[i]) ? static_cast<double>(std::get<int>(a[i])) : std::get<double>(a[i]);
        double valB = std::holds_alternative<int>(b[i]) ? static_cast<double>(std::get<int>(b[i])) : std::get<double>(b[i]);

        if (valA < valB) return -1; // a가 b보다 작음
        if (valA > valB) return 1;  // a가 b보다 큼
    }
    return 0; // 두 벡터가 같음
}
