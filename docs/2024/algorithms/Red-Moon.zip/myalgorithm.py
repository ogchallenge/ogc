import numpy as np
import gurobipy as gp
import time
from gurobipy import GRB
from util import *
import practice
import concurrent.futures

########################################################################################
####                                  Algorithm                                     ####
########################################################################################

def decide_parameters(K, timelimit, avg_dist):

    if K >= 1500:
        RATIO_1ST = 0.3
        COVERAGE = 25
        SAFEFY = 8

    elif K >= 1000:
        RATIO_1ST = 0.5
        if timelimit > 200:
            RATIO_1ST = 0.4
        COVERAGE = 18
        SAFEFY = 2

    elif K >= 750:
        RATIO_1ST = 0.4
        COVERAGE = 18
        SAFEFY = 1.5

    elif K >= 500:
        RATIO_1ST = 0.5
        COVERAGE = 15
        SAFEFY = 1
    else:
        RATIO_1ST = 0.5
        COVERAGE = 15
        SAFEFY = 0.7
    
    return RATIO_1ST, COVERAGE, SAFEFY

def algorithm(K, all_orders, all_riders, dist_mat, timelimit):

    start_time = time.time()

    for r in all_riders:
        r.T = np.round(dist_mat/r.speed + r.service_time)
        
    # A solution is a list of bundles
    solution = []

    #------------- Custom algorithm code starts from here --------------#

    dist_mat = dist_mat.astype(np.float64)
    avg_dist = dist_mat.mean()
    RATIO_1ST, COVERAGE, SAFETY = decide_parameters(K, timelimit, avg_dist)

    basic_bundles, bike2, car2 = practice.make_basic_bundles(K, all_orders, all_riders, dist_mat)

    time_left = timelimit - (time.time() - start_time)
    print(time_left)
    tasks = [
        (practice.worker1, (K, all_orders, all_riders, dist_mat, COVERAGE, time_left*RATIO_1ST, bike2, car2)),
        (practice.worker2, (K, all_orders, all_riders, dist_mat, COVERAGE, time_left*RATIO_1ST, bike2, car2)),
        (practice.worker3, (K, all_orders, all_riders, dist_mat, COVERAGE, time_left*RATIO_1ST, bike2, car2)),
        (practice.worker4, (K, all_orders, all_riders, dist_mat, COVERAGE, time_left*RATIO_1ST, bike2, car2))
    ]

    pool = concurrent.futures.ProcessPoolExecutor(max_workers=4)
    procs = []

    for i in range(4):
        procs.append(pool.submit(tasks[i][0], tasks[i][1][0], tasks[i][1][1], tasks[i][1][2], tasks[i][1][3], 
                                 tasks[i][1][4], tasks[i][1][5], tasks[i][1][6], tasks[i][1][7]))

    for p in concurrent.futures.as_completed(procs):
        basic_bundles += p.result()

    print(f"number of profitable bundle {len(basic_bundles)}")
                
    total_bundles = basic_bundles

    cost = []
    w = []
    b = []
    c = []

    for bundle in total_bundles:
        cost.append(bundle.cost)

        if bundle.rider.type == 'BIKE':
            w.append(0)
            b.append(1)
            c.append(0)

        elif bundle.rider.type == 'CAR':
            w.append(0)
            b.append(0)
            c.append(1)

        else:
            w.append(1)
            b.append(0)
            c.append(0)

    B = all_riders[0].available_number
    W = all_riders[1].available_number
    C = all_riders[2].available_number
    
    # Number of variables (i) and constraints (k)
    n_i = len(cost)

    model = gp.Model('binary_optimization')
    
    # Define binary variables
    x = model.addVars(n_i, vtype=GRB.BINARY, name="x")

    objective = gp.LinExpr()
    objective.addTerms(cost, [x[i] for i in range(n_i)])
    model.setObjective(objective, GRB.MINIMIZE)

    linDict = dict()
    for k in range(K):
        linDict[k] = gp.LinExpr()
    for i in range(n_i):
        bundle = total_bundles[i]
        for ind in bundle.shop_seq:
            linDict[ind].addTerms(1, x[i])

    for k in range(K):
        model.addConstr(linDict[k] == 1)

    # Constraint 2: sigma x_i * w_i <= W
    model.addConstr(gp.quicksum(x[i] * w[i] for i in range(n_i)) <= W)

    # Constraint 3: sigma x_i * b_i <= B
    model.addConstr(gp.quicksum(x[i] * b[i] for i in range(n_i)) <= B)

    # Constraint 4: sigma x_i * c_i <= C
    model.addConstr(gp.quicksum(x[i] for i in range(n_i)) <= C)


    time_left = timelimit - (time.time()-start_time)
    print(time_left)
    model.setParam('TimeLimit', time_left-SAFETY)
    model.setParam('Heuristics',0.99)
    model.optimize()
    
    solution_bundles = []

    sol = model.getAttr('x', x)
    indices_of_ones = [i for i in range(n_i) if sol[i] > 0.5]

    for index in indices_of_ones:
        solution_bundles.append(total_bundles[index])
    
    solution = [
       # rider type, shop_seq, dlv_seq
        [bundle.rider.type, bundle.shop_seq, bundle.dlv_seq]
        for bundle in solution_bundles
    ]

    #------------- End of custom algorithm code--------------#
    return solution
