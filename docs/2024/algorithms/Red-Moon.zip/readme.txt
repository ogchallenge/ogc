0. 디렉토리로 이동
1. 디렉토리에서 python setup.py build_ext --inplace 명령, practice.pyx에 있는 내용이 practice.c, practice.cpython-310-x86_64-linux-gnu.so 파일로 만들어짐
2. myalgorithm.py 사용 가능