# OGC2025 - TEAM FORRORO

## 소개

본 프로젝트는 **OGC2025** 대회를 위해 개발된 **RORO 최적화 알고리즘**입니다.  
모든 구현은 **Python**을 이용하여 작성되었으며, 총 6개의 `.py` 파일을 통해 정상적으로 실행 가능합니다.

## 파일 구성

- **myalgorithm.py**  
  메인 실행 파일로, 문제 정보를 입력받아 전체 최적화 알고리즘을 수행합니다.

- **path_optimization_2.py**  
  자동차 **상·하역 경로 탐색 및 최적화 로직**을 포함하고 있습니다.

- **solution_evaluator.py**  
  생성된 해의 **비용 계산 및 타당성 검증**을 담당합니다.

- **util.py**  
  **해 검증 및 그래프 탐색 유틸리티 함수**들이 포함되어 있습니다.

- **utils.py**  
  **수요 처리, 그래프 생성, 거리 계산** 등의 보조 기능을 제공합니다.

- **mip_optimizer_2.py**  
  **Mixed Integer Programming (MIP) 기반 배치 최적화**를 수행하여 해를 개선합니다.

## 실행 방법

터미널에서 아래와 같이 실행할 수 있습니다:

python myalgorithm.py <problem_name> <problem_file> <timelimit_in_seconds>
