import json
import os
import sys
import jsbeautifier

import time
import numpy as np
import util
from myalgorithm import algorithm
import argparse
import importlib.util
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("timelimit", nargs="?", type=int, default=30)
parser.add_argument("--aug", "-a", action="store_true")
parser.add_argument("--prob", "-p", action="store_true")
parser.add_argument("--baseline", "-b", action="store_true")
args = parser.parse_args()


def test_ppaga(K, solution):
    P = max(solution.keys())

    for p in range(1, P + 1):
        unload_demands = set(i for i, ((o, d), r) in enumerate(K) if d == p)
        sol = solution[p]
        sol = [x for x in sol if x[1] in unload_demands]
        if any(path[-1] != 0 for path, demand in sol):
            print("개빠가")


def import_module_from_path(module_name: str, file_path: str):
    file_path = Path(file_path).resolve()
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


if args.baseline:
    mod = import_module_from_path("baseline", "../baseline/myalgorithm.py")
    baseline_algorithm = mod.algorithm


def numpy_to_python(obj):
    if isinstance(obj, np.int64) or isinstance(obj, np.int32):
        return int(obj)
    if isinstance(obj, np.float64) or isinstance(obj, np.float32):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()

    raise TypeError(f"Type {type(obj)} not serializable")


# Arguments list should be problem_name, problem_file, timelimit (in seconds)
prob_dir = "../exercise_problems/stage2"
# prob_dir = "../exercise_problems"
files = [os.path.join(prob_dir, f"prob{i}.json") for i in range(1, 11)]  # [:1]
if args.aug:
    files += sorted(
        [
            os.path.join("../augmented_exercise_problems", x)
            for x in sorted(os.listdir("../augmented_exercise_problems"))
            if x.endswith(".json")
        ],
        key=lambda x: int(x.split("/")[-1][len("aug_prob") : -len(".json")]),
    )  # [120:]

timelimit = args.timelimit
for prob_file in files:
    with open(prob_file, "r") as f:
        prob_info = json.load(f)

    exception = None
    solution = None

    alg_start_time = time.time()

    # Run algorithm!
    import copy

    try:
        solution = algorithm(copy.deepcopy(prob_info), timelimit)
        test_ppaga(prob_info["K"], solution)

        alg_end_time = time.time()

        checked_solution = util.check_feasibility(copy.deepcopy(prob_info), solution)

        checked_solution["time"] = alg_end_time - alg_start_time
        checked_solution["timelimit_exception"] = (
            alg_end_time - alg_start_time
        ) > timelimit
        checked_solution["exception"] = exception

        checked_solution["prob_name"] = prob_file.split("/")[-1].replace(".json", "")
        checked_solution["prob_file"] = prob_file

        if args.baseline:
            b_sol = baseline_algorithm(copy.deepcopy(prob_info), timelimit)
            b_sol_obj = int(
                util.check_feasibility(copy.deepcopy(prob_info), b_sol)["obj"]
            )
            obj = int(checked_solution["obj"])
            if obj / b_sol_obj > 0.8:
                print(
                    f"{checked_solution['prob_name']}: {obj}\t/\t{b_sol_obj}\t({int(obj/b_sol_obj*100)}%)"
                )
        elif args.prob:
            print(f"{checked_solution['prob_name']}: {int(checked_solution['obj'])}")
        else:
            print(
                f"{int(checked_solution['obj'])} / {alg_end_time - alg_start_time:.0f}s"
            )
            # print(f"{int(checked_solution['obj'])}")
    except Exception as e:
        print(f"Exception occurred for {prob_file}: {type(e)}: {e}")
