import time
import util
import numpy as np

import time
import CLib


def algorithm(prob_info, timelimit=60):
    sol = CLib.main_algorithm(prob_info, timelimit)
    return sol


if __name__ == "__main__":
    # You can run this file to test your algorithm from terminal.

    import json
    import os
    import sys
    import jsbeautifier

    def numpy_to_python(obj):
        if isinstance(obj, np.int64) or isinstance(obj, np.int32):
            return int(obj)
        if isinstance(obj, np.float64) or isinstance(obj, np.float32):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()

        raise TypeError(f"Type {type(obj)} not serializable")

    # Arguments list should be problem_name, problem_file, timelimit (in seconds)
    args = sys.argv[1:]
    prob_file = args[0]
    if len(args) > 1:
        timelimit = int(args[1])
    else:
        timelimit = 30

    with open(prob_file, "r") as f:
        prob_info = json.load(f)

    exception = None
    solution = None

    alg_start_time = time.time()

    # Run algorithm!
    solution = algorithm(prob_info, timelimit)

    alg_end_time = time.time()

    checked_solution = util.check_feasibility(prob_info, solution)
    print("Algorithm finished.:", int(checked_solution["obj"]))

    checked_solution["time"] = alg_end_time - alg_start_time
    print("Time taken:", checked_solution["time"])
    checked_solution["timelimit_exception"] = (
        alg_end_time - alg_start_time
    ) > timelimit + 2  # allowing additional 2 second!
    checked_solution["exception"] = exception

    # checked_solution["prob_name"] = prob_name
    checked_solution["prob_file"] = prob_file

    with open("results.json", "w") as f:
        opts = jsbeautifier.default_options()
        opts.indent_size = 2
        f.write(
            jsbeautifier.beautify(
                json.dumps(checked_solution, default=numpy_to_python), opts
            )
        )

    sys.exit(0)
