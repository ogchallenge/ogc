#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")

#include "libutils.hpp"

#include <omp.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <random>
#include <sstream>
#include <unordered_set>
#include <vector>

using namespace std;

static std::atomic<uint64_t> g_seed_counter{0};
static inline uint64_t splitmix64(uint64_t x) {
  x += 0x9e3779b97f4a7c15ull;
  x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ull;
  x = (x ^ (x >> 27)) * 0x94d049bb133111ebull;
  return x ^ (x >> 31);
}
static std::mt19937& get_thread_rng() {
  thread_local std::mt19937 rng = [] {
    uint64_t t = static_cast<uint64_t>(
        std::chrono::high_resolution_clock::now().time_since_epoch().count());

    uint64_t tid = 0;
    tid = static_cast<uint64_t>(omp_get_thread_num());

    uint64_t c = g_seed_counter.fetch_add(1, std::memory_order_relaxed);
    uint64_t s64 = splitmix64(t ^ (tid + 0x9e3779b97f4a7c15ull * (c + 1)));

    std::seed_seq seq{static_cast<uint32_t>(s64),
                      static_cast<uint32_t>(s64 >> 32)};
    std::mt19937 eng;
    eng.seed(seq);
    return eng;
  }();
  return rng;
}

void shuffle_vector(std::vector<int>& vec) {
  auto& rng = get_thread_rng();
  std::shuffle(vec.begin(), vec.end(), rng);
}

int randint(int n) {
  // [0, n-1]
  auto& rng = get_thread_rng();
  std::uniform_int_distribution<int> dist(0, n - 1);
  return dist(rng);
}

double randreal() {
  int M = 100000000;
  return (double)randint(M) / M;
}

// double max(double a, double b) { return a > b ? a : b; }
// int max(int a, int b) { return a > b ? a : b; }

vector<int> Range(int n) {
  vector<int> ret = vector<int>(n);
  for (int i = 0; i < n; i++) ret[i] = i;
  return ret;
}

vector<int> Range(int s, int t) {
  int n = t - s;
  vector<int> ret = vector<int>(n);
  for (int i = 0; i < n; i++) ret[i] = s + i;
  return ret;
}

vector<int> RandomRange(int n) {
  vector<int> ret(n);
  for (int i = 0; i < n; i++) ret[i] = i;
  random_device rd;
  mt19937 g(rd());
  shuffle(ret.begin(), ret.end(), g);
  return ret;
}

vector<int> RandomRange(int s, int t) {
  int n = t - s;
  vector<int> ret(n);
  for (int i = 0; i < n; i++) ret[i] = s + i;
  random_device rd;
  mt19937 g(rd());
  shuffle(ret.begin(), ret.end(), g);
  return ret;
}

double Elapsed(chrono::high_resolution_clock::time_point start_time) {
  chrono::duration<double> elapsed =
      chrono::high_resolution_clock::now() - start_time;
  return elapsed.count();
}

vector<int> sort_alternating(const vector<int>& lst) {
  vector<int> result;
  int n = lst.size();
  result.reserve(n);  // 미리 공간 확보

  for (int i = 0; i < n; ++i) {
    if (i % 2 == 0) {
      // 짝수: 뒤에서 i//2번째
      result.push_back(lst[n - (i / 2) - 1]);
    } else {
      // 홀수: 앞에서 i//2번째
      result.push_back(lst[i / 2]);
    }
  }
  return result;
}

string to_string(const vector<int>& vec) {
  ostringstream oss;
  oss << "[";
  for (size_t i = 0; i < vec.size(); ++i) {
    oss << vec[i];
    if (i + 1 < vec.size()) {
      oss << ", ";
    }
  }
  oss << "]";
  return oss.str();
}

string to_string(const unordered_set<int>& set) {
  vector<int> vec(set.begin(), set.end());
  std::sort(vec.begin(), vec.end());
  return to_string(vec);
}

string to_string(const vector<pair<int, int>>& vec) {
  ostringstream oss;
  oss << "[";
  for (size_t i = 0; i < vec.size(); ++i) {
    oss << "(" << vec[i].first << ", " << vec[i].second << ")";
    if (i + 1 < vec.size()) {
      oss << ", ";
    }
  }
  oss << "]";
  return oss.str();
}

string to_string(const unordered_set<pair<int, int>>& set) {
  vector<pair<int, int>> vec(set.begin(), set.end());
  std::sort(vec.begin(), vec.end());
  return to_string(vec);
}