import os
import ctypes
import numpy as np

C_ALGOFUNC = None
C_FREE = None
FLAGS = ["C_CONTIGUOUS", "ALIGNED"]

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ALGO_SO_PATH = os.path.join(BASE_DIR, "..", "CLib", "obj", "algorithm.so")


def _init_clibalgorithm():
    global ALGO_SO_PATH, FLAGS, C_ALGOFUNC, C_FREE

    C_INT_PTR = ctypes.POINTER(ctypes.c_int32)
    C_INT_PTRPTR = ctypes.POINTER(C_INT_PTR)
    C_INT_PTRPTRPTR = ctypes.POINTER(C_INT_PTRPTR)

    lib = ctypes.cdll.LoadLibrary(ALGO_SO_PATH)
    func = lib.Main
    func.argtypes = [
        ctypes.c_int,  # N
        np.ctypeslib.ndpointer(np.int32, ndim=2, flags=FLAGS),  # A
        ctypes.c_int,  # P
        np.ctypeslib.ndpointer(np.int32, ndim=1, flags=FLAGS),  # K
        ctypes.c_int,  # F
        ctypes.c_double,  # timelimit
    ]
    func.restype = C_INT_PTRPTRPTR
    C_ALGOFUNC = func

    C_FREE = lib.FreeRetPtrs
    C_FREE.argtypes = [ctypes.c_int, C_INT_PTRPTRPTR]
    C_FREE.restype = None


def _init():
    _init_clibalgorithm()
