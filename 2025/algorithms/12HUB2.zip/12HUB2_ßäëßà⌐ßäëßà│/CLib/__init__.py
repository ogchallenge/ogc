from ._wrappers import main_algorithm


__all__ = ["main_algorithm"]
