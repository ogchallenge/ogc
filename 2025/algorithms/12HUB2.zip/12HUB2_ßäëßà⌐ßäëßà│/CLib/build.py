import os
from pathlib import Path

DIR = Path(__file__).resolve().parent
OBJ = DIR / "obj"
OBJ.mkdir(exist_ok=True)

core_libs = {"libutils", "libnode", "libgraphutils"}


def build_so(name, options=None):
    cpp = DIR / f"{name}.cpp"
    so = OBJ / f"{name}.so"
    opts = " ".join(["-std=c++17", "-DNDEBUG", *(options or [])])
    if name in core_libs:
        os.system(f"g++ {opts} -c {cpp} -shared -o {so}")
    else:
        os.system(f"g++ {cpp} -L{OBJ} {opts} -shared -o {so}")
    print(f"Built {name}")


libs = [
    ("libutils", ["-fPIC", "-fopenmp"]),
    ("libgraphutils", ["-lutils", "-fPIC", "-fopenmp"]),
    ("libnode", ["-fPIC", "-fopenmp"]),
    ("libdeck", ["-lnode", "-lgraphutils", "-lutils", "-fPIC", "-fopenmp"]),
    (
        "algorithm",
        [
            "-lnode",
            "-lutils",
            "-ldeck",
            "-lgraphutils",
            "-fopenmp",
            "-fPIC",
            "-Wl,-rpath,'$ORIGIN'",
        ],
    ),
]

if __name__ == "__main__":
    for name, opts in libs:
        build_so(name, opts)
