from . import _load_clib
import ctypes
import numpy as np

_load_clib._init()


def main_algorithm(
    prob_info: dict,
    timelimit: float,
):
    assert _load_clib.C_ALGOFUNC is not None
    assert _load_clib.C_FREE is not None
    N = prob_info["N"]
    E = prob_info["E"]
    P = prob_info["P"]
    K = prob_info["K"]
    F = prob_info["F"]

    _K = []
    for (o, d), r in K:
        _K += [o, d, r]
    _K = np.array([len(K)] + _K, dtype=np.int32)

    A = np.zeros((N, N), dtype=np.int32)
    for u, v in E:
        A[u, v] = 1
        A[v, u] = 1

    ret = _load_clib.C_ALGOFUNC(N, A, P, _K, F, ctypes.c_double(timelimit))
    solution = {p: [] for p in range(P)}
    for p in range(P):
        n_paths = ret[p][0][0]
        for i in range(n_paths):
            data = ret[p][i + 1]
            demand = data[0]
            path_len = data[1]
            path = data[2 : 2 + path_len]
            solution[p].append((path, demand))

    _load_clib.C_FREE(P, ret)
    return solution
