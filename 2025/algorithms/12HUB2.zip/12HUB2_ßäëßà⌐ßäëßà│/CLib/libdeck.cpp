#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")

#include "libdeck.hpp"

#include <algorithm>
#include <cassert>
#include <cstdio>
#include <deque>
#include <functional>
#include <limits>
#include <stack>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#include "libgraphutils.hpp"
#include "libnode.hpp"
#include "libutils.hpp"

using namespace std;

Deck::Deck(int N, vector<vector<bool>> &A) : N(N), A(A) {
  nodes.reserve(N);
  for (int i = 0; i < N; ++i)
    nodes.emplace_back(Node(i));

  this->make_adj_lists();
  this->compute_centrality();
  this->compute_degree();
  this->identify_terminal_nodes();
  this->compute_distances();
  this->make_arcs();
}

void Deck::make_adj_lists() {
  for (int u = 0; u < N; u++) {
    for (int v = 0; v < N; v++) {
      if (A[u][v]) {
        adj_lists[u].push_back(v);
      }
    }
  }
}

void Deck::compute_centrality() {
  bool normalized = true;    // 정규화 여부
  vector<double> CB(N, 0.0); // 매개 중심성 결과

  for (int s = 0; s < N; s++) {
    stack<int> S;
    vector<vector<int>> P(N); // predecessor 리스트
    vector<int> sigma(N, 0);  // 최단경로 수
    vector<int> d(N, -1);     // 거리
    deque<int> q;

    sigma[s] = 1;
    d[s] = 0;
    q.push_back(s);

    // BFS
    while (!q.empty()) {
      int v = q.front();
      q.pop_front();
      S.push(v);

      for (int w : adj_lists[v]) {
        if (d[w] < 0) {
          d[w] = d[v] + 1;
          q.push_back(w);
        }
        if (d[w] == d[v] + 1) {
          sigma[w] += sigma[v];
          P[w].push_back(v);
        }
      }
    }

    vector<double> delta(N, 0.0);

    // 역순으로 dependency 계산
    while (!S.empty()) {
      int w = S.top();
      S.pop();
      for (int v : P[w]) {
        delta[v] += ((double)sigma[v] / sigma[w]) * (1.0 + delta[w]);
      }
      if (w != s) {
        CB[w] += delta[w];
      }
    }
  }

  // 무방향 그래프는 2로 나눠줌
  for (double &c : CB) {
    c /= 2.0;
  }

  // 정규화 (normalized=True)
  if (normalized && N > 2) {
    double scale = 1.0 / ((N - 1.0) * (N - 2.0) / 2.0);
    for (double &c : CB) {
      c *= scale;
    }
  }

  for (int i = 0; i < N; ++i) {
    centrality[i] = CB[i];
  }
}

void Deck::compute_degree() {
  for (auto &[u, neighbors] : adj_lists)
    degree[u] = neighbors.size();
}

void Deck::identify_terminal_nodes() {
  terminal_nodes.clear();
  terminal_nodes = bfs_dead_ends(adj_lists, 0);

  // degree <= 2만 필터링
  terminal_nodes.erase(std::remove_if(terminal_nodes.begin(),
                                      terminal_nodes.end(),
                                      [&](int n) { return degree[n] > 2; }),
                       terminal_nodes.end());

  // 인덱스가 너무 낮은(0에서 가까운) 노드 제거
  terminal_nodes.erase(std::remove_if(terminal_nodes.begin(),
                                      terminal_nodes.end(),
                                      [&](int n) {
                                        return static_cast<double>(n) <=
                                               0.2 * static_cast<double>(N);
                                      }),
                       terminal_nodes.end());

  // 너무 가까운 노드들은 인덱스가 낮은 것을 제거
  terminal_nodes = reduce_nodes_by_distance(N, adj_lists, terminal_nodes);
}

void Deck::compute_distances() {
  distances = all_pairs_shortest_path_length(N, Range(N), adj_lists);
}

void Deck::make_arcs() {
  all_arcs.clear();
  inbound_arcs.clear();
  outbound_arcs.clear();

  for (int u = 0; u < N; ++u) {
    for (int v = 0; v < N; ++v) {
      if (A[u][v]) {
        all_arcs.emplace_back(u, v);
        all_arcs.emplace_back(v, u);
      }
    }
  }

  for (int v = 0; v < N; ++v) {
    for (auto &arc : all_arcs) {
      if (arc.second == v)
        inbound_arcs[v].push_back(arc);
      if (arc.first == v)
        outbound_arcs[v].push_back(arc);
    }
  }
}

void Deck::preempt_nodes(Cargo cargo, int n_cargo) {
  // 노드 0에서 가장 가까운 n_cargo개의 empty nodes를, 다음 항구가 목적지인
  // 화물들을 위해 선점한다.

  vector<int> _preempted_nodes;
  unordered_set<int> visited;
  deque<int> queue;
  queue.push_back(0);

  // bfs
  while (!queue.empty() && _preempted_nodes.size() < n_cargo) {
    int curr_node_id = queue.front();
    queue.pop_front();

    if (visited.count(curr_node_id))
      continue;

    visited.insert(curr_node_id);

    if (curr_node_id != 0 && nodes[curr_node_id].is_empty()) {
      nodes[curr_node_id].preempt(cargo);
      _preempted_nodes.push_back(curr_node_id);

      if (_preempted_nodes.size() == n_cargo)
        break;
    }

    for (int neighbor_id : adj_lists[curr_node_id]) {
      if (visited.count(neighbor_id) == 0 &&
          (nodes[neighbor_id].is_empty() || nodes[neighbor_id].is_preempted()))
        queue.push_back(neighbor_id);
    }
  }

  if (_preempted_nodes.size() < n_cargo)
    throw runtime_error("선점해야 하는 화물 수만큼 선점하지 못함.");

  for (int x : _preempted_nodes) {
    preempted_nodes.insert(x);
  }
}

pair<unordered_map<int, vector<int>>, vector<int>>
Deck::find_adjacent_groups(int destination) {
  /*
  입력된 destination의 화물을 가졌으면서 인접한 노드 그룹을 반환한다.
  map의 key는 그룹의 노드 중 ID가 가장 작은 것이며, value는 그룹에 속한 노드들의
  ID 리스트이다. destination == -1이면 empty nodes가 탐색 대상이다.
  */

  vector<int> P(N, -1);
  vector<int> rank(N, 0);

  // caching
  vector<int> dest;
  dest.reserve(N);
  for (auto &node : nodes) {
    dest.push_back(node.get_destination());
  }

  auto get_root = [&](int x) -> int {
    int root = x;
    while (P[root] != -1) {
      root = P[root];
    }

    // path compression
    while (x != root) {
      int parent = P[x];
      P[x] = root;
      x = parent;
    }
    return root;
  };

  // union-find with rank
  auto union_nodes = [&](int x, int y) {
    int x_root = get_root(x);
    int y_root = get_root(y);
    if (x_root == y_root)
      return;

    if (rank[x_root] < rank[y_root]) {
      P[x_root] = y_root;
    } else {
      P[y_root] = x_root;
      if (rank[x_root] == rank[y_root]) {
        rank[x_root]++;
      }
    }
  };

  // bfs
  unordered_set<int> visited;
  deque<int> queue;
  visited.insert(0);
  queue.push_back(0);

  while (!queue.empty()) {
    int curr_node = queue.front();
    queue.pop_front();

    for (int neighbor : adj_lists[curr_node]) {
      if (visited.find(neighbor) == visited.end()) {
        visited.insert(neighbor);
        queue.push_back(neighbor);
      }
      if (dest[curr_node] == destination && dest[neighbor] == destination) {
        union_nodes(curr_node, neighbor);
      }
    }
  }

  unordered_map<int, vector<int>> groups;
  for (int x = 0; x < N; x++) {
    if (dest[x] == destination) {
      int root_x = get_root(x);
      groups[root_x].push_back(x);
    }
  }

  for (auto &[k, group] : groups) {
    sort(group.begin(), group.end());
  }

  return {groups, P};
}

pair<unordered_map<int, unordered_map<int, vector<int>>>, vector<int>>
Deck::find_adjacent_groups() {
  /* destination 무관하게 모든 노드가 탐색 대상인 경우 */
  vector<int> P(N, -1);

  // caching
  vector<int> dest;
  dest.reserve(N);
  for (auto &node : nodes) {
    dest.push_back(node.get_destination());
  }

  auto get_root = [&](int x) -> int {
    int root = x;
    while (P[root] != -1) {
      root = P[root];
    }

    // path compression
    while (x != root) {
      int parent = P[x];
      P[x] = root;
      x = parent;
    }
    return root;
  };

  // union-find with rank
  auto union_nodes = [&](int x, int y) {
    int x_root = get_root(x);
    int y_root = get_root(y);
    if (x_root == y_root)
      return;

    if (x_root > y_root) {
      P[x_root] = y_root;
    } else {
      P[y_root] = x_root;
    }
  };

  // bfs
  unordered_set<int> visited;
  deque<int> queue;
  visited.insert(0);
  queue.push_back(0);

  while (!queue.empty()) {
    int curr_node = queue.front();
    queue.pop_front();

    for (int neighbor : adj_lists[curr_node]) {
      if (visited.count(neighbor) == 0) {
        visited.insert(neighbor);
        queue.push_back(neighbor);
      }
      if (dest[curr_node] == dest[neighbor]) {
        union_nodes(curr_node, neighbor);
      }
    }
  }

  unordered_map<int, unordered_map<int, vector<int>>> groups;
  for (int x = 0; x < N; x++) {
    int d = dest[x];
    int root_x = get_root(x);
    groups[d][root_x].push_back(x);
  }

  for (auto &[d, inner_map] : groups) {
    for (auto &[k, group] : inner_map) {
      P[k] = k;
      sort(group.begin(), group.end());
    }
  }

  return {groups, P};
}

unordered_set<int> Deck::find_adjacent_nodes(unordered_set<int> &A) {
  unordered_set<int> B;
  for (int n : A) {
    for (int m : adj_lists[n]) {
      if (A.find(m) == A.end()) { // A에 없는 경우
        B.insert(m);
      }
    }
  }
  return B;
}

int Deck::find_loading_node(unordered_set<int> &candidates,
                            unordered_set<int> *banned) {
  unordered_set<int> _banned =
      banned == nullptr ? unordered_set<int>() : unordered_set<int>(*banned);

  unordered_set<int> filtered;
  for (int x : candidates) {
    if (_banned.count(x) == 0 && nodes[x].is_empty() && x != 0)
      filtered.insert(x);
  }

  if (this->preempted_nodes.size() > 0) {
    for (int x : this->preempted_nodes)
      filtered.erase(x);
  }

  if (filtered.empty()) {
    return -1;
  } else if (filtered.size() == 1) {
    return *filtered.begin();
  }

  // 1) centrality가 가장 낮은 노드들 찾기
  double min_cent = std::numeric_limits<double>::max();
  for (int x : filtered) {
    min_cent = std::min(min_cent, centrality[x]);
  }

  vector<int> nodes_with_min_cent;
  for (int x : filtered) {
    if (std::abs(centrality[x] - min_cent) < 1e-4)
      nodes_with_min_cent.push_back(x);
  }

  if (nodes_with_min_cent.size() == 1)
    return nodes_with_min_cent[0];

  // 2) 0과의 거리가 가장 먼 노드 찾기
  int max_dist = 0;
  for (int x : nodes_with_min_cent) {
    int dist2root = this->distances[{0, x}];
    max_dist = std::max(max_dist, dist2root);
  }

  vector<int> nodes_with_max_dist;
  for (int x : nodes_with_min_cent) {
    if (this->distances[{0, x}] == max_dist)
      nodes_with_max_dist.push_back(x);
  }

  if (nodes_with_max_dist.size() == 1)
    return nodes_with_max_dist[0];

  // 3) 거리와 centrality가 모두 같은 경우 → 가장 큰 인덱스 선택
  return *std::max_element(nodes_with_max_dist.begin(),
                           nodes_with_max_dist.end());
}

unordered_set<int> Deck::find_reachable_nodes(int additional_depth,
                                              bool find_layered) {
  /*
  노드 0에서 도달 가능한 노드들을 찾는다.

  additional_depth > 0인 경우 reachable nodes의 인접 노드 집합을 그 값만큼의
  깊이로 포함한다.

  find_layered == true인 경우 화물이 있어도 bfs 탐색 순서상 destination이
  오름차순이면 도달 가능하다고 판단한다. (simulation에서 blocking 여부 확인용)
  */
  unordered_set<int> visited;
  deque<int> q;

  q.push_back(0);

  // bfs
  while (!q.empty()) {
    int curr_node = q.front();
    q.pop_front();

    if (visited.count(curr_node))
      continue;

    visited.insert(curr_node);

    if (find_layered) {
      for (int neighbor : adj_lists[curr_node]) {
        if (visited.count(neighbor) == 0 &&
            (nodes[neighbor].is_empty() || nodes[neighbor].is_preempted() ||
             (nodes[neighbor].get_destination() >=
              nodes[curr_node].get_destination())))
          q.push_back(neighbor);
      }
    } else {
      for (int neighbor : adj_lists[curr_node]) {
        if (visited.count(neighbor) == 0 &&
            (nodes[neighbor].is_empty() || nodes[neighbor].is_preempted())) {
          q.push_back(neighbor);
        }
      }
    }
  }

  for (int d = 0; d < additional_depth; ++d) {
    unordered_set<int> B = this->find_adjacent_nodes(visited);
    visited.insert(B.begin(), B.end());
  }

  return visited;
}

SimulationResult Deck::simulate_loading(int node, int destination) {
  /*
  node에 목적지가 destination인 화물을 적재하였을 때 어떤 일이 일어나는지
  시뮬레이션한다.

  SimStatus::Feasible: 문제 없음
  SimStatus::Isolation: empty but unreachable한 노드가 발생
  SimStatus::Blocking: destination보다 더 가까운 목적지의 화물이 unreachable하게
  되어 추후 반드시 rehandling이 발생

  status가 Isolation이면 blocking이 발생하지 않은 것이고, Blocking이면
  isolation이 발생했을 수도 있다.
  */

  assert(nodes[node].is_empty() && "Cannot load cargo to a non-empty node.");
  unordered_set<int> reachable_before = this->find_reachable_nodes(1, false);
  nodes[node].occupy({destination, destination});
  unordered_set<int> reachable_after = this->find_reachable_nodes(1, false);

  unordered_set<int> now_unreachable;
  for (int n : reachable_before) {
    if (reachable_after.count(n) == 0)
      now_unreachable.insert(n);
  }

  auto adj_groups_result = this->find_adjacent_groups();
  unordered_map<int, unordered_map<int, vector<int>>> groups =
      adj_groups_result.first;
  vector<int> roots = adj_groups_result.second;

  unordered_set<int> still_reachable_roots;
  for (int n : reachable_after)
    still_reachable_roots.insert(roots[n]);

  unordered_set<int> filtered_unreachable;
  for (int n : now_unreachable) {
    if (still_reachable_roots.count(roots[n]) == 0)
      filtered_unreachable.insert(n);
  }
  now_unreachable.swap(filtered_unreachable);

  unordered_set<int> isolated;
  unordered_set<int> blocked;
  unordered_set<int> reachables_layered = this->find_reachable_nodes(0, true);

  for (int n : now_unreachable) {
    if (nodes[n].is_empty()) {
      isolated.insert(n);
    } else if (nodes[n].get_destination() != destination &&
               reachables_layered.count(n) == 0) {
      blocked.insert(n);
    }
  }

  nodes[node].unload();

  if (!blocked.empty()) {
    bool all_father_dest = true;
    for (int x : blocked) {
      if (nodes[x].get_destination() < destination) {
        all_father_dest = false;
        break;
      }
    }
    return SimulationResult{SimStatus::Blocking, std::move(isolated),
                            std::move(blocked), all_father_dest};
  }

  if (!isolated.empty()) {
    return SimulationResult{
        SimStatus::Isolation, std::move(isolated), {}, false};
  }

  return SimulationResult{SimStatus::Feasible, {}, {}, false};
}

unordered_set<int> Deck::load_at_adjacent_node(unordered_set<int> &A,
                                               deque<Cargo> &cargo_queue,
                                               unordered_set<int> *banned) {
  /*
  노드 집합 A에 인접한 노드 중 한 곳에 화물을 배치한다.

  Isolation이 발생한 경우 isolated nodes의 수가 선적해야 할 화물 수보다 작을
  때 isolated nodes 모두에 화물을 선적한다.

  Blocking이 발생한 경우 blocked nodes의 destination이 모두 현재 선적할
  화물의 목적지보다 멀거나 같을 때 선적한다.
  */
  int destination = cargo_queue.front().second;
  unordered_set<int> B = this->find_adjacent_nodes(A);
  unordered_set<int> _banned =
      banned == nullptr ? unordered_set<int>() : unordered_set<int>(*banned);
  vector<pair<int, unordered_set<int>>> isolation_results;

  int C = this->find_loading_node(B, &_banned);
  if (C == -1)
    return {};

  SimulationResult result = this->simulate_loading(C, destination);
  unordered_set<int> &isolated = result.isolated;

  if (result.is_feasible()) {
    nodes[C].reserve(cargo_queue.front());
    cargo_queue.pop_front();
    return {C};
  } else if (result.is_isolation()) {
    // isolation
    if (isolated.size() <= cargo_queue.size() - 1) {
      unordered_set<int> loading_nodes = {C};
      loading_nodes.insert(isolated.begin(), isolated.end());
      for (int n : loading_nodes) {
        nodes[n].reserve(cargo_queue.front());
        cargo_queue.pop_front();
      }
      return loading_nodes;
    } else {
      isolation_results.emplace_back(C, isolated);
    }
  } else {
    // blocking
    if (result.all_father_dest && isolated.size() <= cargo_queue.size() - 1) {
      unordered_set<int> unioned = {C};
      unioned.insert(isolated.begin(), isolated.end());
      for (int n : unioned) {
        nodes[n].reserve(cargo_queue.front());
        cargo_queue.pop_front();
      }
      return unioned;
    }
  }

  _banned.insert(C);
  // TODO B의 모든 노드들을 비교해보자. 근데 너무 느릴지도;

  // banned < B일 때까지 반복
  while (_banned.size() < B.size()) {
    C = this->find_loading_node(B, &_banned);
    if (C == -1)
      return {}; // None과 동일

    result = this->simulate_loading(C, destination);
    unordered_set<int> &iso = result.isolated;
    unordered_set<int> &blk = result.blocked;

    if (result.is_feasible()) {
      nodes[C].reserve(cargo_queue.front());
      cargo_queue.pop_front();
      return {C};
    } else if (result.is_isolation()) {
      if (iso.size() <= cargo_queue.size() - 1) {
        unordered_set<int> loading_nodes = {C};
        loading_nodes.insert(iso.begin(), iso.end());
        for (int n : loading_nodes) {
          nodes[n].reserve(cargo_queue.front());
          cargo_queue.pop_front();
        }
        return loading_nodes;
      } else {
        isolation_results.emplace_back(C, iso);
      }
    }
    _banned.insert(C);
  }

  // len(_banned) == len(B)
  if (!isolation_results.empty()) {
    vector<pair<int, unordered_set<int>>> feasible_isolation_cases;
    for (auto &[c, iso] : isolation_results) {
      if (iso.size() <= cargo_queue.size() - 1) {
        feasible_isolation_cases.emplace_back(c, iso);
      }
    }

    if (feasible_isolation_cases.empty())
      return {};

    auto best_case = *std::max_element(
        feasible_isolation_cases.begin(), feasible_isolation_cases.end(),
        [](auto &a, auto &b) { return a.second.size() < b.second.size(); });

    int best_C = best_case.first;
    auto &best_iso = best_case.second;

    unordered_set<int> loading_nodes = {best_C};
    loading_nodes.insert(best_iso.begin(), best_iso.end());

    for (int n : loading_nodes) {
      nodes[n].reserve(cargo_queue.front());
      cargo_queue.pop_front();
    }
    return loading_nodes;
  }
  return {};
}

function<unordered_set<int>()>
Deck::check_terminal_available(int terminal_node, Cargo cargo, int n_remains) {
  /*
  해당 terminal node가 새 화물을 적재하기 적절한 위치인지 확인한다.
   */

  if (!nodes[terminal_node].is_empty())
    return nullptr;

  if (preempted_nodes.size() > 0 && preempted_nodes.count(terminal_node) > 0)
    return nullptr;

  int p = cargo.first;
  int destination = cargo.second;

  SimulationResult result = this->simulate_loading(terminal_node, destination);
  unordered_set<int> &isolated = result.isolated;
  unordered_set<int> &blocked = result.blocked;

  if (result.is_feasible()) {
    return [this, terminal_node, cargo]() {
      nodes[terminal_node].reserve(cargo);
      return unordered_set<int>{terminal_node};
    };
  } else if (result.is_isolation()) {
    if (isolated.size() <= n_remains) {
      return [this, terminal_node, cargo, isolated]() {
        unordered_set<int> loading_nodes = {terminal_node};
        loading_nodes.insert(isolated.begin(), isolated.end());
        for (int n : loading_nodes) {
          nodes[n].reserve(cargo);
        }
        return loading_nodes;
      };
    }
    return nullptr;
  }
  return nullptr;
}

void Deck::reserve_baseline(vector<Cargo> &cargo_list) {
  /*
  baseline의 로딩 휴리스틱대로 화물을 선적한다.
  선적 순서는 목적지에 대해 내림차순이다.
  */

  std::sort(cargo_list.begin(), cargo_list.end(),
            [](auto &a, auto &b) { return a.second > b.second; });

  unordered_set<int> reachables = this->find_reachable_nodes(0, false);

  unordered_map<int, vector<int>> shortest_paths =
      single_source_shortest_path(N, reachables, adj_lists, 0);

  for (int node : preempted_nodes)
    reachables.erase(node);
  reachables.erase(0);
  vector<int> X(reachables.begin(), reachables.end());

  vector<int> reachable_list(reachables.begin(), reachables.end());

  std::sort(reachable_list.begin(), reachable_list.end());
  std::sort(reachable_list.begin(), reachable_list.end(), [&](int a, int b) {
    return shortest_paths[a].size() < shortest_paths[b].size();
  });

  if (reachable_list.size() < cargo_list.size()) {
    throw runtime_error(
        "도달 가능한 노드보다 배치해야 하는 나머지 화물 수가 더 많음.");
  }

  int idx = reachable_list.size() - 1;
  for (auto &cargo : cargo_list) {
    int node_id = reachable_list[idx];
    nodes[node_id].reserve(cargo);
    idx--;
  }
}

unordered_set<int> Deck::reserve_baseline_nonblock(deque<Cargo> &cargo_queue,
                                                   unordered_set<int> *banned) {
  /*
  baseline의 로딩 휴리스틱대로 화물을 선적한다. 다만 blocking이 발생하는지
  확인하여 non-block case만 선적을 수행한다.
  선적 순서는 목적지에 대해 내림차순이다.
  */

  unordered_set<int> _banned =
      banned == nullptr ? unordered_set<int>() : unordered_set<int>(*banned);
  unordered_set<int> reachables = this->find_reachable_nodes(0, false);

  unordered_map<int, vector<int>> shortest_paths =
      single_source_shortest_path(N, reachables, adj_lists, 0);

  for (int node : preempted_nodes)
    reachables.erase(node);
  for (int node : _banned)
    reachables.erase(node);
  reachables.erase(0);

  vector<int> reachable_list(reachables.begin(), reachables.end());
  std::sort(reachable_list.begin(), reachable_list.end());
  std::stable_sort(reachable_list.begin(), reachable_list.end(),
                   [&](int a, int b) {
                     return shortest_paths[a].size() > shortest_paths[b].size();
                   });

  if (banned == nullptr && reachable_list.size() < cargo_queue.size()) {
    throw runtime_error(
        "도달 가능한 노드보다 배치해야 하는 나머지 화물 수가 더 많음.");
  }

  Cargo cargo = cargo_queue.front();
  for (int r : reachable_list) {
    Node &n = nodes[r];
    SimulationResult result = this->simulate_loading(r, cargo.second);
    unordered_set<int> &isolated = result.isolated;
    if (result.is_feasible()) {
      n.reserve(cargo);
      cargo_queue.pop_front();
      return {r};
      // } else if (result.is_isolation() &&
      //            isolated.size() <= cargo_queue.size() - 1) {
    } else if ((result.is_isolation() ||
                (result.is_blocking() && result.all_father_dest)) &&
               isolated.size() <= cargo_queue.size() - 1) {
      isolated.insert(r);
      for (int i : isolated) {
        nodes[i].reserve(cargo_queue.front());
        cargo_queue.pop_front();
      }
      return isolated;
    }
    // TODO 이거 block케이스 해봐야 하는 건 아닌지? 위에 조건식만 수정하면 될듯.
    // (result.is_isolation() || (result.is_blocking() &&
    // result.all_father_dest))
  }
  return {};
}

void Deck::identify_major_terminal_nodes(int P) {
  /*
  terminal nodes 중에서 서로간의 거리를 기반으로 주요한 것을 뽑는다.
  */
  unordered_set<int> _major_terminal_nodes = {0};
  unordered_set<int> banned;

  int n_iters = min(P + 10, (int)terminal_nodes.size());

  while (n_iters--) {
    unordered_map<int, int> _dists;
    int min_d = std::numeric_limits<int>::max();

    for (int v : terminal_nodes) {
      // major_terminal_nodes에 없는지 확인
      if (_major_terminal_nodes.count(v) == 0 && banned.count(v) == 0) {
        int d = 0;
        for (int u : _major_terminal_nodes) {
          auto it = distances.find({u, v});
          if (it != distances.end()) {
            min_d = min(min_d, static_cast<int>(it->second));
            d += it->second;
          }
        }
        _dists[v] = d;
      }
    }

    if (_dists.empty())
      break;

    auto max_it =
        std::max_element(_dists.begin(), _dists.end(),
                         [](auto &a, auto &b) { return a.second < b.second; });
    int max_dist = max_it->second;
    vector<int> max_dist_nodes;
    for (auto &[node, dist] : _dists) {
      if (dist == max_dist) {
        max_dist_nodes.push_back(node);
      }
    }
    int max_node =
        *std::min_element(max_dist_nodes.begin(), max_dist_nodes.end());

    if (min_d <= 2) {
      banned.insert(max_node);
      continue;
    }

    _major_terminal_nodes.insert(max_node);
  }

  _major_terminal_nodes.erase(0);

  this->major_terminal_nodes =
      vector<int>(_major_terminal_nodes.begin(), _major_terminal_nodes.end());
}

int Deck::find_good_major_terminal_node(int destination) {
  /*
  major_terminal_node 중에서 노드를 배치하기에 적당한 것 하나를 골라 반환한다.
  */
  vector<int> filtered_nodes;
  for (int n : major_terminal_nodes) {
    if (nodes[n].is_empty() &&
        this->simulate_loading(n, destination).is_feasible()) {
      filtered_nodes.push_back(n);
    }
  }

  // preempted_nodes 제외
  if (!preempted_nodes.empty()) {
    vector<int> tmp;
    for (int n : filtered_nodes) {
      if (preempted_nodes.find(n) == preempted_nodes.end() && n != 0) {
        tmp.push_back(n);
      }
    }
    filtered_nodes = std::move(tmp);
  }

  if (filtered_nodes.empty())
    return -1;
  if (filtered_nodes.size() == 1)
    return filtered_nodes[0];

  vector<int> dists;
  // 각 major_terminal_node 별로 BFS
  for (size_t i = 0; i < filtered_nodes.size(); ++i) {
    int terminal_node = filtered_nodes[i];
    unordered_set<int> visited;
    deque<pair<int, int>> q;
    q.push_back({terminal_node, 0});

    while (!q.empty()) {
      auto [curr_node, d] = q.front();
      q.pop_front();

      if (visited.find(curr_node) != visited.end())
        continue;
      visited.insert(curr_node);

      for (int neighbor : adj_lists[curr_node]) {
        if (visited.find(neighbor) == visited.end()) {
          if (neighbor == 0 || !nodes[neighbor].is_empty()) {
            dists.push_back(d + 1);
            break;
          } else {
            q.push_back({neighbor, d + 1});
          }
        }
      }

      if (dists.size() > i)
        break;
    }
  }

  // 최대 거리 값을 가진 노드 선택
  if (dists.empty())
    return filtered_nodes[0];

  int max_index = std::distance(dists.begin(),
                                std::max_element(dists.begin(), dists.end()));
  return filtered_nodes[max_index];
}

int Deck::find_good_new_position(int destination, bool random) {
  /*
  empty nodes 중에서 주변 또한 많이 비어 있는 위치를 하나 찾는다.
  */
  unordered_set<int> reachables = this->find_reachable_nodes(0, false);
  reachables.erase(0);

  if (preempted_nodes.size() > 0) {
    for (int n : preempted_nodes)
      reachables.erase(n);
  }
  unordered_set<int> candidates;
  candidates.reserve(reachables.size());
  for (int r : reachables) {
    if (degree[r] <= 3)
      candidates.insert(r);
  }

  unordered_map<int, int> n_empty_near;
  for (int i : candidates) {
    int x = 0;
    for (int j = 1; j < N; j++) {
      if (distances[{i, j}] <= 3)
        x++;
    }
    n_empty_near[i] = x;
  }
  unordered_set<int> all_values_set;
  for (const auto &[key, value] : n_empty_near)
    all_values_set.insert(value);
  vector<int> all_values(all_values_set.begin(), all_values_set.end());
  std::sort(all_values.begin(), all_values.end(), std::greater<int>());

  // n_empty_near 값으로 내림차순 candidates를 정렬

  /*vector<int> sorted_candidates;
  if (random) {
    sorted_candidates = vector<int>(candidates.begin(), candidates.end());
    shuffle_vector(sorted_candidates);
  } else {
    for (int value : all_values) {
      vector<int> corresponding_nodes;
      for (int i : candidates) {
        if (n_empty_near[i] == value) corresponding_nodes.push_back(i);
      }
      shuffle_vector(corresponding_nodes);
      sorted_candidates.insert(sorted_candidates.end(),
                               corresponding_nodes.begin(),
                               corresponding_nodes.end());
    }
  }*/
  vector<int> sorted_candidates(candidates.begin(), candidates.end());
  if (random)
    shuffle_vector(sorted_candidates);
  else
    std::sort(
        sorted_candidates.begin(), sorted_candidates.end(),
        [&](auto &a, auto &b) { return n_empty_near[a] > n_empty_near[b]; });

  for (int node_id : sorted_candidates) {
    SimulationResult result = this->simulate_loading(node_id, destination);
    if (result.is_feasible()) {
      return node_id;
    } else if (result.is_blocking() && result.all_father_dest &&
               result.isolated.size() == 0) {
      return node_id;
    }
  }

  return -1;
}

void Deck::loading_hueristic_port0(DemandList &K, bool random) {
  /* 첫 항구 선적 수행 */

  unordered_map<Cargo, int> demand_map;
  for (int i = 0; i < K.size(); ++i) {
    demand_map[K[i].first] = i;
  }

  vector<int> dests_to_load;
  for (auto &[od, r] : K) {
    if (od.first == 0 && r > 0)
      dests_to_load.push_back(od.second);
  }
  std::sort(dests_to_load.begin(), dests_to_load.end());

  if (demand_map.count({0, 1})) {
    int demand = demand_map[{0, 1}];
    int n_preempt = K[demand].second;
    this->preempt_nodes({0, 1}, n_preempt);
    dests_to_load.erase(
        std::remove(dests_to_load.begin(), dests_to_load.end(), 1),
        dests_to_load.end());
  }

  std::sort(dests_to_load.begin(), dests_to_load.end(), [&](int x, int y) {
    return K[demand_map[{0, x}]].second > K[demand_map[{0, y}]].second;
  });
  dests_to_load = sort_alternating(dests_to_load);

  deque<int> node_queue;
  if (random) {
    vector<int> _nodes;
    if (tid <= 2) {
      unordered_set<int> reachables = this->find_reachable_nodes(0, false);
      _nodes = vector<int>(reachables.begin(), reachables.end());
    } else {
      _nodes = bfs_dead_ends(this->adj_lists, 0);
    }
    _nodes.erase(std::remove(_nodes.begin(), _nodes.end(), 0), _nodes.end());
    shuffle_vector(_nodes);

    node_queue = deque<int>(_nodes.begin(), _nodes.end());
  } else {
    node_queue = deque<int>(this->major_terminal_nodes.begin(),
                            this->major_terminal_nodes.end());
  }

  for (int destination : dests_to_load) {
    deque<Cargo> cargo_queue(K[demand_map[{0, destination}]].second,
                             {0, destination});
    if (!node_queue.empty()) {
      int node = node_queue.front();
      node_queue.pop_front();

      function<unordered_set<int>()> apply = this->check_terminal_available(
          node, {0, destination}, cargo_queue.size() - 1);
      while (apply == nullptr) {
        if (node_queue.empty())
          break;
        node = node_queue.front();
        node_queue.pop_front();
        apply = this->check_terminal_available(node, {0, destination},
                                               cargo_queue.size() - 1);
      }

      if (apply != nullptr) {
        unordered_set<int> A = apply();
        for (int n : A)
          cargo_queue.pop_front();
        this->load_expansion(A, cargo_queue);
      }
    }
    this->load_cargo(destination, "NB", cargo_queue);
  }

  vector<Cargo> remain_cargoes;
  for (Demand &k : K) {
    Cargo od = k.first;
    int r = k.second;
    if (od.first != 0 || od.second == 1)
      continue;
    int s = std::count_if(nodes.begin(), nodes.end(), [&](Node &n) {
      return n.get_origin() == od.first && n.get_destination() == od.second;
    });
    if (r - s > 0) {
      for (int i = 0; i < r - s; i++)
        remain_cargoes.push_back(od);
    }
  }

  this->reserve_baseline(remain_cargoes);
}

PartialSolution Deck::make_path(DemandList &K) {
  /* 현재 선적 계획 상태로부터 경로 생성 */

  for (Node &n : nodes) {
    if (n.get_state() == NodeState::PREEMPTED)
      n.set_state(NodeState::RESERVED);
  }
  preempted_nodes.clear();

  unordered_map<Cargo, int> demand_map;
  demand_map.reserve(K.size());
  for (size_t i = 0; i < K.size(); ++i) {
    Cargo &od = K[i].first;
    demand_map[od] = static_cast<int>(i);
  }

  unordered_set<int> sub_nodes;
  sub_nodes.reserve(nodes.size());
  for (size_t i = 0; i < nodes.size(); ++i) {
    if (nodes[i].get_state() != NodeState::OCCUPIED) {
      sub_nodes.insert(static_cast<int>(i));
    }
  }

  unordered_map<int, vector<int>> sssp =
      single_source_shortest_path(N, sub_nodes, adj_lists, 0);

  vector<pair<int, vector<int>>> sssp_items;
  sssp_items.reserve(sssp.size());
  for (auto &kv : sssp) {
    sssp_items.emplace_back(kv.first, kv.second);
  }
  std::sort(sssp_items.begin(), sssp_items.end(),
            [](auto &a, auto &b) { return a.second.size() > b.second.size(); });

  PartialSolution sol;
  for (auto &kv : sssp_items) {
    int node_id = kv.first;
    vector<int> &path = kv.second;

    if (nodes[node_id].get_state() == NodeState::RESERVED) {
      int o = nodes[node_id].get_origin();
      int d = nodes[node_id].get_destination();
      auto it = demand_map.find({o, d});
      if (it == demand_map.end()) {
        continue;
      }
      sol.emplace_back(path, it->second);
      nodes[node_id].occupy();
    }
  }

  for (auto &n : nodes) {
    auto st = n.get_state();
    if (st != NodeState::OCCUPIED && st != NodeState::EMPTY) {
      throw runtime_error("After load(), all nodes must be OCCUPIED or EMPTY.");
    }
  }

  return sol;
}

pair<PartialSolution, vector<int>> Deck::unloading_hueristic(DemandList &K,
                                                             int p, int F) {
  /* 항구 p에서의 하역 수행 */
  unordered_map<Cargo, int> demand_map;
  demand_map.reserve(K.size());
  for (int i = 0; i < (int)K.size(); ++i) {
    demand_map[K[i].first] = i;
  }

  PartialSolution route_list_unload;
  vector<int> rehandling_demands;

  unordered_set<Cargo> unload_cargoes;
  unload_cargoes.reserve(K.size());
  for (auto &kv : demand_map) {
    if (kv.first.second == p)
      unload_cargoes.insert(kv.first);
  }

  auto adj_group_result = this->find_adjacent_groups(p);
  unordered_map<int, vector<int>> groups = adj_group_result.first;
  vector<int> roots = adj_group_result.second;

  auto unload_along_shortest_path = [&](vector<int> &_nodes) {
    vector<int> nodes_to_unload;
    nodes_to_unload.reserve(_nodes.size());
    for (int n : _nodes)
      if (!nodes[n].is_empty())
        nodes_to_unload.push_back(n);

    unordered_set<int> sub_nodes;
    sub_nodes.reserve(N);
    for (int i = 0; i < N; ++i) {
      bool keep = nodes[i].is_empty();
      if (!keep) {
        int o = nodes[i].get_origin();
        int d = nodes[i].get_destination();
        if (o != -1 && d != -1 && unload_cargoes.count({o, d}))
          keep = true;
      }
      if (keep)
        sub_nodes.insert(i);
    }
    sub_nodes.insert(0);

    unordered_map<int, vector<int>> SPs =
        single_source_shortest_path(N, sub_nodes, this->adj_lists, 0);

    vector<pair<int, vector<int>>> node_path_pairs;
    node_path_pairs.reserve(nodes_to_unload.size());
    for (int n : nodes_to_unload) {
      auto it = SPs.find(n);
      if (it == SPs.end())
        continue;
      node_path_pairs.emplace_back(n, it->second);
    }
    std::sort(
        node_path_pairs.begin(), node_path_pairs.end(),
        [](auto &a, auto &b) { return a.second.size() > b.second.size(); });

    vector<Path> x;
    for (pair<int, vector<int>> &pr : node_path_pairs) {
      int n = pr.first;
      if (nodes[n].is_empty())
        continue;

      vector<int> unloading_path = pr.second;
      std::reverse(unloading_path.begin(), unloading_path.end());

      if (unloading_path.size() >= 3) {
        for (int i = (int)unloading_path.size() - 2; i >= 1; i--) {
          int m = unloading_path[i];
          if (!nodes[m].is_empty()) {
            int o = nodes[m].get_origin();
            int d = nodes[m].get_destination();
            if (o != -1 && d != -1 && unload_cargoes.count({o, d})) {
              vector<int> seg(unloading_path.begin() + i, unloading_path.end());
              int demand = demand_map[{o, d}];
              x.emplace_back(seg, demand);
              nodes[m].unload();
            }
          }
        }
      }

      {
        int o = nodes[n].get_origin();
        int d = nodes[n].get_destination();
        if (o != -1 && d != -1) {
          int demand = demand_map[{o, d}];
          x.emplace_back(unloading_path, demand);
        }
        nodes[n].unload();
      }
    }

    route_list_unload.insert(route_list_unload.end(), x.begin(), x.end());
  };

  vector<pair<int, vector<int>>> groups_vec(groups.begin(), groups.end());
  std::sort(groups_vec.begin(), groups_vec.end(),
            [](auto &a, auto &b) { return a.first < b.first; });

  int start_idx = route_list_unload.size();
  vector<pair<vector<int>, vector<int>>> rehandled;
  for (auto &g : groups_vec) {
    int main_node = g.first;
    vector<int> &nodes_in_group = g.second;

    unordered_map<int, vector<int>> adj_dir;
    adj_dir.reserve(N);
    vector<vector<int>> edge_costs(N, vector<int>(N, 0));

    auto node_is_ok = [&](int v) -> bool {
      if (nodes[v].is_empty())
        return true;
      int o = nodes[v].get_origin();
      int d = nodes[v].get_destination();
      return (o != -1 && d != -1 && unload_cargoes.count({o, d}));
    };

    int base_len = (int)nodes_in_group.size();
    for (Edge &e : this->all_arcs) {
      int u = e.first, v = e.second;
      int c = node_is_ok(v) ? base_len : (F * 2 + base_len + N / 10);
      adj_dir[u].push_back(v);
      edge_costs[u][v] = c;
    }

    // dijkstra로 하역 경로 찾기(MinimumRehandlingPath)
    vector<int> mrpath = dijkstra(this->N, adj_dir, edge_costs, 0, main_node);
    if (mrpath.empty())
      throw runtime_error("No path found from 0 to main node " +
                          std::to_string(main_node) + ".");

    unordered_set<int> banned_for_rehandling(mrpath.begin(), mrpath.end());

    for (int i = 0; i < mrpath.size(); i++) {
      int node = mrpath[i];
      if (!nodes[node].is_empty()) {
        auto [o, d] = nodes[node].get_cargo();
        int demand = demand_map[{o, d}];
        vector<int> path_rev(mrpath.begin(), mrpath.begin() + i + 1);
        std::reverse(path_rev.begin(), path_rev.end());
        if (d == p) {
          // 어차피 이번 항구에서 하역될 화물이 경로에 있는 경우임. 바로 하역.
          route_list_unload.emplace_back(path_rev, demand);
          nodes[node].unload();
        } else if (o != -1 && d != -1) {
          auto it =
              std::find_if(rehandled.begin(), rehandled.end(), [&](auto &r) {
                return r.first[1] == node && r.first[2] == demand;
              });
          // 재배치했던 화물을 또 다시 재배치하려는 시도 발생
          // --> 임시하역이었던 걸로 과거 솔루션 내역을 변경.
          if (it != rehandled.end()) {
            int idx_rehandled =
                static_cast<int>(std::distance(rehandled.begin(), it));
            auto &x = rehandled[idx_rehandled];

            int idx_sol = -1;
            for (int j = start_idx; j < route_list_unload.size(); j++) {
              auto &ru = route_list_unload[j];
              if (ru.second == x.first[2] && ru.first.front() == x.first[0] &&
                  ru.first.back() == x.first[1]) {
                idx_sol = j;
                break;
              }
            }
            route_list_unload[idx_sol] = {x.second, demand};
            rehandling_demands.push_back(demand);
            nodes[node].unload();
            rehandled.erase(it);
            continue;
          }

          // rehandling phase
          deque<Cargo> cargo_queue({{o, d}});
          vector<pair<bool, unordered_set<int>>> results =
              this->load_cargo(d, "ANB", cargo_queue, &banned_for_rehandling);
          int loaded_node = -1;
          for (auto &res : results) {
            if (res.second.size() > 0) {
              // 새 위치 찾기 성공. 현재 loaded_node is reserved.
              loaded_node = *res.second.begin();
              break;
            }
          }

          if (loaded_node != -1 && node != loaded_node) {
            // node -> loaded_node shortest path
            unordered_set<int> subgraph_nodes;
            subgraph_nodes.reserve(N);
            for (int i = 0; i < N; i++) {
              if (nodes[i].is_empty())
                subgraph_nodes.insert(i);
            }
            subgraph_nodes.insert(0);
            subgraph_nodes.insert(node);
            subgraph_nodes.insert(loaded_node);

            vector<int> spath = shortest_path_between_two_nodes(
                N, subgraph_nodes, adj_lists, node, loaded_node);
            if (spath.empty()) {
              // 경로 없음(infeasible)
              nodes[node].set_empty();
              nodes[loaded_node].set_empty();
              route_list_unload.emplace_back(path_rev, demand);
              rehandling_demands.push_back(demand);
            } else {
              // 경로 있음
              route_list_unload.emplace_back(spath, demand);
              nodes[node].unload();
              nodes[loaded_node].occupy();
              rehandled.push_back({{node, loaded_node, demand}, path_rev});
            }
            continue;
          }

          // 재배치 실패: loaded_node == -1 or node == loaded_node
          // 두 경우 모두 load_cargo가 실패함을 의미. 즉, 마땅한 위치가 전혀
          // 없음. 그냥 임시하역.
          nodes[node].set_empty();
          route_list_unload.emplace_back(path_rev, demand);
          rehandling_demands.push_back(demand);
        }
      }
    }

    // 하역
    unload_along_shortest_path(nodes_in_group);
  }

  return {route_list_unload, rehandling_demands};
}

void Deck::loading_hueristic(DemandList &K, int p,
                             vector<int> &rehandling_demands) {
  /* 항구 p에서의 선적 수행 */
  vector<int> _rehandling_demands = rehandling_demands;
  std::sort(_rehandling_demands.begin(), _rehandling_demands.end(),
            std::greater<int>());

  unordered_map<Cargo, int, hash<Cargo>> demand_map;
  demand_map.reserve(K.size());
  for (int i = 0; i < (int)K.size(); ++i) {
    demand_map[K[i].first] = i;
  }

  unordered_set<int> dests_to_load_set;
  for (auto &kd : K) {
    auto &od = kd.first;
    int r = kd.second;
    if (od.first == p && r > 0)
      dests_to_load_set.insert(od.second);
  }

  for (int idx : _rehandling_demands) {
    if (idx >= 0 && idx < (int)K.size()) {
      dests_to_load_set.insert(K[idx].first.second);
    }
  }

  bool has_preempted = false;

  // (p, p+1) 수요 사전 선점
  auto it_dm_next = demand_map.find({p, p + 1});
  if (it_dm_next != demand_map.end()) {
    int demand_idx = it_dm_next->second;
    int n_preempt = K[demand_idx].second;
    if (n_preempt > 0) {
      this->preempt_nodes({p, p + 1}, static_cast<size_t>(n_preempt));
      has_preempted = true;
    }
  }

  // rehandling 중에서도 다음 항구(p+1)로 가는 화물이 있으면 하나씩 선점
  vector<Cargo> next_port_r_demands;
  for (int idx : _rehandling_demands) {
    if (idx >= 0 && idx < (int)K.size())
      next_port_r_demands.push_back(K[idx].first);
  }

  while (true) {
    auto it =
        std::find_if(next_port_r_demands.begin(), next_port_r_demands.end(),
                     [&](Cargo &od) { return od.second == p + 1; });
    if (it == next_port_r_demands.end())
      break;
    Cargo cargo = *it;

    this->preempt_nodes(cargo, 1);
    // rehandling_demands에서 해당 demand index 제거
    auto it_dm = demand_map.find(cargo);
    if (it_dm != demand_map.end()) {
      int demand_idx = it_dm->second;
      auto itr = std::find(_rehandling_demands.begin(),
                           _rehandling_demands.end(), demand_idx);
      if (itr != _rehandling_demands.end())
        _rehandling_demands.erase(itr);
    }
    next_port_r_demands.erase(it);
    has_preempted = true;
  }

  if (has_preempted)
    dests_to_load_set.erase(p + 1);

  // 목적지 내림차순으로 적재
  vector<int> dests_to_load(dests_to_load_set.begin(), dests_to_load_set.end());
  std::sort(dests_to_load.begin(), dests_to_load.end(), std::greater<int>());

  vector<Cargo> remain_cargoes;
  for (int destination : dests_to_load) {
    deque<Cargo> cargo_queue;
    auto it_dm_pd = demand_map.find({p, destination});
    if (it_dm_pd != demand_map.end()) {
      int cnt = K[it_dm_pd->second].second;
      for (int i = 0; i < cnt; ++i)
        cargo_queue.emplace_back(p, destination);
    }

    for (int idx : _rehandling_demands) {
      if (idx >= 0 && idx < (int)K.size()) {
        auto od = K[idx].first;
        if (od.second == destination)
          cargo_queue.push_back(od);
      }
    }

    if (randreal() < 0.3) {
      this->load_cargo(destination, "N", cargo_queue);
    }

    if (!this->load_cargo(destination, "A", cargo_queue)[0].first) {
      if (!this->load_cargo(destination, "M", cargo_queue)[0].first) {
        while (!cargo_queue.empty()) {
          remain_cargoes.push_back(cargo_queue.front());
          cargo_queue.pop_front();
        }
        continue;
      }
    }

    this->load_cargo(destination, "NB", cargo_queue);
    while (!cargo_queue.empty()) {
      remain_cargoes.push_back(cargo_queue.front());
      cargo_queue.pop_front();
    }
  }

  this->reserve_baseline(remain_cargoes);
}

PartialSolution Deck::visit_port(int p, DemandList &K, int F) {
  /* 항구 p에서 하역과 선적 수행. 외부 호출용 */
  PartialSolution route_list_unload;
  vector<int> rehandling_demands = {};
  PartialSolution curr_port_sol;
  if (p > 0) {
    auto result = this->unloading_hueristic(K, p, F);
    route_list_unload = result.first;
    rehandling_demands = result.second;
  }
  this->loading_hueristic(K, p, rehandling_demands);
  PartialSolution route_list_load = this->make_path(K);

  curr_port_sol.reserve(curr_port_sol.size() + route_list_load.size());
  curr_port_sol.insert(curr_port_sol.end(), route_list_unload.begin(),
                       route_list_unload.end());
  curr_port_sol.insert(curr_port_sol.end(), route_list_load.begin(),
                       route_list_load.end());
  return curr_port_sol;
}

unordered_set<int> Deck::load_expansion(unordered_set<int> &A,
                                        deque<Cargo> &cargo_queue,
                                        unordered_set<int> *banned) {
  /*
  주어진 노드 집합 A에 대해, 불가능해질 때 까지 인접한 노드로 확장하며 화물을
  선적한다.
  */
  unordered_set<int> total_loaded_nodes;
  while (!cargo_queue.empty()) {
    unordered_set<int> loaded_nodes =
        this->load_at_adjacent_node(A, cargo_queue, banned);
    if (loaded_nodes.empty())
      break;
    A.insert(loaded_nodes.begin(), loaded_nodes.end());
    total_loaded_nodes.insert(loaded_nodes.begin(), loaded_nodes.end());
  }
  return total_loaded_nodes;
}

vector<pair<bool, unordered_set<int>>>
Deck::load_cargo(int destination, string loading_methods,
                 deque<Cargo> &cargo_queue, unordered_set<int> *banned) {
  /*
  loading_methods에 따라 다양한 방법으로 화물을 선적한다.
   - A: 동일 목적이 화물이 이미 선적되어 있을 경우, 해당 위치에서 확장하며
  선적한다.
   - M: major terminal node중 하나를 골라 시작점을 잡고 확장하며
  선적한다.
   - N: 적당한 빈 노드를 골라 시작점을 잡고 확장하며 선적한다.
   - B: reserve_baseline_nonblock 로직으로 시작점을 잡고 확장하며 선적한다.
   */
  vector<char> loading_methods_vec(loading_methods.begin(),
                                   loading_methods.end());
  vector<pair<bool, unordered_set<int>>> results;
  unordered_set<int> _banned =
      banned == nullptr ? unordered_set<int>() : unordered_set<int>(*banned);

  results.reserve(loading_methods_vec.size());
  for (char method : loading_methods_vec) {
    if (cargo_queue.empty()) {
      results.emplace_back(false, unordered_set<int>());
      continue;
    }

    unordered_set<int> already_loaded;
    unordered_set<int> newly_loaded;
    if (method == 'A') {
      auto groups_ret = this->find_adjacent_groups(destination);
      unordered_map<int, vector<int>> &groups = groups_ret.first;

      for (auto &kv : groups) {
        for (int n : kv.second) {
          if (_banned.count(n) == 0)
            already_loaded.insert(n);
        }
      }
      if (!already_loaded.empty())
        newly_loaded =
            this->load_expansion(already_loaded, cargo_queue, &_banned);
    } else if (method == 'M' || method == 'N' || method == 'R') {
      int target_node = -1;
      switch (method) {
      case 'M':
        target_node = this->find_good_major_terminal_node(destination);
        break;
      case 'N':
        target_node = this->find_good_new_position(destination, false);
        break;
      case 'R':
        target_node = this->find_good_new_position(destination, true);
        break;
      }
      if (target_node != -1 && _banned.count(target_node) == 0) {
        this->nodes[target_node].reserve(cargo_queue.front());
        cargo_queue.pop_front();
        newly_loaded = {target_node};
        this->load_expansion(newly_loaded, cargo_queue, &_banned);
      }
    } else if (method == 'B') {
      // Baseline Non-block
      newly_loaded = this->reserve_baseline_nonblock(cargo_queue, banned);
      this->load_expansion(newly_loaded, cargo_queue, &_banned);
    }

    results.emplace_back(already_loaded.size() > 0, newly_loaded);
  }
  return results;
}