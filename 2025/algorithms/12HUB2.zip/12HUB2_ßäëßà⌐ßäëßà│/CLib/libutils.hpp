/* utility codes */
#ifndef __LIB_UTILS_HPP__
#define __LIB_UTILS_HPP__

#include <chrono>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

// pair<int,int>를 key로 쓰기 위한 hash
namespace std {
template <>
struct hash<pair<int, int>> {
  size_t operator()(const pair<int, int>& p) const {
    return (static_cast<size_t>(p.first) << 32) ^ static_cast<size_t>(p.second);
  }
};
}  // namespace std

using namespace std;
typedef pair<vector<int>, int> Path;
typedef vector<Path> PartialSolution;
typedef unordered_map<int, PartialSolution> Solution;
typedef pair<int, int> Edge;
typedef pair<int, int> Cargo;
typedef pair<Cargo, int> Demand;
typedef vector<Demand> DemandList;

class TaskAbortException : public std::exception {
 private:
  std::string message;

 public:
  explicit TaskAbortException(const std::string& msg = "") : message(msg) {}
  virtual const char* what() const noexcept override { return message.c_str(); }
};

// double max(double a, double b);
// int max(int a, int b);

int randint(int n);

double randreal();

vector<int> Range(int n);
vector<int> Range(int s, int t);
vector<int> RandomRange(int n);
vector<int> RandomRange(int s, int t);

double Elapsed(chrono::high_resolution_clock::time_point start_time);

vector<int> sort_alternating(const vector<int>& lst);

void shuffle_vector(vector<int>& vec);

string to_string(const vector<int>& vec);
string to_string(const unordered_set<int>& set);
string to_string(const vector<pair<int, int>>& vec);
string to_string(const unordered_set<pair<int, int>>& set);
#endif  // __LIB_UTILS_HPP__