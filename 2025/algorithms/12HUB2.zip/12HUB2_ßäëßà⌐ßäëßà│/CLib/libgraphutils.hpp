#ifndef LIBGRAPHUTILS_HPP
#define LIBGRAPHUTILS_HPP

#include <unordered_map>
#include <unordered_set>
#include <vector>

using namespace std;

unordered_map<int, vector<int>> single_source_shortest_path(
    int N, const vector<int>& nodes,
    const unordered_map<int, vector<int>>& adj_lists, int source);
unordered_map<int, vector<int>> single_source_shortest_path(
    int N, const unordered_set<int>& nodes,
    const unordered_map<int, vector<int>>& adj_lists, int source);

vector<int> bfs_dead_ends(const unordered_map<int, vector<int>>& G, int start);

unordered_map<pair<int, int>, int> all_pairs_shortest_path_length(
    int N, const unordered_set<int>& nodes,
    const unordered_map<int, vector<int>>& adj_lists);
unordered_map<pair<int, int>, int> all_pairs_shortest_path_length(
    int N, const vector<int>& nodes,
    const unordered_map<int, vector<int>>& adj_lists);

vector<int> reduce_nodes_by_distance(int N,
                                     unordered_map<int, vector<int>>& adj_lists,
                                     vector<int>& nodes);
vector<int> dijkstra(int N, const unordered_map<int, vector<int>>& adj_lists,
                     const vector<vector<int>>& edge_costs, int s, int t);
vector<int> shortest_path_between_two_nodes(
    int N, const unordered_set<int>& nodes,
    const unordered_map<int, vector<int>>& adj_lists, int s, int t);
#endif  // LIBGRAPHUTILS_HPP
