#ifndef LIBNODE_HPP
#define LIBNODE_HPP

#include <stdexcept>
#include <utility>

enum class NodeState { EMPTY = 0, OCCUPIED = 1, RESERVED = 2, PREEMPTED = 3 };

class Node {
private:
  int id;
  NodeState state;
  int origin;      // cargo origin (없으면 -1)
  int destination; // cargo destination (없으면 -1)

public:
  explicit Node(int id);

  // 상태 변경 메서드
  void unload();
  void set_empty();
  void cancel_reservation();
  void preempt(std::pair<int, int> cargo);
  void occupy(std::pair<int, int> cargo = {-1, -1});
  void reserve(std::pair<int, int> cargo);

  bool is_empty() const;
  bool is_preempted() const;

  int get_id() const { return id; }
  NodeState get_state() const { return state; }
  int get_origin() const { return origin; }
  int get_destination() const { return destination; }
  std::pair<int, int> get_cargo() const {
    if (state != NodeState::EMPTY) {
      return {origin, destination};
    }
    throw std::runtime_error("Node is not occupied or reserved.");
  }

  void set_state(NodeState new_state) { state = new_state; }
  void set_cargo(std::pair<int, int> cargo) {
    origin = cargo.first;
    destination = cargo.second;
  }
};

#endif // LIBNODE_HPP
