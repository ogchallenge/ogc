#ifndef LIBDECK_HPP
#define LIBDECK_HPP

#include <deque>
#include <functional>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#include "libnode.hpp"
#include "libutils.hpp"  // for hash<pair<int, int>>. do not delete

using namespace std;

enum class SimStatus { Feasible = 0, Isolation = 1, Blocking = 2 };

struct SimulationResult {
  SimStatus status;
  unordered_set<int> isolated;
  unordered_set<int> blocked;
  bool all_father_dest = false;

  bool is_feasible() { return status == SimStatus::Feasible; }
  bool is_isolation() { return status == SimStatus::Isolation; }
  bool is_blocking() { return status == SimStatus::Blocking; }
};

class Deck {
  int N;  // 노드 개수
  vector<Node> nodes;

  vector<vector<bool>> A;
  unordered_map<int, vector<int>> adj_lists;

  // 그래프 분석 데이터
  unordered_map<int, double> centrality;
  unordered_map<int, int> degree;
  vector<int> terminal_nodes;
  vector<int> major_terminal_nodes;
  unordered_map<pair<int, int>, int, hash<pair<int, int>>> distances;

  // unload 최적화를 위한 arc 목록
  vector<pair<int, int>> all_arcs;
  unordered_map<int, vector<pair<int, int>>> inbound_arcs;
  unordered_map<int, vector<pair<int, int>>> outbound_arcs;
  unordered_set<int> preempted_nodes;

  void make_adj_lists();
  void compute_centrality();
  void compute_degree();
  void identify_terminal_nodes();
  void compute_distances();
  void make_arcs();

  void preempt_nodes(pair<int, int> cargo, int n_cargo);
  pair<unordered_map<int, vector<int>>, vector<int>> find_adjacent_groups(
      int destination);
  pair<unordered_map<int, unordered_map<int, vector<int>>>, vector<int>>
  find_adjacent_groups();
  unordered_set<int> find_adjacent_nodes(unordered_set<int>& A);
  int find_loading_node(unordered_set<int>& B,
                        unordered_set<int>* banned = nullptr);
  unordered_set<int> find_reachable_nodes(int additional_depth = 0,
                                          bool find_layered = false);
  SimulationResult simulate_loading(int node, int destination);
  unordered_set<int> load_at_adjacent_node(
      unordered_set<int>& A, deque<pair<int, int>>& cargo_queue,
      unordered_set<int>* banned = nullptr);
  function<unordered_set<int>()> check_terminal_available(int terminal_node,
                                                          Cargo cargo,
                                                          int n_remains);
  void reserve_baseline(vector<pair<int, int>>& cargo_list);
  unordered_set<int> reserve_baseline_nonblock(
      deque<pair<int, int>>& cargo_queue, unordered_set<int>* banned = nullptr);
  int find_good_major_terminal_node(int destination);
  int find_good_new_position(int destination, bool random = false);
  pair<vector<pair<vector<int>, int>>, vector<int>> unloading_hueristic(
      vector<pair<pair<int, int>, int>>& K, int p, int F);
  void loading_hueristic(vector<pair<pair<int, int>, int>>& K, int p,
                         vector<int>& rehandling_demands);
  vector<pair<bool, unordered_set<int>>> load_cargo(
      int destination, string loading_methods,
      deque<pair<int, int>>& cargo_queue, unordered_set<int>* banned = nullptr);
  unordered_set<int> load_expansion(unordered_set<int>& A,
                                    deque<pair<int, int>>& cargo_queue,
                                    unordered_set<int>* banned = nullptr);

 public:
  int tid = -1;
  Deck(int N, vector<vector<bool>>& A);
  void identify_major_terminal_nodes(int P);
  void loading_hueristic_port0(vector<pair<pair<int, int>, int>>& K,
                               bool random);
  PartialSolution make_path(DemandList& K);
  PartialSolution visit_port(int p, DemandList& K, int F);
};

#endif  // LIBDECK_HPP
