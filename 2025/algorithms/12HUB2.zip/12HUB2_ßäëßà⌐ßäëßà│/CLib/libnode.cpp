#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")

#include "libnode.hpp"

using namespace std;

Node::Node(int id)
    : id(id), state(NodeState::EMPTY), origin(-1), destination(-1) {}

void Node::unload() {
  if (state != NodeState::OCCUPIED) {
    throw runtime_error("Cannot unload cargo from an empty or reserved node.");
  }
  origin = -1;
  destination = -1;
  state = NodeState::EMPTY;
}

void Node::set_empty() {
  origin = -1;
  destination = -1;
  state = NodeState::EMPTY;
}

void Node::cancel_reservation() {
  if (state != NodeState::RESERVED) {
    throw runtime_error(
        "Cannot cancel reservation on a node that is not reserved.");
  }
  origin = -1;
  destination = -1;
  state = NodeState::EMPTY;
}

void Node::preempt(pair<int, int> cargo) {
  if (this->id == 0) {
    throw runtime_error("Cannot preempt the root node (0).");
  }
  if (state != NodeState::EMPTY) {
    throw runtime_error("Cannot preempt a node that is not empty.");
  }
  origin = cargo.first;
  destination = cargo.second;
  state = NodeState::PREEMPTED;
}

void Node::occupy(pair<int, int> cargo) {
  if (this->id == 0) {
    throw runtime_error("Cannot occupy the root node (0).");
  }
  if (cargo.first != -1 && cargo.second != -1) {
    origin = cargo.first;
    destination = cargo.second;
  }
  state = NodeState::OCCUPIED;
}

void Node::reserve(pair<int, int> cargo) {
  if (this->id == 0) {
    throw runtime_error("Cannot reserve the root node (0).");
  }
  if (state != NodeState::EMPTY) {
    throw runtime_error("Cannot reserve a node that is not empty.");
  }
  // printf("Node %d reserved with (%d, %d)\n", this->id, cargo.first,
  // cargo.second);
  origin = cargo.first;
  destination = cargo.second;
  state = NodeState::RESERVED;
}

bool Node::is_empty() const { return state == NodeState::EMPTY; }
bool Node::is_preempted() const { return state == NodeState::PREEMPTED; }