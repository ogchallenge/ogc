#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")

#include "libgraphutils.hpp"

#include <algorithm>
#include <limits>
#include <queue>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "libutils.hpp" // for hash<pair<int, int>>. do not delete

unordered_map<int, vector<int>>
single_source_shortest_path(int N, const unordered_set<int> &nodes,
                            const unordered_map<int, vector<int>> &adj_lists,
                            int source) {
  unordered_map<int, vector<int>> shortest_paths;
  queue<int> q;
  vector<bool> visited(N, false);
  vector<int> parent(N, -1);

  q.push(0);
  visited[0] = true;

  while (!q.empty()) {
    int u = q.front();
    q.pop();

    for (int neighbor : adj_lists.at(u)) {
      if (!visited[neighbor] && nodes.count(neighbor)) {
        visited[neighbor] = true;
        parent[neighbor] = u;
        q.push(neighbor);
      }
    }
  }

  for (int node : nodes) {
    vector<int> path;
    int curr = node;
    while (curr != 0 && parent[curr] != -1) {
      path.push_back(curr);
      curr = parent[curr];
    }
    path.push_back(0);
    reverse(path.begin(), path.end());
    shortest_paths[node] = path;
  }
  return shortest_paths;
}

unordered_map<int, vector<int>>
single_source_shortest_path(int N, const vector<int> &nodes,
                            const unordered_map<int, vector<int>> &adj_lists,
                            int source) {
  unordered_set<int> _nodes(nodes.begin(), nodes.end());
  return single_source_shortest_path(N, _nodes, adj_lists, source);
}

vector<int> bfs_dead_ends(const unordered_map<int, vector<int>> &G, int start) {
  unordered_set<int> visited;
  vector<int> dead_ends;
  queue<int> q;

  q.push(start);
  visited.insert(start);

  while (!q.empty()) {
    int current = q.front();
    q.pop();

    vector<int> children;
    for (int neighbor : G.at(current)) {
      if (visited.find(neighbor) == visited.end()) {
        children.push_back(neighbor);
      }
    }

    sort(children.begin(), children.end());

    if (children.empty()) {
      dead_ends.push_back(current);
    } else {
      for (int child : children) {
        visited.insert(child);
        q.push(child);
      }
    }
  }

  return dead_ends;
}

unordered_map<pair<int, int>, int> all_pairs_shortest_path_length(
    int N, const unordered_set<int> &nodes,
    const unordered_map<int, vector<int>> &adj_lists) {
  unordered_map<pair<int, int>, int> dist;

  for (int src : nodes) {
    vector<int> distance(N, numeric_limits<int>::max());
    queue<int> q;

    distance[src] = 0;
    q.push(src);

    while (!q.empty()) {
      int u = q.front();
      q.pop();

      for (int v : adj_lists.at(u)) {
        if (nodes.find(v) == nodes.end())
          continue;

        if (distance[v] == numeric_limits<int>::max()) {
          distance[v] = distance[u] + 1;
          q.push(v);
        }
      }
    }

    for (int dst : nodes) {
      if (distance[dst] != numeric_limits<int>::max()) {
        dist[{src, dst}] = distance[dst];
        dist[{dst, src}] = distance[dst];
      }
    }
  }

  return dist;
}

unordered_map<pair<int, int>, int> all_pairs_shortest_path_length(
    int N, const vector<int> &nodes,
    const unordered_map<int, vector<int>> &adj_lists) {
  unordered_set<int> _nodes(nodes.begin(), nodes.end());
  return all_pairs_shortest_path_length(N, _nodes, adj_lists);
}

vector<int> bfs_distances(const unordered_map<int, vector<int>> &adj_lists,
                          int start, const unordered_set<int> &targets,
                          int max_depth) {
  queue<pair<int, int>> q;
  unordered_set<int> visited;
  vector<int> reachable;

  q.push({start, 0});
  visited.insert(start);

  while (!q.empty()) {
    auto [u, dist] = q.front();
    q.pop();

    if (dist > max_depth)
      continue;

    if (u != start && targets.count(u) && dist <= max_depth) {
      reachable.push_back(u);
    }

    for (int v : adj_lists.at(u)) {
      if (!visited.count(v)) {
        visited.insert(v);
        q.push({v, dist + 1});
      }
    }
  }

  return reachable;
}

vector<int> reduce_nodes_by_distance(int N,
                                     unordered_map<int, vector<int>> &adj_lists,
                                     vector<int> &nodes) {
  // Step 1: Construct graph H from nodes, edges exist if dist <= 3
  unordered_map<int, unordered_set<int>> H; // adjacency list for H
  unordered_set<int> node_set(nodes.begin(), nodes.end());

  for (int i = 0; i < nodes.size(); ++i) {
    int u = nodes[i];
    vector<int> reachable = bfs_distances(adj_lists, u, node_set, 3);
    for (int v : reachable) {
      if (v == u)
        continue;
      if (u < v) {
        H[u].insert(v);
        H[v].insert(u);
      }
    }
  }

  // Step 2: Find connected components in H
  unordered_set<int> visited;
  vector<int> result;

  for (int node : nodes) {
    if (visited.count(node))
      continue;

    vector<int> component;
    queue<int> q;
    q.push(node);
    visited.insert(node);

    while (!q.empty()) {
      int u = q.front();
      q.pop();
      component.push_back(u);
      for (int v : H[u]) {
        if (!visited.count(v)) {
          visited.insert(v);
          q.push(v);
        }
      }
    }

    // Choose max node in the component
    result.push_back(*max_element(component.begin(), component.end()));
  }

  sort(result.begin(), result.end());
  return result;
}

vector<int> dijkstra(int N, const unordered_map<int, vector<int>> &adj_lists,
                     const vector<vector<int>> &edge_costs, int s, int t) {
  if (s < 0 || s >= N || t < 0 || t >= N) {
    throw invalid_argument("s or t out of range");
  }
  if (s == t) {
    return {s};
  }

  const int INF = numeric_limits<int>::max() / 4 * 3; // INF 값 설정
  vector<int> dist(N, INF);
  vector<int> parent(N, -1);

  using PQItem = pair<int, int>;
  priority_queue<PQItem, vector<PQItem>, greater<PQItem>> pq;

  dist[s] = 0;
  pq.emplace(0, s);

  while (!pq.empty()) {
    PQItem top = pq.top();
    pq.pop();
    int d = top.first;
    int u = top.second;

    if (d != dist[u])
      continue;
    if (u == t)
      break;

    auto it = adj_lists.find(u);
    if (it == adj_lists.end())
      continue;

    const vector<int> &nbrs = it->second;
    for (size_t i = 0; i < nbrs.size(); ++i) {
      int v = nbrs[i];
      int w = edge_costs[u][v];
      int nd = d + static_cast<int>(w);
      if (nd < dist[v]) {
        dist[v] = nd;
        parent[v] = u;
        pq.emplace(nd, v);
      }
    }
  }

  if (dist[t] == INF) {
    return {};
  }

  vector<int> path;
  for (int cur = t; cur != -1; cur = parent[cur]) {
    path.push_back(cur);
  }
  std::reverse(path.begin(), path.end());
  return path;
}

vector<int> shortest_path_between_two_nodes(
    int N, const unordered_set<int> &nodes,
    const unordered_map<int, vector<int>> &adj_lists, int s, int t) {
  if (N <= 0 || s < 0 || s >= N || t < 0 || t >= N)
    return {};
  if (s == 0 || t == 0)
    return {};
  if (nodes.find(s) == nodes.end() || nodes.find(t) == nodes.end())
    return {};

  vector<int> parent(N, -1);
  vector<char> visited(N, 0);

  if (0 < N)
    visited[0] = 1;

  deque<int> q;
  visited[s] = 1;
  q.push_back(s);

  while (!q.empty()) {
    int u = q.front();
    q.pop_front();
    if (u == t)
      break;

    auto it = adj_lists.find(u);
    if (it == adj_lists.end())
      continue;

    for (int v : it->second) {
      if (v < 0 || v >= N)
        continue;
      if (v == 0)
        continue;
      if (nodes.find(v) == nodes.end())
        continue;
      if (visited[v])
        continue;

      visited[v] = 1;
      parent[v] = u;
      q.push_back(v);
    }
  }

  if (!visited[t])
    return {};

  vector<int> path;
  for (int cur = t; cur != -1; cur = parent[cur])
    path.push_back(cur);
  std::reverse(path.begin(), path.end());

  if (std::find(path.begin(), path.end(), 0) != path.end())
    return {};
  for (int v : path)
    if (nodes.find(v) == nodes.end())
      return {};

  return path;
}