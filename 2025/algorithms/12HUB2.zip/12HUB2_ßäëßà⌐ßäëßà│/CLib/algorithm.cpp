#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")

#include <omp.h>
#include <stdio.h>

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <unordered_map>
#include <vector>

#include "libdeck.hpp"
#include "libutils.hpp"

#define NUM_CPU 4
#define NOW std::chrono::high_resolution_clock::now

using namespace std;

static int N;
static int P;
static int F;
static int BEST_COST;
static double ALGO_TIME;

struct TimeData {
  chrono::high_resolution_clock::time_point start_time;
  double remain_time;

  TimeData(chrono::high_resolution_clock::time_point st, double rt)
      : start_time(st), remain_time(rt) {}

  bool isTimeout() { return elapsed() > remain_time - ALGO_TIME - 2; }
  double elapsed() { return Elapsed(start_time); }
};

int calc_obj(Solution& solution) {
  // 목적함수 값 계산
  int obj = 0;
  for (int p = 0; p < P; p++) {
    PartialSolution& sol = solution[p];
    for (Path& s : sol) {
      vector<int>& route = s.first;
      obj += F + route.size() - 1;
    }
  }
  return obj;
}

int calc_obj_LB(DemandList& K, Solution& sol, int curr_P) {
  // 아직 완성되지 않은 해가 가질 최종 목적함수 값의 하한을 계산
  int obj = 0;
  for (int p = 0; p <= curr_P; p++) {
    for (pair<vector<int>, int> pd : sol[p]) {
      obj += static_cast<int>(pd.first.size()) + F;
    }
  }

  for (Demand k : K) {
    auto [o, d] = k.first;
    int r = k.second;
    if (o <= curr_P && d > curr_P)
      obj += F;
    else if (o > curr_P)
      obj += 2 * F;
  }
  return obj;
}

static inline bool all_nodes_in_range(const std::vector<int>& route, int N) {
  if (route.empty()) return false;
  for (int v : route)
    if (v < 0 || v >= N) return false;
  return true;
}
static inline bool is_simple_route(const std::vector<int>& route) {
  std::unordered_set<int> seen;
  seen.reserve(route.size() * 2);
  for (int v : route) {
    if (!seen.insert(v).second) return false;
  }
  return true;
}

int calc_obj2(const Solution& solution, const std::unordered_set<Edge>& E,
              const std::vector<Demand>& K) {
  // ----- 사전 조건 방어 -----
  if (N <= 0 || P <= 0) {
    std::cout << "Infeasible: invalid global N or P\n";
    return 0;
  }

  // ----- 각 포트 p 직후 적재되어 있어야 하는 수요 카운트( demand k -> required
  // r ) -----
  std::vector<std::unordered_map<int, int>> supposed;
  supposed.resize(P);
  for (int p = 0; p < P; ++p) {
    auto& mp = supposed[p];
    // 대략 크기 예측(선택): mp.reserve(K.size());
    for (int k = 0; k < (int)K.size(); ++k) {
      int o = K[k].first.first;
      int d = K[k].first.second;
      int r = K[k].second;
      if (o <= p && p < d) mp[k] = r;
    }
  }

  // ----- 노드 점유 상태: -1 비어있음 / >=0 demand index -----
  std::vector<int> node_allocations;
  node_allocations.assign((size_t)N, -1);

  int obj = 0;
  bool is_infeasible = false;

  // 빈 컨테이너 참조용 (누수 방지)
  static const std::vector<std::pair<std::vector<int>, int>> EMPTY_ROUTES;

  for (int p = 0; p < P; ++p) {
    auto itp = solution.find(p);
    if (itp == solution.end()) {
      std::cout << "Infeasible: solution has no route list for port " << p
                << "\n";
      is_infeasible = true;
    }

    // 누수 없는 안전한 빈 참조
    const auto& route_list =
        (itp == solution.end()) ? EMPTY_ROUTES : itp->second;

    for (const auto& rk : route_list) {
      const std::vector<int>& route = rk.first;
      const int k = rk.second;

      // 경로 기본 검증
      if ((int)route.size() <= 1) {
        std::cout << "Infeasible: route length < 2\n";
        is_infeasible = true;
      }
      if (!all_nodes_in_range(route, N)) {
        std::cout << "Infeasible: route has invalid node index\n";
        is_infeasible = true;
      }
      if (!is_simple_route(route)) {
        std::cout << "Infeasible: route is not simple (has duplicate node)\n";
        is_infeasible = true;
      }

      // 간선 유효성
      for (size_t i = 0; i + 1 < route.size(); ++i) {
        int u = route[i], v = route[i + 1];
        if (E.find({u, v}) == E.end()) {
          std::cout << "Infeasible: route contains invalid edge (" << u << ","
                    << v << ")\n";
          is_infeasible = true;
        }
      }

      if (route.empty()) continue;

      // 유형별 처리
      if (route.front() == 0) {
        // Loading: 0 -> ... -> loading_node
        int loading_node = route.back();
        if (loading_node < 0 || loading_node >= N) {
          std::cout << "Infeasible: loading node out of range\n";
          is_infeasible = true;
        } else {
          if (node_allocations[loading_node] != -1) {
            std::cout << "Infeasible: loading node " << loading_node
                      << " already occupied by demand "
                      << node_allocations[loading_node] << " at port " << p
                      << "\n";
            is_infeasible = true;
          }
        }
        for (size_t i = 0; i + 1 < route.size(); ++i) {
          int v = route[i];
          if (v < 0 || v >= N) continue;
          if (node_allocations[v] != -1) {
            std::cout << "Infeasible: loading route blocked by node " << v
                      << " occupied by demand " << node_allocations[v]
                      << " at port " << p << "\n";
            is_infeasible = true;
          }
        }
        if (0 <= loading_node && loading_node < N)
          node_allocations[loading_node] = k;

      } else if (route.back() == 0) {
        // Unloading: unloading_node -> ... -> 0
        int unloading_node = route.front();
        if (unloading_node < 0 || unloading_node >= N) {
          std::cout << "Infeasible: unloading node out of range\n";
          is_infeasible = true;
        } else {
          if (node_allocations[unloading_node] == -1) {
            std::cout << "Infeasible: unloading node " << unloading_node
                      << " is not occupied by any demand at port " << p << "\n";
            is_infeasible = true;
          }
        }
        for (size_t i = 1; i < route.size(); ++i) {
          int v = route[i];
          if (v < 0 || v >= N) continue;
          if (node_allocations[v] != -1) {
            std::cout << "Infeasible: unloading route blocked by node " << v
                      << " occupied by demand " << node_allocations[v]
                      << " at port " << p << "\n";
            is_infeasible = true;
          }
        }
        if (0 <= unloading_node && unloading_node < N)
          node_allocations[unloading_node] = -1;

      } else {
        // Rehandling: unloading_node -> ... -> loading_node (both non-zero)
        int unloading_node = route.front();
        int loading_node = route.back();

        if (!(0 <= unloading_node && unloading_node < N) ||
            !(0 <= loading_node && loading_node < N)) {
          std::cout << "Infeasible: rehandling endpoints out of range\n";
          is_infeasible = true;
        } else {
          if (node_allocations[unloading_node] == -1) {
            std::cout << "Infeasible: rehandling unloading node "
                      << unloading_node
                      << " not occupied by any demand at port " << p << "\n";
            is_infeasible = true;
          }
          if (node_allocations[loading_node] != -1) {
            std::cout << "Infeasible: rehandling loading node " << loading_node
                      << " already occupied by demand "
                      << node_allocations[loading_node] << " at port " << p
                      << "\n";
            is_infeasible = true;
          }
        }
        for (size_t i = 1; i + 1 < route.size(); ++i) {
          int v = route[i];
          if (v < 0 || v >= N) continue;
          if (node_allocations[v] != -1) {
            std::cout << "Infeasible: rehandling route blocked by node " << v
                      << " occupied by demand " << node_allocations[v]
                      << " at port " << p << "\n";
            is_infeasible = true;
          }
        }
        if (0 <= loading_node && loading_node < N)
          node_allocations[loading_node] = k;
        if (0 <= unloading_node && unloading_node < N)
          node_allocations[unloading_node] = -1;
      }

      obj += (int)F + (int)route.size() - 1;
    }

    // 현재 적재 상태 카운트
    std::unordered_map<int, int> current_status;
    current_status.reserve((size_t)N);
    for (int v = 0; v < N; ++v) {
      int d = node_allocations[v];
      if (d >= 0) current_status[d]++;
    }

    const auto& supposed_map = supposed[p];
    if (current_status != supposed_map) {
      std::cout << "Debug: mismatch after port " << p << "\n";

      for (const auto& kv : current_status) {
        int dk = kv.first, r = kv.second;
        auto it = supposed_map.find(dk);
        if (it == supposed_map.end()) {
          std::cout << "  Demand " << dk << " loaded but should NOT be\n";
        } else if (it->second != r) {
          auto od = K[dk].first;
          std::cout << "  Demand " << dk << " (" << od.first << "," << od.second
                    << ") count mismatch: " << r << " vs " << it->second
                    << "\n";
        }
      }
      for (const auto& kv : supposed_map) {
        int dk = kv.first, r = kv.second;
        if (current_status.find(dk) == current_status.end()) {
          std::cout << "  Demand " << dk << " should be loaded with qty " << r
                    << " but is missing\n";
        }
      }

      // infeasible 사유
      for (const auto& kv : supposed_map) {
        int dk = kv.first, r = kv.second;
        auto it = current_status.find(dk);
        if (it == current_status.end()) {
          std::cout << "Infeasible: Demand " << dk << " is not loaded at port "
                    << p << " or before\n";
          is_infeasible = true;
        } else if (it->second != r) {
          std::cout << "Infeasible: Demand " << dk << " is loaded with qty "
                    << it->second << " but should be " << r << "\n";
          is_infeasible = true;
        }
      }
      for (const auto& kv : current_status) {
        int dk = kv.first;
        if (supposed_map.find(dk) == supposed_map.end()) {
          std::cout << "Infeasible: Demand " << dk << " is loaded at port " << p
                    << " or before but it should not be\n";
          is_infeasible = true;
        }
      }
    }
  }

  if (!is_infeasible) {
    int adjusted = obj;
    if (adjusted < (int)std::numeric_limits<int>::min())
      adjusted = (int)std::numeric_limits<int>::min();
    if (adjusted > (int)std::numeric_limits<int>::max())
      adjusted = (int)std::numeric_limits<int>::max();
    return (int)adjusted;
  } else {
    // 기존과 동일하게 표기
    std::cout << "infeasible";
    return 0;
  }
}

int check_feasibility(Solution& solution, unordered_set<Edge>& E,
                      vector<Demand>& K) {
  // 해가 feasible하면 목적함수값 반환
  // infeasible한 경우 int type max value 반환
  vector<unordered_map<int, int>> supposed;
  supposed.resize(P);
  for (int p = 0; p < P; ++p) {
    auto& mp = supposed[p];
    for (int k = 0; k < (int)K.size(); ++k) {
      int o = K[k].first.first;
      int d = K[k].first.second;
      int r = K[k].second;
      if (o <= p && p < d) mp[k] = r;
    }
  }

  vector<int> node_allocations;
  node_allocations.assign((size_t)N, -1);

  bool is_infeasible = false;

  static const vector<pair<vector<int>, int>> EMPTY_ROUTES;

  for (int p = 0; p < P; ++p) {
    auto itp = solution.find(p);
    if (itp == solution.end()) {
      is_infeasible = true;
    }

    const auto& route_list =
        (itp == solution.end()) ? EMPTY_ROUTES : itp->second;

    for (const auto& rk : route_list) {
      const vector<int>& route = rk.first;
      const int k = rk.second;

      if ((int)route.size() <= 1 || !all_nodes_in_range(route, N) ||
          !is_simple_route(route))
        is_infeasible = true;

      for (size_t i = 0; i + 1 < route.size(); ++i) {
        int u = route[i], v = route[i + 1];
        if (E.find({u, v}) == E.end()) is_infeasible = true;
      }

      if (route.empty()) continue;

      if (route.front() == 0) {
        int loading_node = route.back();
        if (loading_node < 0 || loading_node >= N) {
          is_infeasible = true;
        } else {
          if (node_allocations[loading_node] != -1) is_infeasible = true;
        }
        for (size_t i = 0; i + 1 < route.size(); ++i) {
          int v = route[i];
          if (v < 0 || v >= N) continue;
          if (node_allocations[v] != -1) is_infeasible = true;
        }
        if (0 <= loading_node && loading_node < N)
          node_allocations[loading_node] = k;

      } else if (route.back() == 0) {
        int unloading_node = route.front();
        if (unloading_node < 0 || unloading_node >= N) {
          is_infeasible = true;
        } else {
          if (node_allocations[unloading_node] == -1) is_infeasible = true;
        }
        for (size_t i = 1; i < route.size(); ++i) {
          int v = route[i];
          if (v < 0 || v >= N) continue;
          if (node_allocations[v] != -1) is_infeasible = true;
        }
        if (0 <= unloading_node && unloading_node < N)
          node_allocations[unloading_node] = -1;

      } else {
        int unloading_node = route.front();
        int loading_node = route.back();

        if (!(0 <= unloading_node && unloading_node < N) ||
            !(0 <= loading_node && loading_node < N)) {
          is_infeasible = true;
        } else {
          if (node_allocations[unloading_node] == -1) is_infeasible = true;
          if (node_allocations[loading_node] != -1) is_infeasible = true;
        }
        for (size_t i = 1; i + 1 < route.size(); ++i) {
          int v = route[i];
          if (v < 0 || v >= N) continue;
          if (node_allocations[v] != -1) is_infeasible = true;
        }
        if (0 <= loading_node && loading_node < N)
          node_allocations[loading_node] = k;
        if (0 <= unloading_node && unloading_node < N)
          node_allocations[unloading_node] = -1;
      }
    }

    unordered_map<int, int> current_status;
    current_status.reserve((size_t)N);
    for (int v = 0; v < N; ++v) {
      int d = node_allocations[v];
      if (d >= 0) current_status[d]++;
    }

    const auto& supposed_map = supposed[p];
    if (current_status != supposed_map) {
      for (const auto& kv : supposed_map) {
        int dk = kv.first, r = kv.second;
        auto it = current_status.find(dk);
        if (it == current_status.end() || it->second != r) is_infeasible = true;
      }
      for (const auto& kv : current_status) {
        int dk = kv.first;
        if (supposed_map.find(dk) == supposed_map.end()) is_infeasible = true;
      }
    }
  }

  if (!is_infeasible) {
    return calc_obj(solution);
  } else {
    printf("infeasible\n");
    return std::numeric_limits<int>::max();
  }
}

int*** make_return_pointer(const Solution& solution, int P) {
  // 파이썬 반환용 데이터 생성

  if (P < 0) return nullptr;
  const int PP = P;

  int*** ret = (int***)std::malloc(static_cast<size_t>(PP) * sizeof(int**));
  if (!ret) return nullptr;

  vector<size_t> counts(static_cast<size_t>(PP), 0);

  for (int p = 0; p < PP; ++p) {
    size_t nRoutes = 0;
    const vector<pair<vector<int>, int>>* routes = nullptr;
    if (auto it = solution.find(p); it != solution.end()) {
      routes = &it->second;
      nRoutes = routes->size();
    }

    size_t nPtrs = nRoutes + 2;
    ret[p] = (int**)std::malloc(nPtrs * sizeof(int*));
    if (!ret[p]) goto FAIL;

    counts[p] = 0;

    ret[p][0] = (int*)std::malloc(sizeof(int));
    if (!ret[p][0]) goto FAIL;
    counts[p] = 1;

    ret[p][0][0] = static_cast<int>(nRoutes);

    for (size_t i = 0; i < nRoutes; ++i) {
      const auto& path = (*routes)[i].first;
      const int demand = (*routes)[i].second;
      const size_t pathLen = path.size();

      size_t nInts = pathLen + 2;
      ret[p][i + 1] = (int*)std::malloc(nInts * sizeof(int));
      if (!ret[p][i + 1]) goto FAIL;

      ret[p][i + 1][0] = demand;
      ret[p][i + 1][1] = static_cast<int>(pathLen);
      for (size_t j = 0; j < pathLen; ++j) {
        ret[p][i + 1][j + 2] = path[j];
      }
      counts[p] = (i + 2);
    }

    ret[p][nRoutes + 1] = nullptr;
  }

  return ret;

FAIL:
  for (int p2 = 0; p2 < PP; ++p2) {
    if (!ret[p2]) continue;
    size_t kMax = counts[p2];
    for (size_t k = 0; k < kMax; ++k) {
      if (ret[p2][k]) std::free(ret[p2][k]);
    }
    std::free(ret[p2]);
  }
  std::free(ret);
  return nullptr;
}

Solution algorithm(int tid, vector<vector<bool>>& A, DemandList& K,
                   bool random_port_0 = false, int best_cost = -1) {
  if (best_cost == -1) best_cost = std::numeric_limits<int>::max();

  Deck deck(N, A);
  deck.identify_major_terminal_nodes(P);
  deck.tid = tid;

  Solution solution;
  for (int p = 0; p < P; p++) solution[p] = vector<pair<vector<int>, int>>();

  deck.loading_hueristic_port0(K, random_port_0);
  solution[0] = deck.make_path(K);

  for (int p = 1; p < P; p++) {
    solution[p] = deck.visit_port(p, K, F);

    if (random_port_0) {
      // 각 스레드의 첫 실행에서만 random_port_0 = false인데,
      // 처음 feasible solution을 들고 시작하도록 분기.
      int virtual_LB = calc_obj_LB(K, solution, p);
      if (virtual_LB >= BEST_COST) return {};
    }
  }
  return solution;
}

pair<Solution, int> iter_algorithm(int tid, vector<vector<bool>>& A,
                                   unordered_set<Edge>& E, DemandList& K,
                                   double remain_time) {
  auto st = NOW();
  Solution best_solution;
  int best_cost = std::numeric_limits<int>::max();

  int sort_port_0;
  switch (tid) {
    case 0:
    case 1:
      sort_port_0 = 0;
      break;
    case 2:
      sort_port_0 = 1;
      break;
    case 3:
      sort_port_0 = 2;
      break;
    default:
      sort_port_0 = 0;
  }

  Solution curr_sol = algorithm(tid, A, K, false);
  int obj = check_feasibility(curr_sol, E, K);
  if (obj < best_cost) {
    best_solution = curr_sol;
    best_cost = obj;
  }
  curr_sol.clear();
  if (Elapsed(st) > remain_time - 3) return {best_solution, best_cost};

  double first_algo_time = Elapsed(st);

#pragma omp critical
  {
    BEST_COST = best_cost < BEST_COST ? best_cost : BEST_COST;
    ALGO_TIME = ALGO_TIME < first_algo_time ? first_algo_time : ALGO_TIME;
  }

  TimeData time_data(NOW(), remain_time - Elapsed(st));
  while (!time_data.isTimeout()) {
    curr_sol = algorithm(tid, A, K, true, best_cost);
    if (curr_sol.size() == 0) continue;

    obj = check_feasibility(curr_sol, E, K);

    if (obj < best_cost) {
      best_solution = curr_sol;
      best_cost = obj;
#pragma omp critical
      {
        BEST_COST = best_cost < BEST_COST ? best_cost : BEST_COST;
      }
    }

    curr_sol.clear();
  }

  return {best_solution, best_cost};
}

extern "C" int*** Main(int _N, int* _A, int _P, int* _K, int _F,
                       double timelimit) {
  auto st = NOW();
  omp_set_dynamic(0);

  BEST_COST = std::numeric_limits<int>::max();
  ALGO_TIME = 0;

  N = _N;
  P = _P;
  F = _F;

  vector<vector<bool>> A(N, vector<bool>(N));
  unordered_set<Edge> E;
  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N; j++) {
      A[i][j] = _A[i * N + j] == 1;
      if (A[i][j]) {
        E.insert({i, j});
        E.insert({j, i});  // 무향 간선
      }
    }
  }

  DemandList K;
  int len_K = _K[0];
  K.reserve(len_K);
  for (int i = 0; i < len_K; i++) {
    int o = _K[i * 3 + 1];
    int d = _K[i * 3 + 2];
    int r = _K[i * 3 + 3];
    K.push_back({{o, d}, r});
  }

  double initialization_time = Elapsed(st);
  vector<pair<Solution, int>> solutions(NUM_CPU);

#pragma omp parallel num_threads(NUM_CPU) \
    firstprivate(A, E, K, timelimit, initialization_time)
  {
    int tid = omp_get_thread_num();
    solutions[tid] =
        iter_algorithm(tid, A, E, K, timelimit - initialization_time);
  }

  int best_idx = -1;
  int best_cost = std::numeric_limits<int>::max();
  for (int i = 0; i < NUM_CPU; i++) {
    if (solutions[i].second < best_cost) {
      best_cost = solutions[i].second;
      best_idx = i;
    }
  }

  int*** ret = make_return_pointer(solutions[best_idx].first, P);
  return ret;
}

extern "C" void FreeRetPtrs(int P, int*** ret) {
  for (int p = 0; p < P; p++) {
    int n_paths = ret[p][0][0];
    for (int i = 0; i < n_paths; i++) free(ret[p][i + 1]);
    free(ret[p][0]);
    free(ret[p]);
  }
  free(ret);
  ret = nullptr;
}