Team '12HUB2' README

 - The location of C/C++ code: `./CLib`
 - The location of Shared Object files: `./CLib/obj`
 - How to build: Run the `./CLib/build.py` file (e.g., `python3 ./CLib/build.py`).
                 The .so files will be generated in the specified directory regardless of where you run the script.
 