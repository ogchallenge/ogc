import util
import util2
import networkx as nx

# Unloading heuristic
def unloading_heuristic(p, node_allocations, K, G, N, new_paths, num_iter):
    # All demands that should be unloaded at port p
    K_unload = {idx: r for idx, ((o,d),r) in enumerate(K) if d == p}
    K_unload_list = list(K_unload.keys())
    
    # print(f'Starting unloading phase...')
    # print(f'Demands that are destined to this port: {K_unload}')

    route_list = []
    rehandling_demands = []
    unloading_nodes = []
    moving_count = 0
    rehandle_count = 0
    
    while True:
        
        prev_unloading_count = len(unloading_nodes)
        unloading_nodes = sorted([n for n in range(1,N) if node_allocations[n] in K_unload_list])
        max_num = sum([1 for i in node_allocations if i != 1]) - len(unloading_nodes)
        
        # if r != len(unloading_nodes):
        #     print(f"==> Demand {k} at port {p} is not loaded correctly. Demand {k} should be {r} but it is {len(unloading_nodes)}")
        
        for n in unloading_nodes:
            
            k = node_allocations[n]
            # print(f"Unloading demand {k} at node {n}")
                         
            if k == -1 or k not in K_unload:
                # The node may be cleared already for rehandling... we skip if it is the case.
                continue
            
            reachable_nodes2, reachable_node_distances2 = util2.bfs2(G, node_allocations, n)
            
            if 0 in reachable_nodes2:
                distances, previous_nodes = util.dijkstra(G, node_allocations, start=n)
                path = util.path_backtracking(previous_nodes, 0, 0)
                route_list.append((path, k))
                node_allocations[n] = -1
                # print(f"Unloading path for demand {k} at node {n} is reachable. Unload with path {path}!")
            
            elif (prev_unloading_count == 0) or (prev_unloading_count != len(unloading_nodes)):
                # print(f"Unloading path for demand {k} at node {n} is blocked by {min_blocking_nodes[1]} nodes. Try agian...")
                continue
            
            # if there are blocking, and cannot unload any other demands, rehandle blocking node
            else:
                # print(f"Unloading path for demand {k} at node {n} is blocked by {min_blocking_nodes[1]} nodes. Rehandling...")
                # # The path with the minimum blocking nodes
                min_blocking_nodes = util2.find_blocking_nodes(n, node_allocations, new_paths)
                
                blocking_nodes = min_blocking_nodes[1]
                path = min_blocking_nodes[2]
                num_blocking = 0
                
                for bn in blocking_nodes:
                    
                    # demand key of the blocking node
                    bk = node_allocations[bn]
                    
                    reachable_nodes2, reachable_node_distances2 = util2.bfs2(G, node_allocations, bn)
                    
                    # Find critical nodes that are blocking the path of ahead nodes
                    critical_nodes = util2.find_critical_nodes_unloading(bn, node_allocations, reachable_nodes2, K, N, new_paths)
                    # Define candidate nodes that are reachable from the blocking node and not critical
                    candidate_nodes = [i for i in reachable_nodes2 if i not in critical_nodes + [0,1]]
                    
                    # if (p == 8) and (bn in [2, 84]) and (moving_count < 12):
                    #     critical_nodes = util2.find_critical_nodes2(bn, node_allocations, reachable_nodes2, K, N, new_paths)
                    #     candidate_nodes = [i for i in reachable_nodes2 if i not in critical_nodes + [0,1]]
                    #     print(node_allocations)
                    #     print(f"    Critical nodes for blocking node {bn} with demand {bk} are {critical_nodes}.")
                    #     print(f"    Candidate nodes for blocking node {bn} with demand {bk} are {candidate_nodes}.")
                    
                    # If the every reachable node is critical, rehanlde the blocking node
                    if len(candidate_nodes) < 1:
                        
                        rehandle_count += 1
                        
                        # Check unload availability of the blocking node
                        reachable_nodes2, reachable_node_distances2 = util2.bfs2(G, node_allocations, bn)
                        if 0 in reachable_nodes2:
                            distances, previous_nodes = util.dijkstra(G, node_allocations, start = bn)
                            path = util.path_backtracking(previous_nodes, 0, 0)
                            # Check if the blocking demand is in the unloading list
                            if node_allocations[bn] not in K_unload:
                                # Rehandle the demand
                                rehandling_demands.append(bk)   
                                # print(f"  Rehandle demand {bk} at node {bn} to unload demand {k} at node {n} with path {path[::-1]}")
                            else:
                                # print(f"  Demand {bk} at node {bn} is already in the unloading list. Unload demand {k} at node {n} with path {path[::-1]}")
                                pass
                            route_list.append((path, bk))
                            node_allocations[bn] = -1
                            
                    # If there are more than 2 reachable nodes, we don't unload the blocking node demand, but we rehandle it to other reachable nodes which are not critical
                    else:
                        moving_count += 1
                        # choose the random candidate node  as rehandle node
                        # moving_node = int(np.random.choice(candidate_nodes))
                        gajokus = [node for node in range(1,N) if K[node_allocations[node]][0][1] == K[k][0][1] and node_allocations[node] != -1]
                        moving_node = util2.find_loading_node(gajokus, candidate_nodes, node_allocations, G)
                        if moving_node == -1:
                            loading_ratio = (K[k][0][1] - p) / (max([demand[0][1] for demand in K]) - p)
                            moving_node = candidate_nodes[int(loading_ratio * len(candidate_nodes)) - 1]
                        # Get the shortest path to the node from the blocking node
                        distances, previous_nodes = util.dijkstra(G, node_allocations, start=bn)
                        path = util.path_backtracking(previous_nodes, 0, moving_node)
                        route_list.append((path, bk))
                                                        
                        node_allocations[moving_node] = bk
                        node_allocations[bn] = -1
                        # print(f"  Blocking node {bn} is moved to node {moving_node} with path {path}.")
                
                    reachable_nodes2, reachable_node_distances2 = util2.bfs2(G, node_allocations, n)
            
                    if 0 in reachable_nodes2:
                        distances, previous_nodes = util.dijkstra(G, node_allocations, start=n)
                        path = util.path_backtracking(previous_nodes, 0, 0)
                        route_list.append((path, k))
                        node_allocations[n] = -1
                        break
                        # print(f"Unloading path for demand {k} at node {n} is reachable. Unload with path {path}!")   
                    else:
                        # print(f"  Despite rehandling, unloading path for demand {k} at node {n} is blocked by {blocking_nodes} nodes. Retry rehandling...")
                        pass
        
        # No more unloading nodes at this port, we can stop
        if len([n for n in range(N) if node_allocations[n] in K_unload_list]) == 0:
            # If there are no more unloading nodes, we can stop
            # print(f'Unloading phase completed with {len(route_list)} routes including {moving_count} moving routes and {rehandle_count} rehandling routes!')
            break
        
        # To prevent infinite loop, we limit the number of rehandling and moving operations
        if rehandle_count + moving_count >= max_num:
            # If we have rehandled all the demands, we can stop
            
            # print(f'------ To prevent infinite loop, unloading phase is terminated. BASELINE Unloading Activated ------')
        
            # All demands that should be unloaded at port p
            K_unload = {idx: r for idx, ((o,d),r) in enumerate(K) if d == p}
            for k, r in K_unload.items():
                unloading_nodes = sorted([n for n in range(N) if node_allocations[n] == k])
                # if r != len(unloading_nodes):
                #     print(f"==> Demand {k} at port {p} is not loaded correctly. Demand {k} should be {r} but it is {len(unloading_nodes)}")
                for n in unloading_nodes:
                
                    if node_allocations[n] == -1:
                        # The node may be cleared already for rehandling... we skip if it is the case.
                        continue
                    
                    # The path with the minimum blocking nodes
                    min_blocking_nodes = util2.find_blocking_nodes(n, node_allocations, new_paths)
                    if min_blocking_nodes[0] == 0:
                        # No blocking nodes exist
                        path = min_blocking_nodes[2]
                        route_list.append((path[::-1], k))
                        node_allocations[n] = -1
                        
                    else:
                        # We first unload the blocking nodes
                        blocking_nodes = min_blocking_nodes[1]
                        path = min_blocking_nodes[2]
                        num_blocking = 0
                        for bn in blocking_nodes:
                            # Trim the path after the blocking node
                            unload_route = []
                            for i in path:
                                unload_route.append(i)
                                if bn == i:
                                    break
                            route_list.append((unload_route[::-1], node_allocations[bn]))
                            # Check if the blocking demand is in the unloading list
                            if node_allocations[bn] not in K_unload:
                                # Rehandle the demand
                                rehandling_demands.append(node_allocations[bn])
                                num_blocking += 1
                            # Roll-off the demand
                            node_allocations[bn] = -1
                        route_list.append((path[::-1], k))
                        node_allocations[n] = -1
                        if num_blocking>0: 
                            # print(f"Unloading path for demand {k} at node {n} is blocked by {num_blocking} nodes. Rehandling...")
                            pass
            # print(f'Unloading phase completed with {len(route_list)} routes including {len(rehandling_demands)} rehandling routes!')
            break
    
    return route_list, rehandling_demands, moving_count, rehandle_count

# Unloading heuristic
def unloading_baseline(p, node_allocations, K, G, N, new_paths):

    # All demands that should be unloaded at port p
    K_unload = {idx: r for idx, ((o,d),r) in enumerate(K) if d == p}

    # print(f'Starting unloading phase...')
    # print(f'Demands that are destined to this port: {K_unload}')
    route_list = []

    rehandling_demands = []
    moving_count = 0
    rehandle_count = 0
    for k, r in K_unload.items():
        unloading_nodes = sorted([n for n in range(N) if node_allocations[n] == k])

        # if r != len(unloading_nodes):
        #     print(f"==> Demand {k} at port {p} is not loaded correctly. Demand {k} should be {r} but it is {len(unloading_nodes)}")

        for n in unloading_nodes:

            if node_allocations[n] == -1:
                # The node may be cleared already for rehandling... we skip if it is the case.
                continue

            num_blocking_nodes = []

            # To unload a demand, we consider k-shortest paths to the gate node
            for path in new_paths[n]:
                # For each path, we check if there are blocking nodes
                blocking_nodes = [i for i in path[:-1] if node_allocations[i] != -1]
                num_blocking_nodes.append((len(blocking_nodes), blocking_nodes, path))
                
            # The path with the minimum blocking nodes
            min_blocking_nodes = sorted(num_blocking_nodes, key=lambda x: x[0])[0]

            if min_blocking_nodes[0] == 0:
                # No blocking nodes exist
                path = min_blocking_nodes[2]
                route_list.append((path[::-1], k))
                node_allocations[n] = -1
            else:
                # We first unload the blocking nodes
                blocking_nodes = min_blocking_nodes[1]
                path = min_blocking_nodes[2]
                num_blocking = 0
                for bn in blocking_nodes:
                    
                    # Trim the path after the blocking node
                    # unload_route = []
                    # for i in path:
                    #     unload_route.append(i)
                    #     if bn == i:
                    #         break
                    unload_route = new_paths[bn][0][::-1]
                    route_list.append((unload_route, node_allocations[bn]))

                    # Check if the blocking demand is in the unloading list
                    if node_allocations[bn] not in K_unload:
                        # Rehandle the demand
                        rehandling_demands.append(node_allocations[bn])
                        num_blocking += 1
                        rehandle_count += 1
                        
                    # Roll-off the demand
                    node_allocations[bn] = -1
                    
                route_list.append((path[::-1], k))
                node_allocations[n] = -1
                
                if num_blocking>0:
                    pass
                    # print(f"Unloading path for demand {k} at node {n} is blocked by {num_blocking} nodes. Rehandling...")

    # print(f'Unloading phase completed with {len(route_list)} routes including {len(rehandling_demands)} rehandling routes!')

    return route_list, rehandling_demands, moving_count, rehandle_count