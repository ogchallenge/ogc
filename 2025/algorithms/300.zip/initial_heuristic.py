import time
import util
import networkx as nx
from itertools import islice
import numpy as np
import util2
from unloading_heuristic import unloading_baseline, unloading_heuristic
from loading_heuristic import loading_heuristic

def select_path_candidates(path_candidates, path_info, P, N, E, K, G, prob_info, alg_start_time2):
    incumbent_obj = float('inf')
    solution = {p: [] for p in range(P)}
    final_new_paths = None
    best_moving = float('inf')
    best_rehandle = float('inf')
    single = True
    result = []
    for i in range(len(path_candidates)):

        new_paths = path_candidates[i]
        blocked_nodes_set = util2.blocked_node_set(new_paths)
        node_weight, weight_as_idx = util2.node_weight(new_paths)
        node_allocations = np.ones(N, dtype=int) * -1
        new_paths_set = [set()]+[set(i[0]) for i in new_paths[1:]]
        current_solution = {p: [] for p in range(P)}
        total_moving_count = 0
        total_rehandle_count = 0
        for p in range(P):
            if p>0:
                route_list_unload, rehandling_demands, moving_count, rehandling_count = unloading_baseline(p, node_allocations, K, G, N, new_paths)
                current_solution[p].extend(route_list_unload)
                total_moving_count += moving_count
                total_rehandle_count += rehandling_count
            else:
                rehandling_demands = []
            if p<P-1:
                route_list_load, node_allocations = loading_heuristic(p, P,node_allocations, rehandling_demands, K, G, N, new_paths, i, blocked_nodes_set, node_weight, weight_as_idx, num_paths=len(path_candidates),new_paths_set=new_paths_set, first_trial=True)
                current_solution[p].extend(route_list_load)
        obj_val = util.check_feasibility(prob_info, current_solution)['obj']
        result.append((obj_val, i))
        if obj_val < incumbent_obj:
            incumbent_obj = obj_val
            solution = current_solution
            final_new_paths = new_paths
            best_moving = total_moving_count
            best_rehandle = total_rehandle_count
            idx = i
        #print(f"Time: {time.time() - alg_start_time2:.2f} New incumbent solution acquired at iteration {i}! Obj: {obj_val}, Rehandling {total_rehandle_count} with # {path_info[i]}")
    if best_rehandle > 50:
        large = True
        single = False
    else:
        large = False
        single = True
    result = sorted(result, key=lambda x: x[0])
    return solution, final_new_paths, best_moving, best_rehandle, single, [result[0][1], result[1][1], result[2][1], result[3][1]], large

def initial_heuristic(prob_info, N, E, K, P, F, G, heuristic_timelimit=60):

    # try:
    #print(" ## Initial Heuristic Activated ## ")   
    np.random.seed(300)    

    alg_start_time2 = time.time()
    path_candidates, path_info = util2.generate_path_candidates(N, E)
    solution, final_new_paths, best_moving, best_rehandle, single, idx, large = select_path_candidates(path_candidates, path_info, P, N, E, K, G, prob_info, alg_start_time2)

    if single:
        path_candidates = [path_candidates[idx[0]]]
        path_info = [path_info[0]]
    else:
        path_candidates = [path_candidates[idx[0]], path_candidates[idx[1]], path_candidates[idx[2]], path_candidates[idx[3]]]
        path_info = [path_info[idx[0]], path_info[idx[1]], path_info[idx[2]], path_info[idx[3]]]
    # Create a graph for the problem
    blocked_nodes_set_candidates = []
    node_weight_candidates = []
    weight_as_idx_candidates = []
    new_paths_sets = {}
    for idx, new_paths in enumerate(path_candidates):
        blocked_nodes_set_candidates.append(util2.blocked_node_set(new_paths))
        node_weight, weight_as_idx = util2.node_weight(new_paths)
        node_weight_candidates.append(node_weight)
        weight_as_idx_candidates.append(weight_as_idx)
        new_paths_sets.update({idx: [set()]+[set(i[0]) for i in new_paths[1:]]})
    # Loop over all ports and apply the loading and unloading heuristics to generate the routes
    incumbent_obj = util.check_feasibility(prob_info, solution)['obj']
    cnt=0
    for num_iter in range(1, 301): 


        total_moving_count = 0
        total_rehandle_count = 0
        # Solution dictionary
        current_solution = {p: [] for p in range(P)}
        node_allocations = np.ones(N, dtype=int) * -1

        blocked_nodes_set = blocked_nodes_set_candidates[(num_iter - 1) % len(path_candidates)]
        new_paths = path_candidates[(num_iter - 1) % len(path_candidates)]
        node_weight = node_weight_candidates[(num_iter - 1) % len(path_candidates)]
        weight_as_idx = weight_as_idx_candidates[(num_iter - 1) % len(path_candidates)]
        new_paths_set = new_paths_sets[(num_iter - 1) % len(path_candidates)]
        for p in range(P):
            if p > 0:
                # Unloading heuristic
                route_list_unload, rehandling_demands, moving_count, rehandling_count = unloading_baseline(p, node_allocations, K, G, N, new_paths)


                current_solution[p].extend(route_list_unload)
                total_moving_count += moving_count
                total_rehandle_count += rehandling_count
                # print(f"Port {p} Unloading Completed, moving count: {moving_count}, rehandling count: {rehandling_count}" )
            else:
                rehandling_demands = []
                
            if p < P-1:
                # Loading heuristic
                route_list_load, node_allocations = loading_heuristic(p, P, node_allocations, rehandling_demands, K, G, N, new_paths, num_iter, blocked_nodes_set, node_weight, weight_as_idx, new_paths_set=new_paths_set, num_paths=len(path_candidates))
                # print(f"Node allocations in loading at port {p}: {node_allocations}")
                current_solution[p].extend(route_list_load)
        
        checked_solution = util.check_feasibility(prob_info, current_solution)
        
        if checked_solution['feasible']:
            # print(f"Feasible Solution Acquired!")
            obj_val = checked_solution['obj']
            if obj_val < incumbent_obj:
                print(f"Time: {time.time() - alg_start_time2:.2f} New incumbent solution acquired at iteration {10+num_iter}! Obj: {obj_val}, Rehandling {total_rehandle_count} with # {path_info[(num_iter - 1) % len(path_candidates)]}")
                if incumbent_obj - obj_val > 100:
                    cnt = 0
                incumbent_obj = obj_val
                solution = current_solution
                final_new_paths = new_paths
                best_moving = total_moving_count
                best_rehandle = total_rehandle_count
                
            else:
                cnt += 1
                if cnt > 50 and best_rehandle <= 50:
                    break

        if time.time() - alg_start_time2 > heuristic_timelimit:
            break
        
        if num_iter > 50 and best_rehandle <= 50:
            break
            



    return solution, final_new_paths

