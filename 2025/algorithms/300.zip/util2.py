import util 
from itertools import islice
import networkx as nx
from collections import defaultdict
import numpy as np
import random

random.seed(300)

def sort_demands(K):
    new_K = []
    for idx, k in enumerate(K):
        k.append(idx)
        new_K.append(k)
    return sorted(new_K, key=lambda x: (x[0][0], -x[0][1])), sorted(new_K, key=lambda x: (x[0][1], -x[0][0]))

def back_count(K,p):
    back_count = [0 for i in range(len(K)) if K[i][0][0] == p]
    sorted_demands_by_loading_order, sorted_demands_by_unloading_order = sort_demands(K)
    sdblo = [i for i in sorted_demands_by_loading_order if i[0][0] == p]
    sdbulo = [i for i in sorted_demands_by_unloading_order if i[0][0] == p]
    for idx, (o,d), r, demand_id in enumerate(sdblo):
        for idx2, (o_,d_), r_, demand_id_ in enumerate(sdbulo):
            if o==o_ and d==d_:
                continue
            if o_>o and d>d_:
                back_count[idx] += r_
    return back_count
    
def bfs2(G, node_allocations, node):
    
    current_layer = [node]
    visited = set(current_layer)

    reachable_nodes = []
    reachable_node_distances = []

    dist = 0
    while current_layer:
        next_layer = []
        for node in current_layer:
            for child in G[node]:
                if child not in visited and node_allocations[child] == -1:
                    visited.add(child)
                    next_layer.append(child)
        current_layer = next_layer
        dist += 1
        reachable_nodes.extend(current_layer)
        reachable_node_distances.extend([dist] * len(current_layer))
    
    return reachable_nodes, reachable_node_distances

def node_weight(new_paths):
    node_weight = defaultdict(int)
    for path in new_paths:
        if len(path) == 0:
            continue
        for node in path[0]:
            node_weight[node] += 1
    weight_as_idx = defaultdict(list)
    for key, value in node_weight.items():
        weight_as_idx[value].append(key)

    return node_weight, weight_as_idx

def blocked_node_set(new_paths):
    """
    해당 노드에 의해 막히는 노드들의 set을 반환
    """
    blocked_nodes_set = defaultdict(set)
    for path in new_paths:
        # Skip empty paths
        if not path or len(path) == 0:
            continue
        for i in range(len(path[0])):
            for j in range(i, len(path[0])):
                blocked_nodes_set[path[0][i]].add(path[0][j])
    
    return blocked_nodes_set
def blocking_node_set(new_paths):
    """
    해당 노드를 막는 노드들의 set을 반환
    """
    blocking_nodes_set = defaultdict(set)
    for path in new_paths:
        # Skip empty paths
        if not path or len(path) == 0:
            continue
        for node in path[0]:
            blocking_nodes_set[path[0][-1]].add(node)
    
    return blocking_nodes_set

def find_current_reachable_nodes(N, node_allocations, blocked_nodes_set):
    reachable_nodes = set([i for i in range(1,N)])
    b = set()
    for n in range(1,N):
        if node_allocations[n] != -1 and n not in b:
            b = b.union(blocked_nodes_set[n])

    reachable_nodes -= b
    return list(reachable_nodes)


def find_blocking_nodes(n, node_allocations, new_paths):
    """
    Find the minimum blocking nodes from the given blocking nodes.
    This function takes a list of blocking nodes and their corresponding paths,
    and returns the path with the minimum number of blocking nodes.
    """
    num_blocking_nodes = []
    
    for path in new_paths[n]:
        # For each path, we check if there are blocking nodes
        blocking_nodes = [i for i in path[:-1] if node_allocations[i] != -1]
        num_blocking_nodes.append((len(blocking_nodes), blocking_nodes, path[:-1]))
    
    # The path with the minimum blocking nodes
    min_blocking_nodes = sorted(num_blocking_nodes, key=lambda x: x[0])[0]
    
    return min_blocking_nodes

# def find_blocking_nodes2(n, node_allocations, G):
#     """
#     Find the minimum blocking nodes from the given blocking nodes.
#     This function takes a list of blocking nodes and their corresponding paths,
#     and returns the path with the minimum number of blocking nodes.
#     """
    
#     distances, previous_nodes = util.dijkstra(G, node_allocations)
#     path = util.path_backtracking(previous_nodes, 0, n)
#     blocking_nodes = [i for i in path[:-1] if node_allocations[i] != -1]
#     min_blocking_nodes = (len(blocking_nodes), blocking_nodes, path[:-1])
    
#     return min_blocking_nodes

def find_critical_nodes_unloading(blocking_node, node_allocations, reachable_nodes2, K, N, G, new_paths):
    
    k = node_allocations[blocking_node]
    destination = K[k][0][1]
    # print(f"demand :{k}, destination: {destination}")
    
    ahead_nodes = [i for i in range(1,N) if (node_allocations[i] != -1) and (K[node_allocations[i]][0][1] < destination)]
    empty_nodes = [i for i in range(1,N) if node_allocations[i] == -1]
    
    # print(f"Ahead nodes for blocking node {blocking_node} with demand {k} are {ahead_nodes}.")
    critical_nodes_list = []
    # print(f"Reachable Nodes2: {reachable_nodes2}")
    for rn in reachable_nodes2:
        blocking_count = 0
        
        if len(ahead_nodes) > 1:
            for an in ahead_nodes:

                # The path with the minimum blocking nodes
                min_blocking_nodes = find_blocking_nodes(an, node_allocations, new_paths)
                # print(min_blocking_nodes)

                if rn in min_blocking_nodes[2]:
                    blocking_count += 1

                if blocking_count > 0:
                # If there are more than 2 blocking nodes, we consider the node as critical
                    # print(min_blocking_nodes)
                    critical_nodes_list.append(rn)
                    break
        else:

            # The path with the minimum blocking nodes
            min_blocking_nodes = find_blocking_nodes(ahead_nodes[0], node_allocations, new_paths)
            # print(min_blocking_nodes)
            if rn in min_blocking_nodes[2]:
                # print(min_blocking_nodes)
                critical_nodes_list.append(rn)
                    
    return critical_nodes_list

def find_critical_nodes_loading(k, node_allocations, reachable_nodes, K, N, G, new_paths, blocking_threshold, ahead_nodes, blocked_nodes_set):
    # print(f"Ahead nodes for blocking node {blocking_node} with demand {k} are {ahead_nodes}.")
    critical_nodes_list = []
    # 닿을 수 있는 노드들 중에서, 해당 노드가 점유될 경우 ahead node의 길을 막는 경우를 찾는다.
    for rn in reachable_nodes:
        blocking_count = 0
        for an in ahead_nodes:
            if an in blocked_nodes_set[rn]:
                blocking_count += 1
        if blocking_count > blocking_threshold:
            critical_nodes_list.append(rn)
    return critical_nodes_list

def find_empty_blocking_nodes_loading(node_allocations, reachable_nodes, K, N, G, new_paths, bsn):
    
    empty_nodes = [i for i in range(1,N) if node_allocations[i] == -1]
    # print(f"Ahead nodes for blocking node {blocking_node} with demand {k} are {ahead_nodes}.")
    empty_blocking_nodes = []
    
    for rn in reachable_nodes:
        for en in empty_nodes:
            if en in bsn[rn] and en!=rn:
                empty_blocking_nodes.append(rn)
                break
    return empty_blocking_nodes

def find_loading_node(gajokus, candidate_nodes, node_allocations, G):
    loading_node = -1
    
    # find loading node based on demands with same destinations
    neighbor_nodes = []
    for gajoku in gajokus:
        if loading_node == -1:
            empty_neighbors = [node for node in list(G.neighbors(gajoku)) if node_allocations[node] == -1]
            for empty_neighbor in empty_neighbors:
                if empty_neighbor in neighbor_nodes:
                    continue
                else:
                    if empty_neighbor in candidate_nodes:
                        loading_node = empty_neighbor
                        break   
                    else:
                        neighbor_nodes.append(empty_neighbor)
        else:
            break
        
    # Try second neighbor node if there are no direct neighbor node    
    sec_neighbor_nodes = []
    if loading_node == -1:
        for gajoku in neighbor_nodes:
            if loading_node == -1:
                empty_neighbors = [node for node in list(G.neighbors(gajoku)) if node_allocations[node] == -1]
                for empty_neighbor in empty_neighbors:
                    if (empty_neighbor in sec_neighbor_nodes) or (empty_neighbor in neighbor_nodes):
                        continue
                    else:
                        if empty_neighbor in candidate_nodes:
                            loading_node = empty_neighbor
                            break
                        else:
                            sec_neighbor_nodes.append(empty_neighbor)
            else:
                break
    return loading_node

def shortest_paths_to_new_paths(shortest_paths, N):
    new_paths = []
    determined_nodes = set()
    for n in range(1,N)[::-1]:
        shortest_path = shortest_paths[n][0]
        new_path = shortest_path
        for index, node in enumerate(new_path[::-1]):
            real_index = len(new_path) - index - 1
            if node not in determined_nodes:
                continue
            else:
                for path in new_paths:
                    if node in path:
                        new_path = path[:path.index(node)] + new_path[real_index:]
                        break
                break
        new_paths.append(new_path)
        determined_nodes.update(new_path)
    new_paths = [[]] + [[path] for path in new_paths[::-1]]
    return new_paths

def generate_path_candidates(N, E):
    random.seed(300)
    path_candidates = []
    path_info = [0]
    
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(E)
    
    shortest_distances = np.zeros(N, dtype=int)
    shortest_paths = [[]]
    max_num_paths = 10

    for i in range(1, N):

        sps_i = list(islice(nx.shortest_simple_paths(G, 0, i), max_num_paths))
        shortest_distances[i] = len(sps_i[0]) - 1
        paths = []
        for sp in sps_i:
            if len(sp) - 1 == shortest_distances[i]:
                paths.append(sp)
        shortest_paths.append(paths)

    shortest_paths_1 = [[]] + [[paths[0]] for paths in shortest_paths[1:]]
    path_candidates.append(shortest_paths_to_new_paths(shortest_paths_1, N))

    for i in range(2,8):
        shortest_paths_r = [[]] + [[random.choice(paths)] for paths in shortest_paths[1:]]
        new_paths = shortest_paths_to_new_paths(shortest_paths_r, N)
        if new_paths not in path_candidates:
            path_candidates.append(new_paths)
            path_info.append(i)
        
    new_paths = [[]] + [[nx.single_source_shortest_path(G, 0)[n]] for n in range(1,N)]
    if new_paths not in path_candidates:
        path_candidates.append(new_paths)
        path_info.append(1)
        
    E = set([(u,v) for (u,v) in E])
    # Create a graph for the problem
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(E)

    shortest_paths = [[]] 
    for i in range(1, N):
        sp_i = list(islice(nx.shortest_simple_paths(G, 0, i), 1))
        shortest_paths.append(sp_i)

    new_paths = shortest_paths_to_new_paths(shortest_paths, N)
    if new_paths not in path_candidates:
        path_candidates.append(new_paths)
        path_info.append(8)
        
    new_paths = [[]] + [[nx.single_source_shortest_path(G, 0)[n]] for n in range(1,N)]
    if new_paths not in path_candidates:
        path_candidates.append(new_paths)
        path_info.append(9)
        
    return path_candidates, path_info

# case1
def find_loading_node_1(gajokus, candidate_nodes, node_allocations, G, new_paths_set):
    loading_node = -1
    
    # find loading node based on demands with same destinations
    neighbor_nodes = []
    max_distance = float('inf')
    for candidate_node in candidate_nodes:
        total_distance = 0
        for gajoku in gajokus:
            total_distance += len(new_paths_set[gajoku].union(new_paths_set[candidate_node])-(new_paths_set[gajoku].intersection(new_paths_set[candidate_node])))
        if total_distance < max_distance:
            max_distance = total_distance
            loading_node = candidate_node
    return loading_node


def find_loading_node_2(gajokus, candidate_nodes, node_allocations, G, new_paths_set):
    loading_node = -1
    neighbor_nodes = []
    max_distance = float('inf')
    for candidate_node in candidate_nodes:
        total_distance = 0
        for gajoku in gajokus[1:]:
            total_distance += len(new_paths_set[gajoku].union(new_paths_set[candidate_node])-(new_paths_set[gajoku].intersection(new_paths_set[candidate_node])))
        if total_distance < max_distance:
            max_distance = total_distance
            loading_node = candidate_node
    return loading_node


def find_initial_loading_node(candidate_nodes, node_allocations, G, new_paths, K, origin, destination, p, blocking_threshold):
    loading_node = -1
    paths_to_candidate_nodes = []
    for candidate_node in candidate_nodes:
        paths_to_candidate_nodes.append(new_paths[candidate_node][0])
    paths_to_candidate_nodes.sort(key=lambda x: len(x))

    loading_ratio = 0
    back_count = 0
    front_count = 0

    for k in range(len(K)):
        if K[k][0][1]<=p:
            continue
        elif K[k][0][1]>destination and K[k][0][0]<=destination:
            back_count += K[k][1]
        elif K[k][0][1]<destination and K[k][0][0]>=destination:
            front_count += K[k][1]
    if front_count + back_count == 0 and blocking_threshold == 0:
        return candidate_nodes[0]
    elif front_count + back_count == 0 and blocking_threshold > 0:
        return np.random.choice(candidate_nodes)
    else:
        loading_ratio = front_count / (back_count + front_count)
        return candidate_nodes[int(loading_ratio * len(candidate_nodes))]