import util
import util2
import networkx as nx
import numpy as np

# Loading heuristic
def loading_heuristic(p,P, node_allocations, rehandling_demands, K, G, N, new_paths, num_iter, blocked_nodes_set, node_weight, weight_as_idx, num_paths, new_paths_set, first_trial=False, large=False):
    # print(f'Starting loading phase...')
    # All demands that should be loaded at port p
    K_load = {idx: r for idx, ((o,d),r) in enumerate(K) if o == p}
    
    # print(f'Demands that are originated from this port: {K_load}')
    if len(rehandling_demands) > 0:
        # print(f'Rehandled demands from unloading phase: {rehandling_demands}')
        # Merge the rehandling demands with the loading demands
        for k in rehandling_demands:
            if k in K_load:
                K_load[k] += 1
            else:
                K_load[k] = 1
                
    route_list = []
    last_rehandling_demands = []
    
    # Total number of demands to load (including rehandling demands)
    total_loading_demands = sum([r for k,r in K_load.items()])
    
    # Get reachable nodes from the gate
    reachable_nodes = util2.find_current_reachable_nodes(N, node_allocations, blocked_nodes_set)
    reachable_nodes.sort()
    # Get not occupied nodes
    available_nodes = util.get_available_nodes(node_allocations)
    
    if len(available_nodes) < total_loading_demands:
        print(f"Not enough available nodes ({len(available_nodes)} are available) to load {total_loading_demands} at port {p}.")
        
        raise Exception("Not enough available nodes to load demand!!! This must not happen!!!")
    if len(reachable_nodes) < total_loading_demands:
        
        print(f"Not enough reachable nodes ({len(reachable_nodes)} are reachable) to load {total_loading_demands} demands at port {p}. Rehandling...")

        available_but_not_reachable = [n for n in available_nodes if n not in reachable_nodes]
        while len(reachable_nodes) < total_loading_demands:
            
            if len(available_but_not_reachable) == 0:
                print("Not enough available_but_not_reachable nodes to rehandle. This must not happen!!!")
                raise Exception("Not enough available_but_not_reachable nodes to rehandle. This must not happen!!!")
            
            # Pick a node from the available but not reachable nodes
            n = available_but_not_reachable.pop(0)
            
            # Get the shortest path to the node from the gate
            
            distances, previous_nodes = util.dijkstra(G, node_allocations=None)
            path = util.path_backtracking(previous_nodes, 0, n)
            
            # Roll-off blocking demands on the path by order of distance from the gate. (and push to last_rehandling_demands list for the later reloading)
            for idx, i in enumerate(path[:-1]):
                if node_allocations[i] != -1:
                    # Node i is occupied by demand node_allocations[i]
                    last_rehandling_demands.append(node_allocations[i])
                    node_allocations[i] = -1
                    # Rehandling route (from the blocking node to the gate)
                    route_list.append((path[:idx+1][::-1], node_allocations[i]))
                    # Increasing the number demands to load
                    total_loading_demands += 1
            
            # Check if the number of reachable nodes is enough to load the demand
            reachable_nodes = util2.find_current_reachable_nodes(N, node_allocations, blocked_nodes_set)
        
        print(f'After rehandling, we have {len(reachable_nodes)} reachable nodes now! (but have to rehandle {len(last_rehandling_demands)} demands)')
    
    # Merge the rehandling demands with the loading demands
    for k in last_rehandling_demands:
        if k in K_load:
            K_load[k] += 1
        else:
            K_load[k] = 1
    # print(f'total_loading_demands = {total_loading_demands}')
    

    sorted_K_load = sorted(K_load.items(), key=lambda x: K[x[0]][0][1], reverse=True)
    flattened_K_load = []
    for k, r in sorted_K_load:
        for _ in range(r):
            flattened_K_load.append(k)
    # Find loading demands that should be unloaded at nextport        
    if total_loading_demands > 0:
        next_port = 0
        # Find the next port to load the demands
        for key in K_load.keys():
            if K[key][0][1] == p+1:
                # number of demands to unload at the next port
                next_port += K_load[key]
        
        # Divide next_port_demand and K_load
        next_port_demands = flattened_K_load[-next_port:] if next_port > 0 else []
        flattened_K_load = flattened_K_load[:-next_port] if next_port > 0 else flattened_K_load
        
        for k in flattened_K_load:
            # if k not in K_load:
            #     print(f"Demand {k} is not in the loading demands. This must not happen!!!")
            #     raise Exception("Demand not in the loading demands!!! This must not happen!!!")
            
            reachable_nodes = util2.find_current_reachable_nodes(N, node_allocations, blocked_nodes_set)
            reachable_nodes.sort()
            if len(reachable_nodes) == 0:
                print(f"No reachable nodes to load demand {k} at port {p}. This must not happen!!!")
                print(f"Node allocations: {node_allocations}")
                raise Exception("No reachable nodes to load demand!!! This must not happen!!!")
            
            # print(f"Reachable nodes for demand {k}: {reachable_nodes}.")
            empty_blocking_nodes = util2.find_empty_blocking_nodes_loading(node_allocations, reachable_nodes, K, N, G, new_paths, blocked_nodes_set)
            # print(f"Empty blocking nodes for demand {k}: {empty_blocking_nodes}.")
            gajokus = [node for node in range(1,N) if K[node_allocations[node]][0][1] == K[k][0][1] and node_allocations[node] != -1]
            
            blocking_threshold = 0
            destination = K[k][0][1]
            ahead_nodes = [i for i in range(1, N) if node_allocations[i] != -1 and K[node_allocations[i]][0][1] < destination]
            while True:
                # print(f"## Blocking threshold for demand {k} is {blocking_threshold} ##")
                critical_nodes = util2.find_critical_nodes_loading(k, node_allocations, reachable_nodes, K, N, G, new_paths, blocking_threshold, ahead_nodes, blocked_nodes_set)
                # print(f"Critical nodes for demand {k} are {critical_nodes}.")
                tmp_nodes = set(critical_nodes + empty_blocking_nodes + [0])
                candidate_nodes = [i for i in reachable_nodes if i not in tmp_nodes]
                # print(f"Candidate nodes for demand {k} are {candidate_nodes}.")
                # Find all nodes with same destination
                
                if len(candidate_nodes) == 0:
                    blocking_threshold += 1
                    
                else:
                    # Load the node to the farest candindate node
                    # loading_node = candidate_nodes[-1]
                    
                    # if there are no demands with same destination, use loading_ratio to find first location
                    if len(gajokus) == 0:
                        if first_trial:
                            loading_node = util2.find_initial_loading_node(candidate_nodes, node_allocations, G, new_paths, K, K[k][0][0], K[k][0][1], p, blocking_threshold)
                        else:
                            loading_node = int(np.random.choice(candidate_nodes))

                    elif blocking_threshold > len(reachable_nodes):
                        loading_node = candidate_nodes[-1] # Load to the farest reachable node
                        # print(f"Farest Reachable Node is selected for safety")

                    else:
                        # # Load the demand near the node with same destination if that node is in candidate nodes
                        loading_node = util2.find_loading_node_1(gajokus, candidate_nodes, node_allocations, G, new_paths_set)
                  
                        # max_neighbor_count = 0
                        # for cn in candidate_nodes:
                        #     neighbor_count = 0
                        #     neighbors = list(G.neighbors(cn))
                        #     # print(f"### Candidate Node {cn}, Neighbors {neighbors} ###")
                        #     for neighbor in neighbors:
                        #         if node_allocations[neighbor] != -1 and K[node_allocations[neighbor]][0][1] == K[k][0][1]:
                        #             # print(f"{neighbor} node is neighbor")
                        #             neighbor_count += 1
                        #     if neighbor_count >= max_neighbor_count:
                        #         max_neighbor_count = neighbor_count
                        #         loading_node = cn
                           
                    # distances, previous_nodes = util.dijkstra(G, node_allocations)
                    # path = util.path_backtracking(previous_nodes, 0, loading_node)
                    route_list.append((new_paths[loading_node][0], k))
                    node_allocations[loading_node] = k
                    # print(f"Loaded demand {k} at node {loading_node} with blocking {blocking_threshold} nodes")
                    break
                
        if next_port > 0:        
            reachable_nodes = util2.find_current_reachable_nodes(N, node_allocations, blocked_nodes_set)
            reachable_nodes.sort()
            for n, k in zip(reachable_nodes[:next_port][::-1], next_port_demands):
                
                # distances, previous_nodes = util.dijkstra(G, node_allocations)
                # path = util.path_backtracking(previous_nodes, 0, n)
                route_list.append((new_paths[n][0], k))
                node_allocations[n] = k
                # print(f"Loaded demand {k} at node {n} with path {path}.")
                
    # print(f'Loading phase completed with {len(route_list)} routes including {len(last_rehandling_demands)} rehandling routes!')
    return route_list, node_allocations