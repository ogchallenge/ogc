### 올라간 파일들은 수리식에 대한 pdf 파일인 Mathematicla_Formulation_Final.pdf를 제외하곤 모두 소스코드이며, OGC2025 환경에서 구동되는 데 문제 없습니다.

## Alogrithm Description
- 제출된 알고리즘은 "shortest_paths"라는 각 노드에서 출입구까지의 최단거리들을 활용하여 배 내부의 그래프를 트리 형식으로 변형하여 RORO 문제를 해결하고자 한다. 이 때 변환된 구조가 트리 구조이기 때문에 각 노드에서 출발한 차들은 항상 단 하나의 길로만 이동할 수 있다. 즉 노드와 노드에서 출구까지의 경로도 일대일대응이고, 노드와 입구에서 노드까지의 경로도 일대일대응이며, 입구에서 노드까지의 경로와 노드에서 출구까지의 경로는 array의 reverse된 형태이다(같은 셋의 노드로 구성되어있음).
- 해당 알고리즘은 대회에서 제공된 baseline 알고리즘을 발전시킨 형태로, 각각의 포트에서의 unloading phase와 loading phase를 구분한다.
- unloading phase에서는 현재 포트에서 내려야하는 수요들을 하역하는 작업을 진행한다. 이떄, 하역해야하는 수요들을 막고있는 수요들을 함께 내려주게 된다. 이렇게 해당 포트가 목적지가 아닌데도, 길을 막고 있어서 하역하는 경우를 rehandling이라고 명명한다.
- loading phase에서는 rehandling으로 내린 차량들과 현재 포트에서 출발하는 차량들을 선적하는 과정을 진행한다. 이 때 만약 
- myalogrithm.py 내부의 algorithm 함수의 큰 흐름은 다음과 같다:
    1. initial_heuristic.py에서 수리 모형에 들어갈 초기 해를 찾는다.
        - select_path_candidates
            1. select_path_candidates 함수에서 문제에서 제시된 그래프를 다양한 트리형식으로 구현하고 정해진 rule-based heuristic으로 각각의 구현된 트리 내에서 해를 찾는다.
            2. 각 트리 중에서 가장 낮은 문제의 목적함수 값을 갖는 트리의 솔루션을 기준으로 rehandling의 수가 50보다 큰 경우, 해당 인스턴스는 large instance로 분류하고, 만약 그 수가 50이하인 경우 해당 인스턴스는 small instance로 분류된다.
            3. large instance로 분류된 경우 commercial solver에서 풀기 어렵기 때문에, 휴리스틱에서 해의 다양성을 위해 가장 초기해의 목적함수 값이 좋았던 4개의 트리를 활용gksek. small instane의 경우에는 commercial solver에서 충분히 잘 풀리기 때문에, 가장 기본적인 형태의 0번 트리를 활용한다. 
        - initial_heuristic
            1. initial_heuristic은 randomized된 알고리즘으로, 해를 개선시켜나가는 휴리스틱이다. 앞서 소개되었던 unloading phase와 loading phase를 매 포트마다 수행하고 해당 solution의 objective value가 개선되었는지 총 300번 확인한다.
            2. 개선이 되었다면 cnt를 초기화하고 개선이 되지 않았다면 cnt를 1 늘린다.
            3. cnt가 50을 넘기고 이때의 가정 좋은 솔루션(incumbent_solution)의 rehandling count가 50이하라면 loop를 종료한다.
            4. 또는 시간이 time_limit의 절반이상이 지났다면 loop를 종료한다.
    2. myalgorithm.py에서 남은 시간 동안 gurobipy를 이용하여 수학적 최적화를 진행한다.
        - 우선 휴리스틱의 solution을 수리식에 넣을 수 있는 형태로 변환해준다.
        - 이후 수리식을 gurobipy에 맞게 변환하고, 남은 시간 동안 해당 수리 모형을 gurobipy로 최적화를 진행한다.
        - 수리식은 첨부된 파일의 Mathematical_Formulation_Final.pdf에 설명되어있다.
    3. time_limit에 도달하기 전 최적화 과정을 멈추고, 구해진 해를 다시 문제에 맞는 형식으로 변환하여 반환한다.

### Unoading Phase: 하역 단계
1. unloading_heuristic.py
    - 해당 파일에서 unloading_heuristic 함수는 deprecate된 버전의 함수이며, 실제로 활용되는 함수는 unloading_baseline이다.
    - unloading_baseline(첫 번째 항구에서는 실행시키지 않음)
        1. 우선 현재 포트(p)에서 내려야하는 수요들이 현재 점유하고 있는 노드들을 node_allocation에서 찾고, 출구에서 가까운 노드 순으로 정렬한다.
        2. 정렬된 노드들 기준으로 for loop을 돌고, 현재 iteration의 노드를 막고 있는 수요들을 rehandling_demands array에 추가한다.
        3. rehandling_demands 먼저 내린 후에 실제로 내려야하는 수요를 내리게 한다

### Loading Phase: 선적 단계
1. loading_heuristic.py
    - loading_heuristic 함수
        1. 현재 포트(p)에서 태워야할 차량들을 확인한다(출발지가 p이거나 하역 단계에서 rehandling당한 차량)
        2. 현재 트리의 구조와 node_allocation하에서 도달할 수 있는 노드들(reachable_nodes)을 구한다(util2.find_current_reachable_nodes 함수)
        3. 도착지가 먼 차량들 부터 실을 수 있게 정렬한다.
            3-1. 바로 다음 포트에서 내릴 차량들은 입구에서 가장 가까운 곳에 배치하게 미리 빼둔다.
        4. 트리 구조 상에서 해당 노드를 점거하면 입구에서 도달할 수 없는 빈 노드가 생기면 empty_blocking_nodes로 정의하고, 현재 태워야할 차량보다 일찍 내리는 차량의 길을 막는 경우에 해당하면 critical_nodes로 정의하며, reachable_nodes 중에서 critical_nodes와 empty_blocking_nodes에 해당하지 않는 경우에 candidate_nodes로 정의한다.
            4-1. 만약 candidate_nodes의 수가 0인 경우, blocking_threshold를 1씩 늘려 critical_nodes를 자신보다 일찍 내리는 차량을 blocking_threshold의 수만큼 막을 수 있는 노드들로 재정의하여 기준을 완화한다.
        5. 현재 태워야할 차량과 목적지가 같은 차량이 이미 트리 내부에 있다면 해당 차량들과 거리의 합이 가장 가까운 candidate_node를 선정하고, 현재 태워야할 차량과 목적지가 같은 차량이 존재하지 않는다면 앞선 tree를 evaluation의 단계라면 rule_based인 util2.find_initial_loading_node에 따라 지정해주고, evaluation이 끝나고 loop단계라면 candidate_nodes 중 random하게 하나의 노드를 선택한다.