import time
import util
import networkx as nx
from itertools import islice
import numpy as np
import gurobipy as gp
from gurobipy import GRB
from initial_heuristic import initial_heuristic
import util2

def algorithm(prob_info, timelimit=60):
    """
    This is a template for the custom algorithm.
    The algorithm should return a solution that is a list of (route, k) pairs.
    Each route is a list of node indices, and k is the index of the demand that is moved by the route.
    You CANNOT change or remove this function signature.
    But it is fine to define extra functions or mudules that are used in this function.
    """

    #------------- begin of custom algorithm code --------------#
    
    start_time = time.time()
    
    # Get parameters from the prob_info dictionary
    N = prob_info['N']
    E = prob_info['E']
    K = prob_info['K']
    P = prob_info['P']
    F = prob_info['F']
    LB = prob_info['LB']
    
    # Create a graph for the problem
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(E)
    
    shortest_distances = np.zeros(N, dtype=int)
    for i in range(1, N):

        sp_i = list(islice(nx.shortest_simple_paths(G, 0, i), 1))
        shortest_distances[i] = len(sp_i[0]) - 1
        
    # Create Cumulative demand dictionary
    C = {p2: {p1: 0 for p1 in range(P)} for p2 in range(P)}
    for ([o, d], k) in K:
        for i in range(d-o):
            C[o + i][d] += k
    
    heuristic_timelimit = timelimit//2
    
    ### Get initial solution by initial_heuristic ###
    heuristic_solution, final_new_paths = initial_heuristic(prob_info, N, E, K, P, F, G, heuristic_timelimit)
    heuristic_result = util.check_feasibility(prob_info, heuristic_solution)
    if heuristic_result["feasible"] == True:
        obj = heuristic_result['obj']
        print(f"Heuristic built in {time.time() - start_time:.2f} seconds., result: {obj}")

    solution = heuristic_solution
    
    # # Convert heuristic solution to initial solver solution
    x_start = {}; y_start = {}; u_start = {}; v_start = {}

    for p in range(P):
        for n in range(1, N):
            for d in range(P):
                u_start[p, n, d] = 0
                v_start[p, n, d] = 0
                x_start[p, n, d] = 0
                y_start[p, n, d] = 0
                
    for p, ops in heuristic_solution.items():
        
        # Initialize u[p, n, d] based on x[p-1, n, d]
        for n in range(1, N):
            for d in range(P):
                if p > 0:
                    u_start[p,n,d] = x_start[p-1,n,d]
        
        action = 0
        while True:
            if len(ops) <= action:
                break
            
            route, k = ops[action]
            d = K[k][0][1]  # Get the destination from the key k
            start_node, end_node = route[0], route[-1]

            # --- 경로가 [n → … → 0]: 언로딩 or 재적재 언로딩(ru) ---
            if end_node == 0 and start_node != 0:
                n = start_node
                v_start[p, n, d] = 1   
                u_start[p, n, d] = 0
                action += 1
            else:
                break
            
        # Initialize x[p, n, d] based on u[p, n, d]
        for n in range(1, N):
            for d in range(P):
                if p < P - 1:
                    x_start[p,n,d] = u_start[p,n,d]
                    
        while True:
            if len(ops) <= action:
                break
            
            route, k = ops[action]
            d = K[k][0][1]  # Get the destination from the key k
            start_node, end_node = route[0], route[-1]
            
            # --- 경로가 [0 → … → n]: 적재 or 재적재 (rl) ---
            if start_node == 0 and end_node != 0:
                n = end_node
                y_start[p, n, d] = 1
                x_start[p, n, d] = 1
                action += 1
    
    # Mathematical Model
    model = gp.Model("Roll-On Roll-Off")

    # Define variables

    # x[p, n, d]: Binary Variable, 1 if node n is Occupied with a vehicle with destination d at port p loading phase
    x = model.addVars(P, range(1,N), P, vtype=GRB.BINARY, name="x")
    # u[p, n, d]: Binary Variable, 1 if node n is Occupied with a vehicle with destination d at port p unloading phase
    u = model.addVars(P, range(1,N), P, vtype=GRB.BINARY, name="u")
    # y[p, n, d]: Binary Variable, 1 if vehicle to destination d is loaded at port p to node n
    y = model.addVars(P, range(1,N), P, vtype=GRB.BINARY, name="y")
    # v[p, n, d]: Binary Variable, 1 if vehicle to destination d is unloaded at port p from node n
    v = model.addVars(P, range(1,N), P, vtype=GRB.BINARY, name="v")

    # Define Objective function
    # Minimize the total fixed cost of loading and unloading vehicles at ports
    model.setObjective(F * gp.quicksum(y[p, n, d] for n in range(1, N) for p in range(P - 1) for d in range(P))
                    + F * gp.quicksum(v[p, n, d] for n in range(1, N) for p in range(1, P) for d in range(P))
                    + gp.quicksum(shortest_distances[n] * y[p, n, d] for n in range(1, N) for p in range(P - 1) for d in range(P))
                    + gp.quicksum(shortest_distances[n] * v[p, n, d] for n in range(1, N) for p in range(1, P) for d in range(P))
                    - LB, GRB.MINIMIZE)

    # Define Constraints
    # (1): Each node can only be occupied by one vehicle at a time
    model.addConstrs((gp.quicksum(x[p, n, d] for d in range(P)) <= 1
                    for p in range(P) for n in range(1, N)), name="Node_Occupancy_Loading")
    model.addConstrs((gp.quicksum(u[p, n, d] for d in range(P)) <= 1
                    for p in range(P) for n in range(1, N)), name="Node_Occupancy_Unloading")

    # (2): For each port, every vehicle must be loaded and unloaded
    model.addConstrs((gp.quicksum(x[p, n, d] for n in range(1, N)) == C[p][d]
                    for p in range(P) for d in range(P)), name="Demand_Satisfaction_Loading")

    for p in range(P):
        for d in range(P):
            if p >= d:
                model.addConstr((gp.quicksum(u[p, n, d] for n in range(1, N)) == 0), name=f"Demand_Satisfaction_Unloading{p,d}")
                
    # (3) Initial & Terminal & Logic conditions
    model.addConstrs((u[0, n, d] == 0 for n in range(1, N) for d in range(P)), name="Initial_Condition_Unloading")
    model.addConstrs((x[P-1, n, d] == 0 for n in range(1, N) for d in range(P)), name="Terminal_Condition_loading")
        
    # (4) Vehicle Conservation constraints (Do Not allow Rehanlding or Moving)
    model.addConstrs((u[p, n, d] + y[p, n, d] == x[p, n, d] for p in range(P - 1) for n in range(1, N) for d in range(P))
                    , name = "Vehicle_Conservation_Loading")
    model.addConstrs((x[p - 1, n, d] - v[p, n, d] == u[p, n, d] for p in range(1, P) for n in range(1, N) for d in range(P))
                    , name = "Vehicle_Conservation_Unloading")

    # (5) Shortest path constraints
    model.addConstrs((shortest_distances[n] * (1 - gp.quicksum(y[p,n,d] for d in range(P))) 
                        >= gp.quicksum(u[p, sn, d] for sn in final_new_paths[n][0][1:-1] for d in range(P)) 
                        for n in range(1, N) for p in range(P - 1)), name=f"Shortest_Path_Loading")

    model.addConstrs((shortest_distances[n] * (1 - gp.quicksum(v[p,n,d] for d in range(P))) 
                            >= gp.quicksum(u[p, sn, d] for sn in final_new_paths[n][0][1:-1] for d in range(P))
                            for n in range(1, N) for p in range(1, P)), name=f"Shortest_Path_Unloading")

    model.update()
                
    for p in range(P):
        for n in range(1, N):
            for d in range(P):
                u[p, n, d].Start = u_start[p, n, d]
                v[p, n, d].Start = v_start[p, n, d]
                x[p, n, d].Start = x_start[p, n, d]
                y[p, n, d].Start = y_start[p, n, d]

    model.update()
    
    # Optimization Model Parameters
    model.setParam('Threads', 0)  # Use all available cores (default)
    model.setParam("OutputFlag", 0)  # Set to 1 to enable output, 0 to suppress
    model.setParam("timelimit", timelimit - (time.time() - start_time) - 2)  # Set a time limit for the optimization
    model.setParam('ImproveStartTime', (timelimit - (time.time() - start_time) - 2)/2)   # After 1 min, focus on improvement only
    model.setParam('Seed', 300)
    model.optimize()

    demand_id = {}
    for i, k in enumerate(K):
        demand_id[tuple(k[0])] = i

    node_allocations = list(np.full(N, -1, dtype=int))
    solution = {}
    total_rehandle_count = 0
    
    for p in range(P):
        
        rehandle_list = []
        port_solution = []
        
        for n in range(1, N):
            for d in range(P):
                if v[p, n, d].X > 0.5:
                    k = node_allocations[n]
                    node_allocations[n] = -1
                    path = final_new_paths[n][0][::-1]
                    port_solution.append([path, k])
                    if d != p:
                        rehandle_list.append(k)
                        total_rehandle_count += 1
                        
        y_count = np.zeros(P)
        for n in range(1, N)[::-1]:# Reverse order
            for d in range(P):
                if y[p, n, d].X > 0.5:
                    if (demand_id.get((p, d)) is not None) and (y_count[d] < K[demand_id[(p, d)]][1]):
                        k = demand_id[(p, d)]
                        node_allocations[n] = k
                        path = final_new_paths[n][0]
                        port_solution.append([path, k])
                        y_count[d] += 1
                    
                    else:
                        for k in rehandle_list:
                            if K[k][0][1] == d:
                                del rehandle_list[rehandle_list.index(k)]
                                node_allocations[n] = k
                                path = final_new_paths[n][0]
                                port_solution.append([path, k])
                                break

        solution[p] = port_solution
    
    print(f"Final Solution: Obj: {model.ObjVal}, Total Rehandle Count: {total_rehandle_count}")
    #------------- end of custom algorithm code --------------
    
    return solution

if __name__ == "__main__":
    # You can run this file to test your algorithm from terminal.

    import json
    import os
    import sys
    import jsbeautifier

    def numpy_to_python(obj):
        if isinstance(obj, np.int64) or isinstance(obj, np.int32):
            return int(obj)  
        if isinstance(obj, np.float64) or isinstance(obj, np.float32):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        
        raise TypeError(f"Type {type(obj)} not serializable")
    
    # Arguments list should be problem_name, problem_file, timelimit (in seconds)
    if len(sys.argv) == 4:
        prob_name = sys.argv[1]
        prob_file = sys.argv[2]
        timelimit = int(sys.argv[3])

        with open(prob_file, 'r') as f:
            prob_info = json.load(f)

        exception = None
        solution = None

        try:

            alg_start_time = time.time()

            # Run algorithm!
            solution = algorithm(prob_info, timelimit)

            alg_end_time = time.time()
            print(f"Algorithm finished in {alg_end_time - alg_start_time:.2f} seconds.")

            checked_solution = util.check_feasibility(prob_info, solution)

            checked_solution['time'] = alg_end_time - alg_start_time
            checked_solution['timelimit_exception'] = (alg_end_time - alg_start_time) > timelimit + 2 # allowing additional 2 second!
            checked_solution['exception'] = exception

            checked_solution['prob_name'] = prob_name
            checked_solution['prob_file'] = prob_file


            with open('results.json', 'w') as f:
                opts = jsbeautifier.default_options()
                opts.indent_size = 2
                f.write(jsbeautifier.beautify(json.dumps(checked_solution, default=numpy_to_python), opts))
                print(f'Results are saved as file results.json')
                
            sys.exit(0)

        except Exception as e:
            print(f"Exception: {repr(e)}")
            sys.exit(1)

    else:
        print("Usage: python myalgorithm.py <problem_name> <problem_file> <timelimit_in_seconds>")
        sys.exit(2)

