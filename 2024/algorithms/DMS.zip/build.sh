rm -r build

python setup.py build_ext --inplace

#clear
