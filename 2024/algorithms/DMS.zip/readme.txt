compile 하는법

0. linux, ogc2024 환경에서 진행

1. pybind 모듈이 있어야 함. 
pip install pybind11

2. bash build.sh 하면 끝


-----------------------------
** g++ 설치된 linux(bits/stdc++.h , openmp 등 헤더들도 있어야함.)
** windows나 mac에서 할거면 MinGW g++ 이나 homebrew로 g++ 잘깔아서 폴더 위치 맞게 setup.py 수정해야 할것.