/* utility codes */
#ifndef __LIB_UTILS_HPP__
#define __LIB_UTILS_HPP__

#include <algorithm>
#include <chrono>
#include <string>
#include <vector>

using namespace std;

class TaskAbortException : public std::exception {
 private:
  std::string message;

 public:
  explicit TaskAbortException(const std::string& msg) : message(msg) {}
  virtual const char* what() const noexcept override { return message.c_str(); }
};

double max(double a, double b);
int max(int a, int b);

int randint(int n);

double randreal();

vector<int> Range(int n);
vector<int> Range(int s, int t);
vector<int> RandomRange(int n);
vector<int> RandomRange(int s, int t);

template <class T>
vector<int> Argsort(const std::vector<T>& values, bool reverse = false) {
  std::vector<int> indices(values.size());
  for (int i = 0; i < indices.size(); ++i) {
    indices[i] = i;
  }

  if (reverse) {
    std::sort(indices.begin(), indices.end(),
              [&values](int a, int b) { return values[a] > values[b]; });
  } else {
    std::sort(indices.begin(), indices.end(),
              [&values](int a, int b) { return values[a] < values[b]; });
  }

  return indices;
}

double Elapsed(chrono::high_resolution_clock::time_point start_time);

size_t HashIntegers(vector<int> arr);
size_t HashIntegerSet(vector<int> arr);
size_t HashOrderSet(int rider_index, vector<int> orders);

#endif  // __LIB_UTILS_HPP__