/*
libheuristic: 다양한 경로(번들)들을 휴리스틱으로 찾아내는 코드.

Implementation References:

[1] Dumas, Yvan, Jacques Desrosiers, and Francois Soumis. "The pickup and
delivery problem with time windows." European journal of operational
research 54.1 (1991): 7-22.

[2] Ropke, Stefan, and David Pisinger. "An adaptive large neighborhood search
heuristic for the pickup and delivery problem with time windows." Transportation
science 40.4 (2006): 455-472.

*/

#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")

#include <omp.h>
#include <stdio.h>

#include <algorithm>
#include <chrono>
#include <ext/pb_ds/assoc_container.hpp>  // to use gp_hash_table
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "libutils.hpp"

#define NUM_CPU 4
#define NOW std::chrono::high_resolution_clock::now
#define MAX_ORDERS 3000
#define MAX_NODES (2 * MAX_ORDERS + 2)

using namespace std;
using namespace __gnu_pbds;  // to use gp_hash_table

static int N_ORDERS;
static int N_NODES;
static int CAPA[3];
static int N_AVLB[3];
static int SERVICE_TIME[3];
static int FIXED_COST[3];
static int TRAVEL_TIMES[3][MAX_NODES][MAX_NODES];
static double COSTS[3][MAX_NODES][MAX_NODES];
static int EARLIEST_TW[3][MAX_NODES];
static int LATEST_TW[3][MAX_NODES];
static int ADJ[3][MAX_NODES][MAX_NODES];
static bool IS_BUNDLEABLE[3][MAX_ORDERS][MAX_ORDERS];
static int DEMANDS[MAX_NODES];
static double MAX_NOISE;

static double SIZE_SUM = 0;
static double SIZE_BIKE = 0;
static double SIZE_WALK = 0;
static double SIZE_CAR = 0;

static bool CUT_LEN2 = false;

bool IsEveryBundleable(int r, int i, int j) {
  return IS_BUNDLEABLE[r][i - 1][j - 1];
}

bool IsEveryBundleable(int r, int i, vector<int>& orders) {
  for (int j : orders) {
    if (!IsEveryBundleable(r, i, j)) return false;
  }
  return true;
}

struct TimeData {
  chrono::high_resolution_clock::time_point start_time;
  double remain_time;

  TimeData(chrono::high_resolution_clock::time_point st, double rt)
      : start_time(st), remain_time(rt) {}

  bool isTimeout() { return elapsed() > remain_time; }
  double elapsed() { return Elapsed(start_time); }
};

// Constrained Shortest Path Problem (CSPP)을 풀기 위한 label 구조체
// 구체적인 로직, 구현, 변수명에 관한 내용은 [1]을 참고하였다.
struct Label {
  vector<int> S;
  int T;
  double Z;

  Label() : S(vector<int>(0)), T(0), Z(0) {}
  Label(vector<int> s, double t, double z) : S(s), T(t), Z(z) {}

  Label extend(int next, double t, double z) {
    vector<int> new_S = S;
    new_S.push_back(next);
    Label new_label = {new_S, t, z};
    return new_label;
  }

  bool contains(int x, bool reverse = false) {
    if (S.size() == 0) return false;

    bool b = false;
    if (reverse) {
      for (int i = S.size() - 1; i >= 0; i--) {
        if (S[i] == x) return true;
      }
    } else {
      for (int i : S) {
        if (i == x) return true;
      }
    }
    return b;
  }

  vector<int> getPickupNodes(int n) {
    if (S.size() == 0) return vector<int>(0);

    vector<int> nodes = S;
    while (nodes[nodes.size() - 1] >= n) nodes.pop_back();
    return nodes;
  }
};

// 경로(번들) 구조체
struct Route {
  int rider_index;
  int n_ord;
  vector<int> shop_seq;
  vector<int> dlv_seq;
  double cost;
  size_t optimal_hash = 0;

  Route(int ridx, int n) : rider_index(ridx), n_ord(n), cost(-1) {}

  Route(int ridx, int n, double c) : rider_index(ridx), n_ord(n), cost(c) {
    cost = -1;
  }

  Route(const Route& r)
      : rider_index(r.rider_index), n_ord(r.n_ord), cost(r.cost) {
    if (n_ord > 0) {
      shop_seq = vector<int>(n_ord, 0);
      dlv_seq = vector<int>(n_ord, 0);

      for (int i = 0; i < n_ord; i++) {
        shop_seq[i] = r.shop_seq[i];
        dlv_seq[i] = r.dlv_seq[i];
      }
    } else {
      shop_seq = vector<int>();
      dlv_seq = vector<int>();
    }
  }

  Route(int ridx, vector<int> ps, vector<int> ds)
      : rider_index(ridx),
        n_ord(ps.size()),
        cost(-1),
        shop_seq(ps),
        dlv_seq(ds) {}

  Route(int ridx, int n, double c, vector<int> ps, vector<int> ds)
      : rider_index(ridx), n_ord(n), cost(c), shop_seq(ps), dlv_seq(ds) {}

  Route(int ridx, vector<int> seq) : rider_index(ridx), cost(-1) {
    n_ord = seq.size() / 2;
    shop_seq = vector<int>(seq.begin(), seq.begin() + n_ord);
    dlv_seq = vector<int>(seq.begin() + n_ord, seq.end());
  }

  ~Route() {
    shop_seq.clear();
    dlv_seq.clear();
    vector<int>().swap(shop_seq);
    vector<int>().swap(dlv_seq);
  }

  void removeOrder(int order_to_remove) {
    // 현재 경로에서 특정 주문을 제거한다.
    if (n_ord == 1 && order_to_remove == shop_seq[0]) {
      shop_seq = vector<int>();
      dlv_seq = vector<int>();
      n_ord = 0;
      cost = -1;
      return;
    } else if (n_ord == 1 && order_to_remove != shop_seq[0]) {
      throw TaskAbortException("Cannot found the item @ _removeOrder");
    }

    int pos_p = -1;
    int pos_d = -1;

    for (int i = 0; i < n_ord; i++) {
      if (shop_seq[i] == order_to_remove) pos_p = i;
      if (dlv_seq[i] == N_ORDERS + order_to_remove) pos_d = i;
    }

    if (pos_p >= 0 && pos_d >= 0) {
      shop_seq.erase(shop_seq.begin() + pos_p);
      dlv_seq.erase(dlv_seq.begin() + pos_d);
      cost = -1;
      n_ord--;

      if (n_ord == 0) {
        shop_seq = vector<int>();
        dlv_seq = vector<int>();
      } else {
        shop_seq.shrink_to_fit();
        dlv_seq.shrink_to_fit();
      }
    } else {
      throw TaskAbortException(
          "Route.removeOrder(): Cannot found the item in this route.");
    }
  }

  void insertOrder(int n_orders, int order_to_insert, int pos_p, int pos_d) {
    // 현재 경로에 특정 주문을 삽입한다. 삽입 위치가 같이 입력되어야 한다.

    shop_seq.insert(shop_seq.begin() + pos_p, order_to_insert);
    dlv_seq.insert(dlv_seq.begin() + pos_d, n_orders + order_to_insert);
    n_ord++;
    cost = -1;
    shop_seq.shrink_to_fit();
    dlv_seq.shrink_to_fit();
  }

  void setFromSequence(vector<int>& seq) {
    // 경로 시퀀스를 입력받아 경로를 초기화한다.

    n_ord = seq.size() / 2;

    shop_seq = vector<int>(n_ord);
    dlv_seq = vector<int>(n_ord);

    for (int i = 0; i < n_ord; i++) {
      shop_seq[i] = seq[i];
      dlv_seq[i] = seq[n_ord + i];
    }
    cost = -1;
  }

  double calculateCost() {
    int fc = FIXED_COST[rider_index];
    double(&costs)[MAX_NODES][MAX_NODES] = COSTS[rider_index];

    if (cost <= 0) {
      double _cost = fc + costs[shop_seq[n_ord - 1]][dlv_seq[0]];
      for (int i = 0; i < n_ord - 1; i++) {
        _cost += costs[shop_seq[i]][shop_seq[i + 1]];
        _cost += costs[dlv_seq[i]][dlv_seq[i + 1]];
      }
      cost = _cost;
    }
    return cost;
  }

  // 현재 경로를 최적으로 재정렬한다. 이는 CSPP를 푸는 것과 같으며, 아래
  // 코드는 [1]에 설명된 CSPP를 로직을 구현한 것이다.
  void reorderOptimally() {
    int n = n_ord;
    int N = 2 * n;
    int(&t)[MAX_NODES][MAX_NODES] = TRAVEL_TIMES[rider_index];
    double(&c)[MAX_NODES][MAX_NODES] = COSTS[rider_index];
    int(&adj_mat)[MAX_NODES][MAX_NODES] = ADJ[rider_index];
    int(&a)[MAX_NODES] = EARLIEST_TW[rider_index];
    int(&b)[MAX_NODES] = LATEST_TW[rider_index];
    int s = SERVICE_TIME[rider_index];

    vector<int> orders = shop_seq;
    vector<int> original_sequence = vector<int>(N);
    for (int i = 0; i < n; i++) {
      original_sequence[i] = shop_seq[i];
      original_sequence[n + i] = dlv_seq[i];
    }

    vector<vector<int>> _t = vector<vector<int>>(N, vector<int>(N));
    vector<vector<int>> A = vector<vector<int>>(N, vector<int>(N));
    vector<vector<double>> _c = vector<vector<double>>(N, vector<double>(N));

    vector<int> _a = vector<int>(N);
    vector<int> _b = vector<int>(N);

    for (int i = 0; i < N; i++) {
      _a[i] = a[original_sequence[i]];
      _b[i] = b[original_sequence[i]];
      for (int j = 0; j < N; j++) {
        _t[i][j] = t[original_sequence[i]][original_sequence[j]];
        _c[i][j] = c[original_sequence[i]][original_sequence[j]];
        A[i][j] = adj_mat[original_sequence[i]][original_sequence[j]];
      }
    }

    queue<Label> prev_labels;
    queue<Label> new_labels;
    queue<Label> feasible_labels;
    for (int i = 0; i < n; i++) {
      prev_labels.emplace(vector<int>(1, i), _a[i], 0);
    }

    // add pickup nodes
    for (int K = 1; K < n; K++) {
      while (!prev_labels.empty()) {
        Label curr_label = prev_labels.front();
        prev_labels.pop();

        const int last = curr_label.S[curr_label.S.size() - 1];

        for (int next = 0; next < n; next++) {
          if (last == next) continue;
          if (A[last][next] == 0) continue;
          if (curr_label.contains(next)) continue;

          const int _T = max(_a[next], curr_label.T + s + _t[last][next]);
          const double _Z = curr_label.Z + _c[last][next];

          if (_T > _b[next]) continue;
          Label new_label = curr_label.extend(next, _T, _Z);

          // non post-feasibility
          // prop1
          bool prop1 = false;
          for (int i : new_label.S) {
            if (_T + _t[next][n + i] + s > _b[n + i]) {
              prop1 = true;
              break;
            }
          }
          if (prop1) continue;

          // prop2
          bool prop2 = false;
          if (new_label.S.size() > 1) {
            for (int i : new_label.S) {
              for (int j : new_label.S) {
                if (i == j) continue;

                int _T1 = _T + _t[next][n + i] + s;
                int _T2 = _T + _t[next][n + j] + s;
                if ((_T1 > _b[n + i] ||
                     _T1 + _t[n + i][n + j] + s > _b[n + j]) &&
                    (_T2 > _b[n + j] ||
                     _T2 + _t[n + j][n + i] + s > _b[n + i])) {
                  prop2 = true;
                  break;
                }
              }
              if (prop2) break;
            }
          }
          if (prop2) continue;

          new_labels.push(new_label);
        }
      }

      prev_labels = new_labels;
      while (!new_labels.empty()) new_labels.pop();

      if (prev_labels.size() == 0) break;
    }

    // add delivery nodes
    for (int K = 0; K < n; K++) {
      while (!prev_labels.empty()) {
        Label curr_label = prev_labels.front();
        prev_labels.pop();

        const int last = curr_label.S[curr_label.S.size() - 1];

        vector<int> p_nodes = curr_label.getPickupNodes(n);

        for (int visited_p : p_nodes) {
          int next = visited_p + n;

          if (A[last][next] == 0) continue;
          if (curr_label.contains(next, true)) continue;

          const int _T = max(_a[next], curr_label.T + s + _t[last][next]);
          const double _Z = curr_label.Z + _c[last][next];

          if (_T > _b[next]) continue;
          Label new_label = curr_label.extend(next, _T, _Z);

          // non post-feasibility
          // prop1
          if (new_label.S.size() + 1 <= N) {
            bool prop1 = false;
            for (int i : new_label.S) {
              if (i >= n) break;
              if (new_label.contains(n + i, true)) continue;

              if (_T + _t[next][n + i] + s > _b[n + i]) {
                prop1 = true;
                break;
              }
            }
            if (prop1) continue;
          }

          // prop2
          if (new_label.S.size() + 2 <= N) {
            bool prop2 = false;
            if (new_label.S.size() > 1) {
              for (int i : new_label.S) {
                if (i >= n) break;
                if (new_label.contains(n + i, true)) continue;
                for (int j : new_label.S) {
                  if (i == j) continue;
                  if (j >= n) break;
                  if (new_label.contains(n + j, true)) continue;

                  int _T1 = _T + _t[next][n + i] + s;
                  int _T2 = _T + _t[next][n + j] + s;
                  if ((_T1 > _b[n + i] ||
                       _T1 + _t[n + i][n + j] + s > _b[n + j]) &&
                      (_T2 > _b[n + j] ||
                       _T2 + _t[n + j][n + i] + s > _b[n + i])) {
                    prop2 = true;
                    break;
                  }
                }
                if (prop2) break;
              }
            }
            if (prop2) continue;
          }

          if (new_label.S.size() == N) {
            feasible_labels.push(new_label);
          } else {
            new_labels.push(new_label);
          }
        }
      }

      prev_labels = new_labels;
      while (!new_labels.empty()) new_labels.pop();

      if (prev_labels.size() == 0) break;
    }

    if (feasible_labels.size() == 0) {
      throw TaskAbortException(
          "_reorderOptimallyLarge(): Failed to find any feasible sequence!!\n");
    }

    vector<int> opt_seq;
    double best_cost = -1;

    while (!feasible_labels.empty()) {
      if (best_cost < 0 || feasible_labels.front().Z < best_cost) {
        best_cost = feasible_labels.front().Z;
        opt_seq = feasible_labels.front().S;
      }
      feasible_labels.pop();
    }

    for (int i = 0; i < n; i++) {
      shop_seq[i] = original_sequence[opt_seq[i]];
      dlv_seq[i] = original_sequence[opt_seq[n + i]];
    }

    optimal_hash = hash();
    cost = -1;
  }

  size_t hash() { return hashWithRiderIdx(rider_index); }
  size_t hashWithRiderIdx(int ridx) {
    std::size_t seed = 42;
    seed ^= std::hash<int>()(ridx) + 0x9e3779b9 + (seed << 6) + (seed >> 2);

    seed ^= HashIntegers(shop_seq);
    seed ^= HashIntegers(dlv_seq);

    return seed;
  }
  size_t orderset_hash() {
    std::size_t seed =
        std::hash<int>()(rider_index) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
    seed ^= HashIntegerSet(shop_seq);
    return seed;
  }
};

// PDPTW solution 구조체
struct Solution {
  int n_split;  // splite된 뒤 특정 '스레드'에 할당된 주문들의 개수
  vector<int> available_orders;

  vector<Route> routes;
  gp_hash_table<int, int> order_route_map;

  // 경로에 할당되지 않은 주문들은 request_bank에 저장된다. [2]를 참고하였다.
  vector<int> request_bank;
  double total_cost;

  Solution() {}

  Solution(vector<int> avlb_ords, vector<Route> r)
      : available_orders(avlb_ords), routes(r), total_cost(-1) {
    n_split = avlb_ords.size();
    for (int o : available_orders) {
      int route_idx = -1;

      for (int i = 0; i < routes.size(); i++) {
        bool is_included = false;
        for (int j = 0; j < routes[i].n_ord; j++) {
          if (routes[i].shop_seq[j] == o) {
            is_included = true;
            route_idx = i;
            break;
          }
        }
        if (is_included) {
          route_idx = i;
          break;
        }
      }

      order_route_map.insert(make_pair(o, route_idx));
      if (route_idx == -1) {
        request_bank.push_back(o);
      }
    }
  }

  ~Solution() {
    routes.clear();
    available_orders.clear();
    request_bank.clear();
    order_route_map.clear();

    vector<Route>().swap(routes);
    vector<int>().swap(available_orders);
    vector<int>().swap(request_bank);
    gp_hash_table<int, int>().swap(order_route_map);
  }

  double calculateTotalCost() {
    double tc = 0;
    for (int i = 0; i < routes.size(); i++) {
      tc += routes[i].calculateCost();
    }
    total_cost = tc;
    return total_cost;
  }

  double reorderOptimally() {
    for (int i = 0; i < routes.size(); i++) {
      routes[i].reorderOptimally();
    }
    return calculateTotalCost();
  }

  bool isEveryAssigned() {
    bool b = true;
    for (int i = 1; i <= N_ORDERS; i++) {
      b &= order_route_map[i] != -1;
    }
    return b;
  }

  void cleanEmpties() {
    // removeOrder 등으로 어떤 경로가 empty하게 되면, routes 리스트에서
    // 제거한다. (vector.erase)
    vector<int> routes_to_remove;
    for (int i = 0; i < routes.size(); i++) {
      if (routes[i].n_ord == 0) {
        routes_to_remove.push_back(i);
      }
    }
    int cnt = 0;
    for (int i = 0; i < routes_to_remove.size(); i++) {
      int rtr = routes_to_remove[i];
      int idx = rtr - cnt;
      routes.erase(routes.begin() + idx);
      cnt++;
    }

    resetMap();
  }

  // 하나의 주문을 가지는 경로 생성
  void createNewRoute(int oti, int rider_index) {
    int route_idx = routes.size();

    routes.emplace_back(rider_index, 1, -1);

    routes[route_idx].shop_seq.push_back(oti);
    routes[route_idx].dlv_seq.push_back(N_ORDERS + oti);
    order_route_map[oti] = route_idx;
  }

  // 현재 솔루션에서 할당되어 있는 주문을 un-assign한다.
  // 경우에 따라 request bank에 추가한다.
  void removeOrder(int order_to_remove, bool reqbank = true) {
    int route_idx = order_route_map[order_to_remove];
    if (route_idx >= 0) {
      routes[route_idx].removeOrder(order_to_remove);
      if (reqbank) request_bank.push_back(order_to_remove);
      order_route_map[order_to_remove] = -1;
      cleanEmpties();
    } else {
      throw TaskAbortException(
          "trying to remove an already removed order @ __removeOrder");
    }
  }

  void insertOrder(int route_idx, int order_to_insert, int pos_p, int pos_d) {
    // order_to_insert 주문을 route_idx 경로의 pos_p, pos_d 위치에 삽입한다.
    routes[route_idx].insertOrder(N_ORDERS, order_to_insert, pos_p, pos_d);
    order_route_map[order_to_insert] = route_idx;
  }

  queue<int> removeRoute(int route_idx, bool reset_order_route_map = true) {
    // 경로를 지우고 unassigned_orders의 queue을 만든다.

    queue<int> orders;
    for (int i : routes[route_idx].shop_seq) {
      orders.push(i);
      order_route_map[i] = -1;
    }
    routes.erase(routes.begin() + route_idx);
    if (reset_order_route_map) resetMap();
    return orders;
  }

  void resetMap() {
    // order_route_map을 초기화한다.
    for (int r = 0; r < routes.size(); r++) {
      for (int order : routes[r].shop_seq) order_route_map[order] = r;
    }
  }

  size_t hash() {
    std::size_t seed = 0;

    for (const Route& route : routes) {
      std::size_t route_hash = 0;
      for (int p : route.shop_seq) {
        route_hash ^= std::hash<int>()(p) + 0x9e3779b9 + (route_hash << 6) +
                      (route_hash >> 2);
      }
      for (int d : route.dlv_seq) {
        route_hash ^= std::hash<int>()(d) + 0x9e3779b9 + (route_hash << 6) +
                      (route_hash >> 2);
      }
      seed ^= route_hash + 0x9e3779b9 + (seed << 6) + (seed >> 2);
    }

    return seed;
  }

  void dropUnavailables() {
    gp_hash_table<int, null_type> avlb_set;
    for (int i : available_orders) avlb_set.insert(i);

    for (Route& route : routes) {
      vector<int> route_orders = route.shop_seq;
      for (int order : route_orders) {
        if (avlb_set.find(order) == avlb_set.end()) {
          route.removeOrder(order);
        }
      }
    }

    cleanEmpties();
  }
};

struct Pool {
  gp_hash_table<size_t, null_type> route_hashes;
  queue<Route> generated_routes;
  vector<gp_hash_table<int, int>> len3_cost_freqs;

  Pool() {
    route_hashes = gp_hash_table<size_t, null_type>();
    generated_routes = queue<struct Route>();
    len3_cost_freqs =
        vector<gp_hash_table<int, int>>(3, gp_hash_table<int, int>());
  }

  void insert(Route& route) {
    if (route.n_ord < 3) return;

    size_t hash = route.hash();
    if (route_hashes.find(hash) == route_hashes.end()) {
      route_hashes.insert(hash);
      generated_routes.push(route);
    }
  }

  void update(Solution& sol) {
    for (auto& route : sol.routes) insert(route);
  }
};

// 현재 솔루션에서 랜덤하게 q개의 주문을 제거한다.
// [2]를 참고해 구현하였다.
void RemoveRandom(Solution& curr_sol, int q) {
  curr_sol.total_cost = -1;

  if (q == 1) {
    int order_to_remove = curr_sol.available_orders[randint(curr_sol.n_split)];
    while (curr_sol.order_route_map[order_to_remove] == -1)
      order_to_remove = curr_sol.available_orders[randint(curr_sol.n_split)];

    curr_sol.removeOrder(order_to_remove);
  } else if (q > 1) {
    gp_hash_table<int, null_type> reqbank_set;
    for (int i : curr_sol.request_bank) reqbank_set.insert(i);

    gp_hash_table<int, null_type> otr_set;
    gp_hash_table<int, null_type> removed_set;
    vector<int> random_range = RandomRange(curr_sol.n_split);
    for (int i : random_range) {
      int order = curr_sol.available_orders[i];
      if (reqbank_set.find(order) == reqbank_set.end()) {
        otr_set.insert(order);
        if (otr_set.size() >= q) break;
      }
    }

    // 경로 전체가 otr_set에 존재하는 경우 route를 remove.
    // vector.erase의 complexity를 고려하여, route는 뒤에서부터 제거 --> PQ 사용
    priority_queue<int> routes_to_remove;
    for (int i = 0; i < curr_sol.routes.size(); i++) {
      bool any_remains = false;
      for (int j : curr_sol.routes[i].shop_seq) {
        if (otr_set.find(j) == otr_set.end()) {
          any_remains = true;
          break;
        }
      }

      if (!any_remains) routes_to_remove.push(i);
    }

    while (!routes_to_remove.empty()) {
      int route_idx = routes_to_remove.top();
      routes_to_remove.pop();

      queue<int> removed_orders = curr_sol.removeRoute(route_idx, false);
      while (!removed_orders.empty()) {
        curr_sol.request_bank.push_back(removed_orders.front());
        removed_set.insert(removed_orders.front());
        removed_orders.pop();
      }
    }
    curr_sol.resetMap();

    for (const int& elem : otr_set) {
      if (removed_set.find(elem) != removed_set.end()) continue;

      curr_sol.removeOrder(elem);
    }
  } else {
    throw TaskAbortException("RemoveRandom(): Invalid Argument `q`");
  }
}

// Request bank에 있는 주문들을 greedy하게 삽입한다.
// [2]를 참고해 구현하였으며, 다만 bank의 전체 주문에 대해서 탐색하지 않고,
// 하나의 주문을 고정하고 greedy하게 탐색한다(=naively).
void InsertNaiveGreedy(Solution& curr_sol) {
  random_shuffle(curr_sol.request_bank.begin(), curr_sol.request_bank.end());
  vector<int> remains;

  while (curr_sol.request_bank.size() > 0) {
    int oti = curr_sol.request_bank.back();
    curr_sol.request_bank.pop_back();

    // Find best position to insert
    int best_route_idx;
    int best_pos_p;
    int best_pos_d;
    double best_cost_diff = -1;

    for (int it_route = 0; it_route < curr_sol.routes.size(); it_route++) {
      Route& route = curr_sol.routes[it_route];

      int r = route.rider_index;
      int(&travel_time)[MAX_NODES][MAX_NODES] = TRAVEL_TIMES[r];
      double(&costs)[MAX_NODES][MAX_NODES] = COSTS[r];
      int(&a)[MAX_NODES] = EARLIEST_TW[r];
      int(&b)[MAX_NODES] = LATEST_TW[r];

      int s = SERVICE_TIME[r];
      int C = CAPA[r];
      int n_ord = route.n_ord;
      double cost_before = route.calculateCost();

      // check capacity feasibility
      int loads = DEMANDS[oti];
      for (int i = 0; i < n_ord; i++) loads += DEMANDS[route.shop_seq[i]];
      if (loads > C) continue;

      // check bundleability
      if (n_ord >= 1 && !IsEveryBundleable(r, oti, route.shop_seq)) continue;

      int len = 2 * n_ord + 2 + 2;
      vector<int> seq = vector<int>(len);
      seq[0] = 0;
      seq[1] = oti;
      seq[n_ord + 2] = N_ORDERS + oti;
      seq[len - 1] = 2 * N_ORDERS + 1;
      for (int i = 0; i < n_ord; i++) {
        seq[2 + i] = route.shop_seq[i];
        seq[n_ord + 3 + i] = route.dlv_seq[i];
      }

      int curr_pos_p = 1, curr_pos_d = n_ord + 2;
      do {
        double _cost = 0.0;
        for (int i = 0; i < len - 1; i++) _cost += costs[seq[i]][seq[i + 1]];

        // 삽입하면 비용은 반드시 증가한다. 따라서 cost_diff는 항상 양수이다.
        double cost_diff_seq = _cost - cost_before;

        // check time feasibility
        int tau = a[seq[1]];
        for (int it_seq = 2; it_seq < len - 1; it_seq++) {
          int arrival_time =
              tau + travel_time[seq[it_seq - 1]][seq[it_seq]] + s;
          if (arrival_time > b[seq[it_seq]]) {
            tau = -1;
            break;
          }
          if (arrival_time < a[seq[it_seq]]) arrival_time = a[seq[it_seq]];
          tau = arrival_time;
        }

        // tau > 0 이라면 time windows 기준으로 feasible한 상황이다.
        // 즉 여기서는 pos_p와 pos_d가 feasible하다.
        if (tau > 0) {
          if ((cost_diff_seq < best_cost_diff || best_cost_diff < 0)) {
            best_route_idx = it_route;
            best_pos_p = curr_pos_p - 1;
            best_pos_d = curr_pos_d - (n_ord + 2);
            best_cost_diff = cost_diff_seq;
          }
        }

        // change sequence by swapping
        int tmp_last_p = curr_pos_p;
        int tmp_last_d = curr_pos_d;
        curr_pos_p++;
        if (curr_pos_p == n_ord + 2) {
          curr_pos_d++;
          if (curr_pos_d <= len - 2) curr_pos_p = 1;
        }
        if (curr_pos_d <= len - 2) {
          if (curr_pos_p == 1 && tmp_last_p == n_ord + 1) {
            for (int it_seq = 0; it_seq < n_ord; it_seq++) {
              seq[n_ord + 1 - it_seq] = seq[n_ord + 1 - (it_seq + 1)];
            }
            seq[1] = oti;
          } else {
            int tmp = seq[curr_pos_p];
            seq[curr_pos_p] = seq[tmp_last_p];
            seq[tmp_last_p] = tmp;
          }

          int tmp = seq[curr_pos_d];
          seq[curr_pos_d] = seq[tmp_last_d];
          seq[tmp_last_d] = tmp;
        }
      } while (curr_pos_p <= n_ord + 1 && curr_pos_d <= len - 2);
    }

    if (best_cost_diff > 0) {
      curr_sol.insertOrder(best_route_idx, oti, best_pos_p, best_pos_d);
    } else {
      vector<bool> is_feasible;
      for (int r = 0; r < 3; r++) {
        is_feasible.push_back((EARLIEST_TW[r][oti] +
                                   TRAVEL_TIMES[r][oti][N_ORDERS + oti] +
                                   SERVICE_TIME[r] <=
                               LATEST_TW[r][N_ORDERS + oti]) &&
                              DEMANDS[oti] <= CAPA[r]);
      }
      vector<int> feasible_indices;
      for (int r = 0; r < 3; r++) {
        if (is_feasible[r]) feasible_indices.push_back(r);
      }

      if (feasible_indices.size() > 0) {
        if (is_feasible[0])
          curr_sol.createNewRoute(oti, 0);
        else {
          int r = feasible_indices[randint(feasible_indices.size())];
          curr_sol.createNewRoute(oti, r);
        }
      } else {
        // feasible indices가 없다면 skip...
        remains.push_back(oti);
      }
    }
  }

  if (remains.size() > 0) {
    curr_sol.request_bank = remains;
  } else {
    curr_sol.request_bank.clear();
  }
}

// 파이썬에서 전달한 초기 솔루션을 Route 구조체로 변환한다.
vector<Route> ConvertInitSol(int* init_sol) {
  // init_sol[0]: 배열 길이
  // init_sol[1]: n_routes
  // init_sol[2:-1]: routes --> [n_ord, rider_index, p1, p2, ..., d1, d2, ...]
  // init_sol[-1]: 배열 끝 플래그(== -1)
  int total_length = init_sol[0];
  int n_routes = init_sol[1];

  vector<Route> routes;
  routes.reserve(n_routes);

  int curr_idx = 2;
  while (init_sol[curr_idx] != -1) {
    int n_ord = init_sol[curr_idx++];
    int rider_index = init_sol[curr_idx++];
    vector<int> shop_seq(n_ord);
    vector<int> dlv_seq(n_ord);

    for (int i = 0; i < n_ord; i++) shop_seq[i] = init_sol[curr_idx++];
    for (int i = 0; i < n_ord; i++)
      dlv_seq[i] = N_ORDERS + init_sol[curr_idx++];
    routes.emplace_back(rider_index, n_ord, 0, shop_seq, dlv_seq);
  }
  return routes;
}

Solution LNS(Pool& pool, Solution init_sol, double MAX_NOISE,
             TimeData timedata) {
  // LNS 함수
  init_sol.calculateTotalCost();

  if (init_sol.request_bank.size() > 0) {
    InsertNaiveGreedy(init_sol);
  }

  Solution curr_sol = init_sol;
  Solution best_sol = init_sol;
  curr_sol.calculateTotalCost();
  best_sol.calculateTotalCost();

  int MAX_ITER = 10;
  int MAX_N_TO_REM = (int)(0.8 * curr_sol.n_split);
  int MIN_N_TO_REM = (int)(0.4 * curr_sol.n_split);
  int n_iter = 0;

  while (n_iter++ < MAX_ITER) {
    if (timedata.isTimeout()) break;
    Solution tmp_sol = curr_sol;

    if (n_iter == 1) {
      // Guided Ejection Search(GES)의 발상을 차용하여 일부 반복에서는 order가
      // 아니라 route를 제거한다(eject).
      int n_routes_to_remove = 3;
      while (n_routes_to_remove-- > 0) {
        int idx = randint(tmp_sol.routes.size());
        queue<int> q = tmp_sol.removeRoute(idx, false);
        while (!q.empty()) {
          tmp_sol.request_bank.push_back(q.front());
          q.pop();
        }
      }
      tmp_sol.resetMap();
    } else {
      int n_to_remove = randint(MAX_N_TO_REM + 1 - MIN_N_TO_REM) + MIN_N_TO_REM;
      RemoveRandom(tmp_sol, n_to_remove);
    }
    InsertNaiveGreedy(tmp_sol);

    tmp_sol.calculateTotalCost();

    if ((tmp_sol.total_cost < best_sol.total_cost) &&
        tmp_sol.isEveryAssigned()) {
      best_sol = tmp_sol;
    }

    double noise = (randreal() * 2 - 1) * MAX_NOISE * 0.05;
    tmp_sol.total_cost += noise;
    if (curr_sol.total_cost > tmp_sol.total_cost && tmp_sol.isEveryAssigned()) {
      tmp_sol.total_cost -= noise;
      curr_sol = tmp_sol;
    }

    tmp_sol.reorderOptimally();
    pool.update(tmp_sol);

    if (timedata.isTimeout()) break;
  }

  return best_sol;
}

void HEURISTIC(int tid, vector<int> orders, int* init_sol, double remain_time,
               Pool& pool, TimeData timedata) {
  srand(tid * (tid + 42));

  vector<Route> all_routes = ConvertInitSol(init_sol);

  Solution curr_sol = {orders, all_routes};
  curr_sol.dropUnavailables();
  curr_sol.calculateTotalCost();

  double threashold = (double)N_ORDERS / 5.0;
  double decay = 0.95;
  while (!timedata.isTimeout()) {
    Solution tmp_sol = curr_sol;
    int n_route_before = pool.generated_routes.size();

    tmp_sol = LNS(pool, tmp_sol, MAX_NOISE, timedata);

    int n_route_after = pool.generated_routes.size();
    if (n_route_after - n_route_before < threashold) {
      curr_sol = tmp_sol;
      threashold *= decay;
    }
  }
}

void InitRiderCostants(int* n_availables, int* capas, int* service_times,
                       double* fixed_costs, int* a, int* b, int* travel_times,
                       double* costs) {
  for (int r = 0; r < 3; r++) {
    N_AVLB[r] = n_availables[r];
    CAPA[r] = capas[r];
    SERVICE_TIME[r] = service_times[r];
    FIXED_COST[r] = (int)fixed_costs[r];
  }

  int N2 = N_NODES * N_NODES;
#pragma omp parallel for num_threads(3)
  for (int r = 0; r < 3; r++) {
    for (int i = 0; i < N_NODES; i++) {
      EARLIEST_TW[r][i] = a[r * N_NODES + i];
      LATEST_TW[r][i] = b[r * N_NODES + i];
    }

    for (int i = 0; i < N_NODES; i++) {
      for (int j = 0; j < N_NODES; j++) {
        TRAVEL_TIMES[r][i][j] = travel_times[r * N2 + i * N_NODES + j];
        COSTS[r][i][j] = costs[r * N2 + i * N_NODES + j];
      }
    }
  }

  MAX_NOISE = 0;
  for (int r = 0; r < 3; r++) {
    for (int i = 1; i < N_NODES; i++) {
      for (int j = 1; j < N_NODES; j++) {
        if (COSTS[r][i][j] > MAX_NOISE) MAX_NOISE = COSTS[r][i][j];
      }
    }
  }
}

void ConstructNetwork() {
  // 노드 사이의 이동 feasibility를 계산한다.
  // [1]을 참고해 구현하였다.
#pragma omp parallel for num_threads(3)
  for (int r = 0; r < 3; r++) {
    int(&t)[MAX_NODES][MAX_NODES] = TRAVEL_TIMES[r];
    int(&a)[MAX_NODES] = EARLIEST_TW[r];
    int(&b)[MAX_NODES] = LATEST_TW[r];
    int s = SERVICE_TIME[r];
    int C = CAPA[r];

    auto TSum4 = [&](int i1, int i2, int i3, int i4) -> int {
      return t[i1][i2] + t[i2][i3] + t[i3][i4];
    };

    // 1로 초기화
    for (int i = 0; i < MAX_NODES; i++) {
      for (int j = 0; j < MAX_NODES; j++) {
        ADJ[r][i][j] = 1;
      }
    }

    // 자기 자신으로 가는 arc 제거
    for (int i = 0; i < N_NODES; i++) ADJ[r][i][i] = 0;

    for (int i = 1; i <= N_ORDERS; i++) {
      // (a) priority
      ADJ[r][0][N_ORDERS + i] = 0;
      ADJ[r][N_ORDERS + i][i] = 0;
      ADJ[r][N_NODES - 1][0] = 0;
      ADJ[r][N_NODES - 1][i] = 0;
      ADJ[r][N_NODES - 1][(N_ORDERS + i)] = 0;
      ADJ[r][N_NODES - 1][(N_ORDERS + i)] = 0;

      // (b) pairing
      ADJ[r][i][N_NODES - 1] = 0;

      ADJ[r][i][0] = 0;
      ADJ[r][N_ORDERS + i][0] = 0;
    }

    // (d) time windows
    for (int i = 1; i < N_NODES - 1; i++) {
      for (int j = 1; j < N_NODES - 1; j++) {
        if (i == j) continue;
        if (a[i] + s + t[i][j] > b[j]) ADJ[r][i][j] = 0;
      }
    }

    for (int i = 1; i <= N_ORDERS; i++) {
      for (int j = 1; j <= N_ORDERS; j++) {
        if (i == j) continue;
        ADJ[r][N_ORDERS + i][j] = 0;

        // (c) vehicle capacity
        if (DEMANDS[i] + DEMANDS[j] > C) {
          ADJ[r][i][j] = 0;
          ADJ[r][j][i] = 0;
          ADJ[r][i][N_ORDERS + j] = 0;
          ADJ[r][j][N_ORDERS + i] = 0;
          ADJ[r][N_ORDERS + i][N_ORDERS + j] = 0;
          ADJ[r][N_ORDERS + j][N_ORDERS + i] = 0;
        }

        // (e) time windows and pairing of requests
        // (i, n+j): j, i, n+j, n+i
        if (a[j] + s + TSum4(j, i, N_ORDERS + j, N_ORDERS + i) >
            b[N_ORDERS + i])
          ADJ[r][i][N_ORDERS + j] = 0;

        // (i, j): i, j, n+i, n+j and i, j, n+j, n+i
        if (a[i] + s + TSum4(i, j, N_ORDERS + i, N_ORDERS + j) >
                b[N_ORDERS + j] &&
            a[i] + s + TSum4(i, j, N_ORDERS + j, N_ORDERS + i) >
                b[N_ORDERS + i])
          ADJ[r][i][j] = 0;

        // (n+i, n+j): i, j, n+i, n+j and j, i, n+i, n+j
        if (a[i] + s + TSum4(i, j, N_ORDERS + i, N_ORDERS + j) >
                b[N_ORDERS + j] &&
            a[j] + s + TSum4(j, i, N_ORDERS + i, N_ORDERS + j) >
                b[N_ORDERS + j])
          ADJ[r][N_ORDERS + i][N_ORDERS + j] = 0;
      }
    }

    // impossible for a specific rider
    for (int i = 1; i <= N_ORDERS; i++) {
      if (a[i] + s + t[i][N_ORDERS + i] > b[N_ORDERS + i] || DEMANDS[i] > C) {
        // request i를 아예 픽업하지 못함.
        for (int j = 1; j <= N_ORDERS; j++) {
          if (i == j) continue;
          ADJ[r][i][j] = 0;
          ADJ[r][j][i] = 0;
          ADJ[r][N_ORDERS + i][j] = 0;
          ADJ[r][j][N_ORDERS + i] = 0;
        }
        ADJ[r][0][i] = 0;
        ADJ[r][N_ORDERS + i][N_NODES - 1] = 0;
        ADJ[r][i][N_ORDERS + i] = 0;
      }
    }
  }
}

void FindSimpleRoutes(queue<Route>& pool) {
  // 주문을 1개 혹은 2개를 포함하는 모든 경로를 찾는다.

  vector<queue<Route>> simple_routes = vector<queue<Route>>(3);
  vector<vector<int>> len2_avg_costs = vector<vector<int>>(3);

  // 빠른 push를 위해 공간 reserve
  len2_avg_costs[0].reserve(0.5 * N_ORDERS * (N_ORDERS - 1) / 2);
  len2_avg_costs[1].reserve(0.2 * N_ORDERS * (N_ORDERS - 1) / 2);
  len2_avg_costs[2].reserve(0.5 * N_ORDERS * (N_ORDERS - 1) / 2);

#pragma omp parallel num_threads(3) shared(simple_routes, len2_avg_costs)
  {
    int r = omp_get_thread_num();
    queue<Route>& _pool = simple_routes[r];
    vector<int>& _len2_costs = len2_avg_costs[r];

    int(&a)[MAX_NODES] = EARLIEST_TW[r];
    int(&b)[MAX_NODES] = LATEST_TW[r];
    int(&t)[MAX_NODES][MAX_NODES] = TRAVEL_TIMES[r];
    double(&cc)[MAX_NODES][MAX_NODES] = COSTS[r];
    int s = SERVICE_TIME[r];
    int fc = FIXED_COST[r];
    int C = CAPA[r];

    // IS_BUNDLEABLE false로 초기화
    for (int i = 0; i < N_ORDERS; i++) {
      for (int j = 0; j < N_ORDERS; j++) {
        IS_BUNDLEABLE[r][i][j] = false;
      }
    }

    auto _isFeasible = [&](vector<int>& sequence) -> bool {
      int tau = a[sequence[0]];
      int curr, next;
      for (int i = 0; i < sequence.size() - 1; i++) {
        curr = sequence[i];
        next = sequence[i + 1];
        tau += t[curr][next] + s;
        tau = max(tau, a[next]);
        if (tau > b[next]) return false;
      }
      return true;
    };

    for (int i = 1; i <= N_ORDERS; i++) {
      // single order route
      if (DEMANDS[i] <= C && a[i] + s + t[i][N_ORDERS + i] <= b[N_ORDERS + i]) {
        // feasible
        _pool.emplace(r, (vector<int>){i}, (vector<int>){N_ORDERS + i});
      }

      // two order routes
      for (int j = i + 1; j <= N_ORDERS; j++) {
        // if (i == j) continue;
        if (DEMANDS[i] + DEMANDS[j] > C) continue;
        if (a[j] + s + t[j][N_ORDERS + j] <= b[N_ORDERS + j]) {
          // can be feasible
          // check feasibility and cost
          vector<int> perm_p = vector<int>(2, 0);
          vector<int> perm_d = vector<int>(2, 0);
          vector<int> seq = vector<int>(4, 0);
          vector<int> _seq;
          double cost = -1;

          // i j n+i n+j
          // i j n+j n_i
          // j i n+i n+j
          // j i n+j n+i
          for (int k = 0; k < 4; k++) {
            switch (k) {
              case 0:
                _seq = {i, j, N_ORDERS + i, N_ORDERS + j};
                break;
              case 1:
                _seq = {i, j, N_ORDERS + j, N_ORDERS + i};
                break;
              case 2:
                _seq = {j, i, N_ORDERS + i, N_ORDERS + j};
                break;
              case 3:
                _seq = {j, i, N_ORDERS + j, N_ORDERS + i};
                break;
            }

            if (_isFeasible(_seq)) {
              double _cost = fc + cc[_seq[0]][_seq[1]] + cc[_seq[1]][_seq[2]] +
                             cc[_seq[2]][_seq[3]];
              if (cost < 0 || _cost < cost) {
                seq = _seq;
                cost = _cost;
              }
            }
          }

          if (cost > 0) {
            _pool.emplace(r, seq);
            IS_BUNDLEABLE[r][i - 1][j - 1] = true;
            IS_BUNDLEABLE[r][j - 1][i - 1] = true;
            _len2_costs.push_back(cost / 2);
          }
        } else
          continue;
      }
    }
  }

  SIZE_BIKE =
      (double)simple_routes[0].size() / (N_ORDERS * (N_ORDERS - 1) / 2.0);
  SIZE_WALK =
      (double)simple_routes[1].size() / (N_ORDERS * (N_ORDERS - 1) / 2.0);
  SIZE_CAR =
      (double)simple_routes[2].size() / (N_ORDERS * (N_ORDERS - 1) / 2.0);
  SIZE_SUM = SIZE_BIKE + SIZE_WALK + SIZE_CAR;

  vector<gp_hash_table<int, int>> freq =
      vector<gp_hash_table<int, int>>(3, gp_hash_table<int, int>());
  vector<int> mode_vals(3);
  vector<int> q3(3);
  vector<int> max_vals(3, 0);
  vector<int> min_vals(3, 0);
  mode_vals[1] = -1;
  q3[1] = -1;

  if (CUT_LEN2) {
    // 각 경로의 평균 비용(경로 비용 / 주문 개수) 분포로부터 비싼 경로들을 일부
    // 버림한다.
#pragma omp parallel for num_threads(3)
    for (int r = 0; r < 3; r++) {
      vector<int>& _costs = len2_avg_costs[r];
      min_vals[r] = _costs[0];
      if (r == 1) continue;

      int BIN_SIZE = 100;
      for (int x : _costs) {
        int val = (x / BIN_SIZE) * BIN_SIZE;
        if (freq[r].find(val) == freq[r].end())
          freq[r].insert(make_pair(val, 0));
        freq[r][val]++;
        min_vals[r] = min(val, min_vals[r]);
        max_vals[r] = max(val, max_vals[r]);
      }

      int mode;
      int mode_freq = 0;
      for (auto& elem : freq[r]) {
        if (mode_freq < elem.second) {
          mode = elem.first;
          mode_freq = elem.second;
        }
      }
      mode_vals[r] = mode;

      // find q3
      int q3_size = len2_avg_costs[r].size() * 0.10;
      int curr = max_vals[r];
      int sum = 0;
      while (curr >= min_vals[r]) {
        if (freq[r].find(curr) != freq[r].end()) {
          sum += freq[r][curr];
          if (sum > q3_size) {
            q3[r] = curr + BIN_SIZE;
            break;
          }
        }
        curr -= BIN_SIZE;
      }
    }
  }

  for (int r = 0; r < 3; r++) {
    if (!CUT_LEN2 || r == 1) {
      while (!simple_routes[r].empty()) {
        pool.push(simple_routes[r].front());
        simple_routes[r].pop();
      }
    } else {
      int at = 0;
      while (!simple_routes[r].empty()) {
        auto& route = simple_routes[r].front();
        if (route.n_ord == 1)
          pool.push(route);
        else {
          // n_ord == 2
          if (len2_avg_costs[r][at] <= mode_vals[r] + 500) pool.push(route);
          at++;
        }
        simple_routes[r].pop();
      }
    }
  }

  for (int r = 0; r < 3; r++) {
    len2_avg_costs[r].clear();
    vector<int>().swap(len2_avg_costs[r]);
  }
}

vector<vector<int>> SplitOrders(vector<vector<bool>>& B) {
  // 각 스레드에 주문을 분배한다 = Problem Decomposition
  if (NUM_CPU < 4) {
    return vector<vector<int>>(4, Range(1, N_ORDERS + 1));
  }

  vector<int> _a = vector<int>(N_ORDERS);

#pragma omp parallel for num_threads(4)
  for (int i = 0; i < N_ORDERS; i++) {
    _a[i] = EARLIEST_TW[0][1 + i];
    for (int j = 0; j < N_ORDERS; j++) {
      // BIKE -> CAR -> WALK 순으로 bundleable할 확률이 큼.
      B[i][j] = IS_BUNDLEABLE[0][i][j] ||
                (IS_BUNDLEABLE[2][i][j] || IS_BUNDLEABLE[1][i][j]);
    }
  }
  vector<int> a_order = Argsort(_a);
  vector<vector<int>> indices = {{0, N_ORDERS / 4},
                                 {N_ORDERS / 4, N_ORDERS / 2},
                                 {N_ORDERS / 2, 3 * N_ORDERS / 4},
                                 {3 * N_ORDERS / 4, N_ORDERS}};

  vector<vector<int>> splitted_orders = vector<vector<int>>(4);

#pragma omp parallel for num_threads(4)
  for (int it = 0; it < 4; it++) {
    vector<int> I = indices[it];
    int i = I[0], j = I[1];
    vector<int> originals(j - i);
    for (int k = i; k < j; k++) originals[k - i] = a_order[k];

    unordered_set<int> o_set;
    for (int o : originals) {
      for (int i = 0; i < N_ORDERS; i++) {
        if (B[o][i]) o_set.insert(i);
      }
    }

    vector<int> group;
    for (int o : o_set) group.push_back(o + 1);
    sort(group.begin(), group.end());
    splitted_orders[it] = group;
  }

  return splitted_orders;
}

extern "C" int*** MAIN(int n, int* l, int* n_availables, int* capas,
                       int* service_times, double* fixed_costs,
                       int* travel_times, double* costs, int* a, int* b,
                       int* init_sol, double timelimit) {
  auto st = NOW();
  omp_set_dynamic(0);
  if (n > 1000 && timelimit <= 45) CUT_LEN2 = true;
  double remain_time = timelimit * 0.35 - 2;

  N_ORDERS = n;
  N_NODES = 2 * n + 2;

  for (int i = 0; i < N_NODES; i++) DEMANDS[i] = l[i];

  queue<Route> simple_routes;
  InitRiderCostants(n_availables, capas, service_times, fixed_costs, a, b,
                    travel_times, costs);
  ConstructNetwork();
  FindSimpleRoutes(simple_routes);

  int offset = simple_routes.size();

  vector<vector<bool>> B = vector<vector<bool>>(n, vector<bool>(n, false));
  vector<vector<int>> orders = SplitOrders(B);

  if (SIZE_SUM <= 0.15 && n < 1500) {
    remain_time = (timelimit * 0.5);
  }

  vector<Pool> pools = vector<Pool>(NUM_CPU, Pool());

  double init_time = ((chrono::duration<double>)(NOW() - st)).count();
  vector<bool> is_terminated(4, false);

#pragma omp parallel num_threads(NUM_CPU) shared( \
    pools, init_time, n, l, init_sol, remain_time, orders, is_terminated)
  {
    int tid = omp_get_thread_num();
    if (orders[tid].size() >= N_ORDERS / 4) {
      // CPU마다 time point가 달라서 따로 만들어줘야 함.
      auto start_time = NOW();
      TimeData timedata = {start_time, remain_time - init_time};

      Pool& pool = pools[tid];

      try {
        HEURISTIC(tid, orders[tid], init_sol, remain_time, pool, timedata);
      } catch (...) {
        while (!pool.generated_routes.empty()) pool.generated_routes.pop();
        pool.len3_cost_freqs.clear();
        pool.route_hashes.clear();
        is_terminated[tid] = true;
      }
    }
  }

  queue<Route> final_generated_routes = simple_routes;
  gp_hash_table<size_t, null_type> final_route_hashes;
  for (int i = 0; i < NUM_CPU; i++) {
    if (is_terminated[i]) continue;
    while (!pools[i].generated_routes.empty()) {
      Route& route = pools[i].generated_routes.front();
      size_t hash = route.hash();

      if (final_route_hashes.find(hash) == final_route_hashes.end()) {
        final_route_hashes.insert(hash);
        final_generated_routes.push(route);
      }

      pools[i].generated_routes.pop();
    }
  }

  vector<Route> all_routes;
  all_routes.reserve(final_generated_routes.size());
  while (!final_generated_routes.empty()) {
    Route& route = final_generated_routes.front();
    route.cost = -1;
    route.calculateCost();
    all_routes.push_back(route);
    final_generated_routes.pop();
  }

  gp_hash_table<int, vector<int>> a_dict;
  vector<vector<int>> r_dict = vector<vector<int>>(3, vector<int>());
  vector<int> rk_matching = vector<int>(all_routes.size(), -100);
  vector<int> route_costs = vector<int>(all_routes.size(), -1);
  for (int i = 1; i <= n; i++) a_dict.insert(make_pair(i, vector<int>()));

  int*** ret = (int***)malloc(sizeof(int**) * 6);
  ret[0] = (int**)malloc(sizeof(int*) * 1);  // n_routes
  ret[0][0] = (int*)malloc(sizeof(int) * 3);
  ret[0][0][0] = all_routes.size();
  ret[0][0][1] = offset;
  ret[0][0][2] = (int)round(SIZE_SUM * 1000000);

  ret[1] = (int**)malloc(sizeof(int*) * all_routes.size());  // routes

  ret[2] = (int**)malloc(sizeof(int*) * 1);  // costs
  ret[2][0] = (int*)malloc(sizeof(int) * all_routes.size());

  ret[3] = (int**)malloc(sizeof(int*) * 1);  // rk_matching
  ret[3][0] = (int*)malloc(sizeof(int) * all_routes.size());

  ret[4] = (int**)malloc(sizeof(int*) * n);  // a_dict
  ret[5] = (int**)malloc(sizeof(int*) * 3);  // r_dict

  for (int i = 0; i < all_routes.size(); i++) {
    Route& route = all_routes[i];
    int n_ord = route.n_ord;
    int rider_idx = route.rider_index;
    int cost = (int)round(route.cost);

    ret[2][0][i] = cost;
    ret[3][0][i] = rider_idx;

    ret[1][i] = (int*)malloc(sizeof(int) * (2 * n_ord + 1));
    ret[1][i][0] = 2 * n_ord;
    for (int j = 0; j < n_ord; j++) {
      ret[1][i][j + 1] = route.shop_seq[j];
      ret[1][i][j + n_ord + 1] = route.dlv_seq[j];
      a_dict[route.shop_seq[j]].push_back(i);
      r_dict[rider_idx].push_back(i);
    }
  }

  for (int i = 1; i <= n; i++) {
    ret[4][i - 1] = (int*)malloc(sizeof(int) * (a_dict[i].size() + 1));
    ret[4][i - 1][0] = a_dict[i].size();
    for (int j = 0; j < a_dict[i].size(); j++)
      ret[4][i - 1][j + 1] = a_dict[i][j];
  }

  for (int r = 0; r < 3; r++) {
    ret[5][r] = (int*)malloc(sizeof(int) * (r_dict[r].size() + 1));
    ret[5][r][0] = r_dict[r].size();
    for (int i = 0; i < r_dict[r].size(); i++) ret[5][r][i + 1] = r_dict[r][i];
  }

  return ret;
}

extern "C" void FreeRetPtrs(int n, int*** ret) {
  int n_routes = ret[0][0][0];
  free(ret[0][0]);
  free(ret[0]);
  for (int i = 0; i < n_routes; i++) free(ret[1][i]);
  free(ret[1]);
  free(ret[2][0]);
  free(ret[2]);
  free(ret[3][0]);
  free(ret[3]);
  for (int i = 0; i < n; i++) free(ret[4][i]);
  free(ret[4]);
  for (int i = 0; i < 3; i++) free(ret[5][i]);
  free(ret[5]);

  free(ret);
  ret = nullptr;
}