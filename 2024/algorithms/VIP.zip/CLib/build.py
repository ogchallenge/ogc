import os
import json
import hashlib
import argparse

this_path = os.path.abspath(__file__)
dir_path = os.path.split(this_path)[0]
hash_path = os.path.join(dir_path, "_hash")

parser = argparse.ArgumentParser()
parser.add_argument("--init", action="store_true")
args = parser.parse_args()

if args.init and os.path.isfile(hash_path):
    os.remove(hash_path)


hashes = None
if os.path.isfile(hash_path):
    with open(hash_path, "r") as f:
        hashes = json.load(f)

new_hashes = {} if hashes is None else hashes.copy()


def build_so(name, options=None):
    cpp_path = os.path.join(dir_path, f"{name}.cpp")
    o_path = os.path.join(dir_path, f"obj/{name}.o")
    so_path = os.path.join(dir_path, f"obj/{name}.so")

    with open(cpp_path, "r") as f:
        text = f.read()
        hash_val = hashlib.sha256(text.encode()).hexdigest()

    if hashes is not None and name in hashes:
        if hashes[name] == hash_val:
            print(f"Skipped {name}")
            return

    _options = ["-std=c++11", "-DNDEBUG"]

    if options is not None:
        _options += list(options)

    _options = " ".join(_options)

    if name == "libutils":
        os.system(f"g++ {_options} -c {cpp_path} -shared -o {so_path}")
    else:
        L = os.path.join(dir_path, "obj")
        os.system(f"g++ {cpp_path} -L{L} -lutils {_options} -shared -o {so_path}")

    new_hashes[name] = hash_val
    print(f"Built {name}")


libs = [
    # TODO gp_hash_table 버리기
    ("libutils", None),
    ("libheuristic", ["-fopenmp", "-fPIC"]),
    ("libinitsol", ["-fopenmp", "-fPIC"]),
]

if __name__ == "__main__":
    for args in libs:
        build_so(*args)

    with open(os.path.join(dir_path, "_hash"), "w") as f:
        json.dump(new_hashes, f)
