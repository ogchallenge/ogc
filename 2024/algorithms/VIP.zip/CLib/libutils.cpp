#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")

#include "libutils.hpp"

#include <algorithm>
#include <chrono>
#include <vector>

using namespace std;

double max(double a, double b) { return a > b ? a : b; }
int max(int a, int b) { return a > b ? a : b; }

int randint(int n) { return (rand()) % n; }

double randreal() {
  int M = 100000;
  return (double)randint(M) / M;
}

vector<int> Range(int n) {
  vector<int> ret = vector<int>(n);
  for (int i = 0; i < n; i++) ret[i] = i;
  return ret;
}

vector<int> Range(int s, int t) {
  int n = t - s;
  vector<int> ret = vector<int>(n);
  for (int i = 0; i < n; i++) ret[i] = s + i;
  return ret;
}

vector<int> RandomRange(int n) {
  vector<int> ret = vector<int>(n);
  for (int i = 0; i < n; i++) ret[i] = i;
  random_shuffle(ret.begin(), ret.end());
  return ret;
}

vector<int> RandomRange(int s, int t) {
  int n = t - s;
  vector<int> ret = vector<int>(n);
  for (int i = 0; i < n; i++) ret[i] = s + i;
  random_shuffle(ret.begin(), ret.end());
  return ret;
}

double Elapsed(chrono::high_resolution_clock::time_point start_time) {
  chrono::duration<double> elapsed =
      std::chrono::high_resolution_clock::now() - start_time;
  return elapsed.count();
}

size_t HashIntegers(vector<int> arr) {
  size_t seed = 0;
  for (int x : arr) {
    seed ^= std::hash<int>()(x) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
  }
  return seed;
}

size_t HashIntegerSet(vector<int> arr) {
  sort(arr.begin(), arr.end());
  return HashIntegers(arr);
}

size_t HashOrderSet(int rider_index, vector<int> orders) {
  unsigned long long prod = 1;
  sort(orders.begin(), orders.end());

  std::size_t seed = rider_index;
  seed ^=
      std::hash<int>()(rider_index) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
  for (int o : orders) {
    prod *= (o + 1);
    seed ^= std::hash<int>()(o) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
  }
  seed ^= std::hash<int>()(prod) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
  seed ^=
      std::hash<int>()(prod * prod) + 0x9e3779b9 + (seed << 6) + (seed >> 2);

  return seed;
}
