/*
libinitsol: 초기해(initial solution)를 생성하는 코드.

본 파일은 libheuristic.cpp를 복사한 뒤에 약간 수정한 코드이다.
따라서 대부분의 주석을 제거하였으며, 설명이 필요한 경우 libheuristic.cpp을
파일을 참고하면 된다. 본 파일의 주석은 libheuristic.cpp과 다른 부분에 대해서만
설명되어 있다.
*/

#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")

#include <chrono>
#include <ext/pb_ds/assoc_container.hpp>
#include <queue>
#include <vector>

#include "libutils.hpp"

#define NOW std::chrono::high_resolution_clock::now
#define MAX_ORDERS 3000
#define MAX_NODES (2 * MAX_ORDERS + 2)

using namespace std;
using namespace __gnu_pbds;

static int N_ORDERS;
static int N_NODES;
static int CAPA[3];
static int N_AVLB[3];
static int SERVICE_TIME[3];
static int FIXED_COST[3];
static int TRAVEL_TIMES[3][MAX_NODES][MAX_NODES];
static double COSTS[3][MAX_NODES][MAX_NODES];
static int EARLIEST_TW[3][MAX_NODES];
static int LATEST_TW[3][MAX_NODES];
static int ADJ[3][MAX_NODES][MAX_NODES];
static int DEMANDS[MAX_NODES];

struct Label {
  vector<int> S;
  int T;
  double Z;

  Label() : S(vector<int>(0)), T(0), Z(0) {}
  Label(vector<int> s, double t, double z) : S(s), T(t), Z(z) {}

  Label extend(int next, double t, double z) {
    vector<int> new_S = S;
    new_S.push_back(next);
    Label new_label = {new_S, t, z};
    return new_label;
  }

  bool contains(int x, bool reverse = false) {
    if (S.size() == 0) return false;

    bool b = false;
    if (reverse) {
      for (int i = S.size() - 1; i >= 0; i--) {
        if (S[i] == x) return true;
      }
    } else {
      for (int i : S) {
        if (i == x) return true;
      }
    }
    return b;
  }

  vector<int> getPickupNodes(int n) {
    if (S.size() == 0) return vector<int>(0);

    vector<int> nodes = S;
    while (nodes[nodes.size() - 1] >= n) nodes.pop_back();
    return nodes;
  }
};

struct Route {
  int rider_index;
  int n_ord;
  vector<int> shop_seq;
  vector<int> d_seq;
  double cost;
  size_t optimal_hash = 0;

  Route(int ridx, int n) : rider_index(ridx), n_ord(n), cost(-1) {}

  Route(int ridx, int n, double c) : rider_index(ridx), n_ord(n), cost(c) {
    cost = -1;
  }

  Route(const Route& r)
      : rider_index(r.rider_index), n_ord(r.n_ord), cost(r.cost) {
    if (n_ord > 0) {
      shop_seq = vector<int>(n_ord, 0);
      d_seq = vector<int>(n_ord, 0);

      for (int i = 0; i < n_ord; i++) {
        shop_seq[i] = r.shop_seq[i];
        d_seq[i] = r.d_seq[i];
      }
    } else {
      shop_seq = vector<int>();
      d_seq = vector<int>();
    }
  }

  Route(int ridx, vector<int> ps, vector<int> ds)
      : rider_index(ridx),
        n_ord(ps.size()),
        cost(-1),
        shop_seq(ps),
        d_seq(ds) {}

  Route(int ridx, int n, double c, vector<int> ps, vector<int> ds)
      : rider_index(ridx), n_ord(n), cost(c), shop_seq(ps), d_seq(ds) {}

  Route(int ridx, vector<int> seq) : rider_index(ridx), cost(-1) {
    n_ord = seq.size() / 2;
    shop_seq = vector<int>(seq.begin(), seq.begin() + n_ord);
    d_seq = vector<int>(seq.begin() + n_ord, seq.end());
  }

  ~Route() {
    shop_seq.clear();
    d_seq.clear();
    vector<int>().swap(shop_seq);
    vector<int>().swap(d_seq);
  }

  void removeOrder(int order_to_remove) {
    if (n_ord == 1 && order_to_remove == shop_seq[0]) {
      shop_seq = vector<int>();
      d_seq = vector<int>();
      n_ord = 0;
      cost = -1;
      return;
    } else if (n_ord == 1 && order_to_remove != shop_seq[0]) {
      throw TaskAbortException("Cannot found the item @ _removeOrder");
    }

    int pos_p = -1;
    int pos_d = -1;

    for (int i = 0; i < n_ord; i++) {
      if (shop_seq[i] == order_to_remove) pos_p = i;
      if (d_seq[i] == N_ORDERS + order_to_remove) pos_d = i;
    }

    if (pos_p >= 0 && pos_d >= 0) {
      shop_seq.erase(shop_seq.begin() + pos_p);
      d_seq.erase(d_seq.begin() + pos_d);
      cost = -1;
      n_ord--;

      if (n_ord == 0) {
        shop_seq = vector<int>();
        d_seq = vector<int>();
      } else {
        shop_seq.shrink_to_fit();
        d_seq.shrink_to_fit();
      }
    } else {
      throw TaskAbortException("Cannot found the item @ _removeOrder");
    }
  }

  void insertOrder(int n_orders, int order_to_insert, int pos_p, int pos_d) {
    shop_seq.insert(shop_seq.begin() + pos_p, order_to_insert);
    d_seq.insert(d_seq.begin() + pos_d, n_orders + order_to_insert);
    n_ord++;
    cost = -1;
    shop_seq.shrink_to_fit();
    d_seq.shrink_to_fit();
  }

  void setFromSequence(vector<int>& seq) {
    n_ord = seq.size() / 2;

    shop_seq = vector<int>(n_ord);
    d_seq = vector<int>(n_ord);

    for (int i = 0; i < n_ord; i++) {
      shop_seq[i] = seq[i];
      d_seq[i] = seq[n_ord + i];
    }
    cost = -1;
  }

  double calculateCost() {
    int fc = FIXED_COST[rider_index];
    double(&costs)[MAX_NODES][MAX_NODES] = COSTS[rider_index];

    if (cost <= 0) {
      double _cost = fc + costs[shop_seq[n_ord - 1]][d_seq[0]];
      for (int i = 0; i < n_ord - 1; i++) {
        _cost += costs[shop_seq[i]][shop_seq[i + 1]];
        _cost += costs[d_seq[i]][d_seq[i + 1]];
      }
      cost = _cost;
    }
    return cost;
  }

  void reorderOptimally() {
    int n = n_ord;
    int N = 2 * n;
    int(&t)[MAX_NODES][MAX_NODES] = TRAVEL_TIMES[rider_index];
    double(&c)[MAX_NODES][MAX_NODES] = COSTS[rider_index];
    int(&adj_mat)[MAX_NODES][MAX_NODES] = ADJ[rider_index];
    int(&a)[MAX_NODES] = EARLIEST_TW[rider_index];
    int(&b)[MAX_NODES] = LATEST_TW[rider_index];
    int s = SERVICE_TIME[rider_index];

    vector<int> orders = shop_seq;
    vector<int> original_sequence = vector<int>(N);
    for (int i = 0; i < n; i++) {
      original_sequence[i] = shop_seq[i];
      original_sequence[n + i] = d_seq[i];
    }

    vector<vector<int>> _t = vector<vector<int>>(N, vector<int>(N));
    vector<vector<int>> A = vector<vector<int>>(N, vector<int>(N));
    vector<vector<double>> _c = vector<vector<double>>(N, vector<double>(N));

    vector<int> _a = vector<int>(N);
    vector<int> _b = vector<int>(N);

    for (int i = 0; i < N; i++) {
      _a[i] = a[original_sequence[i]];
      _b[i] = b[original_sequence[i]];
      for (int j = 0; j < N; j++) {
        _t[i][j] = t[original_sequence[i]][original_sequence[j]];
        _c[i][j] = c[original_sequence[i]][original_sequence[j]];
        A[i][j] = adj_mat[original_sequence[i]][original_sequence[j]];
      }
    }
    queue<Label> prev_labels;
    queue<Label> new_labels;
    queue<Label> feasible_labels;
    for (int i = 0; i < n; i++) {
      prev_labels.emplace(vector<int>(1, i), _a[i], 0);
    }

    for (int K = 1; K < n; K++) {
      while (!prev_labels.empty()) {
        Label curr_label = prev_labels.front();
        prev_labels.pop();

        const int last = curr_label.S[curr_label.S.size() - 1];

        for (int next = 0; next < n; next++) {
          if (last == next) continue;
          if (A[last][next] == 0) continue;
          if (curr_label.contains(next)) continue;

          const int _T = max(_a[next], curr_label.T + s + _t[last][next]);
          const double _Z = curr_label.Z + _c[last][next];

          if (_T > _b[next]) continue;
          Label new_label = curr_label.extend(next, _T, _Z);

          bool prop1 = false;
          for (int i : new_label.S) {
            if (_T + _t[next][n + i] + s > _b[n + i]) {
              prop1 = true;
              break;
            }
          }
          if (prop1) continue;

          bool prop2 = false;
          if (new_label.S.size() > 1) {
            for (int i : new_label.S) {
              for (int j : new_label.S) {
                if (i == j) continue;

                int _T1 = _T + _t[next][n + i] + s;
                int _T2 = _T + _t[next][n + j] + s;
                if ((_T1 > _b[n + i] ||
                     _T1 + _t[n + i][n + j] + s > _b[n + j]) &&
                    (_T2 > _b[n + j] ||
                     _T2 + _t[n + j][n + i] + s > _b[n + i])) {
                  prop2 = true;
                  break;
                }
              }
              if (prop2) break;
            }
          }
          if (prop2) continue;

          new_labels.push(new_label);
        }
      }

      prev_labels = new_labels;
      while (!new_labels.empty()) new_labels.pop();

      if (prev_labels.size() == 0) break;
    }

    for (int K = 0; K < n; K++) {
      while (!prev_labels.empty()) {
        Label curr_label = prev_labels.front();
        prev_labels.pop();

        const int last = curr_label.S[curr_label.S.size() - 1];

        vector<int> p_nodes = curr_label.getPickupNodes(n);

        for (int visited_p : p_nodes) {
          int next = visited_p + n;

          if (A[last][next] == 0) continue;
          if (curr_label.contains(next, true)) continue;

          const int _T = max(_a[next], curr_label.T + s + _t[last][next]);
          const double _Z = curr_label.Z + _c[last][next];

          if (_T > _b[next]) continue;
          Label new_label = curr_label.extend(next, _T, _Z);

          if (new_label.S.size() + 1 <= N) {
            bool prop1 = false;
            for (int i : new_label.S) {
              if (i >= n) break;
              if (new_label.contains(n + i, true)) continue;

              if (_T + _t[next][n + i] + s > _b[n + i]) {
                prop1 = true;
                break;
              }
            }
            if (prop1) continue;
          }

          if (new_label.S.size() + 2 <= N) {
            bool prop2 = false;
            if (new_label.S.size() > 1) {
              for (int i : new_label.S) {
                if (i >= n) break;
                if (new_label.contains(n + i, true)) continue;
                for (int j : new_label.S) {
                  if (i == j) continue;
                  if (j >= n) break;
                  if (new_label.contains(n + j, true)) continue;

                  int _T1 = _T + _t[next][n + i] + s;
                  int _T2 = _T + _t[next][n + j] + s;
                  if ((_T1 > _b[n + i] ||
                       _T1 + _t[n + i][n + j] + s > _b[n + j]) &&
                      (_T2 > _b[n + j] ||
                       _T2 + _t[n + j][n + i] + s > _b[n + i])) {
                    prop2 = true;
                    break;
                  }
                }
                if (prop2) break;
              }
            }
            if (prop2) continue;
          }

          if (new_label.S.size() == N) {
            feasible_labels.push(new_label);
          } else {
            new_labels.push(new_label);
          }
        }
      }

      prev_labels = new_labels;
      while (!new_labels.empty()) new_labels.pop();

      if (prev_labels.size() == 0) break;
    }

    if (feasible_labels.size() == 0) {
      throw TaskAbortException(
          "_reorderOptimallyLarge(): Failed to find any feasible sequence!!\n");
    }

    vector<int> opt_seq;
    double best_cost = -1;

    while (!feasible_labels.empty()) {
      if (best_cost < 0 || feasible_labels.front().Z < best_cost) {
        best_cost = feasible_labels.front().Z;
        opt_seq = feasible_labels.front().S;
      }
      feasible_labels.pop();
    }

    for (int i = 0; i < n; i++) {
      shop_seq[i] = original_sequence[opt_seq[i]];
      d_seq[i] = original_sequence[opt_seq[n + i]];
    }

    optimal_hash = hash();
    cost = -1;
  }

  size_t hash() { return hashWithRiderIdx(rider_index); }

  size_t hashWithRiderIdx(int ridx) {
    std::size_t seed = 42;
    seed ^= std::hash<int>()(ridx) + 0x9e3779b9 + (seed << 6) + (seed >> 2);

    seed ^= HashIntegers(shop_seq);
    seed ^= HashIntegers(d_seq);

    return seed;
  }

  size_t orderset_hash() {
    std::size_t seed =
        std::hash<int>()(rider_index) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
    seed ^= HashIntegerSet(shop_seq);
    return seed;
  }
};

struct Solution {
  int n_split;
  vector<Route> routes;
  vector<int> available_orders;
  vector<int> rider_used = {0, 0, 0};  // 사용된 라이더 수
  gp_hash_table<int, int> order_route_map;

  vector<int> request_bank;
  double total_cost;

  Solution() {}

  Solution(vector<int> avlb_ords, vector<Route> r)
      : available_orders(avlb_ords), routes(r), total_cost(-1) {
    n_split = avlb_ords.size();
    for (int o : available_orders) {
      int route_idx = -1;

      for (int i = 0; i < routes.size(); i++) {
        bool is_included = false;
        for (int j = 0; j < routes[i].n_ord; j++) {
          if (routes[i].shop_seq[j] == o) {
            is_included = true;
            route_idx = i;
            break;
          }
        }
        if (is_included) {
          route_idx = i;
          break;
        }
      }

      order_route_map.insert(make_pair(o, route_idx));
      if (route_idx == -1) {
        request_bank.push_back(o);
      }
    }
  }

  ~Solution() {
    routes.clear();
    available_orders.clear();
    request_bank.clear();
    order_route_map.clear();

    vector<Route>().swap(routes);
    vector<int>().swap(available_orders);
    vector<int>().swap(request_bank);
    gp_hash_table<int, int>().swap(order_route_map);
  }

  // initsol 전용으로 추가
  void UpdateRiderUsed() {
    rider_used = {0, 0, 0};
    for (auto& route : routes) rider_used[route.rider_index]++;
  }

  double calculateTotalCost() {
    double tc = 0;
    for (int i = 0; i < routes.size(); i++) {
      tc += routes[i].calculateCost();
    }
    total_cost = tc;
    return total_cost;
  }

  double reorderOptimally() {
    for (int i = 0; i < routes.size(); i++) {
      routes[i].reorderOptimally();
    }
    return calculateTotalCost();
  }

  bool isEveryAssigned() {
    bool b = true;
    for (int i = 1; i <= N_ORDERS; i++) {
      b &= order_route_map[i] != -1;
    }
    return b;
  }

  void cleanEmpties() {
    vector<int> routes_to_remove;
    for (int i = 0; i < routes.size(); i++) {
      if (routes[i].n_ord == 0) {
        routes_to_remove.push_back(i);
      }
    }
    int cnt = 0;
    for (int i = 0; i < routes_to_remove.size(); i++) {
      int rtr = routes_to_remove[i];
      int idx = rtr - cnt;
      routes.erase(routes.begin() + idx);
      cnt++;
    }

    resetMap();
    UpdateRiderUsed();
  }

  void createNewRoute(int oti, int rider_index) {
    int route_idx = routes.size();

    routes.emplace_back(rider_index, 1, -1);

    routes[route_idx].shop_seq.push_back(oti);
    routes[route_idx].d_seq.push_back(N_ORDERS + oti);
    order_route_map[oti] = route_idx;
    UpdateRiderUsed();
  }

  void removeOrder(int order_to_remove, bool reqbank = true) {
    int route_idx = order_route_map[order_to_remove];
    if (route_idx >= 0) {
      routes[route_idx].removeOrder(order_to_remove);
      if (reqbank) request_bank.push_back(order_to_remove);
      order_route_map[order_to_remove] = -1;
      cleanEmpties();
    } else {
      throw TaskAbortException(
          "trying to remove an already removed order @ __removeOrder");
    }
  }

  void insertOrder(int route_idx, int order_to_insert, int pos_p, int pos_d) {
    routes[route_idx].insertOrder(N_ORDERS, order_to_insert, pos_p, pos_d);
    order_route_map[order_to_insert] = route_idx;
  }

  queue<int> removeRoute(int route_idx, bool reset_ORmap = true) {
    queue<int> orders;
    for (int i : routes[route_idx].shop_seq) {
      orders.push(i);
      order_route_map[i] = -1;
    }
    routes.erase(routes.begin() + route_idx);
    if (reset_ORmap) resetMap();
    return orders;
  }

  void resetMap() {
    for (int r = 0; r < routes.size(); r++) {
      for (int order : routes[r].shop_seq) order_route_map[order] = r;
    }
  }

  size_t hash() {
    std::size_t seed = 0;

    for (const Route& route : routes) {
      std::size_t route_hash = 0;
      for (int p : route.shop_seq) {
        route_hash ^= std::hash<int>()(p) + 0x9e3779b9 + (route_hash << 6) +
                      (route_hash >> 2);
      }
      for (int d : route.d_seq) {
        route_hash ^= std::hash<int>()(d) + 0x9e3779b9 + (route_hash << 6) +
                      (route_hash >> 2);
      }
      seed ^= route_hash + 0x9e3779b9 + (seed << 6) + (seed >> 2);
    }

    return seed;
  }

  void dropUnavailables() {
    gp_hash_table<int, null_type> avlb_set;
    for (int i : available_orders) avlb_set.insert(i);

    for (Route& route : routes) {
      vector<int> route_orders = route.shop_seq;
      for (int order : route_orders) {
        if (avlb_set.find(order) == avlb_set.end()) {
          route.removeOrder(order);
        }
      }
    }

    cleanEmpties();
  }
};

void RemoveRandom(Solution& curr_sol, int q) {
  curr_sol.total_cost = -1;

  if (q == 1) {
    int order_to_remove = curr_sol.available_orders[randint(curr_sol.n_split)];
    while (curr_sol.order_route_map[order_to_remove] == -1)
      order_to_remove = curr_sol.available_orders[randint(curr_sol.n_split)];

    curr_sol.removeOrder(order_to_remove);
  } else if (q > 1) {
    gp_hash_table<int, null_type> reqbank_set;
    for (int i : curr_sol.request_bank) reqbank_set.insert(i);

    gp_hash_table<int, null_type> otr_set;
    gp_hash_table<int, null_type> removed_set;
    vector<int> random_range = RandomRange(curr_sol.n_split);
    for (int i : random_range) {
      int order = curr_sol.available_orders[i];
      if (reqbank_set.find(order) == reqbank_set.end()) {
        otr_set.insert(order);
        if (otr_set.size() >= q) break;
      }
    }

    priority_queue<int> routes_to_remove;
    for (int i = 0; i < curr_sol.routes.size(); i++) {
      bool any_remains = false;
      for (int j : curr_sol.routes[i].shop_seq) {
        if (otr_set.find(j) == otr_set.end()) {
          any_remains = true;
          break;
        }
      }

      if (!any_remains) routes_to_remove.push(i);
    }

    while (!routes_to_remove.empty()) {
      int route_idx = routes_to_remove.top();
      routes_to_remove.pop();

      queue<int> removed_orders = curr_sol.removeRoute(route_idx, false);
      while (!removed_orders.empty()) {
        curr_sol.request_bank.push_back(removed_orders.front());
        removed_set.insert(removed_orders.front());
        removed_orders.pop();
      }
    }
    curr_sol.resetMap();

    for (const int& elem : otr_set) {
      if (removed_set.find(elem) != removed_set.end()) continue;

      curr_sol.removeOrder(elem);
    }
  } else {
    throw TaskAbortException("RemoveRandom(): Invalid Argument `q`");
  }
}

void InsertNaiveGreedy(Solution& curr_sol) {
  // initsol 생성할 땐 shuffle하지 않음.
  // random_shuffle(curr_sol.request_bank.begin(), curr_sol.request_bank.end());

  vector<int> remains;

  while (curr_sol.request_bank.size() > 0) {
    int oti = curr_sol.request_bank.back();
    curr_sol.request_bank.pop_back();

    int best_route_idx;
    int best_pos_p;
    int best_pos_d;
    double best_cost_diff = -1;

    for (int it_route = 0; it_route < curr_sol.routes.size(); it_route++) {
      Route& route = curr_sol.routes[it_route];

      // init sol은 최대 2개만 포함하는 번들만으로 구성한다.
      if (route.n_ord > 1) continue;

      int r = route.rider_index;
      int(&travel_time)[MAX_NODES][MAX_NODES] = TRAVEL_TIMES[r];
      double(&costs)[MAX_NODES][MAX_NODES] = COSTS[r];
      int(&a)[MAX_NODES] = EARLIEST_TW[r];
      int(&b)[MAX_NODES] = LATEST_TW[r];

      int s = SERVICE_TIME[r];
      int C = CAPA[r];
      int n_ord = route.n_ord;
      double cost_before = route.calculateCost();

      int loads = DEMANDS[oti];
      for (int i = 0; i < n_ord; i++) loads += DEMANDS[route.shop_seq[i]];
      if (loads > C) continue;

      int len = 2 * n_ord + 2 + 2;
      vector<int> seq = vector<int>(len);
      seq[0] = 0;
      seq[1] = oti;
      seq[n_ord + 2] = N_ORDERS + oti;
      seq[len - 1] = 2 * N_ORDERS + 1;
      for (int i = 0; i < n_ord; i++) {
        seq[2 + i] = route.shop_seq[i];
        seq[n_ord + 3 + i] = route.d_seq[i];
      }

      int curr_pos_p = 1, curr_pos_d = n_ord + 2;
      do {
        double _cost = 0.0;
        for (int i = 0; i < len - 1; i++) _cost += costs[seq[i]][seq[i + 1]];

        double cost_diff_seq = _cost - cost_before;

        int tau = a[seq[1]];
        for (int it_seq = 2; it_seq < len - 1; it_seq++) {
          int arrival_time =
              tau + travel_time[seq[it_seq - 1]][seq[it_seq]] + s;
          if (arrival_time > b[seq[it_seq]]) {
            tau = -1;
            break;
          }
          if (arrival_time < a[seq[it_seq]]) arrival_time = a[seq[it_seq]];
          tau = arrival_time;
        }

        if (tau > 0) {
          if ((cost_diff_seq < best_cost_diff || best_cost_diff < 0)) {
            best_route_idx = it_route;
            best_pos_p = curr_pos_p - 1;
            best_pos_d = curr_pos_d - (n_ord + 2);
            best_cost_diff = cost_diff_seq;
          }
        }

        int tmp_last_p = curr_pos_p;
        int tmp_last_d = curr_pos_d;
        curr_pos_p++;
        if (curr_pos_p == n_ord + 2) {
          curr_pos_d++;
          if (curr_pos_d <= len - 2) curr_pos_p = 1;
        }
        if (curr_pos_d <= len - 2) {
          if (curr_pos_p == 1 && tmp_last_p == n_ord + 1) {
            for (int it_seq = 0; it_seq < n_ord; it_seq++) {
              seq[n_ord + 1 - it_seq] = seq[n_ord + 1 - (it_seq + 1)];
            }
            seq[1] = oti;
          } else {
            int tmp = seq[curr_pos_p];
            seq[curr_pos_p] = seq[tmp_last_p];
            seq[tmp_last_p] = tmp;
          }

          int tmp = seq[curr_pos_d];
          seq[curr_pos_d] = seq[tmp_last_d];
          seq[tmp_last_d] = tmp;
        }
      } while (curr_pos_p <= n_ord + 1 && curr_pos_d <= len - 2);
    }

    if (best_cost_diff > 0) {
      curr_sol.insertOrder(best_route_idx, oti, best_pos_p, best_pos_d);
    } else {
      vector<bool> is_feasible;
      for (int r = 0; r < 3; r++) {
        // init sol은 feasble해야 하므로, rider의 available number를 확인한다.
        is_feasible.push_back(ADJ[r][oti][N_ORDERS + oti] == 1 &&
                              curr_sol.rider_used[r] < N_AVLB[r]);
      }
      vector<int> feasible_indices;
      for (int r = 0; r < 3; r++) {
        if (is_feasible[r]) feasible_indices.push_back(r);
      }

      if (feasible_indices.size() > 0) {
        int r = feasible_indices[randint(feasible_indices.size())];
        curr_sol.createNewRoute(oti, r);
      } else {
        remains.push_back(oti);
      }
    }
  }

  if (remains.size() > 0) {
    curr_sol.request_bank = remains;
  } else {
    curr_sol.request_bank.clear();
  }
}

void InitRiderCostants(int* n_availables, int* capas, int* service_times,
                       double* fixed_costs, int* a, int* b, int* travel_times,
                       double* costs) {
  for (int r = 0; r < 3; r++) {
    N_AVLB[r] = n_availables[r];
    CAPA[r] = capas[r];
    SERVICE_TIME[r] = service_times[r];
    FIXED_COST[r] = (int)fixed_costs[r];
  }

  int N2 = N_NODES * N_NODES;
#pragma omp parallel for num_threads(3)
  for (int r = 0; r < 3; r++) {
    for (int i = 0; i < N_NODES; i++) {
      EARLIEST_TW[r][i] = a[r * N_NODES + i];
      LATEST_TW[r][i] = b[r * N_NODES + i];
    }

    for (int i = 0; i < N_NODES; i++) {
      for (int j = 0; j < N_NODES; j++) {
        TRAVEL_TIMES[r][i][j] = travel_times[r * N2 + i * N_NODES + j];
        COSTS[r][i][j] = costs[r * N2 + i * N_NODES + j];
      }
    }
  }
}

void ConstructNetwork() {
#pragma omp parallel for num_threads(3)
  for (int r = 0; r < 3; r++) {
    int(&t)[MAX_NODES][MAX_NODES] = TRAVEL_TIMES[r];
    int(&a)[MAX_NODES] = EARLIEST_TW[r];
    int(&b)[MAX_NODES] = LATEST_TW[r];
    int s = SERVICE_TIME[r];
    int C = CAPA[r];

    auto TSum4 = [&](int i1, int i2, int i3, int i4) -> int {
      return t[i1][i2] + t[i2][i3] + t[i3][i4];
    };

    for (int i = 0; i < MAX_NODES; i++) {
      for (int j = 0; j < MAX_NODES; j++) {
        ADJ[r][i][j] = 1;
      }
    }

    for (int i = 0; i < N_NODES; i++) ADJ[r][i][i] = 0;

    for (int i = 1; i <= N_ORDERS; i++) {
      ADJ[r][0][N_ORDERS + i] = 0;
      ADJ[r][N_ORDERS + i][i] = 0;
      ADJ[r][N_NODES - 1][0] = 0;
      ADJ[r][N_NODES - 1][i] = 0;
      ADJ[r][N_NODES - 1][(N_ORDERS + i)] = 0;
      ADJ[r][N_NODES - 1][(N_ORDERS + i)] = 0;

      ADJ[r][i][N_NODES - 1] = 0;

      ADJ[r][i][0] = 0;
      ADJ[r][N_ORDERS + i][0] = 0;
    }

    for (int i = 1; i < N_NODES - 1; i++) {
      for (int j = 1; j < N_NODES - 1; j++) {
        if (i == j) continue;
        if (a[i] + s + t[i][j] > b[j]) ADJ[r][i][j] = 0;
      }
    }

    for (int i = 1; i <= N_ORDERS; i++) {
      for (int j = 1; j <= N_ORDERS; j++) {
        if (i == j) continue;
        ADJ[r][N_ORDERS + i][j] = 0;

        if (DEMANDS[i] + DEMANDS[j] > C) {
          ADJ[r][i][j] = 0;
          ADJ[r][j][i] = 0;
          ADJ[r][i][N_ORDERS + j] = 0;
          ADJ[r][j][N_ORDERS + i] = 0;
          ADJ[r][N_ORDERS + i][N_ORDERS + j] = 0;
          ADJ[r][N_ORDERS + j][N_ORDERS + i] = 0;
        }

        if (a[j] + s + TSum4(j, i, N_ORDERS + j, N_ORDERS + i) >
            b[N_ORDERS + i])
          ADJ[r][i][N_ORDERS + j] = 0;

        if (a[i] + s + TSum4(i, j, N_ORDERS + i, N_ORDERS + j) >
                b[N_ORDERS + j] &&
            a[i] + s + TSum4(i, j, N_ORDERS + j, N_ORDERS + i) >
                b[N_ORDERS + i])
          ADJ[r][i][j] = 0;

        if (a[i] + s + TSum4(i, j, N_ORDERS + i, N_ORDERS + j) >
                b[N_ORDERS + j] &&
            a[j] + s + TSum4(j, i, N_ORDERS + i, N_ORDERS + j) >
                b[N_ORDERS + j])
          ADJ[r][N_ORDERS + i][N_ORDERS + j] = 0;
      }
    }

    for (int i = 1; i <= N_ORDERS; i++) {
      if (a[i] + s + t[i][N_ORDERS + i] > b[N_ORDERS + i] || DEMANDS[i] > C) {
        for (int j = 1; j <= N_ORDERS; j++) {
          if (i == j) continue;
          ADJ[r][i][j] = 0;
          ADJ[r][j][i] = 0;
          ADJ[r][N_ORDERS + i][j] = 0;
          ADJ[r][j][N_ORDERS + i] = 0;
        }
        ADJ[r][0][i] = 0;
        ADJ[r][N_ORDERS + i][N_NODES - 1] = 0;
        ADJ[r][i][N_ORDERS + i] = 0;
      }
    }
  }
}

// 만약 어떤 에러가 발생하게 된다면 이 함수로부터 무조건 feasible한 해를
// 반환하도록 한다.
int* MakeWorstIntialSolution() {
  int total_size = 3 + 4 * N_ORDERS;
  int* ret_sol = (int*)malloc(sizeof(int) * total_size);
  ret_sol[0] = total_size;
  ret_sol[1] = N_ORDERS;
  int pos = 2;
  for (int i = 1; i <= N_ORDERS; i++) {
    ret_sol[pos++] = 1;

    if (DEMANDS[i] > CAPA[0])
      ret_sol[pos++] = 2;
    else if (ADJ[2][i][N_ORDERS + i] == 0)
      ret_sol[pos++] = 0;
    else
      ret_sol[pos++] = 2;

    ret_sol[pos++] = i;
    ret_sol[pos++] = i;
  }
  ret_sol[pos] = -1;

  return ret_sol;
}

extern "C" int* MAIN(int n, int* l, int* n_availables, int* capas,
                     int* service_times, double* fixed_costs, int* travel_times,
                     double* costs, int* a, int* b, double timelimit) {
  auto st = NOW();

  N_ORDERS = n;
  N_NODES = 2 * n + 2;

  for (int i = 0; i < N_NODES; i++) DEMANDS[i] = l[i];

  InitRiderCostants(n_availables, capas, service_times, fixed_costs, a, b,
                    travel_times, costs);
  ConstructNetwork();

  // 초기해 생성 시도
  try {
    vector<int> orders = Range(1, N_ORDERS + 1);
    Solution sol = {orders, vector<Route>()};
    InsertNaiveGreedy(sol);
    sol.reorderOptimally();

    for (int i = 0; i < 5; i++) {
      for (int x : orders) {
        sol.removeOrder(x);
        InsertNaiveGreedy(sol);
      }
    }

    while (!sol.isEveryAssigned() && timelimit > Elapsed(st)) {
      RemoveRandom(sol, 0.5 * N_ORDERS);
      InsertNaiveGreedy(sol);
    }
    if (!sol.isEveryAssigned()) {
      return MakeWorstIntialSolution();
    }
    sol.reorderOptimally();
    int total_size = 3;
    for (auto& route : sol.routes) total_size += route.n_ord * 2 + 2;
    int* ret_sol = (int*)malloc(sizeof(int) * total_size);
    ret_sol[0] = total_size;
    ret_sol[1] = sol.routes.size();
    int pos = 2;
    for (auto& route : sol.routes) {
      ret_sol[pos++] = route.n_ord;
      ret_sol[pos++] = route.rider_index;
      for (int x : route.shop_seq) ret_sol[pos++] = x;
      for (int x : route.d_seq) ret_sol[pos++] = x - N_ORDERS;
    }
    ret_sol[pos] = -1;

    return ret_sol;

  } catch (...) {
    return MakeWorstIntialSolution();
  }
}

extern "C" void FreeRetPtrs(int* ret) {
  free(ret);
  ret = nullptr;
}