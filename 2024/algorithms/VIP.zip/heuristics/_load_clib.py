import os
import config
import ctypes
import numpy as np


C_HEURISTIC = None
C_INITSOL = None
C_FREE = None
C_FREE2 = None
FLAGS = ["C_CONTIGUOUS", "ALIGNED"]
HEUR_SO_PATH = os.path.join(config.SO_DIR, "libheuristic.so")
INITSOL_SO_PATH = os.path.join(config.SO_DIR, "libinitsol.so")


def _init_heur():
    global HEUR_SO_PATH, FLAGS, C_HEURISTIC, C_FREE

    C_INT_PTR = ctypes.POINTER(ctypes.c_int32)
    C_INT_PTRPTR = ctypes.POINTER(C_INT_PTR)
    C_INT_PTRPTRPTR = ctypes.POINTER(C_INT_PTRPTR)

    lib = ctypes.cdll.LoadLibrary(HEUR_SO_PATH)
    func = lib.MAIN
    func.argtypes = [
        ctypes.c_int,  # n
        np.ctypeslib.ndpointer(np.int32, ndim=1, flags=FLAGS),  # l
        np.ctypeslib.ndpointer(np.int32, ndim=1, flags=FLAGS),  # n_availables
        np.ctypeslib.ndpointer(np.int32, ndim=1, flags=FLAGS),  # capas
        np.ctypeslib.ndpointer(np.int32, ndim=1, flags=FLAGS),  # service_times
        np.ctypeslib.ndpointer(np.float64, ndim=1, flags=FLAGS),  # fixed_costs
        np.ctypeslib.ndpointer(np.int32, ndim=3, flags=FLAGS),  # travel_times
        np.ctypeslib.ndpointer(np.float64, ndim=3, flags=FLAGS),  # costs
        np.ctypeslib.ndpointer(np.int32, ndim=2, flags=FLAGS),  # a
        np.ctypeslib.ndpointer(np.int32, ndim=2, flags=FLAGS),  # b
        np.ctypeslib.ndpointer(np.int32, ndim=1, flags=FLAGS),  # init_sol
        ctypes.c_double,  # timelimit
    ]
    func.restype = C_INT_PTRPTRPTR
    C_HEURISTIC = func

    C_FREE = lib.FreeRetPtrs
    C_FREE.argtypes = [ctypes.c_int, C_INT_PTRPTRPTR]
    C_FREE.restype = None


def _init_initsol():
    global INITSOL_SO_PATH, FLAGS, C_INITSOL, C_FREE2

    C_INT_PTR = ctypes.POINTER(ctypes.c_int32)

    lib = ctypes.cdll.LoadLibrary(INITSOL_SO_PATH)
    func = lib.MAIN
    func.argtypes = [
        ctypes.c_int,  # n
        np.ctypeslib.ndpointer(np.int32, ndim=1, flags=FLAGS),  # l
        np.ctypeslib.ndpointer(np.int32, ndim=1, flags=FLAGS),  # n_availables
        np.ctypeslib.ndpointer(np.int32, ndim=1, flags=FLAGS),  # capas
        np.ctypeslib.ndpointer(np.int32, ndim=1, flags=FLAGS),  # service_times
        np.ctypeslib.ndpointer(np.float64, ndim=1, flags=FLAGS),  # fixed_costs
        np.ctypeslib.ndpointer(np.int32, ndim=3, flags=FLAGS),  # travel_times
        np.ctypeslib.ndpointer(np.float64, ndim=3, flags=FLAGS),  # costs
        np.ctypeslib.ndpointer(np.int32, ndim=2, flags=FLAGS),  # a
        np.ctypeslib.ndpointer(np.int32, ndim=2, flags=FLAGS),  # b
        ctypes.c_double,  # timelimit
    ]
    func.restype = C_INT_PTR
    C_INITSOL = func

    C_FREE2 = lib.FreeRetPtrs
    C_FREE2.argtypes = [C_INT_PTR]
    C_FREE2.restype = None


def _init():
    _init_heur()
    _init_initsol()
