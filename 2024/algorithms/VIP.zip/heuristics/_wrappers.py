from . import _load_clib
import ctypes
import numpy as np

_load_clib._init()


def heuristic(
    n: int,
    l: list[int],
    a: list[int],
    b: list[int],
    travel_times: np.ndarray,
    costs: np.ndarray,
    capas: list[int],
    fixed_costs: list[float],
    service_times: list[int],
    avlbs: list[int],
    solution: list[int],
    timelimit: float,
):
    assert _load_clib.C_HEURISTIC is not None
    assert _load_clib.C_FREE is not None

    ret = _load_clib.C_HEURISTIC(
        n,  # n
        np.array(l, dtype=np.int32),  # l
        np.array(avlbs, dtype=np.int32),  # n_availables
        np.array(capas, dtype=np.int32),  # capas
        np.array(service_times, dtype=np.int32),  # service_times
        np.array(fixed_costs, dtype=np.float64),  # fixed_costs
        np.array(travel_times, dtype=np.int32),  # travel_times
        np.array(costs, dtype=np.float64),  # costs
        np.array(a, dtype=np.int32),  # a
        np.array(b, dtype=np.int32),  # b
        np.array(solution, dtype=np.int32),  # init_sol
        ctypes.c_double(timelimit),
    )
    # print("at python got return")

    n_routes = ret[0][0][0]
    offset = ret[0][0][1]
    prob_size = ret[0][0][2] / 1000000
    all_routes = [ret[1][i][1 : ret[1][i][0] + 1] for i in range(n_routes)]
    contained_orders = [np.array(x[: len(x) // 2], dtype=int) - 1 for x in all_routes]
    route_costs = ret[2][0][:n_routes]
    rk_matching = ret[3][0][:n_routes]
    a_dict = {i: {x: 1.0 for x in ret[4][i][1 : ret[4][i][0] + 1]} for i in range(n)}
    r_dict = {i: {x: 1.0 for x in ret[5][i][1 : ret[5][i][0] + 1]} for i in range(3)}

    _load_clib.C_FREE(n, ret)

    return {
        "offset": offset,
        "prob_size": prob_size,
        "routes": all_routes,
        "costs": route_costs,
        "rk_matching": rk_matching,
        "a_dict": a_dict,
        "r_dict": r_dict,
        "contained_orders": contained_orders,
    }


def get_initsol(
    n: int,
    l: list[int],
    a: list[int],
    b: list[int],
    travel_times: np.ndarray,
    costs: np.ndarray,
    capas: list[int],
    fixed_costs: list[float],
    service_times: list[int],
    avlbs: list[int],
    timelimit: float,
):
    assert _load_clib.C_INITSOL is not None
    assert _load_clib.C_FREE2 is not None

    ret = _load_clib.C_INITSOL(
        n,  # n
        np.array(l, dtype=np.int32),  # l
        np.array(avlbs, dtype=np.int32),  # n_availables
        np.array(capas, dtype=np.int32),  # capas
        np.array(service_times, dtype=np.int32),  # service_times
        np.array(fixed_costs, dtype=np.float64),  # fixed_costs
        np.array(travel_times, dtype=np.int32),  # travel_times
        np.array(costs, dtype=np.float64),  # costs
        np.array(a, dtype=np.int32),  # a
        np.array(b, dtype=np.int32),  # b
        ctypes.c_double(timelimit),
    )

    total_size = ret[0]
    sol = list(ret[:total_size])
    _load_clib.C_FREE2(ret)

    return sol
