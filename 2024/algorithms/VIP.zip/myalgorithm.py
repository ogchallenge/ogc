import os
import config

this_path = os.path.abspath(__file__)
config.SO_DIR = os.path.join(os.path.split(this_path)[0], "CLib/obj")

from util import *
import solver
import heuristics
import time

NAME = ""
TIME = ""


def make_time_window(
    n: int,
    travel_time: np.ndarray,
    readytime: np.ndarray,
    deadline: np.ndarray,
    service_time: float,
) -> tuple[np.ndarray]:
    """time window 생성 - 단일 차량에 대해
    depot를 포함한 2n+2개의 노드에 대한 time window를 반환한다.

    Parameters
    ----------
    n : integer
        주문 개수
    travel_time : (n,) array
        i-th item이 주문 i의 pickup node로부터 delivery node까지 이동하는 데 걸리는 시간
    readytime : (n,) array
        주문들의 readytime
    deadline : (n,) array
        주문들의 deadline

    Returns
    -------
    (2n+2,) array
        earliest time windows
    (2n+2,) array
        latest time windows
    """
    readytime = np.array(readytime)
    deadline = np.array(deadline)

    assert len(readytime) == len(deadline) == n
    assert readytime.shape == deadline.shape == travel_time.shape == (n,)

    a = np.zeros((2 * n + 2,), dtype=int)
    b = np.zeros((2 * n + 2,), dtype=int)

    a[0] = 0
    a[1 : n + 1] = readytime
    a[n + 1 : 2 * n + 1] = readytime + travel_time + service_time
    a[2 * n + 1] = 0

    b[1 : n + 1] = deadline - travel_time - service_time
    b[n + 1 : 2 * n + 1] = deadline
    b[0] = b.max()
    b[2 * n + 1] = b.max()

    return a, b


def convert_solution(sol: list[int]) -> list[list]:
    bundles = []
    pos = 2
    minus1 = lambda x: list(map(lambda y: y - 1, x))
    while sol[pos] != -1:
        n_ord = sol[pos]
        pos += 1
        rider = ["BIKE", "WALK", "CAR"][sol[pos]]
        pos += 1

        shop_seq = minus1(sol[pos : pos + n_ord])
        pos += n_ord
        dlv_seq = minus1(sol[pos : pos + n_ord])
        pos += n_ord
        bundles.append([rider, shop_seq, dlv_seq])
    return bundles


def algorithm(K, all_orders, all_riders, dist_mat, timelimit=60):

    available_time = timelimit - 1
    start_time = time.time()

    for r in all_riders:
        r.T = np.round(dist_mat / r.speed + r.service_time)

    assert all(r.type in ["WALK", "BIKE", "CAR"] for r in all_riders)

    # ------------- Custom algorithm code starts from here --------------#

    n = len(all_orders)
    m = 2 * n + 2
    READYTIME = [(order.order_time + order.cook_time) for order in all_orders]
    DEADLINE = [order.deadline for order in all_orders]
    DEMAND = np.array(
        [0]
        + [order.volume for order in all_orders]
        + [-order.volume for order in all_orders]
        + [0]
    )
    DIST = np.zeros((m, m), dtype=int)
    DIST[1:-1, 1:-1] = dist_mat

    n = len(all_orders)
    capas = [rider.capa for rider in all_riders]
    fixed_costs = [rider.fixed_cost for rider in all_riders]
    service_times = [rider.service_time for rider in all_riders]
    avlbs = [rider.available_number for rider in all_riders]

    travel_times = []
    costs = []
    a = []
    b = []
    for rider in all_riders:
        _costs = DIST * rider.var_cost / 100
        _costs[0, :] = rider.fixed_cost
        costs.append(_costs)
        travel_times.append(np.round(DIST / rider.speed).astype(int))

        t_order = dist_mat[np.arange(n), n + np.arange(n)] / rider.speed
        _a, _b = make_time_window(
            n, t_order, np.array(READYTIME), np.array(DEADLINE), rider.service_time
        )
        a.append(_a.astype(int))
        b.append(_b.astype(int))

    travel_times = np.stack(travel_times)
    costs = np.stack(costs)
    a = np.stack(a)
    b = np.stack(b)

    init_sol = heuristics.get_initsol(
        n,
        DEMAND,
        a,
        b,
        travel_times,
        costs,
        capas,
        fixed_costs,
        service_times,
        avlbs,
        timelimit=5,
    )

    try:
        ret = heuristics.heuristic(
            n,
            DEMAND,
            a,
            b,
            travel_times,
            costs,
            capas,
            fixed_costs,
            service_times,
            avlbs,
            init_sol,
            timelimit,
        )
        offset = ret["offset"]
        prob_size = ret["prob_size"]
        all_routes = ret["routes"]
        route_costs = ret["costs"]
        a_dict = ret["a_dict"]
        r_dict = ret["r_dict"]
        rk_matching = ret["rk_matching"]

        score = (len(all_routes) - offset) / n**2 / (timelimit / 60) * 100 * prob_size

        spp_time = available_time - (time.time() - start_time) - 1
        print("n_routes:", len(all_routes))

        if timelimit <= 20:
            spp_time = available_time - (time.time() - start_time) - 0.5
        elif timelimit >= 180:
            spp_time -= max(2, n / 1000) * 3
        elif timelimit >= 60:
            spp_time -= max(2, n / 1000) * 2
        else:
            spp_time -= 2

        if len(route_costs) > 500000:
            spp_time -= 1 + 0.35 * 1.5 * len(all_routes) / 1000000

        route_indices, Gap = solver.solve_SPP(
            n,
            route_costs,
            a_dict,
            r_dict,
            all_riders,
            spp_time - 1,
            MIPGap=0.00,
            Cuts=3,
        )

        solution = []
        for route_idx in route_indices:
            rider_idx = rk_matching[route_idx]
            rider = all_riders[rider_idx]
            route = tuple(map(lambda i: i - 1, all_routes[route_idx]))

            shop_seq = list(route[: len(route) // 2])
            dlv_seq = list(map(lambda i: i - n, route[-len(route) // 2 :]))
            solution.append([rider.type, shop_seq, dlv_seq])
    except Exception as e:
        print("Error in myalgorithm.algorithm():", e)
        solution = convert_solution(init_sol)

    return solution


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("problem", type=str, default="01")
    parser.add_argument("-t", type=int, default=60)
    args = parser.parse_args()

    NAME = args.problem
    TIME = args.t

    _dir = "../problem_data"
    if NAME[-5:] == ".json":
        problem_file = os.path.join(_dir, NAME)
    elif len(NAME) == 3:
        problem_file = os.path.join(_dir, f"STAGE{NAME[0]}_{NAME[1:]}.json")
    elif NAME[0].lower() == "d":
        problem_file = os.path.join(_dir, f"DOUBLE_STAGE{NAME[1]}_{NAME[2:]}.json")

    timelimit = args.t
    n_try = 1

    for _ in range(n_try):
        with open(problem_file, "r") as f:
            prob = json.load(f)

        K = prob["K"]

        ALL_ORDERS = [Order(order_info) for order_info in prob["ORDERS"]]
        ALL_RIDERS = [Rider(rider_info) for rider_info in prob["RIDERS"]]

        DIST = np.array(prob["DIST"])
        for r in ALL_RIDERS:
            r.T = np.round(DIST / r.speed + r.service_time)

        alg_start_time = time.time()
        solution = algorithm(K, ALL_ORDERS, ALL_RIDERS, DIST, timelimit)
        alg_end_time = time.time()

        checked_solution = solution_check(K, ALL_ORDERS, ALL_RIDERS, DIST, solution)
        checked_solution["time"] = alg_end_time - alg_start_time

        print(
            K,
            "{:.2f} / {:.2f}".format(
                checked_solution["avg_cost"], checked_solution["time"]
            ),
        )
