"""solving some problems"""

from .sp import *
