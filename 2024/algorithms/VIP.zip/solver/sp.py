"""Set-partioning Problem"""

import numpy as np
import gurobipy as gp
from gurobipy import GRB
from util import Rider
from collections.abc import Sequence
from itertools import combinations
from functools import partial

from time import time


def solve_SPP(
    n_orders: int,
    costs: Sequence[int],
    a_dict: dict[int, list],
    r_dict: dict[int, list],
    riders: list[Rider],
    remain_time: float = 60,
    OutputFlag=0,
    **kwargs,
) -> list:
    start_time = time()

    n_routes = len(costs)
    costs = np.round(costs).astype(int)

    Gap = 0

    with gp.Env(empty=True) as env:
        env.setParam("OutputFlag", OutputFlag)
        env.start()

        m = gp.Model("my model", env=env)
        indices = np.arange(n_routes)
        X = m.addVars(indices, lb=0, ub=1, vtype=GRB.BINARY)
        c_dict = np.stack([indices, costs]).T.tolist()
        c_dict = dict(c_dict)
        obj = X.prod(c_dict)
        m.setObjective(obj, sense=GRB.MINIMIZE)

        if time() - start_time > remain_time:
            raise Exception("Timelimit")

        rider_availability = m.addConstrs(
            (
                X.prod(r_dict[k]) <= rider.available_number
                for k, rider in enumerate(riders)
            )
        )

        if time() - start_time > remain_time:
            raise Exception("Timelimit")

        order_satisfied = m.addConstrs(
            (X.prod(a_dict[i]) == 1 for i in range(n_orders))
        )

        if time() - start_time > remain_time:
            raise Exception("Timelimit")

        for k, v in kwargs.items():
            m.setParam(k, v)

        m.setParam("Timelimit", remain_time - (time() - start_time))
        m.optimize()
        Gap = m.MIPGap * 100

        opt_sol = np.round(m.getAttr("X", X.values())).astype(int)
        result = np.arange(n_routes)[opt_sol == 1]

    return result, Gap
