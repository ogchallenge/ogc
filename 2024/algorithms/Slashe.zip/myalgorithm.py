from util import *
from slashe_alg import *

def algorithm(K, all_orders, all_riders, dist_mat, timelimit=60):


    solution = solve(K, all_orders, all_riders, dist_mat, timelimit)


    return solution
    