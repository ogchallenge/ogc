# include "final.h"

template<typename T>
inline T max_branchless(T a, T b) // branchless max function, which does not consider overflow
{
    T diff = a - b;
    T mask = diff >> sizeof(T) * 8 - 1;
    return a - (diff & mask);
}

template<typename T>
inline T min_branchless(T a, T b)
{
    T diff = a - b;
    T mask = diff >> sizeof(T) * 8 - 1;
    return b + (diff & mask);
}


template <typename T, std::size_t N>
std::array<T, N-1> removeValue(std::array<T, N>& arr, T value)
{
    std::array<T, N-1> newArr;
    std::size_t j = 0;

    for (std::size_t i = 0; i < N; ++i)
    {
        if (arr[i] != value)
        {
            newArr[j] = arr[i];
            ++j;
        }
    }

    return newArr;
}

template <std::size_t batchSize>
void generatePattern(MatchingMap<batchSize - 1>& previousMatchingMap, MatchingMap<batchSize>& currentMatchingMap, Rider rider,
                    GRBModel& grbModel, vector<GRBLinExpr>& orderConstraintExpr, vector<GRBLinExpr>& riderConstraintExpr, vector<GRBVar>& variableContainer,
                    Order K, Order* pickupSearchList, Order* deliverySearchList, Order searchListSize,
                    Time* orderReadyTime, Time* orderDeadline, Volume* orderVolume, 
                    Time* travelTime, Cost* variableCost,
                    Time* pickupCrit, Time* pickupCrit_self, Time* deliveryCrit, Time* deliveryCrit_self)
{
    const Order locationNum = 2 * K;
    Order previousOrder, currentOrder;
    Order* currentOrder_ptr;
    Time previousTime, currentTime;
    Cost previousCost, currentCost;
    VolumeLeft previousLeftCapacity, currentLeftCapacity;
    Key<batchSize-1> previousKey;
    Key<batchSize> currentKey;
    size_t previousKeyIndex, currentKeyIndex;
    bool skipFlag = false;

    for (auto& previousMatching : previousMatchingMap)
    {
        previousKey = previousMatching.first;  
        const HalfRouteContainer& previousHalfRouteContainer = previousMatching.second;
        previousLeftCapacity = previousHalfRouteContainer.leftCapacity;

        // Enlarge pickup routes
        for (auto& pickupRoute : previousHalfRouteContainer.pickupRoutes)
        {
            previousOrder = pickupRoute.previousOrder;
            previousTime = pickupRoute.time;
            previousCost = pickupRoute.cost;

            currentOrder_ptr = pickupSearchList + previousOrder * searchListSize;
            for ( ; ; ++currentOrder_ptr)
            {
                currentOrder = *(currentOrder_ptr);
                currentLeftCapacity = previousLeftCapacity - orderVolume[currentOrder];
                
                if (currentLeftCapacity < 0)
                {
                    break;
                }

                currentTime = max_branchless<Time>(orderReadyTime[currentOrder], previousTime + travelTime[previousOrder*locationNum + currentOrder]);

                for (Order prevOrder : previousKey)
                {
                    if (pickupCrit[currentOrder*K + prevOrder] - currentTime < 0)
                    {
                        skipFlag = true;
                        break;
                    }
                }

                if (skipFlag || pickupCrit_self[currentOrder] - currentTime < 0)
                {
                    skipFlag = false;
                    continue;
                }

                currentCost = previousCost + variableCost[previousOrder*locationNum + currentOrder];
                
                previousKeyIndex = 0;
                currentKeyIndex = 0;
                while (previousKeyIndex < (batchSize - 1) && previousKey[previousKeyIndex] < currentOrder)
                {
                    currentKey[currentKeyIndex++] = previousKey[previousKeyIndex++];
                }

                currentKey[currentKeyIndex++] = currentOrder;

                while (previousKeyIndex < (batchSize - 1))
                {
                    currentKey[currentKeyIndex++] = previousKey[previousKeyIndex++];
                }

                auto[it, inserted] = currentMatchingMap.try_emplace(std::move(currentKey), HalfRouteContainer(currentLeftCapacity));
                it->second.pickupRoutes.emplace_back(HalfRouteInfo(currentOrder, currentTime, currentCost));
            }
        }

        // Enlarge delivery routes
        for (auto& deliveryRoute : previousHalfRouteContainer.deliveryRoutes)
        {
            previousOrder = deliveryRoute.previousOrder;
            previousTime = deliveryRoute.time;
            previousCost = deliveryRoute.cost;

            currentOrder_ptr = deliverySearchList + previousOrder * searchListSize;
            for ( ; ; ++currentOrder_ptr)
            {
                currentOrder = *(currentOrder_ptr);
                currentLeftCapacity = previousLeftCapacity - orderVolume[currentOrder];

                if (currentLeftCapacity < 0)
                {
                    break;
                }

                currentTime = min_branchless<Time>(previousTime - travelTime[(K+previousOrder)*locationNum + (K+currentOrder)], orderDeadline[currentOrder]);

                for (Order prevOrder : previousKey)
                {
                    if (currentTime - deliveryCrit[currentOrder*K + prevOrder] < 0)
                    {
                        skipFlag = true;
                        break;
                    }
                }

                if (skipFlag || currentTime - deliveryCrit_self[currentOrder] < 0)
                {
                    skipFlag = false;
                    continue;
                }

                currentCost = previousCost + variableCost[(K+previousOrder)*locationNum + (K+currentOrder)];

                previousKeyIndex = 0;
                currentKeyIndex = 0;
                while (previousKeyIndex < (batchSize - 1) && previousKey[previousKeyIndex] < currentOrder)
                {
                    currentKey[currentKeyIndex++] = previousKey[previousKeyIndex++];
                }
                currentKey[currentKeyIndex++] = currentOrder;
                while (previousKeyIndex < (batchSize - 1))
                {
                    currentKey[currentKeyIndex++] = previousKey[previousKeyIndex++];
                }

                auto[it, inserted] = currentMatchingMap.try_emplace(std::move(currentKey), HalfRouteContainer(currentLeftCapacity));
                it->second.deliveryRoutes.emplace_back(HalfRouteInfo(currentOrder, currentTime, currentCost));
            }
        }
    }

    previousMatchingMap.clear();

    Cost pickupCost, deliveryCost, bestCost;
    Time pickupTime, deliveryTime;
    Order pickupPreviousOrder, deliveryPreviousOrder;
    bool feasibleMatchingExist; // true if an order set admits a feasible matching
    bool feasiblePickupSequenceExist; // truen if a pickup sequence exists for a delivery sequence
    size_t deliveryRouteIndex;
    size_t deliveryRouteNum;

    auto endIter = currentMatchingMap.end();
    for (auto it = currentMatchingMap.begin(); it != endIter;)
    {
        feasibleMatchingExist = false;
        bestCost = BIG_COST;

        PickupRoutes& pickupRoutes = it->second.pickupRoutes;
        DeliveryRoutes& deliveryRoutes = it->second.deliveryRoutes;
        deliveryRouteNum = deliveryRoutes.size();

        for (deliveryRouteIndex = 0; deliveryRouteIndex < deliveryRouteNum; )
        {
            HalfRouteInfo& deliveryRoute = deliveryRoutes[deliveryRouteIndex];

            deliveryCost = deliveryRoute.cost;
            deliveryTime = deliveryRoute.time;
            deliveryPreviousOrder = deliveryRoute.previousOrder;

            feasiblePickupSequenceExist = false;

            for (auto& pickupRoute : it->second.pickupRoutes)
            {
                pickupCost = pickupRoute.cost;
                pickupTime = pickupRoute.time;
                pickupPreviousOrder = pickupRoute.previousOrder;

                if (deliveryTime - pickupTime < travelTime[pickupPreviousOrder*locationNum + (K + deliveryPreviousOrder)])
                {
                    continue;
                }

                feasibleMatchingExist = true;
                feasiblePickupSequenceExist = true;
                bestCost = min_branchless<Cost>(bestCost, pickupCost + deliveryCost + variableCost[pickupPreviousOrder*locationNum + (K + deliveryPreviousOrder)]);
            }

            if (!feasiblePickupSequenceExist)
            {
                deliveryRoutes[deliveryRouteIndex] = std::move(deliveryRoutes.back());
                deliveryRoutes.pop_back();
                --deliveryRouteNum;
            }
            else
            {
                ++deliveryRouteIndex;
            }
        }

        if (feasibleMatchingExist)
        {
            GRBVar patternVariable = grbModel.addVar(0.0, 1.0, bestCost, GRB_BINARY);
            variableContainer.push_back(patternVariable);
            riderConstraintExpr[rider] += 1.0 * patternVariable;
            for (Order order : it->first)
            {
                orderConstraintExpr[order] += 1.0 * patternVariable;
            } 
            ++it; 
        }
        else
        {
            it = currentMatchingMap.erase(it); // Safe removal during iteration
            endIter = currentMatchingMap.end(); // Update endIter after an erase
        }
    }
}

void generatePattern_1(Rider rider, MatchingMap<1>& currentMatchingMap,
                GRBModel& grbModel, vector<GRBLinExpr>& orderConstraintExpr, vector<GRBLinExpr>& riderConstraintExpr, vector<GRBVar>& variableContainer,
                Order K, Volume riderCapacity, Cost riderFixedCost, 
                Time* orderReadyTime, Time* orderDeadline, Volume* orderVolume, 
                Time* travelTime, Cost* variableCost)
{
    const Order locationNum = 2 * K;

    for (Order order = 0; order < K; ++order)
    {
        if (orderVolume[order] > riderCapacity)
        {
            continue;
        }

        if (orderReadyTime[order] + travelTime[order*locationNum + (K+order)] > orderDeadline[order])
        {
            continue;
        }

        auto result = currentMatchingMap.emplace(std::make_pair(Key<1> {order}, HalfRouteContainer(riderCapacity - orderVolume[order])));
        auto& halfRouteContainer = result.first->second; 

        halfRouteContainer.pickupRoutes.emplace_back(HalfRouteInfo(order, orderReadyTime[order], riderFixedCost));
        halfRouteContainer.deliveryRoutes.emplace_back(HalfRouteInfo(order, orderDeadline[order], 0));

        GRBVar patternVariable = grbModel.addVar(0.0, 1.0, riderFixedCost + variableCost[locationNum*order + (K + order)], GRB_BINARY);
        variableContainer.push_back(patternVariable);
        orderConstraintExpr[order] += 1.0 * patternVariable;
        riderConstraintExpr[rider] += 1.0 * patternVariable;
    }
}

template <std::size_t batchSize>
void generateSequence(MatchingMap<batchSize - 1>& previousMatchingMap, MatchingMap<batchSize>& currentMatchingMap,
                    Order K, vector<Order> targetOrderList, Time* orderReadyTime, Time* orderDeadline, 
                    Time* travelTime, Cost* variableCost,
                    Time* pickupCrit, Time* pickupCrit_self, Time* deliveryCrit, Time* deliveryCrit_self)
{
    const Order locationNum = 2 * K;
    Order previousOrder;
    Time previousTime, currentTime;
    Cost previousCost, currentCost;
    Key<batchSize-1> previousKey;
    Key<batchSize> currentKey;
    size_t previousKeyIndex, currentKeyIndex;
    bool skipFlag = false;

    for (auto& previousMatching : previousMatchingMap)
    {
        previousKey = previousMatching.first;  
        const HalfRouteContainer& previousHalfRouteContainer = previousMatching.second;

        // Enlarge pickup routes
        for (auto& pickupRoute : previousHalfRouteContainer.pickupRoutes)
        {
            previousOrder = pickupRoute.previousOrder;
            previousTime = pickupRoute.time;
            previousCost = pickupRoute.cost;

            for (Order currentOrder : targetOrderList)
            {
                currentTime = max_branchless<Time>(orderReadyTime[currentOrder], previousTime + travelTime[previousOrder*locationNum + currentOrder]);

                for (Order prevOrder : previousKey)
                {
                    if (pickupCrit[currentOrder*K + prevOrder] - currentTime < 0)
                    {
                        skipFlag = true;
                        break;
                    }
                }

                if (skipFlag || pickupCrit_self[currentOrder] - currentTime < 0)
                {
                    skipFlag = false;
                    continue;
                }

                currentCost = previousCost + variableCost[previousOrder*locationNum + currentOrder];
                
                // Insert currentOrder while maintaining sorted order
                previousKeyIndex = 0;
                currentKeyIndex = 0;
                while (previousKeyIndex < (batchSize - 1) && previousKey[previousKeyIndex] < currentOrder)
                {
                    currentKey[currentKeyIndex++] = previousKey[previousKeyIndex++];
                }

                currentKey[currentKeyIndex++] = currentOrder;

                while (previousKeyIndex < (batchSize - 1))
                {
                    currentKey[currentKeyIndex++] = previousKey[previousKeyIndex++];
                }

                auto[it, inserted] = currentMatchingMap.try_emplace(std::move(currentKey), HalfRouteContainer(0));
                it->second.pickupRoutes.emplace_back(HalfRouteInfo(currentOrder, currentTime, currentCost));
            }
        }

        // Enlarge delivery routes
        for (auto& deliveryRoute : previousHalfRouteContainer.deliveryRoutes)
        {
            previousOrder = deliveryRoute.previousOrder;
            previousTime = deliveryRoute.time;
            previousCost = deliveryRoute.cost;

            for (Order currentOrder : targetOrderList)
            {
                currentTime = min_branchless<Time>(previousTime - travelTime[(K+previousOrder)*locationNum + (K+currentOrder)], orderDeadline[currentOrder]);

                for (Order prevOrder : previousKey)
                {
                    if (currentTime - deliveryCrit[currentOrder*K + prevOrder] < 0)
                    {
                        skipFlag = true;
                        break;
                    }
                }

                if (skipFlag || currentTime - deliveryCrit_self[currentOrder] < 0)
                {
                    skipFlag = false;
                    continue;
                }

                currentCost = previousCost + variableCost[(K+previousOrder)*locationNum + (K+currentOrder)];

                previousKeyIndex = 0;
                currentKeyIndex = 0;
                while (previousKeyIndex < (batchSize - 1) && previousKey[previousKeyIndex] < currentOrder)
                {
                    currentKey[currentKeyIndex++] = previousKey[previousKeyIndex++];
                }
                currentKey[currentKeyIndex++] = currentOrder;
                while (previousKeyIndex < (batchSize - 1))
                {
                    currentKey[currentKeyIndex++] = previousKey[previousKeyIndex++];
                }

                auto[it, inserted] = currentMatchingMap.try_emplace(std::move(currentKey), HalfRouteContainer(0));
                it->second.deliveryRoutes.emplace_back(HalfRouteInfo(currentOrder, currentTime, currentCost));
            }
        }
    }
}

template <std::size_t batchSize>
void findLastOrders(MatchingMap<batchSize>& currentMatchingMap, Key<batchSize>& key, Order K,
                        vector<Order>& optimalPickupSequence, vector<Order>& optimalDeliverySequence,
                        vector<Time>& optimalPickupTime, vector<Time>& optimalDeliveryTime,
                        vector<Cost>& optimalPickupCost, vector<Cost>& optimalDeliveryCost,
                        Time* orderReadyTime, Time* orderDeadline, Time* travelTime, Cost* variableCost)
{

    HalfRouteContainer& halfRouteContainer = currentMatchingMap[key];

    Cost bestCost = BIG_COST;

    Order locationNum = 2 * K;

    Order lastPickupOrder, lastDeliveryOrder;
    Time lastPickupTime, lastDeliveryTime;
    Cost lastPickupCost, lastDeliveryCost;

    for (HalfRouteInfo& pickupRoute : halfRouteContainer.pickupRoutes)
    {
        Order pickupPreviousOrder = pickupRoute.previousOrder;
        Time pickupTime = pickupRoute.time;
        Cost pickupCost = pickupRoute.cost;

        for (HalfRouteInfo& deliveryRoute : halfRouteContainer.deliveryRoutes)
        {
            Order deliveryPreviousOrder = deliveryRoute.previousOrder;
            Time deliveryTime = deliveryRoute.time;
            Cost deliveryCost = deliveryRoute.cost;

            if (deliveryTime - pickupTime < travelTime[pickupPreviousOrder*locationNum + (K + deliveryPreviousOrder)])
            {
                continue;
            }

            Cost currentCost = pickupCost + deliveryCost + variableCost[pickupPreviousOrder*locationNum + (K + deliveryPreviousOrder)];
            if (currentCost < bestCost)
            {
                bestCost = currentCost;
                lastPickupOrder = pickupPreviousOrder;
                lastDeliveryOrder = deliveryPreviousOrder;
                lastPickupTime = pickupTime;
                lastDeliveryTime = deliveryTime;
                lastPickupCost = pickupCost;
                lastDeliveryCost = deliveryCost;
            }
        }
    }


    optimalPickupSequence.push_back(lastPickupOrder);
    optimalDeliverySequence.push_back(lastDeliveryOrder);
    optimalPickupTime.push_back(lastPickupTime);
    optimalDeliveryTime.push_back(lastDeliveryTime);
    optimalPickupCost.push_back(lastPickupCost);
    optimalDeliveryCost.push_back(lastDeliveryCost);
}

template<std::size_t batchSize>
void findLastPickupOrder(MatchingMap<batchSize>& currentMatchingMap, Key<batchSize> key, Order K,
                        Order targetOrder, Time targetTime, Cost targetCost,
                        vector<Order>& optimalPickupSequence, vector<Time>& optimalPickupTime, vector<Cost>& optimalPickupCost,
                        Time* orderReadyTime, Time* orderDeadline, Time* travelTime, Cost* variableCost)
{
    Order locationNum = 2 * K;

    HalfRouteContainer& halfRouteContainer = currentMatchingMap[key];


    for (HalfRouteInfo& pickupRoute : halfRouteContainer.pickupRoutes)
    {
        Order pickupPreviousOrder = pickupRoute.previousOrder;
        Time pickupTime = pickupRoute.time;
        Cost pickupCost = pickupRoute.cost;

        if (pickupCost + variableCost[pickupPreviousOrder*locationNum + targetOrder] != targetCost)
        {
            continue;
        }

        if (max_branchless<Time>(pickupTime + travelTime[pickupPreviousOrder*locationNum + targetOrder], orderReadyTime[targetOrder]) != targetTime)
        {
            continue;
        }

        optimalPickupSequence.push_back(pickupPreviousOrder);
        optimalPickupTime.push_back(pickupTime);
        optimalPickupCost.push_back(pickupCost);
        return;
    }
}

template<std::size_t batchSize>
void findLastDeliveryOrder(MatchingMap<batchSize>& currentMatchingMap, Key<batchSize> key, Order K,
                        Order targetOrder, Time targetTime, Cost targetCost,
                        vector<Order>& optimalDeliverySequence, vector<Time>& optimalDeliveryTime, vector<Cost>& optimalDeliveryCost,
                        Time* orderReadyTime, Time* orderDeadline, Time* travelTime, Cost* variableCost)
{
    Order locationNum = 2 * K;

    HalfRouteContainer& halfRouteContainer = currentMatchingMap[key];
    
    for (HalfRouteInfo& deliveryRoute : halfRouteContainer.deliveryRoutes)
    {
        Order deliveryPreviousOrder = deliveryRoute.previousOrder;
        Time deliveryTime = deliveryRoute.time;
        Cost deliveryCost = deliveryRoute.cost;

        if (deliveryCost + variableCost[(K + deliveryPreviousOrder)*locationNum + (K + targetOrder)] != targetCost)
        {
            continue;
        }

        if (min_branchless<Time>(deliveryTime - travelTime[(K + targetOrder)*locationNum + (K + deliveryPreviousOrder)], orderDeadline[targetOrder]) != targetTime)
        {
            continue;
        }

        optimalDeliverySequence.push_back(deliveryPreviousOrder);
        optimalDeliveryTime.push_back(deliveryTime);
        optimalDeliveryCost.push_back(deliveryCost);
        return;
    }
}

void retrieveSequence(BatchSize batchSize, Order* result, Rider rider, Order K, vector<Order> targetOrderList, Cost riderFixedCost,
                    Time* orderReadyTime, Time* orderDeadline, Time* travelTime, Cost* variableCost,
                    Time* pickupCrit, Time* pickupCrit_self, Time* deliveryCrit, Time* deliveryCrit_self)
{
    Order locationNum = 2 * K;

    *(result) = rider;
    *(result+1) = batchSize;
    if (batchSize == 1)
    {
        *(result+2) = targetOrderList[0];
        *(result+3) = targetOrderList[0];
        return;
    }

    Key<1> pickupArr_1; Key<1> deliveryArr_1;
    Key<2> pickupArr_2; Key<2> deliveryArr_2;
    Key<3> pickupArr_3; Key<3> deliveryArr_3;
    Key<4> pickupArr_4; Key<4> deliveryArr_4;
    Key<5> pickupArr_5; Key<5> deliveryArr_5;
    Key<6> pickupArr_6; Key<6> deliveryArr_6;
    Key<7> pickupArr_7; Key<7> deliveryArr_7;
    Key<8> pickupArr_8; Key<8> deliveryArr_8;

    MatchingMap<1> bundle_1;
    MatchingMap<2> bundle_2;
    MatchingMap<3> bundle_3;
    MatchingMap<4> bundle_4;
    MatchingMap<5> bundle_5;
    MatchingMap<6> bundle_6;
    MatchingMap<7> bundle_7;
    MatchingMap<8> bundle_8;

    generateSequence_1(bundle_1, targetOrderList, riderFixedCost, orderReadyTime, orderDeadline,
                        travelTime, variableCost);

    if (batchSize == 1)
    {
        goto searchFinished;
    }

    generateSequence<2>(bundle_1, bundle_2, K, targetOrderList, orderReadyTime, orderDeadline, 
                        travelTime, variableCost, pickupCrit, pickupCrit_self,
                        deliveryCrit, deliveryCrit_self);

    if (batchSize == 2)
    {
        goto searchFinished;
    }

    generateSequence<3>(bundle_2, bundle_3, K, targetOrderList, orderReadyTime, orderDeadline,
                        travelTime, variableCost, pickupCrit, pickupCrit_self,
                        deliveryCrit, deliveryCrit_self);

    if (batchSize == 3)
    {
        goto searchFinished;
    }

    generateSequence<4>(bundle_3, bundle_4, K, targetOrderList, orderReadyTime, orderDeadline,
                        travelTime, variableCost, pickupCrit, pickupCrit_self,
                        deliveryCrit, deliveryCrit_self);

    if (batchSize == 4)
    {
        goto searchFinished;
    }

    generateSequence<5>(bundle_4, bundle_5, K, targetOrderList, orderReadyTime, orderDeadline,
                        travelTime, variableCost, pickupCrit, pickupCrit_self,
                        deliveryCrit, deliveryCrit_self);

    if (batchSize == 5)
    {
        goto searchFinished;
    }
    
    generateSequence<6>(bundle_5, bundle_6, K, targetOrderList, orderReadyTime, orderDeadline,
                        travelTime, variableCost, pickupCrit, pickupCrit_self,
                        deliveryCrit, deliveryCrit_self);

    if (batchSize == 6)
    {
        goto searchFinished;
    }

    generateSequence<7>(bundle_6, bundle_7, K, targetOrderList, orderReadyTime, orderDeadline,
                        travelTime, variableCost, pickupCrit, pickupCrit_self,
                        deliveryCrit, deliveryCrit_self);

    if (batchSize == 7)
    {
        goto searchFinished;
    }

    generateSequence<8>(bundle_7, bundle_8, K, targetOrderList, orderReadyTime, orderDeadline, 
                        travelTime, variableCost, pickupCrit, pickupCrit_self,
                        deliveryCrit, deliveryCrit_self);

    searchFinished:


    vector<Order> optimalPickupSequence;
    vector<Order> optimalDeliverySequence;
    vector<Time> optimalPickupTime;
    vector<Time> optimalDeliveryTime;
    vector<Cost> optimalPickupCost;
    vector<Cost> optimalDeliveryCost;


    switch (batchSize)
    {
        case 8:
            copy(targetOrderList.begin(), targetOrderList.end(), pickupArr_8.begin());
            copy(targetOrderList.begin(), targetOrderList.end(), deliveryArr_8.begin());
            findLastOrders<8>(bundle_8, pickupArr_8, K, optimalPickupSequence, optimalDeliverySequence, 
                            optimalPickupTime, optimalDeliveryTime, optimalPickupCost, optimalDeliveryCost,
                            orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_7 = removeValue(pickupArr_8, optimalPickupSequence.back());
            deliveryArr_7 = removeValue(deliveryArr_8, optimalDeliverySequence.back());
            break;
        case 7:
            copy(targetOrderList.begin(), targetOrderList.end(), pickupArr_7.begin());
            copy(targetOrderList.begin(), targetOrderList.end(), deliveryArr_7.begin());
            findLastOrders<7>(bundle_7, pickupArr_7, K, optimalPickupSequence, optimalDeliverySequence, 
                            optimalPickupTime, optimalDeliveryTime, optimalPickupCost, optimalDeliveryCost,
                            orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_6 = removeValue(pickupArr_7, optimalPickupSequence.back());
            deliveryArr_6 = removeValue(deliveryArr_7, optimalDeliverySequence.back());
            break;
        case 6:
            copy(targetOrderList.begin(), targetOrderList.end(), pickupArr_6.begin());
            copy(targetOrderList.begin(), targetOrderList.end(), deliveryArr_6.begin());
            findLastOrders<6>(bundle_6, pickupArr_6, K, optimalPickupSequence, optimalDeliverySequence, 
                            optimalPickupTime, optimalDeliveryTime, optimalPickupCost, optimalDeliveryCost,
                            orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_5 = removeValue(pickupArr_6, optimalPickupSequence.back());
            deliveryArr_5 = removeValue(deliveryArr_6, optimalDeliverySequence.back());
            break;
        case 5:
            copy(targetOrderList.begin(), targetOrderList.end(), pickupArr_5.begin());
            copy(targetOrderList.begin(), targetOrderList.end(), deliveryArr_5.begin());
            findLastOrders<5>(bundle_5, pickupArr_5, K, optimalPickupSequence, optimalDeliverySequence, 
                            optimalPickupTime, optimalDeliveryTime, optimalPickupCost, optimalDeliveryCost,
                            orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_4 = removeValue(pickupArr_5, optimalPickupSequence.back());
            deliveryArr_4 = removeValue(deliveryArr_5, optimalDeliverySequence.back());
            break;
        case 4:
            copy(targetOrderList.begin(), targetOrderList.end(), pickupArr_4.begin());
            copy(targetOrderList.begin(), targetOrderList.end(), deliveryArr_4.begin());
            findLastOrders<4>(bundle_4, pickupArr_4, K, optimalPickupSequence, optimalDeliverySequence, 
                            optimalPickupTime, optimalDeliveryTime, optimalPickupCost, optimalDeliveryCost,
                            orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_3 = removeValue(pickupArr_4, optimalPickupSequence.back());
            deliveryArr_3 = removeValue(deliveryArr_4, optimalDeliverySequence.back());
            break;
        case 3:
            copy(targetOrderList.begin(), targetOrderList.end(), pickupArr_3.begin());
            copy(targetOrderList.begin(), targetOrderList.end(), deliveryArr_3.begin());
            findLastOrders<3>(bundle_3, pickupArr_3, K, optimalPickupSequence, optimalDeliverySequence, 
                            optimalPickupTime, optimalDeliveryTime, optimalPickupCost, optimalDeliveryCost,
                            orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_2 = removeValue(pickupArr_3, optimalPickupSequence.back());
            deliveryArr_2 = removeValue(deliveryArr_3, optimalDeliverySequence.back());
            break;
        case 2:
            copy(targetOrderList.begin(), targetOrderList.end(), pickupArr_2.begin());
            copy(targetOrderList.begin(), targetOrderList.end(), deliveryArr_2.begin());
            findLastOrders<2>(bundle_2, pickupArr_2, K, optimalPickupSequence, optimalDeliverySequence, 
                            optimalPickupTime, optimalDeliveryTime, optimalPickupCost, optimalDeliveryCost,
                            orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_1 = removeValue(pickupArr_2, optimalPickupSequence.back());
            deliveryArr_1 = removeValue(deliveryArr_2, optimalDeliverySequence.back());
    }

    switch (batchSize)
    {
        case 8:
            findLastPickupOrder<7>(bundle_7, pickupArr_7, K, optimalPickupSequence.back(), optimalPickupTime.back(), optimalPickupCost.back(),
                                optimalPickupSequence, optimalPickupTime, optimalPickupCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            findLastDeliveryOrder<7>(bundle_7, deliveryArr_7, K, optimalDeliverySequence.back(), optimalDeliveryTime.back(), optimalDeliveryCost.back(),
                                optimalDeliverySequence, optimalDeliveryTime, optimalDeliveryCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_6 = removeValue(pickupArr_7, optimalPickupSequence.back());
            deliveryArr_6 = removeValue(deliveryArr_7, optimalDeliverySequence.back());
        case 7:
            findLastPickupOrder<6>(bundle_6, pickupArr_6, K, optimalPickupSequence.back(), optimalPickupTime.back(), optimalPickupCost.back(),
                                optimalPickupSequence, optimalPickupTime, optimalPickupCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            findLastDeliveryOrder<6>(bundle_6, deliveryArr_6, K, optimalDeliverySequence.back(), optimalDeliveryTime.back(), optimalDeliveryCost.back(),
                                optimalDeliverySequence, optimalDeliveryTime, optimalDeliveryCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_5 = removeValue(pickupArr_6, optimalPickupSequence.back());
            deliveryArr_5 = removeValue(deliveryArr_6, optimalDeliverySequence.back());
        case 6:
            findLastPickupOrder<5>(bundle_5, pickupArr_5, K, optimalPickupSequence.back(), optimalPickupTime.back(), optimalPickupCost.back(),
                                optimalPickupSequence, optimalPickupTime, optimalPickupCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            findLastDeliveryOrder<5>(bundle_5, deliveryArr_5, K, optimalDeliverySequence.back(), optimalDeliveryTime.back(), optimalDeliveryCost.back(),
                                optimalDeliverySequence, optimalDeliveryTime, optimalDeliveryCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_4 = removeValue(pickupArr_5, optimalPickupSequence.back());
            deliveryArr_4 = removeValue(deliveryArr_5, optimalDeliverySequence.back());
        case 5:
            findLastPickupOrder<4>(bundle_4, pickupArr_4, K, optimalPickupSequence.back(), optimalPickupTime.back(), optimalPickupCost.back(),
                                optimalPickupSequence, optimalPickupTime, optimalPickupCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            findLastDeliveryOrder<4>(bundle_4, deliveryArr_4, K, optimalDeliverySequence.back(), optimalDeliveryTime.back(), optimalDeliveryCost.back(),
                                optimalDeliverySequence, optimalDeliveryTime, optimalDeliveryCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_3 = removeValue(pickupArr_4, optimalPickupSequence.back());
            deliveryArr_3 = removeValue(deliveryArr_4, optimalDeliverySequence.back());
        case 4:
            findLastPickupOrder<3>(bundle_3, pickupArr_3, K, optimalPickupSequence.back(), optimalPickupTime.back(), optimalPickupCost.back(),
                                optimalPickupSequence, optimalPickupTime, optimalPickupCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            findLastDeliveryOrder<3>(bundle_3, deliveryArr_3, K, optimalDeliverySequence.back(), optimalDeliveryTime.back(), optimalDeliveryCost.back(),
                                optimalDeliverySequence, optimalDeliveryTime, optimalDeliveryCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_2 = removeValue(pickupArr_3, optimalPickupSequence.back());
            deliveryArr_2 = removeValue(deliveryArr_3, optimalDeliverySequence.back());
        case 3:
            findLastPickupOrder<2>(bundle_2, pickupArr_2, K, optimalPickupSequence.back(), optimalPickupTime.back(), optimalPickupCost.back(),
                                optimalPickupSequence, optimalPickupTime, optimalPickupCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            findLastDeliveryOrder<2>(bundle_2, deliveryArr_2, K, optimalDeliverySequence.back(), optimalDeliveryTime.back(), optimalDeliveryCost.back(),
                                optimalDeliverySequence, optimalDeliveryTime, optimalDeliveryCost,
                                orderReadyTime, orderDeadline, travelTime, variableCost);
            pickupArr_1 = removeValue(pickupArr_2, optimalPickupSequence.back());
            deliveryArr_1 = removeValue(deliveryArr_2, optimalDeliverySequence.back());
    }

    optimalPickupSequence.push_back(pickupArr_1[0]);
    optimalDeliverySequence.push_back(deliveryArr_1[0]);

    Order* pickup_start = result + 2;
    for (size_t i = 0; i < batchSize; ++i)
    {
        *(pickup_start + i) = optimalPickupSequence[batchSize - 1 - i];
        *(pickup_start + batchSize + i) = optimalDeliverySequence[i];
    }

}

void generateSequence_1(MatchingMap<1>& currentMatchingMap, vector<Order> targetOrderList, Cost riderFixedCost,
                Time* orderReadyTime, Time* orderDeadline, 
                Time* travelTime, Cost* variableCost)
{
    for (Order order : targetOrderList)
    {
        auto result = currentMatchingMap.emplace(std::make_pair(Key<1> {order}, HalfRouteContainer(0)));
        auto& halfRouteContainer = result.first->second; 

        halfRouteContainer.pickupRoutes.emplace_back(HalfRouteInfo(order, orderReadyTime[order], 0));
        halfRouteContainer.deliveryRoutes.emplace_back(HalfRouteInfo(order, orderDeadline[order], 0));
    }
}



extern "C"
{
    Order* run(Order K, Time* readyTime, Time* deadline,
            Volume* volume, Time* travelTime, Cost* variableCost,
            Cost* fixedCost, Volume* capacity, RiderNumber* availableNumber,
            DistanceCriterion distanceCriterion, TimeCriterion timeCriterion,
            TimeLimit timeLimit, int instanceNumber)
    {
        double start = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();

        const Order neighborhoodNumber = static_cast<Order>(distanceCriterion * K); // maximum number of neighbors to consider, without including a dummy order
        const Order searchListSize = neighborhoodNumber + 1; // size of the search list, including a dummy order
        const Order locationNum = 2 * K; // number of locations, including pickup and delivery locations
        const Time timeCriterion_big = timeCriterion;
        const Time timeCriterion_small = -(timeCriterion - 300);

        Time* pickupCrit = new Time[RIDERTYPENUM * K * K];
        Time* pickupCrit_self = new Time[RIDERTYPENUM * K];
        Time* deliveryCrit = new Time[RIDERTYPENUM * K * K];
        Time* deliveryCrit_self = new Time[RIDERTYPENUM * K];

        // Data preprocessing

        for (Rider rider = 0; rider < RIDERTYPENUM; ++rider)
        {
            for (Order i = 0; i < K; ++i)
            {
                for (Order j = 0; j < K; ++j)
                {
                    pickupCrit[rider*K*K + i*K + j] = deadline[j] - travelTime[rider*locationNum*locationNum + i*locationNum + (K+j)];
                    deliveryCrit[rider*K*K + i*K + j] = readyTime[j] + travelTime[rider*locationNum*locationNum + j*locationNum + (K+i)];
                }
                pickupCrit_self[rider*K + i] = pickupCrit[rider*K*K + i*K + i];
                deliveryCrit_self[rider*K + i] = deliveryCrit[rider*K*K + i*K + i];
                pickupCrit[rider*K*K + i*K + i] = SMALL_TIME;
                deliveryCrit[rider*K*K + i*K + i] = BIG_TIME;
            }
        }

        Order* pickupSearchList = new Order[K * searchListSize];
        Order* deliverySearchList = new Order[K * searchListSize];
        Order* pickupSearchList_ptr;
        Order* deliverySearchList_ptr;

        Time readyTimeDiff, deadlineDiff;
        
        std::vector<DistanceFunctionInfo> indexedOrderList(K);

        for (Order i = 0; i < K; ++i)
        {
            for (Order j = 0; j < K; ++j)
            {
                indexedOrderList[j].order = j;
                indexedOrderList[j].value = travelTime[i*locationNum + j] + travelTime[(K+i)*locationNum + (K+j)];
            }
            
            std::sort(indexedOrderList.begin(), indexedOrderList.end(),
                        [](const DistanceFunctionInfo& a, const DistanceFunctionInfo& b) {
                            return a.value < b.value;
                        });

            
            
            std::sort(indexedOrderList.begin()+1, indexedOrderList.begin() + neighborhoodNumber,
                        [&volume](const DistanceFunctionInfo& a, const DistanceFunctionInfo& b) {
                            return volume[a.order] < volume[b.order];
                        });
            pickupSearchList_ptr = pickupSearchList + (i*searchListSize);
            deliverySearchList_ptr = deliverySearchList + (i*searchListSize);
            for (size_t idx = 1; idx < neighborhoodNumber; ++idx)
            {
                Order j = indexedOrderList[idx].order;
                readyTimeDiff = readyTime[j] - readyTime[i];
                if (readyTimeDiff > timeCriterion_small && readyTimeDiff < timeCriterion_big)
                {
                    *(pickupSearchList_ptr++) = j;
                }
                deadlineDiff = deadline[i] - deadline[j];
                if (deadlineDiff > timeCriterion_small && deadlineDiff < timeCriterion_big)
                {
                    *(deliverySearchList_ptr++) = j;
                }
            }
            *(pickupSearchList_ptr) = K; // Termination of search by dummy order
            *(deliverySearchList_ptr)= K;
        }

        GRBEnv env = GRBEnv(true);
        env.set(GRB_IntParam_LogToConsole, 0);
        env.start();

        GRBModel grbModel = GRBModel(env);
        vector<GRBVar> variableContainer;
        std::vector<GRBLinExpr> orderConstraintExpr(K, 0.0);
        std::vector<GRBLinExpr> riderConstraintExpr(RIDERTYPENUM, 0.0);
        std::vector<GRBConstr> orderConstraints(K);
        std::vector<GRBConstr> riderConstraints(RIDERTYPENUM);

        for (Rider riderType = 0; riderType < RIDERTYPENUM; ++riderType)
        {
            // Initialize bundle_1
            MatchingMap<1> bundle_1(K);
            generatePattern_1(riderType, bundle_1, grbModel, orderConstraintExpr, riderConstraintExpr, variableContainer,
                                K, capacity[riderType], fixedCost[riderType], readyTime, deadline, volume,
                                travelTime + (riderType*locationNum*locationNum), variableCost + (riderType*locationNum*locationNum));

            // Iteratively build bundle_2 to bundle_8
            MatchingMap<2> bundle_2(1500000);
            generatePattern<2>(bundle_1, bundle_2, riderType, grbModel, orderConstraintExpr, riderConstraintExpr, variableContainer,
                                K, pickupSearchList, deliverySearchList, searchListSize, readyTime, deadline, volume,
                                travelTime + (riderType*locationNum*locationNum), variableCost + (riderType*locationNum*locationNum),
                                pickupCrit + (riderType*K*K), pickupCrit_self + (riderType*K), deliveryCrit + (riderType*K*K), deliveryCrit_self + (riderType*K));
          
            MatchingMap<3> bundle_3(1500000);
            generatePattern<3>(bundle_2, bundle_3, riderType, grbModel, orderConstraintExpr, riderConstraintExpr, variableContainer,
                                K, pickupSearchList, deliverySearchList, searchListSize, readyTime, deadline, volume,
                                travelTime + (riderType*locationNum*locationNum), variableCost + (riderType*locationNum*locationNum),
                                pickupCrit + (riderType*K*K), pickupCrit_self + (riderType*K), deliveryCrit + (riderType*K*K), deliveryCrit_self + (riderType*K));
         
            MatchingMap<4> bundle_4(1500000);
            generatePattern<4>(bundle_3, bundle_4, riderType, grbModel, orderConstraintExpr, riderConstraintExpr, variableContainer,
                                K, pickupSearchList, deliverySearchList, searchListSize, readyTime, deadline, volume,
                                travelTime + (riderType*locationNum*locationNum), variableCost + (riderType*locationNum*locationNum),
                                pickupCrit + (riderType*K*K), pickupCrit_self + (riderType*K), deliveryCrit + (riderType*K*K), deliveryCrit_self + (riderType*K));
            
            MatchingMap<5> bundle_5(1500000);
            generatePattern<5>(bundle_4, bundle_5, riderType, grbModel, orderConstraintExpr, riderConstraintExpr, variableContainer,
                                K, pickupSearchList, deliverySearchList, searchListSize, readyTime, deadline, volume,
                                travelTime + (riderType*locationNum*locationNum), variableCost + (riderType*locationNum*locationNum),
                                pickupCrit + (riderType*K*K), pickupCrit_self + (riderType*K), deliveryCrit + (riderType*K*K), deliveryCrit_self + (riderType*K));
            
            MatchingMap<6> bundle_6(1500000);
            generatePattern<6>(bundle_5, bundle_6, riderType, grbModel, orderConstraintExpr, riderConstraintExpr, variableContainer,
                                K, pickupSearchList, deliverySearchList, searchListSize, readyTime, deadline, volume,
                                travelTime + (riderType*locationNum*locationNum), variableCost + (riderType*locationNum*locationNum),
                                pickupCrit + (riderType*K*K), pickupCrit_self + (riderType*K), deliveryCrit + (riderType*K*K), deliveryCrit_self + (riderType*K));
            
            MatchingMap<7> bundle_7(1500000);
            generatePattern<7>(bundle_6, bundle_7, riderType, grbModel, orderConstraintExpr, riderConstraintExpr, variableContainer,
                                K, pickupSearchList, deliverySearchList, searchListSize, readyTime, deadline, volume,
                                travelTime + (riderType*locationNum*locationNum), variableCost + (riderType*locationNum*locationNum),
                                pickupCrit + (riderType*K*K), pickupCrit_self + (riderType*K), deliveryCrit + (riderType*K*K), deliveryCrit_self + (riderType*K));
            
            MatchingMap<8> bundle_8(10000);
            generatePattern<8>(bundle_7, bundle_8, riderType, grbModel, orderConstraintExpr, riderConstraintExpr, variableContainer,
                                K, pickupSearchList, deliverySearchList, searchListSize, readyTime, deadline, volume,
                                travelTime + (riderType*locationNum*locationNum), variableCost + (riderType*locationNum*locationNum),
                                pickupCrit + (riderType*K*K), pickupCrit_self + (riderType*K), deliveryCrit + (riderType*K*K), deliveryCrit_self + (riderType*K));

        }
        Order* result = new Order[K * 18 + 1];
        
        model(grbModel, orderConstraintExpr, riderConstraintExpr, orderConstraints, riderConstraints, K, availableNumber);


        double end = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
        double remainingTime = timeLimit - (end - start) / 1000;

        if (remainingTime < 0.01)
        {
            result[0] = 0;
            return result;
        }

        grbModel.set(GRB_DoubleParam_TimeLimit, remainingTime);

        grbModel.optimize();

        if (grbModel.get(GRB_IntAttr_SolCount) == 0)
        {
            result[0] = 0;
            return result;
        }
        
        size_t variableNum = variableContainer.size();
        BatchSize batchSize;
        Order bundleNum = 0;
        Rider rider;
        vector<Order> orderVec;
        Volume bundleVolume = 0;
        
        Order* curr_result = result + 1;

        for (size_t i = 0; i < variableNum; ++i)
        {
            GRBVar var = variableContainer[i];
            double sol = var.get(GRB_DoubleAttr_X);
            if (sol > VAR_ACTIVE_CRIT)
            {
                bundleVolume = 0;
                batchSize = 0;
                orderVec.clear();

                rider = 2; // car

                for (Rider riderType = 0; riderType < 2; ++riderType) // exclude car
                {
                    if (grbModel.getCoeff(riderConstraints[riderType], var) > VAR_ACTIVE_CRIT)
                    {
                        rider = riderType;
                        break;
                    }
                }

                for (Order order = 0; order < K; ++order)
                {
                    if (grbModel.getCoeff(orderConstraints[order], var) > VAR_ACTIVE_CRIT)
                    {
                        orderVec.push_back(order);
                        batchSize++;
                    }
                }

                retrieveSequence(batchSize, curr_result, rider, K, orderVec, fixedCost[rider],  
                                readyTime, deadline, travelTime + (rider*locationNum*locationNum), variableCost + (rider*locationNum*locationNum),
                                pickupCrit + (rider*K*K), pickupCrit_self + (rider*K), deliveryCrit + (rider*K*K), deliveryCrit_self + (rider*K));

                curr_result += 18;
                ++bundleNum;
            }
        }

        result[0] = bundleNum;

        // delete arrays

        delete[] pickupCrit;
        delete[] pickupCrit_self;
        delete[] deliveryCrit;
        delete[] deliveryCrit_self;
        delete[] pickupSearchList;
        delete[] deliverySearchList;

        return result;
    }

    void deleteArray(Order* array)
    {
        delete[] array;
    }
}

void model(GRBModel& grbModel, vector<GRBLinExpr>& orderConstraintExpr, vector<GRBLinExpr>& riderConstraintExpr,
            std::vector<GRBConstr>& orderConstraints, std::vector<GRBConstr>& riderConstraints,
            Order K, RiderNumber* riderNumber)
{
    for (Order order = 0; order < K; ++order)
    {
        orderConstraints[order] = grbModel.addConstr(orderConstraintExpr[order] == 1.0);
    }

    riderConstraints[0] = grbModel.addConstr(riderConstraintExpr[0] <= riderNumber[0]);
    riderConstraints[1] = grbModel.addConstr(riderConstraintExpr[1] <= riderNumber[1]);

    grbModel.set(GRB_IntAttr_ModelSense, GRB_MINIMIZE);

}
