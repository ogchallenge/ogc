from util import *
import ctypes
import numpy as np
import time
import os


def algorithm(K, all_orders, all_riders, dist_mat, timelimit):
    
    startTime = time.time()

    # default values
    restorationTime = 1 
    timeCriterion = 2700
    distanceCriterion = 0.1
    use_revised = True

    Order = np.int16
    Order_ctypes = ctypes.c_int16
    Time = np.int16
    Time_ctypes = ctypes.c_int16
    Cost = np.int32
    Cost_ctypes = ctypes.c_int32
    Volume = np.int16
    Volume_ctypes = ctypes.c_int16
    RiderNumber = np.int16
    RiderNumber_ctypes = ctypes.c_int16
    DistanceCriterion_ctypes = ctypes.c_double
    TimeCriterion_ctypes = Time_ctypes
    TimeLimit_ctypes = ctypes.c_double
    
    DUMMY_VOLUME = np.int16(201)
    
    if K == 2000 and timelimit == 300:  # Instance 1
        distanceCriterion = 27 / K
        timeCriterion = 1600
        restorationTime = 3
        use_revised = True
    elif K == 2000 and timelimit == 480:  # Instance 2
        distanceCriterion = 39 / K
        timeCriterion = 2000
        restorationTime = 3
        use_revised = True
    elif K == 1000 and timelimit == 60:  # Instance 3
        distanceCriterion = 24 / K
        restorationTime = 1
        use_revised = False
    elif K == 1000 and timelimit == 180:  # Instance 4
        distanceCriterion = 22 / K
        timeCriterion = 1200
        restorationTime = 2
        use_revised = True
    elif K == 1000 and timelimit == 300:  # Instance 5
        distanceCriterion = 38 / K
        timeCriterion = 2400
        restorationTime = 2
        use_revised = True
    elif K == 750 and timelimit == 30:  # Instance 6
        distanceCriterion = 33 / K
        timeCriterion = 2400
        restorationTime = 1
        use_revised = True
    elif K == 750 and timelimit == 60:  # Instance 7
        distanceCriterion = 35 / K
        timeCriterion = 2700
        restorationTime = 1.5
        use_revised = True
    elif K == 500 and timelimit == 15:  # Instance 8
        distanceCriterion = 20 / K
        timeCriterion = 2500
        restorationTime = 0.5
        use_revised = True
    elif K == 500 and timelimit == 30:  # Instance 9
        distanceCriterion = 21 / K
        restorationTime = 1
        use_revised = False
    elif K == 300 and timelimit == 15:  # Instance 10
        distanceCriterion = 24 / K
        restorationTime = 0.5
        use_revised = False
    else:
        distanceCriterion = (15 / K) + (timelimit / 20 / K) + (2000 / K / K)
        restorationTime = 1 + (K / 1000)
    
    def to_ctypes_array(arr, dtype):
        return arr.ctypes.data_as(ctypes.POINTER(dtype))
    
    K_ctypes = Order_ctypes(K)

    readyTime = np.array([order.order_time + order.cook_time for order in all_orders], dtype=Time)
    readyTime_ptr = to_ctypes_array(readyTime.flatten(), dtype=Time_ctypes)

    deadline = np.array([order.deadline for order in all_orders], dtype=Time)
    deadline_ptr = to_ctypes_array(deadline.flatten(), dtype=Time_ctypes)

    volume = np.array([order.volume for order in all_orders], dtype=Volume)
    volume = np.append(volume, DUMMY_VOLUME)
    volume_ptr = to_ctypes_array(volume.flatten(), dtype=Volume_ctypes)

    travelTime = np.array([rider.T for rider in all_riders], dtype = Time)
    travelTime_ptr = to_ctypes_array(travelTime.flatten(order='C'), dtype = Time_ctypes)

    variableCost = np.array([dist_mat * rider.var_cost for rider in all_riders], dtype = Cost)
    variableCost_ptr = to_ctypes_array(variableCost.flatten(order='C'), dtype = Cost_ctypes)

    fixedCost = np.array([rider.fixed_cost * 100 for rider in all_riders], dtype = Cost)
    fixedCost_ptr = to_ctypes_array(fixedCost.flatten(), dtype = Cost_ctypes)

    capacity = np.array([rider.capa for rider in all_riders], dtype = Volume)
    capacity_ptr = to_ctypes_array(capacity.flatten(), dtype = Volume_ctypes)

    availableNumber = np.array([rider.available_number for rider in all_riders], dtype = RiderNumber)
    availableNumber_ptr = to_ctypes_array(availableNumber.flatten(), dtype = RiderNumber_ctypes)

    timeCriterion_ctypes = TimeCriterion_ctypes(timeCriterion)
    distanceCriterion_ctypes = DistanceCriterion_ctypes(distanceCriterion)


    current_dir = os.path.dirname(os.path.abspath(__file__))

    if use_revised:
        so_path = os.path.join(current_dir, 'libfinal_revised.so')
    else:
        so_path = os.path.join(current_dir, 'libfinal.so')
    
    lib = ctypes.CDLL(so_path)

    lib.run.argtypes = [
        Order_ctypes, # K
        ctypes.POINTER(Time_ctypes), # readyTime
        ctypes.POINTER(Time_ctypes), # deadline
        ctypes.POINTER(Volume_ctypes), # volume
        ctypes.POINTER(Time_ctypes), # travelTime
        ctypes.POINTER(Cost_ctypes), # variableCost
        ctypes.POINTER(Cost_ctypes), # fixedCost
        ctypes.POINTER(Volume_ctypes), # capacity
        ctypes.POINTER(RiderNumber_ctypes), # availableNumber
        DistanceCriterion_ctypes, # distanceCriterion
        TimeCriterion_ctypes, # timeCriterion
        TimeLimit_ctypes, # timeLimit
        ctypes.c_int # dummy value, which corresponds to a instance number
    ]

    
    lib.run.restype = ctypes.POINTER(Order_ctypes)

    lib.deleteArray.argtypes = [ctypes.POINTER(Order_ctypes)]
    lib.deleteArray.restype = None
    
    timeLeft = timelimit - (time.time() - startTime) - restorationTime
    timeLimit_ctypes = TimeLimit_ctypes(timeLeft)
    instanceNum_ctypes = ctypes.c_int(0)

    result_ptr = lib.run(
        K_ctypes,
        readyTime_ptr,
        deadline_ptr,
        volume_ptr,
        travelTime_ptr,
        variableCost_ptr,
        fixedCost_ptr,
        capacity_ptr,
        availableNumber_ptr,
        distanceCriterion_ctypes,
        timeCriterion_ctypes,
        timeLimit_ctypes,
        instanceNum_ctypes
    )

    solution = process_result_ptr(result_ptr)

    lib.deleteArray(result_ptr)

    return solution


def riderToString(rider):
    if rider == 0:
        return "BIKE"
    elif rider == 1:
        return "WALK"
    elif rider == 2:
        return "CAR"
    else:
        return "UNKNOWN"

def process_result_ptr(result_ptr):
    
    solution = []

    num_bundles = result_ptr[0]

    idx = 1 

    for _ in range(num_bundles):
        ridertype = result_ptr[idx]
        size = result_ptr[idx + 1]

        pickup_start = idx + 2
        pickup_end = pickup_start + size
        pickup_sequence = [int(result_ptr[i]) for i in range(pickup_start, pickup_end)]

        delivery_start = pickup_end
        delivery_end = delivery_start + size
        delivery_sequence = [int(result_ptr[i]) for i in range(delivery_start, delivery_end)]

        # Append the bundle to the solution list
        solution.append([riderToString(ridertype), pickup_sequence, delivery_sequence])

        # Move to the next bundle (increment idx by 18)
        idx += 18

    return solution