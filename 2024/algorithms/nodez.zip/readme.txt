Shared object file "libfinal.so" is made from a c++ source code file "final.cpp"
and "libfinal_revised.so" is made from "final_revised.cpp"

The process of generating the two shared object files are the same as follows:

1. We made a final.o file with the following code:

g++ -c -fPIC -O3 -std=c++17 \
    -I"/home/newsky/ogc-final" \
    -I"/opt/gurobi1101/linux64/include" \
    "final.cpp" \
    -o "final.o"
    
File directories must be modified, and replace "final_revised" in the place of "final" to make "final_revised.o".

2. We made an libfinal.so file with the following code:

g++ -shared -static-libstdc++ -static-libgcc -o libfinal.so final.o \
    -L/opt/gurobi1101/linux64/lib \
    -lgurobi_c++ -lgurobi110 -lpthread -lm 
    
Replace "final_revised" in the place of "final" to make "libfinal_revised.so".
