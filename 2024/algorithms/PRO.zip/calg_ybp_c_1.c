#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>
#include "xprb.h"
#include "xprs.h"
#include "hashmap.h"


#define NUM_THREADS 4
#define MAX_TH_PATTERNS 2000000

#define MAX_COL 500000
#define MAX_COL_FIN 100000
#define IT_PAT_MAX 100
#define EARLY_ITER 30
#define IT_PAT_MAX_EARLY 100
#define IT_PAT_MAX_EARLY_ENUM 200

#define FINAL_IP_RESERVED 0.5
#define ENUM_TIME 0.7
#define ENUM_IP_TIME 0.2
#define TREE_TIME 0.97
#define DUAL_PAT_ENUM 4

#define INF 1e9

#define THRESHOLD_DUAL 50
#define NUM_DUAL_CG_COLS 3000

#define NUM_TREE_EDGE_CHANGE 350
#define TREE_IT_FIRST 100000
#define THRESHOLD_FIRST 50 // stop improving tree by option 1, if not improved # times


#define TREE_IT_TOTAL 500
#define MAX_ORDER_IN_PATT 10

void solve();


double *getdual_first(XPRBprob *prob, XPRBvar *x, int *x_idx, XPRBctr *assign, XPRBctr *cardi, XPRBctr *obj, XPRBbasis *basis);
double *getdual_from(int n, XPRBprob *prob, XPRBvar *x, int *x_idx, XPRBctr *assign, XPRBctr *cardi, XPRBctr *obj, XPRBbasis *basis);
void dual_pattern_enum(int max_element, int from_n, int to_n);

double* solve_tree();
int** max_spanning_tree(int **patterns, int ***pat_h_n_idxs);
int** skeleton_from_inital_sol(int **patterns, int *dual_sol_idx, int num_dual_sol);
void tree_enum(int **skeleton);
int** tree_improve_first(int **skeleton);
int** loop_tree_improve_first(int **skeleton);


void get_sequenced_solution();
int* get_best_sequence(int* pattern, int* min_dist, int h);

inline double rider_capa(int rider_type);
inline double rider_var_cost(int rider_type);
inline double rider_fixed_cost(int rider_type);
inline double rider_speed(int rider_type);
inline double rider_service_time(int rider_type);
inline double rider_avail_num(int rider_type);
inline int order_ready_time(int order_num);
inline int order_deadline(int order_num);
inline int order_volume(int order_num);
inline int dist(int i, int j);

// utility functions
struct timespec start, finish;
int time_limit;
void print_time(char *msg)
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  printf("  %s %.4f\n", msg, (double)(finish.tv_sec - start.tv_sec) + (double)(finish.tv_nsec - start.tv_nsec) / 1000000000);
}

bool time_limit_exceeded_enum() // only used to check enumeration time_limit
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  return (finish.tv_sec - start.tv_sec) > (time_limit * ENUM_TIME );
}

bool time_limit_exceeded() // only used to check enumeration time_limit
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  return (finish.tv_sec - start.tv_sec) > (time_limit * TREE_TIME );
}
const int factorial[] = {1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800};
int ***nth_permutation_of_size;
void free_permutations()
{
  if (nth_permutation_of_size != NULL)
  {
    for (int i = 0; i < 11; i++)
    {
      if (nth_permutation_of_size[i] != NULL)
      {
        for (int j = 0; j < factorial[i]; j++)
        {
          if (nth_permutation_of_size[i][j] != NULL)
          {
            free(nth_permutation_of_size[i][j]);
          }
        }
        free(nth_permutation_of_size[i]);
      }
    }
    free(nth_permutation_of_size);
  }
}
void generate_permutations(int max_size)
{
  if (nth_permutation_of_size == NULL)
  {
    nth_permutation_of_size = (int ***)calloc(11, sizeof(int **));
    nth_permutation_of_size[1] = (int **)calloc(1, sizeof(int *));
    nth_permutation_of_size[1][0] = (int *)calloc(1, sizeof(int));
    nth_permutation_of_size[1][0][0] = 0;
  }
  for (int size = 2; size <= max_size; size++)
  {
    nth_permutation_of_size[size] = (int **)calloc(factorial[size], sizeof(int *));
    for (int n = 0; n < factorial[size]; n++)
    {
      nth_permutation_of_size[size][n] = (int *)calloc(size, sizeof(int));
      int q = n / factorial[size - 1];
      int d = n % factorial[size - 1];
      for (int i = 0; i < size; i++)
      {
        if (i < q)
          nth_permutation_of_size[size][n][i] = nth_permutation_of_size[size - 1][d][i];
        else if (i == q)
          nth_permutation_of_size[size][n][i] = size - 1;
        else
          nth_permutation_of_size[size][n][i] = nth_permutation_of_size[size - 1][d][i - 1];
      }
    }
  }
}

int *get_nth_permutation_of_size(int n, int size)
{
  return nth_permutation_of_size[size][n];
}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////

struct th_data_n
{
  int th_id;
  int n;
  int h;
  int idx_from;
  int idx_to;
  int *p_pat_idx;
  double *duals;
};

struct th_data
{
  int th_id;
  int n;
  int h;
  int idx_from;
  int idx_to;
  int *p_pat_idx;
};

typedef struct
{
  double cost;
  double rcost;
  int index;

} Element;

typedef struct
{
  int *parent;
  int *rank;
  int size;
} UnionFind;


// Define the structure for adjacency list node
typedef struct adj_list_node adj_list_node;
struct adj_list_node
{
  int id;
  adj_list_node *next;
};

typedef struct
{
  adj_list_node **adj_list;
  int size;
  UnionFind *uf;
} Tree;
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////

Tree *create_tree(int size);
bool add_edge(Tree *tree, int x, int y);
void free_tree(Tree *tree);

void *p_enum(void *data);
int extend(int th_id, int n, int h, int idx_from, int idx_to);

// Comparison function for sorting in ascending order
int compare(const void *a, const void *b);
void free_patterns();


void *p_enum_n(void *data);
int extend_n(int th_id, int n, int h, int idx_from, int idx_to, double *duals);
int pattern_enum_n(int n, int max_element, double *duals);


// global variables
int **order_arr, num_orders, num_riders, ***rider_time, *trt, **patterns, pattern_upto, ***pat_h_n_idxs, ***th_patterns, **th_patterns_data, num_x, *th_num_patterns, pat_idx, *solution, num_x_sol, *p_pat_idxs;
int ***edge_weight_idx, *tree_trt, **tree_patterns, ***tree_pat_h_n_idxs, tree_pat_idx;
int *tree_sol_idx, num_tree_sol;
int *dual_sol_idx, num_dual_sol;
int *solution, **solution_2d, *seq_solution, **seq_solution_2d;

// tree_it
int **best_patterns, best_pat_idx, *best_trt;
double best_obj;
int not_improved_tree_first = 0;
bool for_debug;
int *iter_patts_idxs, *idxs_sorted_by_deadline_slack;

double* duals;
int64_t *dist_arr;
double **rider_arr;
bool ***compat;
pthread_t pthread[NUM_THREADS];
int num_edges_in_tree;
Tree *tree;


// main function
int *pattern_enum(int **order_array,
                  double **rider_array,
                  int64_t *dist_array,
                  int order_num,
                  int pattern_upto_,
                  int max_element,
                  int *num_gen_patts,
                  int _time_limit)
{
  clock_gettime(CLOCK_MONOTONIC, &start);
  // INITIALIZATION
  time_limit = _time_limit;
  // enumeration related
  pattern_upto = pattern_upto_;
  num_riders = 3;
  rider_arr = rider_array; // capa, var_cost, fixed_cost, speed, service_time
  order_arr = order_array; // ready_time, deadline, volume
  dist_arr = dist_array;
  num_orders = order_num;

  // calculate rider time takes less than 0.1 second for 1000 orders and 3 riders
  rider_time = (int ***)calloc(num_riders, sizeof(int **));
  
  for (int h = 0; h < num_riders; h++)
  {
    rider_time[h] = (int **)calloc(2 * order_num, sizeof(int *));
    for (int j = 0; j < 2 * order_num; j++)
    {
      rider_time[h][j] = (int *)calloc(2 * order_num, sizeof(int));
      for (int jj = 0; jj < 2 * order_num; jj++)
      {
        rider_time[h][j][jj] = round(dist(j, jj) / rider_speed(h) + rider_service_time(h));
      }
    }
  }

  // pairwise compatibility check related
  compat = (bool ***)calloc(num_riders, sizeof(bool **));
  for (int h = 0; h < num_riders; h++)
  {
    compat[h] = (bool **)calloc(num_orders, sizeof(bool *));
    for (int i = 0; i < num_orders; i++)
    {
      compat[h][i] = (bool *)calloc(num_orders, sizeof(bool));
    }
  }
  


  // return related
  trt = (int *)calloc(max_element * (pattern_upto + 3), sizeof(int));
  patterns = (int **)calloc(max_element, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
  for (int i = 0; i < max_element; i++)
  {
    patterns[i] = trt + i * (pattern_upto + 3);
  }

  tree_trt = (int *)calloc(max_element * (pattern_upto + 3), sizeof(int));
  tree_patterns = (int **)calloc(max_element, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
  for (int i = 0; i < max_element; i++)
  {
    tree_patterns[i] = tree_trt + i * (pattern_upto + 3);
  }

  best_trt = (int *)calloc(max_element * (pattern_upto + 3), sizeof(int));
  best_patterns = (int **)calloc(max_element, sizeof(int *)); 
  for (int i = 0; i < max_element; i++)
  {
    best_patterns[i] = best_trt + i * (pattern_upto + 3);
  }

  // thread related
  th_patterns_data = (int **)calloc(NUM_THREADS, sizeof(int *));
  th_patterns = (int ***)calloc(NUM_THREADS, sizeof(int **));
  for (int i = 0; i < NUM_THREADS; i++)
  {
    th_patterns_data[i] = (int *)calloc(MAX_TH_PATTERNS * (pattern_upto + 3), sizeof(int));
    th_patterns[i] = (int **)calloc(MAX_TH_PATTERNS, sizeof(int *));
    for (int j = 0; j < MAX_TH_PATTERNS; j++)
    {
      th_patterns[i][j] = th_patterns_data[i] + (j * (pattern_upto + 3));
    }
  }
  th_num_patterns = (int *)calloc(NUM_THREADS, sizeof(int));
  generate_permutations(pattern_upto);
  print_time("Initialization : ");
  // INITIALIZATION END

  // // TEST INPUTS
  printf("time_limit: %d\n", time_limit);
  printf("num_orders: %d\n", num_orders);
  // printf("num_riders: %d\n", num_riders);
  printf("pattern_upto: %d\n", pattern_upto);


  // PATTERN ENUMERATION
  pat_idx = 0;
  pat_h_n_idxs = (int ***)calloc(num_riders, sizeof(int **));
  for (int h = 0; h < num_riders; h++)
  {
    pat_h_n_idxs[h] = (int **)calloc(pattern_upto, sizeof(int *));
    for (int n = 0; n < pattern_upto; n++)
    {
      pat_h_n_idxs[h][n] = (int *)calloc(2, sizeof(int));
    }
  }

  tree_pat_h_n_idxs = (int ***)calloc(num_riders, sizeof(int **));
  for (int h = 0; h < num_riders; h++)
  {
    tree_pat_h_n_idxs[h] = (int **)calloc(pattern_upto, sizeof(int *));
    for (int n = 0; n < pattern_upto; n++)
    {
      tree_pat_h_n_idxs[h][n] = (int *)calloc(2, sizeof(int));
    }
  }

  // pattern with 1 order (for tree, node!)-------------------------
  for (int h = 0; h < num_riders; h++)
  {
    pat_h_n_idxs[h][0][0] = pat_idx;
    tree_pat_h_n_idxs[h][0][0] = pat_idx;

    for (int i = 0; i < num_orders; i++)
    {
      if ((order_volume(i) <= rider_capa(h)) && (order_ready_time(i) + rider_time[h][i][i + num_orders] <= order_deadline(i)))
      { 
        //printf(" 1 order for %d is fsb \n [", i);
        patterns[pat_idx][0] = 1;
        patterns[pat_idx][1] = i;
        patterns[pat_idx][pattern_upto + 1] = 100 * rider_fixed_cost(h) + rider_var_cost(h) * dist(i, i + num_orders);
        patterns[pat_idx][pattern_upto + 2] = h;

        //for(int j = 0; j < pattern_upto + 3 ; j++){
        //  printf(" %d ", patterns[pat_idx][j]);
        //}
        pat_idx ++;
      }
    }
    pat_h_n_idxs[h][0][1] = pat_idx;
    tree_pat_h_n_idxs[h][0][1] = pat_idx;
    printf("    n %d  h %d  : %8d", 1, h, pat_h_n_idxs[h][0][1] - pat_h_n_idxs[h][0][0]);
  } 

  
  print_time("");
  
  printf("    ----\n");

  p_pat_idxs = (int *)calloc(NUM_THREADS, sizeof(int));
  int num_patterns_to_copy = pat_h_n_idxs[2][0][1] - pat_h_n_idxs[0][0][0];
  tree_pat_idx = num_patterns_to_copy;
  memcpy(&tree_patterns[pat_h_n_idxs[0][0][0]][0], &patterns[pat_h_n_idxs[0][0][0]][0], num_patterns_to_copy * (pattern_upto + 3) * sizeof(int) );




  // pattern with 2 orders (not for tree_patterns) -------------------------
  num_dual_sol = 0;
  dual_sol_idx = (int *)malloc( 2000 * sizeof(int));
  // dual_pattern_enum(max_element, 2, 2);


  for (int h = 0; h < num_riders; h++)
  {
    pat_h_n_idxs[h][1][0] = pat_idx;
    for (int i = 0; i < NUM_THREADS; i++)
    {
      struct th_data *data = (struct th_data *)malloc(sizeof(struct th_data));
      data->th_id = i;
      data->n = 2;
      data->h = h;
      data->idx_from = pat_h_n_idxs[h][0][0];
      data->idx_to = pat_h_n_idxs[h][0][1];
      data->p_pat_idx = &(p_pat_idxs[i]);
      int stat = pthread_create(&pthread[i], NULL, p_enum, (void *)data);
      if (stat != 0)
      {
        printf("pthread_create error\n");
        fflush(stdout);
      }
    }

    for (int i = 0; i < NUM_THREADS; i++)
    {
      pthread_join(pthread[i], NULL);
    }
    // print_time("");
    for (int i = 0; i < NUM_THREADS; i++)
    {
      memcpy(&(patterns[pat_idx][0]), &(th_patterns[i][0][0]), p_pat_idxs[i] * (pattern_upto + 3) * sizeof(int));
      pat_idx += p_pat_idxs[i];
    }
    pat_h_n_idxs[h][1][1] = pat_idx;
    for (int idx = pat_h_n_idxs[h][1][0]; idx < pat_h_n_idxs[h][1][1]; idx++)
    {
      compat[h][patterns[idx][1]][patterns[idx][2]] = true;
      compat[h][patterns[idx][2]][patterns[idx][1]] = true;
    }


    printf("    n %d  h %d  : %8d", 2, h, pat_h_n_idxs[h][1][1] - pat_h_n_idxs[h][1][0]);
    print_time("");
    if (pat_idx == max_element)
      break;
  }
  printf("    ----\n"); 


  // PATTERN ENUMERATION for 1 and 2 orders end////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  
  

  // PATTERN ENUMERATION for n>=3 orders start /////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  // PATTERN ENUM for 3 orders
  dual_pattern_enum(max_element, 3, DUAL_PAT_ENUM);

  // TREE CONSTRUCTION //////////////////////////////////////////////////////////////
  
  //int** skeleton = max_spanning_tree(patterns, pat_h_n_idxs);
  int** skeleton = skeleton_from_inital_sol(patterns, dual_sol_idx, num_dual_sol);
  tree_sol_idx = (int *)malloc( num_orders * sizeof(int));
  for_debug = true;
  skeleton = loop_tree_improve_first(skeleton);

  






  // COLUMN SELECTION and OPT starts ///////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////

  printf("CG starts");
  solve();
  printf("solve ended");
  // COLUMN SELECTION and OPT ends /////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////

  // TREE IMPROVEMENT /////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////

  //improve_tree();


  //FINAL

  get_sequenced_solution();





  // FREE MEMORY
  free(p_pat_idxs);
  for (int i = 0; i < num_riders; i++)
  {
    for (int j = 0; j < 2 * num_orders; j++)
    {
      free(rider_time[i][j]);
    }
    free(rider_time[i]);
  }
  free(rider_time);
  free(patterns);
  free(tree_patterns);
  free(best_patterns);
  // hashmap_free(map);
  free_permutations();
  for (int h = 0; h < num_riders; h++)
  {
    for (int n = 0; n < pattern_upto; n++)
    {
      free(pat_h_n_idxs[h][n]);
      free(tree_pat_h_n_idxs[h][n]);
    }
    free(pat_h_n_idxs[h]);
    free(tree_pat_h_n_idxs[h]);
  }
  free(pat_h_n_idxs);
  free(tree_pat_h_n_idxs);
  free(th_num_patterns);
  for (int i = 0; i < NUM_THREADS; i++)
  {
    free(th_patterns_data[i]);
    free(th_patterns[i]);
    // pthread_cancel(pthread[i]);
  }
  free(th_patterns);
  free(th_patterns_data);
  free(trt);
  free(tree_trt);
  free(best_trt);

  // FREE MEMORY END

  num_gen_patts[0] = num_x_sol;

/*   for (int i = 0; i < num_x_sol; i++)
  {
    for (int j = 0 ; j < 2 * MAX_ORDER_IN_PATT + 3 ; j ++)
      printf(" %d ", seq_solution_2d[i][j]);
    printf("\n");
  }
 */
  // trt = (int *)realloc(trt, pat_idx * (pattern_upto+3) * sizeof(int));
  return seq_solution;
}



inline double rider_capa(int rider_type)
{
  return rider_arr[rider_type][0];
}
inline double rider_var_cost(int rider_type)
{
  return rider_arr[rider_type][1];
}
inline double rider_fixed_cost(int rider_type)
{
  return rider_arr[rider_type][2];
}
inline double rider_speed(int rider_type)
{
  return rider_arr[rider_type][3];
}
inline double rider_service_time(int rider_type)
{
  return rider_arr[rider_type][4];
}
inline double rider_avail_num(int rider_type)
{
  return rider_arr[rider_type][5];
}
inline int order_ready_time(int order_num)
{
  return order_arr[order_num][0];
}
inline int order_deadline(int order_num)
{
  return order_arr[order_num][1];
}
inline int order_volume(int order_num)
{
  return order_arr[order_num][2];
}
inline int dist(int i, int j)
{
  return dist_arr[i * (2 * num_orders) + j];
}


void *p_enum(void *data)
{
  // pid_t pid = getpid();
  // pthread_t tid = pthread_self();
  struct th_data *th_data = (struct th_data *)data;
  // printf("th %d  pid %d  tid %d  running\n", th_data->th_id, pid, tid);
  // printf("  n %d  h %d  idx_from %d  idx_to %d\n", th_data->n, th_data->h, th_data->idx_from, th_data->idx_to);
  *(th_data->p_pat_idx) = extend(th_data->th_id, th_data->n, th_data->h, th_data->idx_from, th_data->idx_to);
  // printf("--------------------------------------\n");
  return NULL;
}

int extend(int th_id, int n, int h, int idx_from, int idx_to)
{
  // printf("th %d  n %d  h %d\n", th_id, n, h);
  // printf("th%d called ", th_id); print_time("");
  int pat_idx = 0;
  int min_last_pickup_time = INF;
  int *pickup_dists = malloc(factorial[n] * sizeof(int));
  int *pickup_times = malloc(factorial[n] * sizeof(int));
  int *delivery_dists = malloc(factorial[n] * sizeof(int));
  int *delivery_times = malloc(factorial[n] * sizeof(int));
  int *base_seq = malloc(n * sizeof(int));
  int *temp_subset_patt = (int *)calloc(pattern_upto + 3, sizeof(int));
  // char *temp_id; // to check pattern with id is in hashmap
  temp_subset_patt[0] = n - 1;
  int *perm, *d_perm, *p_perm;
  temp_subset_patt[pattern_upto + 2] = h;
  int front, end;
  int *sorted_idxs_p = (int *)calloc(factorial[n], sizeof(int));
  int *sorted_idxs_d = (int *)calloc(factorial[n], sizeof(int));
  // printf("th%d init \n", th_id);
  for (int idx = idx_from + th_id; idx < idx_to; idx += NUM_THREADS)
  {
    // printf("th %d idx %d  here\n", th_id, idx);
    int *base_pat = patterns[idx];
    int max_order = base_pat[n - 1];
    int base_pat_volume = 0;
    for (int i = 1; i <= n - 1; i++)
      base_pat_volume += order_volume(base_pat[i]);
    for (int k = max_order + 1; k < num_orders; k++)
    {
      // printf("th %d idx %d k %d  here\n", th_id, idx, k);
      // check capacity
      if (order_volume(k) + base_pat_volume > rider_capa(h) + 1e-5)
        continue;

      // check subset feasibility
      bool subset_feasible = true;
      if (n > 2)
      {
        for (int i = 1; i < n; i++)
        {
          if (!compat[h][base_pat[i]][k])
          {
            subset_feasible = false;
            break;
          }
        }
      }
      if (!subset_feasible)
        continue;

      // check route feasibility
      int min_deadline = order_deadline(k);
      int min_deadline_order = k;
      for (int i = 1; i < n; i++)
      {
        min_deadline = (order_deadline(base_pat[i]) < min_deadline) ? order_deadline(base_pat[i]) : min_deadline;
        if (min_deadline == order_deadline(base_pat[i]))
          min_deadline_order = base_pat[i];
      }
      min_last_pickup_time = INF;
      for (int i = 1; i <= n; i++)
        base_seq[i - 1] = base_pat[i];
      base_seq[n - 1] = k;

      //// pickup sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        pickup_dists[seq_idx] = 0;
        pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);
        if (pickup_times[seq_idx] > min_deadline)
        {
          sorted_idxs_p[end--] = seq_idx;
          pickup_dists[seq_idx] = INF;
          continue;
        }
        for (int i = 1; i < n; i++)
        {
          pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
          pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
          if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
          {
            pickup_dists[seq_idx] = INF;
            break;
          }
          pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
        }
        if (pickup_dists[seq_idx] >= INF)
        {
          sorted_idxs_p[end--] = seq_idx;
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
            break;
        }
        memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
        sorted_idxs_p[idx] = seq_idx;
        front ++;
        // sorted_idxs_p[front++] = seq_idx;
        min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
      }
      if (min_last_pickup_time >= INF)
        continue;

      //// delivery sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        delivery_dists[seq_idx] = 0;
        delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);
        if (delivery_times[seq_idx] < min_last_pickup_time)
        {
          delivery_dists[seq_idx] = INF;
          sorted_idxs_d[end--] = seq_idx;
          continue;
        }
        for (int i = n - 1; i > 0; i--)
        {
          delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
          delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
          if (delivery_times[seq_idx] < min_last_pickup_time)
          {
            delivery_dists[seq_idx] = INF;
            break;
          }
          delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
        }
        if (delivery_dists[seq_idx] >= INF)
        {
          sorted_idxs_d[end--] = seq_idx;
          continue;
        }

        int idx = 0;
        for (; idx < front; idx++)
        {
          if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
            break;
        }
        memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
        sorted_idxs_d[idx] = seq_idx;
        front ++;
        // sorted_idxs_d[front++] = seq_idx;
      }

      //// Find best combination
      int min_dist = INF;
      int p_idx, d_idx;
      for (int i = 0; i < factorial[n]; i++)
      {
        p_idx = sorted_idxs_p[i];
        if (pickup_dists[p_idx] >= INF)
          break;
        bool checker = false; 
        p_perm = get_nth_permutation_of_size(p_idx, n);
        for (int j = 0; j < factorial[n]; j++)
        {
          d_idx = sorted_idxs_d[j];
          if (delivery_dists[d_idx] >= INF)
            break;
          if (pickup_dists[p_idx] + delivery_dists[d_idx] > min_dist)
          {
            checker = true;
            break;
          }
          d_perm = get_nth_permutation_of_size(d_idx, n);
          if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[base_pat[0]]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders) < min_dist))
          {
            min_dist = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders);
          }
        }
        if (checker)
          break;
      }

      //// add if feasible
      if (min_dist < INF)
      {
        th_patterns[th_id][pat_idx][0] = n;
        memcpy(&(th_patterns[th_id][pat_idx][1]), &(base_pat[1]), (n - 1) * sizeof(int));
        th_patterns[th_id][pat_idx][n] = k;
        th_patterns[th_id][pat_idx][pattern_upto + 1] = 100 * rider_fixed_cost(h) + rider_var_cost(h) * min_dist;
        th_patterns[th_id][pat_idx][pattern_upto + 2] = h;
        pat_idx += 1;
      }
      if (pat_idx == MAX_TH_PATTERNS || time_limit_exceeded_enum())
        break;
    }
    if (pat_idx == MAX_TH_PATTERNS || time_limit_exceeded_enum())
      break;
  }
  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  free(temp_subset_patt);
  // printf("th%d done gen %d ", th_id, pat_idx); print_time("");
  return pat_idx;
}

void *p_enum_n(void *data)
{

  struct th_data_n *th_data_n = (struct th_data_n *)data; // th_data_n

  // for each thread, extend_n (enum for order = n)
  *(th_data_n->p_pat_idx) = extend_n(th_data_n->th_id, th_data_n->n, th_data_n->h, th_data_n->idx_from, th_data_n->idx_to, th_data_n->duals);

  return NULL;
}

int extend_n(int th_id, int n, int h, int idx_from, int idx_to, double *duals)
{
  // printf("extended_n is called for n = %d", n);
  // printf("th %d  n %d  h %d\n", th_id, n, h);
  // printf("th%d called ", th_id); print_time("");
  int pat_idx = 0;
  int min_last_pickup_time = 1e9;
  int *pickup_dists = malloc(factorial[n] * sizeof(int));
  int *pickup_times = malloc(factorial[n] * sizeof(int));
  int *delivery_dists = malloc(factorial[n] * sizeof(int));
  int *delivery_times = malloc(factorial[n] * sizeof(int));
  int *base_seq = malloc(n * sizeof(int));
  int *temp_subset_patt = (int *)calloc(pattern_upto + 3, sizeof(int));
  // char *temp_id; // to check pattern with id is in hashmap
  temp_subset_patt[0] = n - 1;
  int *perm, *d_perm, *p_perm;
  temp_subset_patt[pattern_upto + 2] = h;
  int front, end;
  int *sorted_idxs_p = (int *)calloc(factorial[n], sizeof(int));
  int *sorted_idxs_d = (int *)calloc(factorial[n], sizeof(int));
  // printf("th%d init \n", th_id);
  for (int idx = idx_from + th_id; idx < idx_to; idx += NUM_THREADS)
  {
    // printf("th %d idx %d  here\n", th_id, idx);
    int *base_pat = patterns[idx];
    int max_order = base_pat[n - 1];
    int base_pat_volume = 0;

    // printf("\n base pat is (");
    for (int i = 1; i <= n - 1; i++)
    {
      base_pat_volume += order_volume(base_pat[i]);
      // printf("%d, ", base_pat[i]);
    }
    // printf(") \n");

    for (int k = max_order + 1; k < num_orders; k++)
    {

      // printf("th %d idx %d k %d  here\n", th_id, idx, k);
      // check capacity
      if (order_volume(k) + base_pat_volume > rider_capa(h) + 1e-5)
        // printf("capa exceeded and pass");
        continue;

      // check subset feasibility
      bool subset_feasible = true;
      if (n > 2)
      {
        for (int i = 1; i < n; i++)
        {
          if (!compat[h][base_pat[i]][k])
          {
            subset_feasible = false;
            break;
          }
        }
      }
      if (!subset_feasible)
        // printf("subset infeasible and pass");
        continue;

      // check route feasibility
      int min_deadline = order_deadline(k);
      int min_deadline_order = k;
      for (int i = 1; i < n; i++)
      {
        min_deadline = (order_deadline(base_pat[i]) < min_deadline) ? order_deadline(base_pat[i]) : min_deadline;
        if (min_deadline == order_deadline(base_pat[i]))
          min_deadline_order = base_pat[i];
      }
      min_last_pickup_time = 1e9;
      for (int i = 1; i <= n; i++)
        base_seq[i - 1] = base_pat[i];
      base_seq[n - 1] = k;

      //// pickup sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        pickup_dists[seq_idx] = 0;
        pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);
        if (pickup_times[seq_idx] > min_deadline)
        {
          sorted_idxs_p[end--] = seq_idx;
          pickup_dists[seq_idx] = 1e9;
          // printf("pickup exceed deadline");
          continue;
        }
        for (int i = 1; i < n; i++)
        {
          pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
          pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
          if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
          {
            pickup_dists[seq_idx] = 1e9;
            break;
          }
          pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
        }
        if (pickup_dists[seq_idx] >= 1e9)
        {
          sorted_idxs_p[end--] = seq_idx;
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
            break;
        }
        memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
        sorted_idxs_p[idx] = seq_idx;
        front += 1;

        min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
      }
      if (min_last_pickup_time >= 1e9)
        continue;

      //// delivery sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        delivery_dists[seq_idx] = 0;
        delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);
        if (delivery_times[seq_idx] < min_last_pickup_time)
        {
          delivery_dists[seq_idx] = 1e9;
          sorted_idxs_d[end--] = seq_idx;
          // printf("delivera incompat with pickup");
          continue;
        }
        for (int i = n - 1; i > 0; i--)
        {
          delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
          delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
          if (delivery_times[seq_idx] < min_last_pickup_time)
          {
            delivery_dists[seq_idx] = 1e9;
            break;
          }
          delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
        }
        if (delivery_dists[seq_idx] >= 1e9)
        {
          sorted_idxs_d[end--] = seq_idx;
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
            break;
        }
        memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
        sorted_idxs_d[idx] = seq_idx;
        front += 1;
        // sorted_idxs_d[front++] = seq_idx;
      }

      //// Find best combination
      int min_dist = 1e9;
      int p_idx, d_idx;
      for (int i = 0; i < factorial[n]; i++)
      {
        p_idx = sorted_idxs_p[i];
        if (pickup_dists[p_idx] >= 1e9)
          break;
        bool checker = false;
        p_perm = get_nth_permutation_of_size(p_idx, n);
        for (int j = 0; j < factorial[n]; j++)
        {
          d_idx = sorted_idxs_d[j];
          if (delivery_dists[d_idx] >= 1e9)
            break;
          if (pickup_dists[p_idx] + delivery_dists[d_idx] > min_dist)
          {
            checker = true;
            break;
          }
          d_perm = get_nth_permutation_of_size(d_idx, n);
          if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[base_pat[0]]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders) < min_dist))
          {
            min_dist = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders);
          }
        }
        if (checker)
          break;
      }

      //// check feasible
      if (min_dist < 1e9) // fsb
      // add if profitable
      { // candidate_cost : avg cost * (num_orders * 100)
        // printf("in if min_dist < 1e9 \n");
        int candidate_cost = 100 * rider_fixed_cost(h) + rider_var_cost(h) * min_dist;
        double reduced_cost = candidate_cost / (num_orders * 100) - duals[num_orders + h];
        // calculate reduced cost (already rider, now assignment)
        for (int j = 1; j < n; j++) // 1 ~ n-1 th
        {
          reduced_cost -= duals[base_pat[j]];
        }

        reduced_cost -= duals[k]; // n th
        // printf("cost : %d, ", candidate_cost);
        // printf("reduced cost: %f \n", reduced_cost);

        if (reduced_cost < -1e-5)
        {
          th_patterns[th_id][pat_idx][0] = n;
          memcpy(&(th_patterns[th_id][pat_idx][1]), &(base_pat[1]), (n - 1) * sizeof(int));
          th_patterns[th_id][pat_idx][n] = k;
          th_patterns[th_id][pat_idx][pattern_upto + 1] = candidate_cost;
          th_patterns[th_id][pat_idx][pattern_upto + 2] = h;
          pat_idx += 1;
        }
      }
      if (pat_idx == MAX_TH_PATTERNS || time_limit_exceeded_enum())
        break;
    }
    if (pat_idx == MAX_TH_PATTERNS || time_limit_exceeded_enum())
      break;
  }
  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  free(temp_subset_patt);

  /*   printf("\n");
    for (int i = 0; i < pat_idx; i ++){
      printf("[");
      for (int j =0 ; j < pattern_upto + 3 ; j ++){
        printf(" %d ", th_patterns[th_id][i][j]);
      }
      printf("] \n");
    } */

  // printf("th%d done gen %d ", th_id, pat_idx); print_time("");
  return pat_idx;
}



////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
//
//                                     TREE CONSTRUCTION CODE
//
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
  int **mat;
  int **result;
  int n;
  int start_row;
  int end_row;
  int type;
} MatSquareData;

void *compute_block(void *arg)
{
  MatSquareData *data = (MatSquareData *)arg;
  if (data->type == 0){
    for (int i = data->start_row; i < data->end_row; i++)
    {
      for (int j = i ; j < data->end_row; j++)
      {
        int sum = 0;
        for (int k = 0; k < data->n; k++)
        {
          sum += data->mat[i][k] * data->mat[k][j];
        }
        data->result[i][j] = sum;
        data->result[j][i] = sum;
      }
    }}
  else if (data->type == 1)
  {
    for (int i = data->start_row; i < data->end_row; i++)
    {
      for (int j = i + data->n/2; j < data->end_row + data->n/2; j++)
      {
        int sum = 0;
        for (int k = 0; k < data->n; k++)
        {
          sum += data->mat[i][k] * data->mat[k][j];
        }
        data->result[i][j] = sum;
        data->result[j][i] = sum;
      }
    }
  }
  else if (data->type == 2)
  {
    for (int i = data->start_row; i < data->end_row; i++)
    {
      for (int j = 0 + data->n/2; j < i + data->n/2; j++)
      {
        int sum = 0;
        for (int k = 0; k < data->n; k++)
        {
          sum += data->mat[i][k] * data->mat[k][j];
        }
        data->result[i][j] = sum;
        data->result[j][i] = sum;
      }
    }
  }

  pthread_exit(0);
}

int **mat_square(int **mat, int n)
{
  int **result = (int **)malloc(n * sizeof(int *));
  for (int i = 0; i < n; i++)
  {
    result[i] = (int *)malloc(n * sizeof(int));
  }

  pthread_t threads[4];
  MatSquareData thread_data[4];

  thread_data[0].start_row = 0;
  thread_data[0].end_row = n / 2;
  thread_data[0].type = 0;
  thread_data[1].start_row = n / 2;
  thread_data[1].end_row = n;
  thread_data[1].type = 0;
  thread_data[2].start_row = 0;
  thread_data[2].end_row = n / 2;
  thread_data[2].type = 1;
  thread_data[3].start_row = 0;
  thread_data[3].end_row = n / 2;
  thread_data[3].type = 2;

  for (int i = 0; i < 4; i++)
  {
    thread_data[i].mat = mat;
    thread_data[i].result = result;
    thread_data[i].n = n;
    pthread_create(&threads[i], NULL, compute_block, (void *)&thread_data[i]);
  }

  for (int i = 0; i < 4; i++)
  {
    pthread_join(threads[i], NULL);
  }

  return result;
}


int* num_node ;
int finds(int node, int* parent) 
{
    if (parent[node] != node) {
        parent[node] = finds(parent[node], parent);
    }
    return parent[node];
}

void union_nodes(int node1, int node2, int* parent) 
{
    int root1 = finds(node1, parent);
    int root2 = finds(node2, parent);
    if (root1 != root2) {
        parent[root1] = root2;  // 루트를 병합
    }
}

int compare_edges(const void* a, const void* b) 
{
    const int* edge_a = *(const int**)a;
    const int* edge_b = *(const int**)b;

    return edge_b[1] - edge_a[1]; //sort by weight
}

int** max_spanning_tree(int **patterns, int ***pat_h_n_idxs)
{ // vehicle type h = 1
  // parent to avoid cycle

  edge_weight_idx = (int ***)calloc(num_riders, sizeof(int *));
  for (int h = 0; h < num_riders; h++) {
      int num_patterns = pat_h_n_idxs[h][1][1] - pat_h_n_idxs[h][1][0];
      edge_weight_idx[h] = (int **)calloc(num_patterns, sizeof(int *));
      
      for (int i = 0; i < num_patterns; i++) {
          edge_weight_idx[h][i] = (int *)calloc(2, sizeof(int));
      }
  }

  num_node = (int*)malloc(3 * sizeof(int));
  num_node[0] = tree_pat_h_n_idxs[0][0][1];
  num_node[1] = tree_pat_h_n_idxs[1][0][1] - tree_pat_h_n_idxs[1][0][0];
  num_node[2] = tree_pat_h_n_idxs[2][0][1] - tree_pat_h_n_idxs[2][0][0];

  for (int h = 0 ; h < num_riders ; h ++)
  {
    int **node_node; 
    node_node = (int **)calloc(num_orders, sizeof(int *));
    for (int i = 0; i < num_orders; i++) 
    {
      node_node[i] = (int *)calloc(num_orders, sizeof(int));
    }

    for (int idx = pat_h_n_idxs[h][1][0]; idx < pat_h_n_idxs[h][1][1] ; idx++ )
    {
      node_node[patterns[idx][1]][patterns[idx][2]] = 1;
      node_node[patterns[idx][2]][patterns[idx][1]] = 1;
    }

    int ** square_node = mat_square(node_node, num_orders);
    
    int num = 0;
    for (int idx = pat_h_n_idxs[h][1][0]; idx < pat_h_n_idxs[h][1][1] ; idx++ )
    { 
      edge_weight_idx[h][num][0] = num; //idx = 0, 1, ...
      edge_weight_idx[h][num][1] = square_node[patterns[idx][1]][patterns[idx][2]]; //weight
      num ++ ;
    }
  }
  
  tree = create_tree(num_orders);
  
 //tree based on veh type 1
  int** skeleton;
    skeleton = (int **)malloc(num_orders * sizeof(int *));
    for (int i = 0; i < num_orders; i++) 
    {
      skeleton[i] = (int *)malloc(2 * sizeof(int));
    }
  int* parent = (int*)malloc(num_orders * sizeof(int));

  for (int idx = 0 ; idx < pat_h_n_idxs[2][0][1]; idx ++)
  {
    parent[patterns[idx][1]] = patterns[idx][1];
  }
  for (int h = 0 ; h < num_riders; h ++)
  {
    qsort(edge_weight_idx[h], pat_h_n_idxs[h][1][1] - pat_h_n_idxs[h][1][0], sizeof(int *) , compare_edges);
  }

  // based on veh 1 -> skeleton
  int edge_size = pat_h_n_idxs[1][1][1] - pat_h_n_idxs[1][1][0];
  num_edges_in_tree = 0;

  for (int i = 0 ; i < edge_size ; i ++) // ++i 
  {
    int u = patterns[ edge_weight_idx[1][i][0] + pat_h_n_idxs[1][1][0] ][1];
    int v = patterns[ edge_weight_idx[1][i][0] + pat_h_n_idxs[1][1][0] ][2];
    if (add_edge(tree, u, v)) 
    {
      skeleton[num_edges_in_tree][0] = u;
      skeleton[num_edges_in_tree][1] = v;
      num_edges_in_tree++;

    }

    if (num_edges_in_tree == num_orders- 1) 
    {
      break;
    } 
  }

  ////////////////////////////////////////////////////////////////////////////////////////////
  // tree for veh 0 (num: [0][1][1] - [0][1][0])

  printf("starts with all 1 orders, so tree_pat_idx = %d \n", tree_pat_idx);
  edge_size = pat_h_n_idxs[0][1][1] - pat_h_n_idxs[0][1][0];
  printf("edge_size for vehicle 0 is %d \n", edge_size);
  fflush(stdout);


  for (int i = 0 ; i < edge_size ; i ++)
  {
    int u = patterns[ edge_weight_idx[0][i][0] + pat_h_n_idxs[0][1][0] ][1];
    int v = patterns[ edge_weight_idx[0][i][0] + pat_h_n_idxs[0][1][0] ][2];

    if (add_edge(tree, u, v)) 
    {
      skeleton[num_edges_in_tree][0] = u;
      skeleton[num_edges_in_tree][1] = v;
      num_edges_in_tree++;

    }
    if (num_edges_in_tree == num_orders- 1) 
    {
      break;
    } 
  }


  edge_size = pat_h_n_idxs[2][1][1] - pat_h_n_idxs[2][1][0];
  for (int i = 0 ; i < edge_size ; i ++)
  {
    int u = patterns[ edge_weight_idx[2][i][0] + pat_h_n_idxs[2][1][0] ][1];
    int v = patterns[ edge_weight_idx[2][i][0] + pat_h_n_idxs[2][1][0] ][2];

    if (add_edge(tree, u, v)) 
    {
      skeleton[num_edges_in_tree][0] = u;
      skeleton[num_edges_in_tree][1] = v;
      num_edges_in_tree++;

    }

    if (num_edges_in_tree == num_orders - 1) 
    {
      break;
    } 
  }
  
  for (int h = 0; h < num_riders; h++) 
  {
    if (edge_weight_idx[h] != NULL) 
    {
        for (int i = 0; i < (pat_h_n_idxs[h][1][1] - pat_h_n_idxs[h][1][0]); i++) 
        {
            if (edge_weight_idx[h][i] != NULL) {
                free(edge_weight_idx[h][i]);  
            }
        }
        free(edge_weight_idx[h]); 
    }
  }
  free(edge_weight_idx);
  free_tree(tree);

  free(parent); 
  free(num_node);
  

  return skeleton;
}



int get_min_cost_route_enum(int *orders, int n, int h);


// Define the structure for tree
/* START of Union-Find CODES (union-find is used to check connectivity among nodes) */
// Define the structure for Union-Find

// Function to create a new Union-Find structure
UnionFind *create_union_find(int size)
{
  UnionFind *uf = (UnionFind *)malloc(sizeof(UnionFind));
  uf->parent = (int *)malloc(size * sizeof(int));
  uf->rank = (int *)malloc(size * sizeof(int));
  uf->size = size;
  for (int i = 0; i < size; i++)
  {
    uf->parent[i] = i;
    uf->rank[i] = 0;
  }
  return uf;
}
// Function to find the root of an element
int find(UnionFind *uf, int x)
{
  if (uf->parent[x] != x)
  {
    uf->parent[x] = find(uf, uf->parent[x]); // Path compression
  }
  return uf->parent[x];
}
// Function to union two sets
void union_sets(UnionFind *uf, int rootX, int rootY)
{
  if (uf->rank[rootX] > uf->rank[rootY])
  {
    uf->parent[rootY] = rootX;
  }
  else if (uf->rank[rootX] < uf->rank[rootY])
  {
    uf->parent[rootX] = rootY;
  }
  else
  {
    uf->parent[rootY] = rootX;
    uf->rank[rootX]++;
  }
}
// Function to free the Union-Find structure
void free_union_find(UnionFind *uf)
{
  free(uf->parent);
  free(uf->rank);
  free(uf);
}
/* END OF UNION-FIND CODE */


// Tree is represented as an adjacency list


// Function to create a new tree structure
Tree *create_tree(int size)
{
  Tree *tree = (Tree *)malloc(sizeof(Tree));
  tree->adj_list = (adj_list_node **)malloc(size * sizeof(adj_list_node *));
  tree->size = size;
  for (int i = 0; i < size; i++)
  {
    tree->adj_list[i] = NULL;
  }
  tree->uf = create_union_find(size);
  return tree;
}

// Function to add an edge to the tree
bool add_edge(Tree *tree, int x, int y)
{
  int rootX = find(tree->uf, x);
  int rootY = find(tree->uf, y);
  if (rootX != rootY)
  {
    union_sets(tree->uf, rootX, rootY);
    adj_list_node *node = (adj_list_node *)malloc(sizeof(adj_list_node));
    node->id = y;
    node->next = tree->adj_list[x];
    tree->adj_list[x] = node;
    node = (adj_list_node *)malloc(sizeof(adj_list_node));
    node->id = x;
    node->next = tree->adj_list[y];
    tree->adj_list[y] = node;
    return true;
  }
  return false;
}
// Function to free the tree structure
void free_tree(Tree *tree)
{
  for (int i = 0; i < tree->size; i++)
  {
    adj_list_node *temp = tree->adj_list[i];
    while (temp != NULL)
    {
      adj_list_node *next = temp->next;
      free(temp);
      temp = next;
    }
  }
  free(tree->adj_list);
  free_union_find(tree->uf);
  free(tree);
}


/* hashmap codes */
struct pattern {
    char *id;
    bool is_feasible;
};
int pattern_compare(const void *a, const void *b, void *udata) {
    const struct pattern *ua = a;
    const struct pattern *ub = b;
    return strcmp(ua->id, ub->id);
}
bool pattern_iter(const void *item, void *udata) {
    const struct pattern *pattern = item;
    printf("%s (is_feas=%d)\n", pattern->id, pattern->is_feasible);
    return true;
}
uint64_t pattern_hash(const void *item, uint64_t seed0, uint64_t seed1) {
    const struct pattern *pattern = item;
    return hashmap_sip(pattern->id, strlen(pattern->id), seed0, seed1);
}
char *get_id(int *pattern)
{
  char *id = malloc((5*pattern[0]+2) * sizeof(char)); // order당 5글자 vehicle에 2글자
  Element *sorted_orders = malloc((pattern[0]) * sizeof(Element));
  for (int i = 1; i < pattern[0] + 1; i++)
  {
    sorted_orders[i-1].index = pattern[i];
    sorted_orders[i-1].rcost = pattern[i];
  }
  qsort(sorted_orders, pattern[0], sizeof(Element), compare);
  sprintf(id, "%d", sorted_orders[0].index);
  for (int i = 1; i < pattern[0]; i++)
  {
    sprintf(id, "%s_%d", id, sorted_orders[i].index);
  }
  free(sorted_orders);
  sprintf(id, "%s-%d", id, pattern[pattern_upto + 2]);
  return id;
}
struct pattern* create_pattern(int* pattern, bool is_feasible){
  struct pattern * patt = (struct pattern*)malloc(sizeof(struct pattern));
  patt->id = get_id(pattern);
  patt->is_feasible = is_feasible;
  return patt;
}
void pattern_free(void *item) 
{
  struct pattern *pattern = (struct pattern*) item;
  free(pattern->id); pattern->id = NULL;
}
/* end of hashmap codes */


int **adj;

void add_edges(int u, int v) 
{
    adj[u][v] = 1;
    adj[v][u] = 1;
}

struct hashmap *pat_map;

int** skeleton_from_inital_sol(int **patterns, int *dual_sol_idx, int num_dual_sol)
{ 

  // calculate deadline slack for all 2 order patterns
  idxs_sorted_by_deadline_slack = (int *)malloc((pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]) * sizeof(int));
  Element *slacks = (Element *)malloc((pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]) * sizeof(Element));
  for (int idx = pat_h_n_idxs[0][1][0]; idx < pat_h_n_idxs[2][1][1]; idx++)
  {
    int h = patterns[idx][pattern_upto + 2];
    int temp, seq_time;
    int *seq = get_best_sequence(patterns[idx], &temp, h);
    int slack = 1e7;
    if (seq != NULL)
    {
      seq_time = order_ready_time(seq[0]) + rider_time[h][seq[0]][seq[1]];
      seq_time = (seq_time > order_ready_time(seq[1])) ? seq_time : order_ready_time(seq[1]);
      seq_time += rider_time[h][seq[1]][seq[2] + num_orders];
      slack = order_deadline(seq[2]) - seq_time;
      seq_time += rider_time[h][seq[2] + num_orders][seq[3] + num_orders];
      slack = (order_deadline(seq[3]) - seq_time < slack) ? order_deadline(seq[3]) - seq_time : slack;
    }
    slacks[idx - pat_h_n_idxs[0][1][0]].index = idx;
    slacks[idx - pat_h_n_idxs[0][1][0]].rcost = -slack;
  }
  qsort(slacks, pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0], sizeof(Element), compare);
  for (int i = 0; i < pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]; i++)
  {
    idxs_sorted_by_deadline_slack[i] = slacks[i].index;
  }
  // idx_sorted_by_deadline_slack = [pattern idx of 2 ords, from higher slack value]

  //TODO: add edge from the optimal solution
  pat_map = hashmap_new(sizeof(struct pattern), 0, 0, 0,
            pattern_hash, pattern_compare, pattern_free, NULL);

  printf("\n- - - - - - - - - - - - - - - - - - - - \n");
  printf("Start constructing intial tree");
  print_time("");
  printf("- - - - - - - - - - - - - - - - - - - - \n");

  Tree *tree = create_tree(num_orders);
  int** skeleton;
  skeleton = (int **)malloc(num_orders * sizeof(int *));
  for (int i = 0; i < num_orders; i++) 
  {
    skeleton[i] = (int *)malloc(2 * sizeof(int));
  }
  num_edges_in_tree = 0;

  // get solution from previous IP (based on delivery sequence)

/* 
  for (int i = 0 ; i < num_dual_sol ; i ++)
  {
    printf("\n");
    for (int j = 0 ; j < 2 * MAX_ORDER_IN_PATT + 3 ; j ++)
      printf(" %d ", seq_solution_2d[i][j]);
  }
  printf("\n");
 */

  ///// add edge based on delivery sequence of IP optimal solution
  for (int i = 0 ; i < num_x_sol ; i ++)
  {
    for (int j = 0; j < seq_solution_2d[i][0] - 1; j++)
    {
      if (add_edge(tree, seq_solution_2d[i][j + 1 + seq_solution_2d[i][0]], seq_solution_2d[i][j + 2 + seq_solution_2d[i][0]]))
      {
        
        skeleton[num_edges_in_tree][0] = seq_solution_2d[i][j + 1 + seq_solution_2d[i][0]];
        skeleton[num_edges_in_tree][1] = seq_solution_2d[i][j + 2 + seq_solution_2d[i][0]];
        //printf("add edge ( %d, %d ) \n", seq_solution_2d[i][j + 1 + seq_solution_2d[i][0]], seq_solution_2d[i][j + 2 + seq_solution_2d[i][0]]);
        num_edges_in_tree ++;
      }
    }
  }
  //printf("num_Edges_in tree is %d \n", num_edges_in_tree);

  ////// add edges via deadline slack
  for (int i = 0; i < pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]; i++)
  {
    int idx = idxs_sorted_by_deadline_slack[i];
    if (add_edge(tree, patterns[idx][1], patterns[idx][2]))
    {

      skeleton[num_edges_in_tree][0] = patterns[idx][1];
      skeleton[num_edges_in_tree][1] = patterns[idx][2];
      //printf("add edge ( %d, %d ) \n", skeleton[num_edges_in_tree][0], skeleton[num_edges_in_tree][1]);
      num_edges_in_tree ++;
    }

    if (num_edges_in_tree == num_orders - 1)
      break;
  }
  //printf("num_Edges_in tree is %d \n", num_edges_in_tree);



  free_tree(tree);
  return skeleton;
}




int get_min_cost_route_enum(int *orders, int n, int h)
{
  int result = -1;

  //check capacity
  
  int capa = 0;
  for (int i = 0; i < n; i ++)
    capa += order_volume(orders[i]);
    
  if (capa > rider_capa(h) + 1e-5)
  {
    //printf(" capa_exceeded because capa = %f, but volume = %d: ", rider_capa(h), capa);
    return result;
  }
    

  //check subset fsb
  bool subset_feasible = true;
  for(int i = 0 ; i < n-1; i ++)
  {
    if (!compat[h][orders[i]][orders[n-1]])
    {
      subset_feasible = false;
      break;
    }
  }
  if (!subset_feasible)
  {
    //printf(" subset infsb : ");
    return result;
  }
    

  //route
  int *perm, *d_perm, *p_perm;
  // int *sequence = (int*)malloc((n * 2) * sizeof(int));
  int *pickup_dists = malloc(factorial[n] * sizeof(int));
  int *pickup_times = malloc(factorial[n] * sizeof(int));
  int *delivery_dists = malloc(factorial[n] * sizeof(int));
  int *delivery_times = malloc(factorial[n] * sizeof(int));
  int *sorted_idxs_p = (int *)calloc(factorial[n], sizeof(int));
  int *sorted_idxs_d = (int *)calloc(factorial[n], sizeof(int));
  int *base_seq = malloc(n * sizeof(int));
  int min_last_pickup_time = INF;

  int min_deadline = order_deadline(orders[n-1]); //last ord
  int min_deadline_order = orders[n-1];

  //int best_p_idx, best_d_idx;

  for (int i = 0; i < n-1; i++)
  {
    min_deadline = (order_deadline(orders[i]) < min_deadline) ? order_deadline(orders[i]) : min_deadline;
    if (min_deadline == order_deadline(orders[i]))
      min_deadline_order = orders[i];
  }

  min_last_pickup_time = 1e9;
  for (int i = 0; i < n; i ++)
    base_seq[i] = orders[i];


  int front = 0;
  int end = factorial[n] - 1;

  for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
  {
    //printf("seq_idx (in this iteration ) is %d \n", seq_idx);
    // printf("chicekn 210\n"); fflush(stdout);
    perm = get_nth_permutation_of_size(seq_idx, n);
    pickup_dists[seq_idx] = 0;
    pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);

    if (pickup_times[seq_idx] > min_deadline)
    {
      sorted_idxs_p[end--] = seq_idx;
      pickup_dists[seq_idx] = 1e9;
      continue;
    }
    // printf("chicekn 211\n"); fflush(stdout);

    for (int i = 1; i < n; i++)
    {
      pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
      pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
      if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
      {
        pickup_dists[seq_idx] = 1e9;
        break;
      }
      pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
    }
    if (pickup_dists[seq_idx] >= 1e9)
    {
      sorted_idxs_p[end--] = seq_idx;
      continue;
    }

    //printf("pickup_dists[seq_idx] is %d and ", pickup_dists[seq_idx]);
    //printf(" seq_idx is  is %d and ", seq_idx );

    int idx = 0;
    for (; idx < front; idx++)
    {
      if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
        break;
    }

    memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
    sorted_idxs_p[idx] = seq_idx;
    //printf("sorted_idxs_p[%d] = %d;", idx, seq_idx); 

    front += 1;
    // sorted_idxs_p[front++] = seq_idx;
    min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
  
  }


  if (min_last_pickup_time >= 1e9){
    free(pickup_dists);
    free(pickup_times);
    free(delivery_dists);
    free(delivery_times);
    free(base_seq);
    free(sorted_idxs_p);
    free(sorted_idxs_d);
    //printf(" pickup route infsb : ");
    return result; //route infsb (pickup)
  }
  //printf(" pickup route fsb (min_last_pickup_time = %d) and \n ", min_last_pickup_time);

  //////////////////////////////////////////////////////////////
  //DELIVERY//

  front = 0;
  end = factorial[n] - 1;

  for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
  { 
    //printf("seq_idx (in this iteration ) is %d \n", seq_idx);
    perm = get_nth_permutation_of_size(seq_idx, n);
    delivery_dists[seq_idx] = 0;
    delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);

    if (delivery_times[seq_idx] < min_last_pickup_time)
    {
      delivery_dists[seq_idx] = 1e9;
      sorted_idxs_d[end--] = seq_idx;
      continue;
    }

    for (int i = n - 1; i > 0; i--)
    {
      delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
      delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
      if (delivery_times[seq_idx] < min_last_pickup_time)
      {
        delivery_dists[seq_idx] = 1e9;
        break;
      }
      delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
    }

    if (delivery_dists[seq_idx] >= 1e9)
    {
      sorted_idxs_d[end--] = seq_idx;
      continue;
    }

    //printf("delivery_dists[seq_idx] is %d and ", delivery_dists[seq_idx]);
    //printf(" seq_idx is  is %d and ", seq_idx );


    int idx = 0;
    for (; idx < front; idx++)
    {
      if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
        break;
    }
    memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
    sorted_idxs_d[idx] = seq_idx;
    //printf("sorted_idxs_p[%d] = %d;", idx, seq_idx); 
    front += 1;
    // sorted_idxs_d[front++] = seq_idx;
  }


  //// Find best combination
  int min_dist_ = INF;
  int p_idx, d_idx;
  for (int i = 0; i < factorial[n]; i++)
  {
    p_idx = sorted_idxs_p[i];
    if (pickup_dists[p_idx] >= 1e9)
    { 
      //printf("break here 1 and idx = %d, ", p_idx);
      break;
    }
      
    // bool checker = false;
    p_perm = get_nth_permutation_of_size(p_idx, n);
    for (int j = 0; j < factorial[n]; j++)
    {
      d_idx = sorted_idxs_d[j];
      if (delivery_dists[d_idx] >= 1e9)
        break;
      // if (pickup_dists[p_idx] + delivery_dists[d_idx] > min_dist_)
      // {
      //   checker = true;
      //   break;
      // }
      d_perm = get_nth_permutation_of_size(d_idx, n);
      if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[n-1]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[n-1]], base_seq[d_perm[0]] + num_orders) < min_dist_))
      {
        min_dist_ = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[n-1]], base_seq[d_perm[0]] + num_orders);
        //printf("min_dist updated to %d ", min_dist_);
      }
    }
    // if (checker)
    //   break;
  }
  if (min_dist_ >= INF){
    free(pickup_dists);
    free(pickup_times);
    free(delivery_dists);
    free(delivery_times);
    free(base_seq);
    free(sorted_idxs_p);
    free(sorted_idxs_d);
    //printf(" delivery route infsb : ");
    return result; //route infsb (delivery)
  }
  

  // p_perm = get_nth_permutation_of_size(best_p_idx, n);
  // d_perm = get_nth_permutation_of_size(best_d_idx, n);
  // for (int i = 0; i < n; i++)
  // {
  //   sequence[i] = base_seq[p_perm[i]];
  //   sequence[i + n] = base_seq[d_perm[i]];
  // }
  // printf("chicekn 6\n"); fflush(stdout);

  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  free(sorted_idxs_p);
  free(sorted_idxs_d);

  //cost as result
  result = 100 * rider_fixed_cost(h) + rider_var_cost(h) * min_dist_;
  return result; 
}
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
//
//                                       SOLVER CODE
//
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////

// Structure to hold element and its index


// Swap function for heap operations
void swap(Element *a, Element *b)
{
  Element temp = *a;
  *a = *b;
  *b = temp;
}

// Heapify function to maintain the max-heap property
void heapify(Element heap[], int n, int i)
{
  int largest = i;
  int left = 2 * i + 1;
  int right = 2 * i + 2;

  if (left < n && heap[left].rcost > heap[largest].rcost)
    largest = left;

  if (right < n && heap[right].rcost > heap[largest].rcost)
    largest = right;

  if (largest != i)
  {
    swap(&heap[i], &heap[largest]);
    heapify(heap, n, largest);
  }
}

// Function to build a max-heap
void buildHeap(Element heap[], int n)
{
  for (int i = n / 2 - 1; i >= 0; i--)
    heapify(heap, n, i);
}
// END OF HEAP CODE

// Comparison function for sorting in ascending order
int compare(const void *a, const void *b) {
    return ((Element *)a)->rcost - ((Element *)b)->rcost;
}
// END OF qsort CODE


//main solve function

double* solve_tree()
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  printf("Start solving tree");
  print_time("");
  // setup initial restricted master problem
  XPRBprob prob = XPRBnewprob("TREE-LP");
  XPRBvar x[MAX_COL_FIN];
  int x_idx[MAX_COL_FIN];
  XPRBctr assign[num_orders], cardi[num_riders];
  XPRBctr obj;

  //int num_x = tree_pat_h_n_idxs[0][1][0];
  //XPRBbasis basis;
  double objval;
  double* dual = (double*)malloc(sizeof(double) * (num_orders + num_riders));


  obj = XPRBnewctr(prob, "obj", XPRB_N); // XPRB_N indicate this is for objective
  for (int i = 0; i < num_orders; i++)   // iterate over orders
  {
    assign[i] = XPRBnewctr(prob, XPRBnewname("assign_%d", i), XPRB_E);
    XPRBaddterm(assign[i], NULL, 1);
  }
  for (int i = 0; i < num_riders; i++) // iterate over riders
  {
    cardi[i] = XPRBnewctr(prob, XPRBnewname("cardi_%d", i), XPRB_L);
    XPRBaddterm(cardi[i], NULL, rider_avail_num(i));
  }
  for (int i = 0; i < tree_pat_h_n_idxs[0][1][0]; i++) // iterate over length 1 patterns
  {
    x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    x_idx[i] = i;
    XPRBaddterm(obj, x[i], ((double)tree_patterns[i][pattern_upto + 1]) / (num_orders * 100));
    XPRBaddterm(assign[tree_patterns[i][1]], x[i], 1);
    XPRBaddterm(cardi[tree_patterns[i][pattern_upto + 2]], x[i], 1);
  }

  //printf("check column \n");
  for (int i = tree_pat_h_n_idxs[0][1][0]; i < tree_pat_idx; i++) // iterate over length 1 patterns
  {
    x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    x_idx[i] = i;

/*     if (tree_patterns[i][0] > 3) //ord >= 4
    {
      for (int j = 0 ; j < pattern_upto + 3 ; j ++)
        printf(" %d ", tree_patterns[i][j]);
      printf(" \n ");
    } 
 */
    XPRBaddterm(obj, x[i], ((double)tree_patterns[i][pattern_upto + 1]) / (num_orders * 100));
    for (int j = 1; j < tree_patterns[i][0] + 1; j ++ )
      XPRBaddterm(assign[tree_patterns[i][j]], x[i], 1);
    XPRBaddterm(cardi[tree_patterns[i][pattern_upto + 2]], x[i], 1);
  }




  XPRBsetobj(prob, obj);
  // XPRSchgobjsense(prob, XPRS_OBJ_MINIMIZE);
  // XPRBprintprob(prob);

  XPRBsetmsglevel(prob, 0);
  XPRBlpoptimize(prob, "");
  //basis = XPRBsavebasis(prob);
  objval = XPRBgetobjval(prob);
  for (int i = 0; i < num_orders; i++)
    dual[i] = XPRBgetdual(assign[i]);
  for (int i = 0; i < num_riders; i++)
    dual[num_orders + i] = XPRBgetdual(cardi[i]);

  printf("obj %.3f  ", objval);
  print_time("");

  //printf("for now iter, objval is %f and best_obj was %f \n", objval, best_obj);

  if (objval < best_obj - 1e-9) // objval improved !
  {
    best_obj = objval;
    best_pat_idx = tree_pat_idx;
    memcpy(&best_patterns[pat_h_n_idxs[0][0][0]][0], &tree_patterns[pat_h_n_idxs[0][0][0]][0], tree_pat_idx * (pattern_upto + 3) * sizeof(int) );
    not_improved_tree_first = 0 ; //initialize if improvement started
  }
  if (objval > best_obj + 1e-9) // increased !
  {
    printf("issue! so stop \n");
    for_debug = false;
  } 
  else //objval not improved
  { 
    not_improved_tree_first ++;
    //printf("tree not improved, not_improved_tree_first is  %d \n", not_improved_tree_first);

  }

  num_tree_sol = 0;
  for (int i = 0 ; i < tree_pat_idx; i ++)
  {
    if (XPRBgetsol(x[i]) > 1e-9)
    {
      int idx = x_idx[i];
      tree_sol_idx[num_tree_sol] = idx;
      num_tree_sol ++;
    }
  }

/* 
  for(int i = 0 ; i < num_tree_sol ; i ++)
  {
    for (int j = 0 ; j< pattern_upto + 3; j ++)
      printf(" %d ", tree_patterns[tree_sol_idx[i]][j]);
    printf("\n");
  }
   */
 
  XPRBdelprob(prob);

  return dual;
}

void solve()
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  double final_ip_reserved = FINAL_IP_RESERVED * (time_limit - (finish.tv_sec - start.tv_sec));
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  printf("Start solving");
  print_time("");
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  // setup initial restricted master problem
  XPRBprob prob_f = XPRBnewprob("RMP_final");
  XPRBvar x_f[MAX_COL_FIN];
  int x_idx_f[MAX_COL_FIN];
  XPRBctr assign_f[num_orders], cardi_f[num_riders];
  XPRBctr obj_f;

  int num_x_f = pat_h_n_idxs[0][1][0];
  XPRBbasis basis_f;
  double objval_f, dual_assign[num_orders], dual_cardi[num_riders];

  //// initial RMP with length-1 patterns
  obj_f = XPRBnewctr(prob_f, "obj", XPRB_N); // XPRB_N indicate this is for objective
  for (int i = 0; i < num_orders; i++)   // iterate over orders
  {
    assign_f[i] = XPRBnewctr(prob_f, XPRBnewname("assign_f_%d", i), XPRB_E);
    XPRBaddterm(assign_f[i], NULL, 1);
  }
  for (int i = 0; i < num_riders; i++) // iterate over riders
  {
    cardi_f[i] = XPRBnewctr(prob_f, XPRBnewname("cardi_f_%d", i), XPRB_L);
    XPRBaddterm(cardi_f[i], NULL, rider_avail_num(i));
  }
  for (int i = 0; i < pat_h_n_idxs[0][1][0]; i++) // iterate over length 1 patterns
  {
    x_f[i] = XPRBnewvar(prob_f, XPRB_BV, XPRBnewname("x_f_%d", i), 0, 1);
    x_idx_f[i] = i;
    XPRBaddterm(obj_f, x_f[i], ((double)best_patterns[i][pattern_upto + 1]) / (num_orders * 100));
    XPRBaddterm(assign_f[best_patterns[i][1]], x_f[i], 1);
    XPRBaddterm(cardi_f[best_patterns[i][pattern_upto + 2]], x_f[i], 1);
  }
  XPRBsetobj(prob_f, obj_f);
  // XPRSchgobjsense(prob, XPRS_OBJ_MINIMIZE);
  // XPRBprintprob(prob);

  XPRBsetmsglevel(prob_f, 0);

  // column generation
  int it = 0;
  while (true)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if ((finish.tv_sec - start.tv_sec) > time_limit - final_ip_reserved) break;

    // solving RMP
    XPRBlpoptimize(prob_f, "");
    basis_f = XPRBsavebasis(prob_f);
    objval_f = XPRBgetobjval(prob_f);
    for (int i = 0; i < num_orders; i++)
      dual_assign[i] = XPRBgetdual(assign_f[i]);
    for (int i = 0; i < num_riders; i++)
      dual_cardi[i] = XPRBgetdual(cardi_f[i]);
    printf("%3d  obj %.3f   #c %d   ", it++, objval_f, num_x_f);
    print_time("");

    // check profitable columns
    int num_added = 0;
    
    // final version 
    int it_pat_max = (it < EARLY_ITER) ? IT_PAT_MAX_EARLY : IT_PAT_MAX;
    int n_profitable = 0;
    Element *sorted_idxs = (Element *)malloc((best_pat_idx - pat_h_n_idxs[0][1][0] + 1) * sizeof(Element));
    for (int i = best_pat_idx; i >= pat_h_n_idxs[0][1][0]; i--)
    {
      double cost = ((double)best_patterns[i][pattern_upto + 1]) / (num_orders * 100);
      double reduced_cost = cost - dual_cardi[best_patterns[i][pattern_upto + 2]];
      for (int j = 1; j < best_patterns[i][0] + 1; j++)
        reduced_cost -= dual_assign[best_patterns[i][j]];
      if (reduced_cost < -1e-5)
      {
        sorted_idxs[n_profitable].index = i;
        sorted_idxs[n_profitable].cost = cost;
        sorted_idxs[n_profitable].rcost = reduced_cost;
        n_profitable += 1;
      }
    }
    qsort(sorted_idxs, n_profitable, sizeof(Element), compare);

    //printf("here \n"); fflush(stdout);

    it_pat_max = (n_profitable < it_pat_max) ? n_profitable : it_pat_max;
    for (int idx = 0; idx < it_pat_max; idx++)
    {
      // printf("%f ", sorted_idxs[idx].rcost);
      if (sorted_idxs[idx].rcost > -1e-5)
        break;
      int i = sorted_idxs[idx].index;
      double cost = sorted_idxs[idx].cost;
      x_f[num_x_f] = XPRBnewvar(prob_f, XPRB_BV, XPRBnewname("x_f_%d", num_x_f), 0, 1);
      x_idx_f[num_x_f] = i;
      XPRBaddterm(obj_f, x_f[num_x_f], cost);
      for (int j = 1; j < best_patterns[i][0] + 1; j++)
        XPRBaddterm(assign_f[best_patterns[i][j]], x_f[num_x_f], 1);
      XPRBaddterm(cardi_f[best_patterns[i][pattern_upto + 2]], x_f[num_x_f], 1);
      num_x_f ++ ;
      num_added ++ ;
    }
    // printf("\n\n");
    free(sorted_idxs);

    // report stats
    printf("     #nc %d   time", num_added);
    print_time("");
    if (num_added == 0)
    {
      XPRBdelbasis(basis_f);
      break;
    }
    XPRBloadmat(prob_f);
    XPRBloadbasis(basis_f);
    XPRBdelbasis(basis_f);
  }

  // solving final R-IP
  //// gather low reduced cost patterns at the last iteration 
  Element *sorted_idxs = (Element *)malloc((best_pat_idx) * sizeof(Element));
  for (int i = 0; i < best_pat_idx; i++)
  {
    double cost = ((double)best_patterns[i][pattern_upto + 1]) / (num_orders * 100);
    double reduced_cost = cost - dual_cardi[best_patterns[i][pattern_upto + 2]];
    for (int j = 1; j < best_patterns[i][0] + 1; j++)
      reduced_cost -= dual_assign[best_patterns[i][j]];
    sorted_idxs[i].index = i;
    sorted_idxs[i].cost = cost;
    sorted_idxs[i].rcost = reduced_cost;
  }
  qsort(sorted_idxs, best_pat_idx, sizeof(Element), compare);
  for (int idx = 0; idx < ((10000 > best_pat_idx)?best_pat_idx:10000); idx++)
  {
    int i = sorted_idxs[idx].index;
    double cost = sorted_idxs[idx].cost;
    x_f[num_x_f] = XPRBnewvar(prob_f, XPRB_BV, XPRBnewname("x_f_%d", num_x_f), 0, 1);
    x_idx_f[num_x_f] = i;
    XPRBaddterm(obj_f, x_f[num_x_f], cost);
    for (int j = 1; j < best_patterns[i][0] + 1; j++)
      XPRBaddterm(assign_f[best_patterns[i][j]], x_f[num_x_f], 1);
    XPRBaddterm(cardi_f[best_patterns[i][pattern_upto + 2]], x_f[num_x_f], 1);
    num_x_f += 1;
  }
  free(sorted_idxs);

  //// solve
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  XPRSprob opt_prob = XPRBgetXPRSprob(prob_f);
  clock_gettime(CLOCK_MONOTONIC, &finish);
  XPRSsetintcontrol(opt_prob, XPRS_MAXTIME, -((int) time_limit - (finish.tv_sec - start.tv_sec)));

  XPRBmipoptimize(prob_f,"c"); 
  objval_f = XPRBgetobjval(prob_f);
  printf("IP   obj %.3f   stat %d   ", objval_f, XPRBgetmipstat(prob_f)); print_time("");

  // post-processing
  solution = (int *)calloc(num_orders * (pattern_upto + 3), sizeof(int));
  solution_2d = (int **)calloc(num_orders, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
  
  for (int i = 0; i < num_orders; i++)
  {
    solution_2d[i] = solution + i * (pattern_upto + 3);
  }

  num_x_sol = 0;
  for (int i = 0; i < num_x_f; i++)
  {
    if (XPRBgetsol(x_f[i]) > 0.5)
    {
      int idx = x_idx_f[i];
      memcpy(&(solution_2d[num_x_sol][0]), &(best_patterns[idx][0]), (pattern_upto + 3) * sizeof(int));
      // printf("%d   ", patterns[idx][pattern_upto + 2]);
      // for (int j = 1; j < patterns[idx][0] + 1; j++)
      // {
      //   printf("%3d ", patterns[idx][j]);
      // }
      // printf("\n");
      num_x_sol ++ ;
    }
  }

  XPRBdelprob(prob_f);
  XPRBfree();

}


int num_x;
double *getdual_first(XPRBprob *prob, XPRBvar *x, int *x_idx, XPRBctr *assign, XPRBctr *cardi, XPRBctr *obj, XPRBbasis *basis)
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  printf("Start solving for 1 order : get_dual_first() is called");
  print_time("");
  printf("- - - - - - - - - - - - - - - - - - - - \n");

  double *dual = (double *)malloc((num_orders + num_riders) * sizeof(double)); // 동적 메모리 할당
  double objval;

  //// initial RMP with length-1 patterns
  *obj = XPRBnewctr(*prob, "obj", XPRB_N); // XPRB_N indicate this is for objective

  for (int i = 0; i < num_orders; i++) // iterate over orders
  {
    assign[i] = XPRBnewctr(*prob, XPRBnewname("assign_%d", i), XPRB_E);
    XPRBaddterm(assign[i], NULL, 1);
  }

  for (int i = 0; i < num_riders; i++) // iterate over riders
  {
    cardi[i] = XPRBnewctr(*prob, XPRBnewname("cardi_%d", i), XPRB_L);
    XPRBaddterm(cardi[i], NULL, rider_avail_num(i));
  }

  

  for (int i = 0; i < pat_h_n_idxs[2][0][1]; i++) // iterate over length 1 order
  {
    x[i] = XPRBnewvar(*prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    x_idx[i] = i;
    XPRBaddterm(*obj, x[i], ((double)patterns[i][pattern_upto + 1]) / (num_orders * 100));
    XPRBaddterm(assign[patterns[i][1]], x[i], 1);
    XPRBaddterm(cardi[patterns[i][pattern_upto + 2]], x[i], 1);
  }
  num_x = pat_h_n_idxs[2][0][1];


  XPRBsetobj(*prob, *obj);
  // XPRSchgobjsense(prob, XPRS_OBJ_MINIMIZE);
  XPRBsetmsglevel(*prob, 0);


  int it = 0;
  while (true)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if (time_limit_exceeded_enum())
      break;

    // solving RMP
    XPRBlpoptimize(*prob, "");
    *basis = XPRBsavebasis(*prob);
    objval = XPRBgetobjval(*prob);
    for (int i = 0; i < num_orders; i++)
      dual[i] = XPRBgetdual(assign[i]);
    for (int i = 0; i < num_riders; i++)
      dual[num_orders + i] = XPRBgetdual(cardi[i]);
    printf("%3d  obj %.3f   #c %d   ", it++, objval, num_x);
    print_time("");

    // check profitable columns
    int num_added = 0;

    // final version
    int it_pat_max = (it < EARLY_ITER) ? IT_PAT_MAX_EARLY : IT_PAT_MAX;
    int n_profitable = 0;

    Element *sorted_idxs = (Element *)malloc((pat_idx - pat_h_n_idxs[0][1][0] + 1) * sizeof(Element));
    for (int i = pat_idx; i >= pat_h_n_idxs[0][1][0]; i--)
    {
      double cost = ((double)patterns[i][pattern_upto + 1]) / (num_orders * 100);
      double reduced_cost = cost - dual[num_orders + patterns[i][pattern_upto + 2]];
      for (int j = 1; j < patterns[i][0] + 1; j++)
        reduced_cost -= dual[patterns[i][j]];
      if (reduced_cost < -1e-5)
      {
        sorted_idxs[n_profitable].index = i;
        sorted_idxs[n_profitable].cost = cost;
        sorted_idxs[n_profitable].rcost = reduced_cost;
        n_profitable += 1;
      }
    }

    qsort(sorted_idxs, n_profitable, sizeof(Element), compare);

    // printf("here \n"); fflush(stdout);

    it_pat_max = (n_profitable < it_pat_max) ? n_profitable : it_pat_max;
    for (int idx = 0; idx < it_pat_max; idx++)
    {
      // printf("%f ", sorted_idxs[idx].rcost);
      if (sorted_idxs[idx].rcost > -1e-5)
        break;
      int i = sorted_idxs[idx].index;
      double cost = sorted_idxs[idx].cost;
      x[num_x] = XPRBnewvar(*prob, XPRB_BV, XPRBnewname("x_f_%d", num_x), 0, 1);
      x_idx[num_x] = i;
      XPRBaddterm(*obj, x[num_x], cost);
      for (int j = 1; j < patterns[i][0] + 1; j++)
        XPRBaddterm(assign[patterns[i][j]], x[num_x], 1);
      XPRBaddterm(cardi[patterns[i][pattern_upto + 2]], x[num_x], 1);
      num_x += 1;
      num_added += 1;
    }

    // printf("\n\n");
    free(sorted_idxs);

    // report stats
    //printf("     #nc %d   time", num_added);
    //print_time("");
    
    if (num_added == 0)
    {
      XPRBdelbasis(*basis);
      break;
    }
    XPRBloadmat(*prob);
    XPRBloadbasis(*basis);
    XPRBdelbasis(*basis);
  }



  XPRBlpoptimize(*prob, "");
  objval = XPRBgetobjval(*prob);

  for (int i = 0; i < num_orders; i++)
  {
    dual[i] = XPRBgetdual(assign[i]);
  }

  for (int i = 0; i < num_riders; i++)
  {
    dual[num_orders + i] = XPRBgetdual(cardi[i]);
  }

  printf("for 2 ords:  obj %.3f   #columns %d   ", objval, num_x);
  print_time("");
  
/*   num_dual_sol = 0;
  for (int i = 0 ; i < pat_idx; i ++)
  {
    if (XPRBgetsol(x[i]) > 1e-9)
    {
      int idx = x_idx[i];
      dual_sol_idx[num_dual_sol] = idx;
      num_dual_sol ++;
    }
  } */

  return dual;
}

int pattern_enum_n(int n, int max_element, double *duals)
{
  int num_added = 0;

  for (int h = 0; h < num_riders; h++)
  {
    pat_h_n_idxs[h][n - 1][0] = pat_idx;

    for (int i = 0; i < NUM_THREADS; i++)
    {
      struct th_data_n *data = (struct th_data_n *)malloc(sizeof(struct th_data_n));
      data->th_id = i;
      data->n = n;
      data->h = h;
      data->idx_from = pat_h_n_idxs[h][n - 2][0];
      data->idx_to = pat_h_n_idxs[h][n - 2][1];
      data->p_pat_idx = &(p_pat_idxs[i]);
      data->duals = duals;
      int stat = pthread_create(&pthread[i], NULL, p_enum_n, (void *)data);
      if (stat != 0)
      {
        printf("pthread_create error\n");
        fflush(stdout);
      }
    }

    for (int i = 0; i < NUM_THREADS; i++)
    {
      pthread_join(pthread[i], NULL);
    }
    // print_time("");
    for (int i = 0; i < NUM_THREADS; i++)
    {
      memcpy(&(patterns[pat_idx][0]), &(th_patterns[i][0][0]), p_pat_idxs[i] * (pattern_upto + 3) * sizeof(int));
      pat_idx += p_pat_idxs[i];
    }
    pat_h_n_idxs[h][n - 1][1] = pat_idx;
    if (n == 2)
    {
      for (int idx = pat_h_n_idxs[h][n - 1][0]; idx < pat_h_n_idxs[h][n - 1][1]; idx++)
      {
        compat[h][patterns[idx][1]][patterns[idx][2]] = true;
      }
    }

    printf("    n %d  h %d  : %8d", n, h, pat_h_n_idxs[h][n - 1][1] - pat_h_n_idxs[h][n - 1][0]);

    print_time("");
    if (pat_idx == max_element)
      break;
  }

  num_added = pat_h_n_idxs[2][n - 1][1] - pat_h_n_idxs[0][n - 1][0];
  printf("num_added for n = %d is %d \n", n, num_added);
  return num_added;
}

// add patterns of order n and get dual
double *getdual_from(int n, XPRBprob *prob, XPRBvar *x, int *x_idx, XPRBctr *assign, XPRBctr *cardi, XPRBctr *obj, XPRBbasis *basis)
{
  printf("getdual_from() function is called for n = %d \n", n);

  double *dual = (double *)malloc((num_orders + num_riders) * sizeof(double));
  double objval;

  double * costs = (double *)malloc(pat_idx * sizeof(double));
  for (int i = 0; i < pat_idx; i++)
  {
    costs[i] = ((double)patterns[i][pattern_upto + 1]) / (num_orders * 100);
  }


  int it = 0;
  int num_obj_not_improved = 0;
  int best_obj_cg = 1e9;
  Element *sorted_idxs_n = (Element *)malloc((pat_idx) * sizeof(Element));
  while (true)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if (time_limit_exceeded_enum())
      break;

    // solving RMP
    XPRBlpoptimize(*prob, "");
    *basis = XPRBsavebasis(*prob);
    objval = XPRBgetobjval(*prob);
    for (int i = 0; i < num_orders; i++)
      dual[i] = XPRBgetdual(assign[i]);
    for (int i = 0; i < num_riders; i++)
      dual[num_orders + i] = XPRBgetdual(cardi[i]);



    if (objval < best_obj_cg - 1e-9) // objval improved by cg
    {
      best_obj_cg = objval; // objval not improved
    }
    else
    {
      num_obj_not_improved ++;
    }
    
    
    printf("%3d  obj %.3f   #c %d   ", it++, objval, num_x);
    print_time("");
    fflush(stdout);

    if (num_obj_not_improved > THRESHOLD_DUAL)
      break;

    // check profitable columns
    int num_added = 0;
    int it_pat_max = (it < EARLY_ITER) ? IT_PAT_MAX_EARLY_ENUM : IT_PAT_MAX;
    int n_profitable = 0;

    

    for (int i = pat_idx; i >= pat_h_n_idxs[0][1][0]; i--)
    {
      double reduced_cost = costs[i] - dual[num_orders + patterns[i][pattern_upto + 2]];
      
      for (int j = 1; j < patterns[i][0] + 1; j++)
        reduced_cost -= dual[patterns[i][j]];
      
      if (reduced_cost < -1e-5)
      {
        sorted_idxs_n[n_profitable].index = i;
        sorted_idxs_n[n_profitable].rcost = reduced_cost;
        n_profitable += 1;
      }
    }

    qsort(sorted_idxs_n, n_profitable, sizeof(Element), compare);
    it_pat_max = (n_profitable < it_pat_max) ? n_profitable : it_pat_max;
    for (int idx = 0; idx < it_pat_max; idx++)
    {
      // printf("%f ", sorted_idxs[idx].rcost);
      if (sorted_idxs_n[idx].rcost > -1e-5)
        break;
      int i = sorted_idxs_n[idx].index;
      x[num_x] = XPRBnewvar(*prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
      x_idx[num_x] = i;
      XPRBaddterm(*obj, x[num_x], costs[i]);
      for (int j = 1; j < patterns[i][0] + 1; j++)
        XPRBaddterm(assign[patterns[i][j]], x[num_x], 1);
      XPRBaddterm(cardi[patterns[i][pattern_upto + 2]], x[num_x], 1);
      num_x += 1;
      num_added += 1;
    }
    // printf("\n\n");
    

    // report stats
    printf("     #nc %d   time", num_added);
    print_time("");
    if (num_added == 0)
    {
      XPRBdelbasis(*basis);
      break;
    }
    XPRBloadmat(*prob);
    XPRBloadbasis(*basis);
    XPRBdelbasis(*basis);


  }


  printf("from n %d obj %.3f   #c %d   ", n, objval, pat_h_n_idxs[0][n-1][0]);
  print_time("");

  for (int i = 0; i < pat_idx; i++)
  {
    double reduced_cost = costs[i] - dual[num_orders + patterns[i][pattern_upto + 2]];
    for (int j = 1; j < patterns[i][0] + 1; j++)
        reduced_cost -= dual[patterns[i][j]];
        
      sorted_idxs_n[i].index = i;
      sorted_idxs_n[i].rcost = reduced_cost;
  }

  qsort(sorted_idxs_n, pat_idx, sizeof(Element), compare);

  for (int idx = 0; idx < NUM_DUAL_CG_COLS; idx++)
  {
    int i = sorted_idxs_n[idx].index;
    x[num_x] = XPRBnewvar(*prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
    x_idx[num_x] = i;
    XPRBaddterm(*obj, x[num_x], costs[i]);
    for (int j = 1; j < patterns[i][0] + 1; j++)
      XPRBaddterm(assign[patterns[i][j]], x[num_x], 1);
    XPRBaddterm(cardi[patterns[i][pattern_upto + 2]], x[num_x], 1);
    num_x += 1;
  }

   for (int i = 0; i < pat_h_n_idxs[0][1][0]; i++) // iterate over length 1 patterns
  {
    x[num_x + i] = XPRBnewvar(*prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    x_idx[num_x + i] = num_x + i;
    XPRBaddterm(*obj, x[num_x + i], costs[num_x + i]);
    XPRBaddterm(assign[patterns[num_x + i][1]], x[num_x + i], 1);
    XPRBaddterm(cardi[patterns[num_x + i][pattern_upto + 2]], x[num_x + i], 1);
  }

  free(sorted_idxs_n);






  return dual;
}

void dual_pattern_enum(int max_element, int from_n, int to_n)
{
  // printf("\n dual_pattern_enum is called"); fflush(stdout);
  XPRBprob prob = XPRBnewprob("RMP_for_2");

  XPRBvar x[MAX_COL];
  int x_idx[MAX_COL];

  XPRBctr assign[num_orders], cardi[num_riders];
  XPRBctr obj;
  XPRBbasis basis;
  double *dual = getdual_first(&prob, x, x_idx, assign, cardi, &obj, &basis);
  double objval;
  int num = 0;
  

  for (int n = from_n; n < to_n + 1; n++)
  {
    //printf("trying to pattern enum for ord n = %d \n", n);
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if (time_limit_exceeded_enum())
      break;

    num = pattern_enum_n(n, max_element, dual);
    printf("enum_for n=%d finished \n", n);
    free(dual);
    if (num == 0)
    {
      printf("pattern enum break");
      break;
    }
    dual = getdual_from(n, &prob, x, x_idx, assign, cardi, &obj, &basis); //cg n<=2
  }

  //// solve IP //////////////////////////////////////////////////////////////////////
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  XPRSprob opt_prob = XPRBgetXPRSprob(prob);
  clock_gettime(CLOCK_MONOTONIC, &finish);
  //printf("time_limit is %d \n", time_limit);

  XPRSsetintcontrol(opt_prob, XPRS_MAXTIME, -(time_limit * ENUM_IP_TIME));

  XPRBmipoptimize(prob, "c");
  objval = XPRBgetobjval(prob);
  printf("IP   obj %.3f   stat %d   ", objval, XPRBgetmipstat(prob));
  print_time("");

  best_obj = objval;

  // post-processing
  solution = (int *)calloc(num_orders * (pattern_upto + 3), sizeof(int));
  solution_2d = (int **)calloc(num_orders, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
  for (int i = 0; i < num_orders; i++)
  {
    solution_2d[i] = solution + i * (pattern_upto + 3);
  }

  num_dual_sol = 0;

  //printf("num_x is %d \n", num_x);
  for (int i = 0; i < num_x; i++)
  {
    if (XPRBgetsol(x[i]) > 1e-3)
    {
      dual_sol_idx[num_dual_sol] = x_idx[i];
      memcpy(&(solution_2d[num_dual_sol][0]), &(patterns[x_idx[i]][0]), (pattern_upto + 3) * sizeof(int));
      num_dual_sol += 1;
    }
  }


  num_x_sol = num_dual_sol;
  get_sequenced_solution();


  
  XPRBdelprob(prob);
  XPRBfree();
  //printf("dual_pattern_enum finished \n");
  return;
}


int* get_best_sequence(int* pattern, int* min_dist, int h)
{
  int n = pattern[0];

  int *perm, *d_perm, *p_perm;
  int *sequence = (int*)malloc((n * 2) * sizeof(int));
  int *pickup_dists = malloc(factorial[n] * sizeof(int));
  int *pickup_times = malloc(factorial[n] * sizeof(int));
  int *delivery_dists = malloc(factorial[n] * sizeof(int));
  int *delivery_times = malloc(factorial[n] * sizeof(int));
  int *sorted_idxs_p = (int *)calloc(factorial[n], sizeof(int));
  int *sorted_idxs_d = (int *)calloc(factorial[n], sizeof(int));
  int *base_seq = malloc(n * sizeof(int));

  int min_last_pickup_time = INF;
  
  int min_deadline = order_deadline(pattern[1]);
  int min_deadline_order = pattern[1];
  // printf("chicekn\n"); fflush(stdout);
  for (int i = 1; i < pattern[0]; i++)
  {
    min_deadline = (order_deadline(pattern[i+1]) < min_deadline) ? order_deadline(pattern[i+1]) : min_deadline;
    if (min_deadline == order_deadline(pattern[i+1]))
      min_deadline_order = pattern[i+1];
  }
  // printf("chicekn n%d 2\n", n); fflush(stdout);

  for (int i = 0; i < n; i++)
    base_seq[i] = pattern[i+1];
  // for (int i = 0; i < n; i++)
  //   printf("%d ", base_seq[i]);
  // printf("chicekn 21\n"); fflush(stdout);

  //// pickup sequence calculation
  int front = 0;
  int end = factorial[n] - 1;
  for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
  {
    // printf("chicekn 210\n"); fflush(stdout);
    perm = get_nth_permutation_of_size(seq_idx, n);
    pickup_dists[seq_idx] = 0;
    pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);
    if (pickup_times[seq_idx] > min_deadline)
    {
      sorted_idxs_p[end--] = seq_idx;
      pickup_dists[seq_idx] = 1e9;
      continue;
    }
    // printf("chicekn 211\n"); fflush(stdout);
    for (int i = 1; i < n; i++)
    {
      pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
      pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
      if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
      {
        pickup_dists[seq_idx] = 1e9;
        break;
      }
      pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
    }
    if (pickup_dists[seq_idx] >= 1e9)
    {
      sorted_idxs_p[end--] = seq_idx;
      continue;
    }
    int idx = 0;
    for (; idx < front; idx++)
    {
      if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
        break;
    }
    memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
    sorted_idxs_p[idx] = seq_idx;
    front += 1;
    // sorted_idxs_p[front++] = seq_idx;
    min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
  }
  // printf("chicekn 22\n"); fflush(stdout);
  if (min_last_pickup_time >= 1e9){
    free(pickup_dists);
    free(pickup_times);
    free(delivery_dists);
    free(delivery_times);
    free(base_seq);
    free(sorted_idxs_p);
    free(sorted_idxs_d);
    return NULL;
  }
  // printf("chicekn 3\n"); fflush(stdout);

  //// delivery sequence calculation
  front = 0;
  end = factorial[n] - 1;
  for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
  {
    perm = get_nth_permutation_of_size(seq_idx, n);
    delivery_dists[seq_idx] = 0;
    delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);
    if (delivery_times[seq_idx] < min_last_pickup_time)
    {
      delivery_dists[seq_idx] = 1e9;
      sorted_idxs_d[end--] = seq_idx;
      continue;
    }
    for (int i = n - 1; i > 0; i--)
    {
      delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
      delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
      if (delivery_times[seq_idx] < min_last_pickup_time)
      {
        delivery_dists[seq_idx] = 1e9;
        break;
      }
      delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
    }
    if (delivery_dists[seq_idx] >= 1e9)
    {
      sorted_idxs_d[end--] = seq_idx;
      continue;
    }
    int idx = 0;
    for (; idx < front; idx++)
    {
      if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
        break;
    }
    memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
    sorted_idxs_d[idx] = seq_idx;
    front += 1;
    // sorted_idxs_d[front++] = seq_idx;
  }
  // printf("chicekn 4\n"); fflush(stdout);

  //// Find best combination
  int min_dist_ = 1e9;
  int p_idx, d_idx;
  int best_p_idx, best_d_idx;
  for (int i = 0; i < factorial[n]; i++)
  {
    p_idx = sorted_idxs_p[i];
    if (pickup_dists[p_idx] >= 1e9)
      break;
    // bool checker = false;
    p_perm = get_nth_permutation_of_size(p_idx, n);
    for (int j = 0; j < factorial[n]; j++)
    {
      d_idx = sorted_idxs_d[j];
      if (delivery_dists[d_idx] >= 1e9)
        break;
/*       if (pickup_dists[p_idx] + delivery_dists[d_idx] > min_dist_)
      {
        //checker = true;
        break;
      } */
      d_perm = get_nth_permutation_of_size(d_idx, n);
      if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[n-1]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[n-1]], base_seq[d_perm[0]] + num_orders) < min_dist_))
      {
        min_dist_ = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[n-1]], base_seq[d_perm[0]] + num_orders);
        best_p_idx = p_idx;
        best_d_idx = d_idx;
      }
    }
    /* if (checker)
      break; */
  }
  // printf("chicekn 5\n"); fflush(stdout);
  if (min_dist_ >= 1e9){
    free(pickup_dists);
    free(pickup_times);
    free(delivery_dists);
    free(delivery_times);
    free(base_seq);
    free(sorted_idxs_p);
    free(sorted_idxs_d);
    return NULL;
  }

  p_perm = get_nth_permutation_of_size(best_p_idx, n);
  d_perm = get_nth_permutation_of_size(best_d_idx, n);
  for (int i = 0; i < n; i++)
  {
    sequence[i] = base_seq[p_perm[i]];
    sequence[i + n] = base_seq[d_perm[i]];
  }
  // printf("chicekn 6\n"); fflush(stdout);

  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  free(sorted_idxs_p);
  free(sorted_idxs_d);

  *min_dist = min_dist_;
  return sequence;
}

void get_sequenced_solution()
{
  seq_solution = (int *)calloc(num_orders * (2 * MAX_ORDER_IN_PATT + 3), sizeof(int));
  seq_solution_2d = (int **)calloc(num_orders, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
  
  for (int i = 0; i < num_orders; i++)
  {
    seq_solution_2d[i] = seq_solution + i * (2 * MAX_ORDER_IN_PATT + 3);
  }

  for (int i = 0; i < num_x_sol; i++)
  {
    int temp;
    int *sequence = get_best_sequence(solution_2d[i], &temp, solution_2d[i][pattern_upto + 2]);
    
    if (sequence != NULL)
    {
      memcpy(seq_solution_2d[i]+1, sequence, 2 * solution_2d[i][0] * sizeof(int));
      // printf("here22b n%d\n", n); fflush(stdout);
      seq_solution_2d[i][0] = solution_2d[i][0];
      seq_solution_2d[i][2 * MAX_ORDER_IN_PATT + 1] = solution_2d[i][pattern_upto + 1];
      seq_solution_2d[i][2 * MAX_ORDER_IN_PATT + 2] = solution_2d[i][pattern_upto + 2];
    }
    else
    {
      printf("Error in getting sequence\n");
    }
  }
  free(solution);
  free(solution_2d);
}


int** tree_improve_first(int** skeleton)
{

//TODO avoid cycle by create_tree and avoid cycle
Tree *new_tree = create_tree(num_orders);

double* dual = solve_tree();
//int edge_size = pat_h_n_idxs[1][1][1] - pat_h_n_idxs[1][1][0];

int new_num_edges_in_tree = 0;

int** new_skeleton;
new_skeleton = (int **)malloc(num_orders * sizeof(int *));
for (int i = 0; i < num_orders; i++) 
{
  new_skeleton[i] = (int *)malloc(2 * sizeof(int));
}

int* parent = (int*)malloc(num_orders * sizeof(int));
for (int idx = 0 ; idx < pat_h_n_idxs[2][0][1]; idx ++)
{
  parent[patterns[idx][1]] = patterns[idx][1];
}


/* 
printf("previous skeleton was \n");
for (int i = 0 ; i < num_edges_in_tree ; i ++)
  printf(" [ %d, %d ]  \n", skeleton[i][0], skeleton[i][1]);
  */


// keep edges used for optimal subtrees
for(int i = 0 ; i < num_tree_sol ; i ++)
{
  if (tree_patterns[tree_sol_idx[i]][0] == 1) // pass using 1 orders
    continue;
  
  // add first 2 edges
  int u = tree_patterns[tree_sol_idx[i]][1];
  int v = tree_patterns[tree_sol_idx[i]][2];
  union_nodes(u, v, parent);
  new_skeleton[new_num_edges_in_tree][0] = u;
  new_skeleton[new_num_edges_in_tree][1] = v;
  add_edge(new_tree, u, v);
  new_num_edges_in_tree++;
  
  //stop if 2 orders
  if (tree_patterns[tree_sol_idx[i]][0] < 3 ) 
    continue;


  // for more than 3rd orders
  bool stop_outer_loop;
  bool search_completed = false;

  for (int n = 3; n < pattern_upto + 1 && !search_completed; n ++)
  {
    stop_outer_loop = false;
    v = tree_patterns[tree_sol_idx[i]][n];
    for (int idx = 0 ; idx < num_edges_in_tree && !stop_outer_loop ; idx ++)
    { 
      if ( (v == skeleton[idx][0]) || (v == skeleton[idx][1]) )
      {
        for (int j = 1 ; j < n ; j ++)
        {
          int u = tree_patterns[tree_sol_idx[i]][j]; // candidate order id 
          if( (u == skeleton[idx][0]) || (u == skeleton[idx][1]) )
          {
            new_skeleton[new_num_edges_in_tree][0] = u;
            new_skeleton[new_num_edges_in_tree][1] = v;
            add_edge(new_tree, u, v);
            new_num_edges_in_tree ++;
            stop_outer_loop = true; 
            break;
          }
        }
      }
    }
    if (tree_patterns[tree_sol_idx[i]][0] < n + 1 ) 
      search_completed = true;
  }
  continue;
}

//printf("from previous tree with edge num %d, keel edge num %d for opt \n", num_edges_in_tree, new_num_edges_in_tree);

int n_profitable = 0;
Element *sorted_idxs = (Element *)malloc((pat_idx - pat_h_n_idxs[0][1][0] + 1) * sizeof(Element));
  for (int i = pat_h_n_idxs[0][1][0]; i < pat_h_n_idxs[2][1][1]; i++)
  {
    double cost = ((double)patterns[i][pattern_upto + 1]) / (num_orders * 100);
    double reduced_cost = cost - dual[num_orders + patterns[i][pattern_upto + 2]];
    for (int j = 1; j < patterns[i][0] + 1; j++)
      reduced_cost -= dual[patterns[i][j]];
    if (reduced_cost < -1e-5)
    {
      sorted_idxs[n_profitable].index = i;
      sorted_idxs[n_profitable].cost = cost;
      sorted_idxs[n_profitable].rcost = reduced_cost;
      n_profitable += 1;
    }
  }
//printf("n_profitable = %d \n", n_profitable);
if (n_profitable == 0)
  return NULL;

qsort(sorted_idxs, n_profitable, sizeof(Element), compare);


bool if_add_edge = true;

for (int idx = 0; idx < (NUM_TREE_EDGE_CHANGE < n_profitable ? NUM_TREE_EDGE_CHANGE : n_profitable); idx ++)
 // ++i 
  { 
    int i = sorted_idxs[idx].index;
    //double cost = sorted_idxs[idx].cost;
    //double r_cost = sorted_idxs[idx].rcost;

    int u = patterns[i][1];
    int v = patterns[i][2];
    if (add_edge(new_tree, u, v)) 
    {

      new_skeleton[new_num_edges_in_tree][0] = u;
      new_skeleton[new_num_edges_in_tree][1] = v;
      new_num_edges_in_tree++;
      

    }

    if (new_num_edges_in_tree == num_orders- 1) 
    { 
      if_add_edge = false;
      break;
    } 
  }

//printf("after adding profitable, now edge num is %d \n", new_num_edges_in_tree);

// next add pre-existing edge
for (int i = 0 ; i < num_edges_in_tree && if_add_edge ; i ++) // ++i 
{ 

    int u = skeleton[i][0];
    int v = skeleton[i][1];
    if (add_edge(new_tree, u, v)) 
    {

      new_skeleton[new_num_edges_in_tree][0] = u;
      new_skeleton[new_num_edges_in_tree][1] = v;
      new_num_edges_in_tree++;
      
    }

    if (new_num_edges_in_tree == num_orders - 1) 
    { 
      if_add_edge = false;
      break;
    } 
}


/* 
printf("new_skeletons are \n");
for (int i = 0 ; i < new_num_edges_in_tree; i ++)
  printf(" (%d,%d) \n", new_skeleton[i][0], new_skeleton[i][1]);
 
 */
num_edges_in_tree = new_num_edges_in_tree;

//printf("finally adding all left, edge num is %d and constructed tree \n", num_edges_in_tree);

return new_skeleton;
}




void tree_enum(int **skeleton)
{ 

  struct hashmap *map = hashmap_new(sizeof(struct pattern), 0, 0, 0, pattern_hash, pattern_compare, pattern_free, NULL);
  // Create tree
  tree = create_tree(num_orders);

  for (int idx = 0 ; idx < num_edges_in_tree; idx ++)
    add_edge(tree, skeleton[idx][0], skeleton[idx][1]);

  tree_pat_idx = tree_pat_h_n_idxs[2][0][1];
  char *temp_id;
  int *temp_pat;
  int *temp_new_pat = malloc((pattern_upto + 3) * sizeof(int));

  //pattern for order 2, using only skeleton
  for (int h = 0; h < num_riders; h++)
  { 

    tree_pat_h_n_idxs[h][1][0] = tree_pat_idx;
    for (int idx = 0; idx < num_edges_in_tree; idx++)
    { 
      clock_gettime(CLOCK_MONOTONIC, &finish);
      if (time_limit_exceeded())
        break; 

      //printf("add edge (%d, %d) to subtree \n", skeleton[idx][0], skeleton[idx][1]);
      //printf("%d  %d  %d\n", idx, skeleton[idx][0], skeleton[idx][1]);
      int result = get_min_cost_route_enum(skeleton[idx], 2, h);

      temp_new_pat[0] = 2;
      temp_new_pat[1] = skeleton[idx][0];
      temp_new_pat[2] = skeleton[idx][1];
      temp_new_pat[pattern_upto + 1] = result ; 
      temp_new_pat[pattern_upto + 2] = h;
      
      if (result != -1)
      { 
          
        memcpy(tree_patterns[tree_pat_idx], temp_new_pat, (pattern_upto + 3) * sizeof(int));
        tree_pat_idx ++;

        struct pattern *p = create_pattern(temp_new_pat, true);
        hashmap_set(map, (void *) p);
        free(p);

      }
      else
      {
        struct pattern *p = create_pattern(temp_new_pat, false);
        hashmap_set(map, (void *) p);
        free(p);

      } 
    }
    tree_pat_h_n_idxs[h][1][1] = tree_pat_idx;
    //printf("    n %d  h %d  : %8d \n", 2, h, tree_pat_h_n_idxs[h][1][1] - tree_pat_h_n_idxs[h][1][0]);
  fflush(stdout);
  }



  //pattern enum for n >= 3 using tree
  
  for (int n = 3; n <= pattern_upto ; n ++)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if (time_limit_exceeded())
      break;
    for (int h = 0 ; h < num_riders ; h ++)
    {
      clock_gettime(CLOCK_MONOTONIC, &finish);
      if (time_limit_exceeded())
        break;

      //printf("generating subtree with ord = %d and veh %d --------- \n", n, h);
      //printf("for veh %d \n", h);
      tree_pat_h_n_idxs[h][n-1][0] = tree_pat_idx;
      // printf("tree_pat_idx %d", tree_pat_idx);

      for (int i = tree_pat_h_n_idxs[h][n-2][0] ; i < tree_pat_h_n_idxs[h][n-2][1] ; i ++)
      {
        clock_gettime(CLOCK_MONOTONIC, &finish);
        if (time_limit_exceeded())
          break;
        
        temp_pat = tree_patterns[i]; // pattern to extend

        memcpy(temp_new_pat, temp_pat, (pattern_upto + 3) * sizeof(int));
        
        temp_new_pat[0] ++ ;
        //printf("\ntemp_new_pat only add num is -------------- \n");
 /*        for (int j = 0 ; j < pattern_upto + 3; j ++)
          printf(" %d ", temp_new_pat[j]);
        printf(" \n ");
 */
        // for (int ii=0; ii<pattern_upto+3; ii++)
        //   printf("%d ", temp_new_pat[ii]);
        // printf("\n");
        for (int j = 1; j < temp_pat[0] + 1; j++)
        { 
          clock_gettime(CLOCK_MONOTONIC, &finish);
          if (time_limit_exceeded())
            break; 
            
          int tg = temp_pat[j];
          adj_list_node *neighbor = tree->adj_list[tg];
          // if (h > 0)
          //   printf("%d\n", neighbor->id);

          while (neighbor)
          {
/*             if (tg == 3 || tg == 5 || tg == 7 || tg == 13)
              printf("%d  %d.     ", tg, neighbor->id); */
            bool checker = false;
            for (int k = 1; k < temp_pat[0] + 1; k++)
            {
              if (temp_pat[k] == neighbor->id)
              {
                checker = true;
                //printf(" break 1-checker");
                break;
              }
            }

            if (checker) 
            {
              neighbor = neighbor->next;
              //printf("1-checker so continue \n");
              continue;
            }

            // start checking temp_new_pat(= temp_pat + neighbor->id) is feasible
            temp_new_pat[temp_new_pat[0]] = neighbor->id;
            // if (h==2)
            // {for (int ii=0; ii<pattern_upto+3; ii++)
            //   printf("%d ", temp_new_pat[ii]);
            // printf("\n\n");}
            temp_id = get_id(temp_new_pat);
            //printf("\n temp_id was %s " , temp_id);

            if (!hashmap_get(map, &(struct pattern){.id = temp_id}))
            { 
              int ords[temp_new_pat[0]];
              //printf(" \n for making patterns with ords ( ");

              for (int nn = 0; nn < temp_new_pat[0] ; nn ++)
              {
                ords[nn] = temp_new_pat[nn+1];
                //printf(" %d ", ords[nn]);
              }

              //printf(") \n");
              int result = get_min_cost_route_enum(ords, n, h);

              //printf(") and  result is %d \n", result);
              if (result == -1) //infsb
              {
                struct pattern *p = create_pattern(temp_new_pat, false);
                hashmap_set(map, (void *) p);
                free(p);
          
              }
              else //fsb
              {   

                //printf("  is feasible ! \n");
                temp_new_pat[pattern_upto + 1] = result;
                memcpy(tree_patterns[tree_pat_idx], temp_new_pat, (pattern_upto + 3) * sizeof(int));
                tree_pat_idx ++;

                struct pattern *p = create_pattern(temp_new_pat, true);
                hashmap_set(map, (void *) p);
                free(p);
              }
            }
            free(temp_id);
            temp_id = NULL;
            neighbor = neighbor->next;
          }
        }
      }
      tree_pat_h_n_idxs[h][n-1][1] = tree_pat_idx;
      //printf("    n %d  h %d  : %8d \n", n, h, tree_pat_h_n_idxs[h][n-1][1] - tree_pat_h_n_idxs[h][n-1][0]);
      //print_time("");
    fflush(stdout);
    }

    int made_num = tree_pat_h_n_idxs[2][n-1][1] - tree_pat_h_n_idxs[0][n-1][0];
    if (made_num == 0)
      break;
  }
  


  // for (int idx = 0 ; idx < tree_pat_idx ; idx ++)
  // {
  //   for (int j = 0 ; j < pattern_upto + 3 ; j ++)
  //     printf(" %d ", tree_patterns[idx][j]);

  //   printf("\n");
  // }

  hashmap_free(map);
  free_tree(tree);

  return;
}

int** loop_tree_improve_first(int **skeleton)
{

  for(int tree_it = 0; (for_debug) && (tree_it < TREE_IT_FIRST) && (not_improved_tree_first < THRESHOLD_FIRST) ; tree_it ++)
  { 
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if (time_limit_exceeded())
      break;

    printf("-------------------------------\n");
    printf("Solve tree: it = %d  ", tree_it);
    print_time("");

    tree_enum(skeleton);
    skeleton = tree_improve_first(skeleton);
    if (skeleton == NULL)
      break;

  } 
  
  printf("\n- - - - - - - - - - - - - - - - - - - ");
  printf("\nTREE_IMPROVE FIRST OPTION finished \n");
  printf("- - - - - - - - - - - - - - - - - - -\n ");
  return skeleton;   
}

