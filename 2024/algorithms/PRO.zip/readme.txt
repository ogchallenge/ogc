# OGC2024 PRO팀

## 사용된 외부 라이브러리
- FICO Xpress solver
  - Xpress 설치 시 제공되는 라이브러리 파일 중 libxprs.so, libsxprl.so를 소스코드와 같은 디렉토리로 복사  
  - Xpress 설치 시 제공되는 헤더 파일 중 xprb.h, xprs.h를 소스코드와 같은 디렉토리로 복사
- https://github.com/tidwall/hashmap.c (MIT License)
  - hashmap.c, hashmap.h를 소스코드와 같은 디렉토리로 복사

## 라이브러리 compile 방법
- (방법1) 포함된 python 파일을 통한 컴파일
  - 대회 공식 conda 환경에서 `python calg_ybp_xxx.py' 실행 (xxx는 숫자, 모든 xxx에 대해 수행하여야 함) 
- (방법2) gcc 커맨드를 통한 컴파일
  - 각각의 calg_ybp_c_xxx.c 파일에 대하여 (xxx는 숫자) 아래의 커맨드들을 shell에서 순차적으로 수행
gcc -c -pthread -fPIC -Wall -fno-strict-aliasing -O2 -fwrapv calg_ybp_c_xxx.c -o temp_enum.o
gcc -c -pthread -fPIC -Wall -fno-strict-aliasing -O2 -fwrapv hashmap.c -o temp_hashmap.o
gcc -shared -lm libxprs.so temp_enum.o temp_hashmap.o -o libcalg_ybp_xxx.so