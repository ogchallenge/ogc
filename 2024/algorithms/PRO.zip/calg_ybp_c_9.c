#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>
#include "xprb.h"
#include "xprs.h"
#include "hashmap.h"



#define MAX_ELEMENT 50000000 // DO NOT CHANGE
#define MAX_ELEMENT_TREE 50000000
#define MAX_ELEMENT_BEST 50000000

// #define AVG_COST_CUTOFF
#define AVG_COST_THRD 1.3 // 1.15로 했을 때 거의 enum time 감소폭 0.3초;;

#define FIRST_IP_OPTION 3 // 0: do nothing, 1: xprs options, 2: fix var, 3: both
#define FIXING_THRD 0.55

#define NUM_THREADS 4
#define MAX_TH_PATTERNS 4000000

#define INF 1e9
#define MAX_COL 500000
#define MAX_COL_FIN 100000
#define IT_PAT_MAX 100
#define EARLY_ITER 30
#define IT_PAT_MAX_EARLY 100
#define IT_PAT_MAX_EARLY_ENUM 200


// INITIAL ENUM
// To 세영 1 : ENUM_TIME 까지 만들고, 넘으면 CG로.
//           INIT_TIME 까지 첫 IP 풀기 전 마지막 CG
//           ENUM_IP_TIME 동안 첫 IP 풀기
// 초기해 찾는 데 시간 다 쓰면 MAX가 (INIT_TIME + ENUM_IP_TIME)
#define INIT_TIME 0.6 // STOP LAST CG BEFORE INITIAL IP
#define ENUM_TIME 0.55 // STOP ENUM to guarantee time (INIT_TIME - ENUM_TIME) for last CG
#define ENUM_IP_TIME 0.25

// TREE IMPROVE
#define TREE_TIME 0.99 // TREE IMPROVE 를 종료하는 시간 (사실상 개선 끝) // TODO: 수정 필요
#define TREE_IP_TIME 0.2

// IP FROM ALL TREES
#define ALL_IP_TIME 0.93 // starts IP from all trees if not exceeded ALL_IP_TIME when finished tree improve // TODO: 수정 필요
#define FINAL_IP_RESERVED 0.5 
//if time left, then start solve_all () ip 
// CG: left time * (1-FINAL_IP_RESERVED) 
// IP: left time * FINAL_IP_RESERVED

// INITIAL ENUM
#define DUAL_PAT_ENUM 4
#define THRESHOLD_DUAL 3 // Stop CG at dual_pattern_enum if obj not improved # times
#define NUM_DUAL_CG_COLS 1500 // # of columns for initial IP

// TREE IMPROVE - FIRST OPTION
#define NUM_TREE_EDGE_CHANGE 1500 
// Parameter for tree_improve_first();
// 1. edges from previous optional solutions 
// 2. edges from r_cost : NUM__TREE_EDGE_CHANGE **
// 3. edges from deadline slack until acyclic
// NOTE: CHANGED NOT TO KEEP PREVIOUS SKELETON EXCEPT IP SOL  

#define TREE_IT_FIRST 50 // tree iter and change option 
#define THRESHOLD_FIRST 10  // stop loop by first option if not improved 
#define STOP_LOOP 5  // stop improving tree  

// TREE IMPROVE - SECOND OPTION
#define SMALL_PROB_SIZE 50
#define MAX_PAT_IMPROVE 10000000

void solve();
void solve_tree_ip();
void solve_all();

double *getdual_first(XPRBprob *prob, XPRBvar *x, int *x_idx, XPRBctr *assign, XPRBctr *cardi, XPRBctr *obj, XPRBbasis *basis);
double *getdual_from(int n, XPRBprob *prob, XPRBvar *x, int *x_idx, XPRBctr *assign, XPRBctr *cardi, XPRBctr *obj, XPRBbasis *basis);
void dual_pattern_enum(int max_element, int from_n, int to_n);

double *solve_tree();
int **max_spanning_tree(int **patterns, int ***pat_h_n_idxs);
int **skeleton_from_initial_sol(int **patterns, int *dual_sol_idx, int num_dual_sol);
int **skeleton_from_sol(int **patterns, int option);
void tree_enum(int **skeleton);
int **tree_improve_first(int **skeleton, int change_rcost); // reduced cost of 2 orders
int **loop_tree_improve_first(int iter_num, int threshold, int **skeleton, int change_rcost);
int compare_slack(const void* a, const void* b);
int **resolve_small_instance(int **skeleton, int size, int option); //

void get_sequenced_solution();
int *get_best_sequence(int *pattern, int *min_dist, int h);

inline double rider_capa(int rider_type);
inline double rider_var_cost(int rider_type);
inline double rider_fixed_cost(int rider_type);
inline double rider_speed(int rider_type);
inline double rider_service_time(int rider_type);
inline double rider_avail_num(int rider_type);
inline int order_ready_time(int order_num);
inline int order_deadline(int order_num);
inline int order_volume(int order_num);
inline int dist(int i, int j);

// utility functions
struct timespec start, finish;
int time_limit;
void print_time(char *msg)
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  printf("  %s %.4f\n", msg, (double)(finish.tv_sec - start.tv_sec) + (double)(finish.tv_nsec - start.tv_nsec) / 1000000000);
}

bool time_limit_exceeded_enum() // only used to check enumeration time_limit
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  return (finish.tv_sec - start.tv_sec) > (time_limit * ENUM_TIME);
}
bool time_limit_exceeded_init() // used to last cg-enum before inital IP time_limit
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  return (finish.tv_sec - start.tv_sec) > (time_limit * INIT_TIME);
}
bool time_limit_exceeded() // used to check tree_improve time_limit
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  return (finish.tv_sec - start.tv_sec) > (time_limit * TREE_TIME);
}
const int factorial[] = {1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800};
int ***nth_permutation_of_size;
void free_permutations()
{
  if (nth_permutation_of_size != NULL)
  {
    for (int i = 0; i < 11; i++)
    {
      if (nth_permutation_of_size[i] != NULL)
      {
        for (int j = 0; j < factorial[i]; j++)
        {
          if (nth_permutation_of_size[i][j] != NULL)
          {
            free(nth_permutation_of_size[i][j]);
          }
        }
        free(nth_permutation_of_size[i]);
      }
    }
    free(nth_permutation_of_size);
  }
}
void generate_permutations(int max_size)
{
  if (nth_permutation_of_size == NULL)
  {
    nth_permutation_of_size = (int ***)calloc(11, sizeof(int **));
    nth_permutation_of_size[1] = (int **)calloc(1, sizeof(int *));
    nth_permutation_of_size[1][0] = (int *)calloc(1, sizeof(int));
    nth_permutation_of_size[1][0][0] = 0;
  }
  for (int size = 2; size <= max_size; size++)
  {
    nth_permutation_of_size[size] = (int **)calloc(factorial[size], sizeof(int *));
    for (int n = 0; n < factorial[size]; n++)
    {
      nth_permutation_of_size[size][n] = (int *)calloc(size, sizeof(int));
      int q = n / factorial[size - 1];
      int d = n % factorial[size - 1];
      for (int i = 0; i < size; i++)
      {
        if (i < q)
          nth_permutation_of_size[size][n][i] = nth_permutation_of_size[size - 1][d][i];
        else if (i == q)
          nth_permutation_of_size[size][n][i] = size - 1;
        else
          nth_permutation_of_size[size][n][i] = nth_permutation_of_size[size - 1][d][i - 1];
      }
    }
  }
}

int *get_nth_permutation_of_size(int n, int size)
{
  return nth_permutation_of_size[size][n];
}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////

struct th_data_n
{
  int th_id;
  int n;
  int h;
  int idx_from;
  int idx_to;
  int *p_pat_idx;
  double *duals;
};

struct th_data
{
  int th_id;
  int n;
  int h;
  int idx_from;
  int idx_to;
  int *p_pat_idx;
};

typedef struct
{
  double cost;
  double rcost;
  int index;

} Element;

typedef struct
{
  int *parent;
  int *rank;
  int size;
} UnionFind;

// Define the structure for adjacency list node
typedef struct adj_list_node adj_list_node;
struct adj_list_node
{
  int id;
  adj_list_node *next;
};

typedef struct
{
  adj_list_node **adj_list;
  int size;
  UnionFind *uf;
} Tree;

typedef struct {
    int i;
    int j;
    int slack_value;
} SlackCombination;


////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
Tree *create_tree(int size);
struct hashmap *pat_map;
bool add_edge(Tree *tree, int x, int y);
void free_tree(Tree *tree);
void *p_enum(void *data);
int extend(int th_id, int n, int h, int idx_from, int idx_to);

// Comparison function for sorting in ascending order
int compare(const void *a, const void *b);
void free_patterns();

void *p_enum_n(void *data);
int extend_n(int th_id, int n, int h, int idx_from, int idx_to, double *duals);
int pattern_enum_n(int n, int max_element, double *duals);

// global variables
int **order_arr, num_orders, num_riders, ***rider_time, *trt, **patterns, pattern_upto, ***pat_h_n_idxs, ***th_patterns, **th_patterns_data, num_x, *th_num_patterns, pat_idx, num_x_sol, *p_pat_idxs;
int hash_idx;
int ***edge_weight_idx, *tree_trt, **tree_patterns, ***tree_pat_h_n_idxs, tree_pat_idx;
int *tree_sol_idx, num_tree_sol;
int *dual_sol_idx, num_dual_sol;
int *solution, **solution_2d, *seq_solution, **seq_solution_2d;

// tree_it
int **best_patterns, best_pat_idx, *best_trt;
double best_obj, best_ip_obj;
int loop_it = 0;
int loop_not_improved = 0;
int first_not_improved = 0;
bool second_not_improved;
int *iter_patts_idxs, *idxs_sorted_by_deadline_slack;
int ***slack_mat;

double *duals;
int64_t *dist_arr;
double **rider_arr;
bool ***compat;
pthread_t pthread[NUM_THREADS];
int num_edges_in_tree;
Tree *tree;

// main function
int *pattern_enum(int **order_array,
                  double **rider_array,
                  int64_t *dist_array,
                  int order_num,
                  int pattern_upto_,
                  int max_element,
                  int *num_gen_patts,
                  int _time_limit)
{
  clock_gettime(CLOCK_MONOTONIC, &start);
  // INITIALIZATION
  time_limit = _time_limit;
  // enumeration related
  pattern_upto = pattern_upto_;
  num_riders = 3;
  rider_arr = rider_array; // capa, var_cost, fixed_cost, speed, service_time
  order_arr = order_array; // ready_time, deadline, volume
  dist_arr = dist_array;
  num_orders = order_num;

  // calculate rider time takes less than 0.1 second for 1000 orders and 3 riders
  rider_time = (int ***)calloc(num_riders, sizeof(int **));

  for (int h = 0; h < num_riders; h++)
  {
    rider_time[h] = (int **)calloc(2 * order_num, sizeof(int *));
    for (int j = 0; j < 2 * order_num; j++)
    {
      rider_time[h][j] = (int *)calloc(2 * order_num, sizeof(int));
      for (int jj = 0; jj < 2 * order_num; jj++)
        rider_time[h][j][jj] = round(dist(j, jj) / rider_speed(h) + rider_service_time(h));
      
    }
  }
  // pairwise compatibility check related
  compat = (bool ***)calloc(num_riders, sizeof(bool **));
  for (int h = 0; h < num_riders; h++)
  {
    compat[h] = (bool **)calloc(num_orders, sizeof(bool *));
    for (int i = 0; i < num_orders; i++)
      compat[h][i] = (bool *)calloc(num_orders, sizeof(bool));
  }
  // return related
  trt = (int *)calloc(MAX_ELEMENT * (pattern_upto + 3), sizeof(int));
  patterns = (int **)calloc(MAX_ELEMENT, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
  for (int i = 0; i < MAX_ELEMENT; i++)
    patterns[i] = trt + i * (pattern_upto + 3);

  tree_trt = (int *)calloc(MAX_ELEMENT_TREE * (pattern_upto + 3), sizeof(int));
  tree_patterns = (int **)calloc(MAX_ELEMENT_TREE, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
  for (int i = 0; i < MAX_ELEMENT_TREE; i++)
    tree_patterns[i] = tree_trt + i * (pattern_upto + 3);

  best_trt = (int *)calloc(MAX_ELEMENT_BEST * (pattern_upto + 3), sizeof(int));
  best_patterns = (int **)calloc(MAX_ELEMENT_BEST, sizeof(int *));
  for (int i = 0; i < MAX_ELEMENT_BEST; i++)
    best_patterns[i] = best_trt + i * (pattern_upto + 3);

  // thread related
  th_patterns_data = (int **)calloc(NUM_THREADS, sizeof(int *));
  th_patterns = (int ***)calloc(NUM_THREADS, sizeof(int **));
  for (int i = 0; i < NUM_THREADS; i++)
  {
    th_patterns_data[i] = (int *)calloc(MAX_TH_PATTERNS * (pattern_upto + 3), sizeof(int));
    th_patterns[i] = (int **)calloc(MAX_TH_PATTERNS, sizeof(int *));
    for (int j = 0; j < MAX_TH_PATTERNS; j++)
      th_patterns[i][j] = th_patterns_data[i] + (j * (pattern_upto + 3));
  }
  th_num_patterns = (int *)calloc(NUM_THREADS, sizeof(int));
  generate_permutations(pattern_upto);
  print_time("Initialization : ");
  // INITIALIZATION END

  // PATTERN ENUMERATION
  pat_idx = 0;
  pat_h_n_idxs = (int ***)calloc(num_riders, sizeof(int **));
  for (int h = 0; h < num_riders; h++)
  {
    pat_h_n_idxs[h] = (int **)calloc(pattern_upto, sizeof(int *));
    for (int n = 0; n < pattern_upto; n++)
      pat_h_n_idxs[h][n] = (int *)calloc(2, sizeof(int));
  }

  tree_pat_h_n_idxs = (int ***)calloc(num_riders, sizeof(int **));
  for (int h = 0; h < num_riders; h++)
  {
    tree_pat_h_n_idxs[h] = (int **)calloc(pattern_upto, sizeof(int *));
    for (int n = 0; n < pattern_upto; n++)
      tree_pat_h_n_idxs[h][n] = (int *)calloc(2, sizeof(int));
  }
 // 1 order patterns
  for (int h = 0; h < num_riders; h++)
  {
    pat_h_n_idxs[h][0][0] = pat_idx;
    tree_pat_h_n_idxs[h][0][0] = pat_idx;

    for (int i = 0; i < num_orders; i++)
    {
      if ((order_volume(i) <= rider_capa(h)) && (order_ready_time(i) + rider_time[h][i][i + num_orders] <= order_deadline(i)))
      {
        patterns[pat_idx][0] = 1;
        patterns[pat_idx][1] = i;
        patterns[pat_idx][pattern_upto + 1] = 100 * rider_fixed_cost(h) + rider_var_cost(h) * dist(i, i + num_orders);
        patterns[pat_idx][pattern_upto + 2] = h;
        pat_idx++;
      }
    }
    pat_h_n_idxs[h][0][1] = pat_idx;
    tree_pat_h_n_idxs[h][0][1] = pat_idx;
    printf("    n %d  h %d  : %8d", 1, h, pat_h_n_idxs[h][0][1] - pat_h_n_idxs[h][0][0]);
  }
  print_time("");
  printf("    ----\n");

  p_pat_idxs = (int *)calloc(NUM_THREADS, sizeof(int));
  int num_patterns_to_copy = pat_h_n_idxs[2][0][1] - pat_h_n_idxs[0][0][0];
  tree_pat_idx = num_patterns_to_copy;
  memcpy(&tree_patterns[pat_h_n_idxs[0][0][0]][0], &patterns[pat_h_n_idxs[0][0][0]][0], num_patterns_to_copy * (pattern_upto + 3) * sizeof(int));

  // pattern with 2 orders (not for tree_patterns) -------------------------
  num_dual_sol = 0;
  dual_sol_idx = (int *)malloc(2000 * sizeof(int));

  for (int h = 0; h < num_riders; h++)
  {
    pat_h_n_idxs[h][1][0] = pat_idx;
    for (int i = 0; i < NUM_THREADS; i++)
    {
      struct th_data *data = (struct th_data *)malloc(sizeof(struct th_data));
      data->th_id = i;
      data->n = 2;
      data->h = h;
      data->idx_from = pat_h_n_idxs[h][0][0];
      data->idx_to = pat_h_n_idxs[h][0][1];
      data->p_pat_idx = &(p_pat_idxs[i]);
      int stat = pthread_create(&pthread[i], NULL, p_enum, (void *)data);
      if (stat != 0)
      {
        printf("pthread_create error\n");
        fflush(stdout);
      }
    }

    for (int i = 0; i < NUM_THREADS; i++)
      pthread_join(pthread[i], NULL);
    
    // print_time("");
    for (int i = 0; i < NUM_THREADS; i++)
    {
      memcpy(&(patterns[pat_idx][0]), &(th_patterns[i][0][0]), p_pat_idxs[i] * (pattern_upto + 3) * sizeof(int));
      pat_idx += p_pat_idxs[i];
    }
    pat_h_n_idxs[h][1][1] = pat_idx;
    for (int idx = pat_h_n_idxs[h][1][0]; idx < pat_h_n_idxs[h][1][1]; idx++)
    {
      compat[h][patterns[idx][1]][patterns[idx][2]] = true;
      compat[h][patterns[idx][2]][patterns[idx][1]] = true;
    }

    printf("    n %d  h %d  : %8d", 2, h, pat_h_n_idxs[h][1][1] - pat_h_n_idxs[h][1][0]);
    print_time("");
    if (pat_idx == max_element)
      break;
  }
  printf("    ----\n");
  // PATTERN ENUMERATION for 1 and 2 orders end////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // PATTERN ENUM for more than 3 orders
  best_obj = 1e9;
  best_ip_obj = 1e9;
  dual_pattern_enum(max_element, 3, DUAL_PAT_ENUM);
  hash_idx = pat_idx;
  // patterns[0] ~ patterns[pat_idx -1] : patterns made by intial cg_enum
  // patterns[pat_idx] ~ patterns[hash_idx -1] : patterns made from tree

  // TREE CONSTRUCTION //////////////////////////////////////////////////////////////
  int **skeleton = skeleton_from_initial_sol(patterns, dual_sol_idx, num_dual_sol);
  tree_sol_idx = (int *)malloc(num_orders * sizeof(int));

  printf("\n===============TREE IMRPOVE STARTS !===============\n");
  printf("\nTREE_IMPROVE FIRST OPTION started\n\n");
  skeleton = loop_tree_improve_first(TREE_IT_FIRST, THRESHOLD_FIRST, skeleton, NUM_TREE_EDGE_CHANGE);
  solve_tree_ip(); // best tree patterns until now (probably the last one)
  
  loop_not_improved = 0;
  int improve_option = 0;
  while (!time_limit_exceeded() &&  (loop_not_improved < STOP_LOOP))
  { 
    double best_loop_obj = best_ip_obj;
    printf("\nTREE_IMPROVE OPTION CHANGED ! OPTION = %d \n\n", improve_option%3);
    skeleton = skeleton_from_sol(patterns, improve_option);
    skeleton = loop_tree_improve_first(TREE_IT_FIRST, THRESHOLD_FIRST, skeleton, NUM_TREE_EDGE_CHANGE);
    solve_tree_ip(); // best tree patterns until now (probably the last one)
    if (best_ip_obj < best_loop_obj - 1e-5) // ip obj improved by loop
    {
      loop_not_improved = 0;
      best_loop_obj = best_ip_obj;
    }
    loop_not_improved++;
    improve_option ++;
  }
  //TO 세영 2: TREE IMPROVE 멈추면 tree 로 만들어진 패턴 넣고 IP 풀기
  // initial enum patterns 는 patterns[0] 부터 patterns[pat_idx - 1]
  // 그 중 1 order patterns 는 patterns[0] 부터 patterns[pat_h_n_idxs[0][1][0] - 1]
  // tree patterns (hash map)은 patterns[pat_idx]부터 patterns[hash_idx]
  clock_gettime(CLOCK_MONOTONIC, &finish);
  if ((finish.tv_sec - start.tv_sec) < (time_limit * ALL_IP_TIME))
  {
    printf("\n===============SOLVE_ALL STARTS !===============\n");
    solve_all();
  }
  // TODO: IP 풀고 개선되면 거기서 다시 skeleton_from_initial_sol() 해서 초기해 잡고
  // 앞의 tree improve 루프 그대로 돌리면 될 것 같은데, 그렇게 푼 ALL-IP 가 개선이 안되게 
  /*시간 남으면 (ALL_IP_TIME 만큼이 경고되지 않았으면, 즉 (1-timelimit * ALL_IP_TIME) 이 남았으면 지금까지 patterns[pat_idx] 부터 patterns[hash_idx] 에 저장했던 tree 로부터 나온 패턴들 다 넣고 IP 풀어서 이게 개선된 IP sol 을 주면 앞의 tree improve 루프를 복붙해서 다시 돌릴라고 했는데…. 패턴을 잘 못 골라넣는지 개선된 IP sol 이 안나오네요... 확인 부탁드립니다.. (이게 세영2)*/ // TODO: 밑의 best_patterns 없애고 maxtime 조절하면 해결될 것 같습니다. 



  
  // FINAL
  //printf("==================================\n");
  //printf("FINAL ");
  
  //solve();
  //get_sequenced_solution();

  // FREE MEMORY
  free(solution);
  free(solution_2d);
  hashmap_free(pat_map);
  for (int h = 0; h < num_riders; h++)
  {
    for (int i = 0; i < num_orders; i++)
    {
      free(slack_mat[h][i]);
    }
    free(slack_mat[h]);
  }
  free(slack_mat);
  free(p_pat_idxs);
  for (int i = 0; i < num_riders; i++)
  {
    for (int j = 0; j < 2 * num_orders; j++)
    {
      free(rider_time[i][j]);
    }
    free(rider_time[i]);
  }
  free(rider_time);
  free(patterns);
  free(tree_patterns);
  free(best_patterns);
  free_permutations();
  for (int h = 0; h < num_riders; h++)
  {
    for (int n = 0; n < pattern_upto; n++)
    {
      free(pat_h_n_idxs[h][n]);
      free(tree_pat_h_n_idxs[h][n]);
    }
    free(pat_h_n_idxs[h]);
    free(tree_pat_h_n_idxs[h]);
  }
  free(pat_h_n_idxs);
  free(tree_pat_h_n_idxs);
  free(th_num_patterns);
  for (int i = 0; i < NUM_THREADS; i++)
  {
    free(th_patterns_data[i]);
    free(th_patterns[i]);
  }
  free(th_patterns);
  free(th_patterns_data);
  free(trt);
  free(tree_trt);
  free(best_trt);

  // FREE MEMORY END

  num_gen_patts[0] = num_x_sol;

  return seq_solution;
}

inline double rider_capa(int rider_type)
{
  return rider_arr[rider_type][0];
}
inline double rider_var_cost(int rider_type)
{
  return rider_arr[rider_type][1];
}
inline double rider_fixed_cost(int rider_type)
{
  return rider_arr[rider_type][2];
}
inline double rider_speed(int rider_type)
{
  return rider_arr[rider_type][3];
}
inline double rider_service_time(int rider_type)
{
  return rider_arr[rider_type][4];
}
inline double rider_avail_num(int rider_type)
{
  return rider_arr[rider_type][5];
}
inline int order_ready_time(int order_num)
{
  return order_arr[order_num][0];
}
inline int order_deadline(int order_num)
{
  return order_arr[order_num][1];
}
inline int order_volume(int order_num)
{
  return order_arr[order_num][2];
}
inline int dist(int i, int j)
{
  return dist_arr[i * (2 * num_orders) + j];
}

void *p_enum(void *data)
{
  struct th_data *th_data = (struct th_data *)data;
  *(th_data->p_pat_idx) = extend(th_data->th_id, th_data->n, th_data->h, th_data->idx_from, th_data->idx_to);
  return NULL;
}

int extend(int th_id, int n, int h, int idx_from, int idx_to)
{
  int pat_idx = 0;
  int min_last_pickup_time = INF;
  int *pickup_dists = malloc(factorial[n] * sizeof(int));
  int *pickup_times = malloc(factorial[n] * sizeof(int));
  int *delivery_dists = malloc(factorial[n] * sizeof(int));
  int *delivery_times = malloc(factorial[n] * sizeof(int));
  int *base_seq = malloc(n * sizeof(int));
  int *temp_subset_patt = (int *)calloc(pattern_upto + 3, sizeof(int));
  temp_subset_patt[0] = n - 1;
  int *perm, *d_perm, *p_perm;
  temp_subset_patt[pattern_upto + 2] = h;
  int front, end;
  int *sorted_idxs_p = (int *)calloc(factorial[n], sizeof(int));
  int *sorted_idxs_d = (int *)calloc(factorial[n], sizeof(int));

  for (int idx = idx_from + th_id; idx < idx_to; idx += NUM_THREADS)
  {
    int *base_pat = patterns[idx];
    int max_order = base_pat[n - 1];
    int base_pat_volume = 0;
    for (int i = 1; i <= n - 1; i++)
      base_pat_volume += order_volume(base_pat[i]);
    for (int k = max_order + 1; k < num_orders; k++)
    {
      // check capacity
      if (order_volume(k) + base_pat_volume > rider_capa(h) + 1e-5)
        continue;

      // check subset feasibility
      bool subset_feasible = true;
      if (n > 2)
      {
        for (int i = 1; i < n; i++)
        {
          if (!compat[h][base_pat[i]][k])
          {
            subset_feasible = false;
            break;
          }
        }
      }
      if (!subset_feasible)
        continue;

      // check route feasibility
      int min_deadline = order_deadline(k);
      int min_deadline_order = k;
      for (int i = 1; i < n; i++)
      {
        min_deadline = (order_deadline(base_pat[i]) < min_deadline) ? order_deadline(base_pat[i]) : min_deadline;
        if (min_deadline == order_deadline(base_pat[i]))
          min_deadline_order = base_pat[i];
      }
      min_last_pickup_time = INF;
      for (int i = 1; i <= n; i++)
        base_seq[i - 1] = base_pat[i];
      base_seq[n - 1] = k;

      //// pickup sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        pickup_dists[seq_idx] = 0;
        pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);
        if (pickup_times[seq_idx] > min_deadline)
        {
          sorted_idxs_p[end--] = seq_idx;
          pickup_dists[seq_idx] = INF;
          continue;
        }
        for (int i = 1; i < n; i++)
        {
          pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
          pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
          if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
          {
            pickup_dists[seq_idx] = INF;
            break;
          }
          pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
        }
        if (pickup_dists[seq_idx] >= INF)
        {
          sorted_idxs_p[end--] = seq_idx;
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
            break;
        }
        memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
        sorted_idxs_p[idx] = seq_idx;
        front++;
        min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
      }
      if (min_last_pickup_time >= INF)
        continue;

      //// delivery sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        delivery_dists[seq_idx] = 0;
        delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);
        if (delivery_times[seq_idx] < min_last_pickup_time)
        {
          delivery_dists[seq_idx] = INF;
          sorted_idxs_d[end--] = seq_idx;
          continue;
        }
        for (int i = n - 1; i > 0; i--)
        {
          delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
          delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
          if (delivery_times[seq_idx] < min_last_pickup_time)
          {
            delivery_dists[seq_idx] = INF;
            break;
          }
          delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
        }
        if (delivery_dists[seq_idx] >= INF)
        {
          sorted_idxs_d[end--] = seq_idx;
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
            break;
        }
        memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
        sorted_idxs_d[idx] = seq_idx;
        front++;
      }

      //// Find best combination
      int min_dist = INF;
      int p_idx, d_idx;
      for (int i = 0; i < factorial[n]; i++)
      {
        p_idx = sorted_idxs_p[i];
        if (pickup_dists[p_idx] >= INF)
          break;
        p_perm = get_nth_permutation_of_size(p_idx, n);
        for (int j = 0; j < factorial[n]; j++)
        {
          d_idx = sorted_idxs_d[j];
          if (delivery_dists[d_idx] >= INF)
            break;
          d_perm = get_nth_permutation_of_size(d_idx, n);
          if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[base_pat[0]]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders) < min_dist))
          {
            min_dist = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders);
          }
        }
      }

      //// add if feasible
      if (min_dist < INF)
      {
        th_patterns[th_id][pat_idx][0] = n;
        memcpy(&(th_patterns[th_id][pat_idx][1]), &(base_pat[1]), (n - 1) * sizeof(int));
        th_patterns[th_id][pat_idx][n] = k;
        th_patterns[th_id][pat_idx][pattern_upto + 1] = 100 * rider_fixed_cost(h) + rider_var_cost(h) * min_dist;
        th_patterns[th_id][pat_idx][pattern_upto + 2] = h;
        pat_idx += 1;
      }
      if (pat_idx == MAX_TH_PATTERNS || time_limit_exceeded_enum())
        break;
    }
    if (pat_idx == MAX_TH_PATTERNS || time_limit_exceeded_enum())
      break;
  }
  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  free(temp_subset_patt);
  return pat_idx;
}

void *p_enum_n(void *data)
{
  struct th_data_n *th_data_n = (struct th_data_n *)data; // th_data_n
  // for each thread, extend_n (enum for order = n)
  *(th_data_n->p_pat_idx) = extend_n(th_data_n->th_id, th_data_n->n, th_data_n->h, th_data_n->idx_from, th_data_n->idx_to, th_data_n->duals);
  return NULL;
}

int extend_n(int th_id, int n, int h, int idx_from, int idx_to, double *duals)
{
  int pat_idx = 0;
  int min_last_pickup_time = 1e9;
  int *pickup_dists = malloc(factorial[n] * sizeof(int));
  int *pickup_times = malloc(factorial[n] * sizeof(int));
  int *delivery_dists = malloc(factorial[n] * sizeof(int));
  int *delivery_times = malloc(factorial[n] * sizeof(int));
  int *base_seq = malloc(n * sizeof(int));
  int *temp_subset_patt = (int *)calloc(pattern_upto + 3, sizeof(int));
  temp_subset_patt[0] = n - 1;
  int *perm, *d_perm, *p_perm;
  temp_subset_patt[pattern_upto + 2] = h;
  int front, end;
  int *sorted_idxs_p = (int *)calloc(factorial[n], sizeof(int));
  int *sorted_idxs_d = (int *)calloc(factorial[n], sizeof(int));
  double dual_assign_max = -1e6;
  for (int i = 0; i < num_orders; i++)
    dual_assign_max = (duals[i] > dual_assign_max) ? duals[i] : dual_assign_max;

#ifdef AVG_COST_CUTOFF
  double last_cost = 0;
  for (int i = 0; i < num_orders; i++)
    last_cost += duals[i];
  for (int h = 0; h < num_riders; h++)
    last_cost += duals[num_orders + h] * rider_avail_num(h);
#endif

  for (int idx = idx_from + th_id; idx < idx_to; idx += NUM_THREADS)
  {
    int *base_pat = patterns[idx];
    int max_order = base_pat[n - 1];

    // check reduced cost feasibility
    double rc_lb = ((double)base_pat[pattern_upto + 1]) / (100 * num_orders) - duals[num_orders + h];
    for (int i = 1; i < n; i++)
      rc_lb -= duals[base_pat[i]];
    if (rc_lb > dual_assign_max)
      continue;
#ifdef AVG_COST_CUTOFF
    double avg_cost_lb = ((double)base_pat[pattern_upto + 1]) / (100 * num_orders) / n;
    if (avg_cost_lb > (last_cost / num_orders) * AVG_COST_THRD)
      continue;
#endif

    int base_pat_volume = 0;
    for (int i = 1; i <= n - 1; i++)
      base_pat_volume += order_volume(base_pat[i]);

    for (int k = max_order + 1; k < num_orders; k++)
    {

      // check reduced cost feasibility
      if (rc_lb - duals[k] > 0)
        continue;

      // check capacity
      if (order_volume(k) + base_pat_volume > rider_capa(h) + 1e-5)
        continue;

      // check subset feasibility
      bool subset_feasible = true;
      if (n > 2)
      {
        for (int i = 1; i < n; i++)
        {
          if (!compat[h][base_pat[i]][k])
          {
            subset_feasible = false;
            break;
          }
        }
      }
      if (!subset_feasible)
        continue;

      // check route feasibility
      int min_deadline = order_deadline(k);
      int min_deadline_order = k;
      for (int i = 1; i < n; i++)
      {
        min_deadline = (order_deadline(base_pat[i]) < min_deadline) ? order_deadline(base_pat[i]) : min_deadline;
        if (min_deadline == order_deadline(base_pat[i]))
          min_deadline_order = base_pat[i];
      }
      min_last_pickup_time = 1e9;
      for (int i = 1; i <= n; i++)
        base_seq[i - 1] = base_pat[i];
      base_seq[n - 1] = k;

      //// pickup sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        pickup_dists[seq_idx] = 0;
        pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);
        if (pickup_times[seq_idx] > min_deadline)
        {
          sorted_idxs_p[end--] = seq_idx;
          pickup_dists[seq_idx] = 1e9;
          // printf("pickup exceed deadline");
          continue;
        }
        for (int i = 1; i < n; i++)
        {
          pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
          pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
          if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
          {
            pickup_dists[seq_idx] = 1e9;
            break;
          }
          pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
        }
        if (pickup_dists[seq_idx] >= 1e9)
        {
          sorted_idxs_p[end--] = seq_idx;
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
            break;
        }
        memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
        sorted_idxs_p[idx] = seq_idx;
        front += 1;

        min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
      }
      if (min_last_pickup_time >= 1e9)
        continue;

      //// delivery sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        delivery_dists[seq_idx] = 0;
        delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);
        if (delivery_times[seq_idx] < min_last_pickup_time)
        {
          delivery_dists[seq_idx] = 1e9;
          sorted_idxs_d[end--] = seq_idx;
          continue;
        }
        for (int i = n - 1; i > 0; i--)
        {
          delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
          delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
          if (delivery_times[seq_idx] < min_last_pickup_time)
          {
            delivery_dists[seq_idx] = 1e9;
            break;
          }
          delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
        }
        if (delivery_dists[seq_idx] >= 1e9)
        {
          sorted_idxs_d[end--] = seq_idx;
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
            break;
        }
        memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
        sorted_idxs_d[idx] = seq_idx;
        front += 1;
      }

      //// Find best combination
      int min_dist = 1e9;
      int p_idx, d_idx;
      for (int i = 0; i < factorial[n]; i++)
      {
        p_idx = sorted_idxs_p[i];
        if (pickup_dists[p_idx] >= 1e9)
          break;

        p_perm = get_nth_permutation_of_size(p_idx, n);
        for (int j = 0; j < factorial[n]; j++)
        {
          d_idx = sorted_idxs_d[j];
          if (delivery_dists[d_idx] >= 1e9)
            break;

          d_perm = get_nth_permutation_of_size(d_idx, n);
          if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[base_pat[0]]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders) < min_dist))
            min_dist = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders);
        }
      }

      //// check feasible
      if (min_dist < 1e9) // fsb
      // add if profitable
      { 
        int candidate_cost = 100 * rider_fixed_cost(h) + rider_var_cost(h) * min_dist;

#ifdef AVG_COST_CUTOFF
        if (((double)candidate_cost) / (num_orders * 100) / n > (last_cost / num_orders) * AVG_COST_THRD)
          continue;
#endif

        double reduced_cost = candidate_cost / (num_orders * 100) - duals[num_orders + h];
        // calculate reduced cost (already rider, now assignment)
        for (int j = 1; j < n; j++) // 1 ~ n-1 th
          reduced_cost -= duals[base_pat[j]];
        
        reduced_cost -= duals[k]; // n th
        if (reduced_cost < -1e-5)
        {
          th_patterns[th_id][pat_idx][0] = n;
          memcpy(&(th_patterns[th_id][pat_idx][1]), &(base_pat[1]), (n - 1) * sizeof(int));
          th_patterns[th_id][pat_idx][n] = k;
          th_patterns[th_id][pat_idx][pattern_upto + 1] = candidate_cost;
          th_patterns[th_id][pat_idx][pattern_upto + 2] = h;
          pat_idx += 1;
        }
      }
      if (pat_idx == MAX_TH_PATTERNS || time_limit_exceeded_enum())
        break;
    }
    if (pat_idx == MAX_TH_PATTERNS || time_limit_exceeded_enum())
      break;
  }
  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  free(temp_subset_patt);
  return pat_idx;
}

////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
//
//                                     TREE CONSTRUCTION CODE
//
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
  int **mat;
  int **result;
  int n;
  int start_row;
  int end_row;
  int type;
} MatSquareData;

void *compute_block(void *arg)
{
  MatSquareData *data = (MatSquareData *)arg;
  if (data->type == 0)
  {
    for (int i = data->start_row; i < data->end_row; i++)
    {
      for (int j = i; j < data->end_row; j++)
      {
        int sum = 0;
        for (int k = 0; k < data->n; k++)
        {
          sum += data->mat[i][k] * data->mat[k][j];
        }
        data->result[i][j] = sum;
        data->result[j][i] = sum;
      }
    }
  }
  else if (data->type == 1)
  {
    for (int i = data->start_row; i < data->end_row; i++)
    {
      for (int j = i + data->n / 2; j < data->end_row + data->n / 2; j++)
      {
        int sum = 0;
        for (int k = 0; k < data->n; k++)
        {
          sum += data->mat[i][k] * data->mat[k][j];
        }
        data->result[i][j] = sum;
        data->result[j][i] = sum;
      }
    }
  }
  else if (data->type == 2)
  {
    for (int i = data->start_row; i < data->end_row; i++)
    {
      for (int j = 0 + data->n / 2; j < i + data->n / 2; j++)
      {
        int sum = 0;
        for (int k = 0; k < data->n; k++)
        {
          sum += data->mat[i][k] * data->mat[k][j];
        }
        data->result[i][j] = sum;
        data->result[j][i] = sum;
      }
    }
  }

  pthread_exit(0);
}

int **mat_square(int **mat, int n)
{
  int **result = (int **)malloc(n * sizeof(int *));
  for (int i = 0; i < n; i++)
  {
    result[i] = (int *)malloc(n * sizeof(int));
  }

  pthread_t threads[4];
  MatSquareData thread_data[4];

  thread_data[0].start_row = 0;
  thread_data[0].end_row = n / 2;
  thread_data[0].type = 0;
  thread_data[1].start_row = n / 2;
  thread_data[1].end_row = n;
  thread_data[1].type = 0;
  thread_data[2].start_row = 0;
  thread_data[2].end_row = n / 2;
  thread_data[2].type = 1;
  thread_data[3].start_row = 0;
  thread_data[3].end_row = n / 2;
  thread_data[3].type = 2;

  for (int i = 0; i < 4; i++)
  {
    thread_data[i].mat = mat;
    thread_data[i].result = result;
    thread_data[i].n = n;
    pthread_create(&threads[i], NULL, compute_block, (void *)&thread_data[i]);
  }

  for (int i = 0; i < 4; i++)
  {
    pthread_join(threads[i], NULL);
  }

  return result;
}

int *num_node;
int finds(int node, int *parent)
{
  if (parent[node] != node)
  {
    parent[node] = finds(parent[node], parent);
  }
  return parent[node];
}

void union_nodes(int node1, int node2, int *parent)
{
  int root1 = finds(node1, parent);
  int root2 = finds(node2, parent);
  if (root1 != root2)
  {
    parent[root1] = root2; // 루트를 병합
  }
}

int compare_edges(const void *a, const void *b)
{
  const int *edge_a = *(const int **)a;
  const int *edge_b = *(const int **)b;

  return edge_b[1] - edge_a[1]; // sort by weight
}

int get_min_cost_route_enum(int *orders, int n, int h);

// Define the structure for tree
/* START of Union-Find CODES (union-find is used to check connectivity among nodes) */
// Define the structure for Union-Find

// Function to create a new Union-Find structure
UnionFind *create_union_find(int size)
{
  UnionFind *uf = (UnionFind *)malloc(sizeof(UnionFind));
  uf->parent = (int *)malloc(size * sizeof(int));
  uf->rank = (int *)malloc(size * sizeof(int));
  uf->size = size;
  for (int i = 0; i < size; i++)
  {
    uf->parent[i] = i;
    uf->rank[i] = 0;
  }
  return uf;
}
// Function to find the root of an element
int find(UnionFind *uf, int x)
{
  if (uf->parent[x] != x)
  {
    uf->parent[x] = find(uf, uf->parent[x]); // Path compression
  }
  return uf->parent[x];
}
// Function to union two sets
void union_sets(UnionFind *uf, int rootX, int rootY)
{
  if (uf->rank[rootX] > uf->rank[rootY])
  {
    uf->parent[rootY] = rootX;
  }
  else if (uf->rank[rootX] < uf->rank[rootY])
  {
    uf->parent[rootX] = rootY;
  }
  else
  {
    uf->parent[rootY] = rootX;
    uf->rank[rootX]++;
  }
}
// Function to free the Union-Find structure
void free_union_find(UnionFind *uf)
{
  free(uf->parent);
  free(uf->rank);
  free(uf);
}
/* END OF UNION-FIND CODE */

// Tree is represented as an adjacency list

// Function to create a new tree structure
Tree *create_tree(int size)
{
  Tree *tree = (Tree *)malloc(sizeof(Tree));
  tree->adj_list = (adj_list_node **)malloc(size * sizeof(adj_list_node *));
  tree->size = size;
  for (int i = 0; i < size; i++)
  {
    tree->adj_list[i] = NULL;
  }
  tree->uf = create_union_find(size);
  return tree;
}

// Function to add an edge to the tree
bool add_edge(Tree *tree, int x, int y)
{
  int rootX = find(tree->uf, x);
  int rootY = find(tree->uf, y);
  if (rootX != rootY)
  {
    union_sets(tree->uf, rootX, rootY);
    adj_list_node *node = (adj_list_node *)malloc(sizeof(adj_list_node));
    node->id = y;
    node->next = tree->adj_list[x];
    tree->adj_list[x] = node;
    node = (adj_list_node *)malloc(sizeof(adj_list_node));
    node->id = x;
    node->next = tree->adj_list[y];
    tree->adj_list[y] = node;
    return true;
  }
  return false;
}
// Function to free the tree structure
void free_tree(Tree *tree)
{
  for (int i = 0; i < tree->size; i++)
  {
    adj_list_node *temp = tree->adj_list[i];
    while (temp != NULL)
    {
      adj_list_node *next = temp->next;
      free(temp);
      temp = next;
    }
  }
  free(tree->adj_list);
  free_union_find(tree->uf);
  free(tree);
}

/* hashmap codes */
struct pattern
{
  char *id;
  int idx;
};
int pattern_compare(const void *a, const void *b, void *udata)
{
  const struct pattern *ua = a;
  const struct pattern *ub = b;
  return strcmp(ua->id, ub->id);
}
bool pattern_iter(const void *item, void *udata)
{
  const struct pattern *pattern = item;
  printf("%s (is_feas=%d)\n", pattern->id, pattern > 0);
  return true;
}

uint64_t pattern_hash(const void *item, uint64_t seed0, uint64_t seed1)
{
  const struct pattern *pattern = item;
  return hashmap_sip(pattern->id, strlen(pattern->id), seed0, seed1);
}
char *get_id(int *pattern)
{
  char *id = malloc((5 * pattern[0] + 2) * sizeof(char)); // order당 5글자 vehicle에 2글자
  Element *sorted_orders = malloc((pattern[0]) * sizeof(Element));
  for (int i = 1; i < pattern[0] + 1; i++)
  {
    sorted_orders[i - 1].index = pattern[i];
    sorted_orders[i - 1].rcost = pattern[i];
  }
  qsort(sorted_orders, pattern[0], sizeof(Element), compare);
  sprintf(id, "%d", sorted_orders[0].index);
  for (int i = 1; i < pattern[0]; i++)
  {
    sprintf(id, "%s_%d", id, sorted_orders[i].index);
  }
  free(sorted_orders);
  sprintf(id, "%s-%d", id, pattern[pattern_upto + 2]);
  return id;
}
struct pattern *create_pattern(int *pattern, int idx)
{
  struct pattern *patt = (struct pattern *)malloc(sizeof(struct pattern));
  patt->id = get_id(pattern);
  patt->idx = idx;
  return patt;
}
void pattern_free(void *item)
{
  struct pattern *pattern = (struct pattern *)item;
  free(pattern->id);
  pattern->id = NULL;
}
/* end of hashmap codes */

int **adj;

void add_edges(int u, int v)
{
  adj[u][v] = 1;
  adj[v][u] = 1;
}

int **skeleton_from_initial_sol(int **patterns, int *dual_sol_idx, int num_dual_sol)
{
  pat_map = hashmap_new(sizeof(struct pattern), 0, 0, 0,
                        pattern_hash, pattern_compare, pattern_free, NULL);
  for (int i = 0; i < pat_h_n_idxs[2][1][1]; i++)
  {
    struct pattern *p = create_pattern(patterns[i], i);
    hashmap_set(pat_map, (void *)p);
    free(p);
  }
  // keep 1, 2 length orders to pat_map
  // calculate deadline slack for all 2 order patterns
  idxs_sorted_by_deadline_slack = (int *)malloc((pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]) * sizeof(int));
  Element *slacks = (Element *)malloc((pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]) * sizeof(Element));
  slack_mat = (int ***)calloc(num_riders, sizeof(int **));
  for (int h = 0; h < num_riders; h++)
  {
    slack_mat[h] = (int **)calloc(num_orders, sizeof(int *));
    for (int i = 0; i < num_orders; i++)
      slack_mat[h][i] = (int *)calloc(num_orders, sizeof(int));
  }

  for (int idx = pat_h_n_idxs[0][1][0]; idx < pat_h_n_idxs[2][1][1]; idx++)
  {
    int h = patterns[idx][pattern_upto + 2];
    int temp, seq_time;
    int *seq = get_best_sequence(patterns[idx], &temp, h);
    int slack = 1e7;
    if (seq != NULL)
    {
      seq_time = order_ready_time(seq[0]) + rider_time[h][seq[0]][seq[1]];
      seq_time = (seq_time > order_ready_time(seq[1])) ? seq_time : order_ready_time(seq[1]);
      seq_time += rider_time[h][seq[1]][seq[2] + num_orders];
      slack = order_deadline(seq[2]) - seq_time;
      seq_time += rider_time[h][seq[2] + num_orders][seq[3] + num_orders];
      slack = (order_deadline(seq[3]) - seq_time < slack) ? order_deadline(seq[3]) - seq_time : slack;
    }
    slacks[idx - pat_h_n_idxs[0][1][0]].index = idx;
    slacks[idx - pat_h_n_idxs[0][1][0]].rcost = -slack;
    slack_mat[h][patterns[idx][1]][patterns[idx][2]] = slack;
    slack_mat[h][patterns[idx][2]][patterns[idx][1]] = slack;
  }

  qsort(slacks, pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0], sizeof(Element), compare);
  for (int i = 0; i < pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]; i++)
  {
    idxs_sorted_by_deadline_slack[i] = slacks[i].index;
  }

  printf("Start constructing intial tree");
  print_time("");
  printf("- - - - - - - - - - - - - - - - - - - - \n");

  Tree *tree = create_tree(num_orders);
  int **skeleton;
  skeleton = (int **)malloc(num_orders * sizeof(int *));
  for (int i = 0; i < num_orders; i++)
    skeleton[i] = (int *)malloc(2 * sizeof(int));
  num_edges_in_tree = 0;

  // get solution from previous IP (based on delivery sequence)//
  ///////////////////////////////////////////////////////////////
  ///// add edge based on delivery sequence of IP optimal solution
  for (int i = 0; i < num_x_sol; i++)
  {
    for (int j = 0; j < seq_solution_2d[i][0] - 1; j++)
    {
      if (add_edge(tree, seq_solution_2d[i][j + 1 + seq_solution_2d[i][0]], seq_solution_2d[i][j + 2 + seq_solution_2d[i][0]]))
      {

        skeleton[num_edges_in_tree][0] = seq_solution_2d[i][j + 1 + seq_solution_2d[i][0]];
        skeleton[num_edges_in_tree][1] = seq_solution_2d[i][j + 2 + seq_solution_2d[i][0]];
        num_edges_in_tree++;
      }
    }
  }

  ////// add edges via deadline slack
  for (int i = 0; i < pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]; i++)
  {
    int idx = idxs_sorted_by_deadline_slack[i];
    if (add_edge(tree, patterns[idx][1], patterns[idx][2]))
    {

      skeleton[num_edges_in_tree][0] = patterns[idx][1];
      skeleton[num_edges_in_tree][1] = patterns[idx][2];
      num_edges_in_tree++;
    }

    if (num_edges_in_tree == num_orders - 1)
      break;
  }

  free_tree(tree);
  return skeleton;
}

int compare_slack(const void* a, const void* b) {
  // return ((SlackCombination*)b)->slack_value - ((SlackCombination*)a)->slack_value;
  if (((SlackCombination *)a)->slack_value < ((SlackCombination *)b)->slack_value)
    return 1;
  else if (((SlackCombination *)a)->slack_value > ((SlackCombination *)b)->slack_value)
    return -1;
  else
    return 0;
} // TODO: rcost랑은 반대 방향으로 정렬하고 있는 것 같은데 맞나요

int **skeleton_from_sol(int **patterns, int option)
{

  Tree *tree = create_tree(num_orders);
  int **skeleton; // TODO: 여기랑 skeleton_from_initial_sol에서 skeleton이 각각 정의되는데 확인 필요
  skeleton = (int **)malloc(num_orders * sizeof(int *));
  for (int i = 0; i < num_orders; i++)
  {
    skeleton[i] = (int *)malloc(2 * sizeof(int));
  }
  num_edges_in_tree = 0; 

  //FIRST OPTION
  ///// add edge based on delivery sequence of IP optimal solution
  if (option % 3 == 0 )
  {
    for (int i = 0; i < num_x_sol; i++)
    {
      for (int j = 0; j < seq_solution_2d[i][0] - 1; j++)
      {
        if (add_edge(tree, seq_solution_2d[i][j + 1 + seq_solution_2d[i][0]], seq_solution_2d[i][j + 2 + seq_solution_2d[i][0]]))
        {
          skeleton[num_edges_in_tree][0] = seq_solution_2d[i][j + 1 + seq_solution_2d[i][0]];
          skeleton[num_edges_in_tree][1] = seq_solution_2d[i][j + 2 + seq_solution_2d[i][0]];
          num_edges_in_tree++;
        }
      }
    }
  }
  //SECOND OPTION
  ///// add edge based on pickup sequence of IP optimal solution
  if (option % 3 == 1)
  {
    for (int i = 0; i < num_x_sol; i++)
    {
      for (int j = 0; j < seq_solution_2d[i][0] - 1; j++)
      {
        if (add_edge(tree, seq_solution_2d[i][j + 1], seq_solution_2d[i][j + 2]))
        {
          skeleton[num_edges_in_tree][0] = seq_solution_2d[i][j + 1];
          skeleton[num_edges_in_tree][1] = seq_solution_2d[i][j + 2];
          num_edges_in_tree++;
        }
      }
    }
  }

  //THIRD OPTION 
  //TO 세영 3: solution 내에서 dealine slack 큰 edge 순으로 추가
  ////// add edge based on deadline slack of IP optimal solution
  if (option % 3 == 2)
  {
    for (int idx = 0 ; idx < num_x_sol; idx ++)
    { 
      int n = seq_solution_2d[idx][0];
      int h = seq_solution_2d[idx][2*pattern_upto + 2];
      if (n < 2)
        continue; // pass 1 order solution
      if (n < 3) // keep 2 order solution
      {
        add_edge(tree, seq_solution_2d[idx][1], seq_solution_2d[idx][2]);
        skeleton[num_edges_in_tree][0] = seq_solution_2d[idx][1];
        skeleton[num_edges_in_tree][1] = seq_solution_2d[idx][2];
        num_edges_in_tree++;
        continue;
      }
      int comb = 0;
      int num_combinations = (n * (n - 1))/ 2;
      SlackCombination slack_comb[num_combinations]; 

      for (int i = 1; i < n; i++) 
      {
        for (int j = i + 1; j < n + 1; j++) 
        {
          slack_comb[comb].i = i;
          slack_comb[comb].j = j;
          slack_comb[comb].slack_value = slack_mat[h][seq_solution_2d[idx][i]][seq_solution_2d[idx][j]];
          comb++;
        }
      }

      qsort(slack_comb, num_combinations, sizeof(SlackCombination), compare_slack);
      int num_edge_sub = 0;
      for (int k = 0; k < num_combinations; k++) 
      { 
        if (add_edge(tree, seq_solution_2d[idx][slack_comb[k].i], seq_solution_2d[idx][slack_comb[k].j]))
        { 
          skeleton[num_edges_in_tree][0] = seq_solution_2d[idx][slack_comb[k].i];
          skeleton[num_edges_in_tree][1] = seq_solution_2d[idx][slack_comb[k].j];
          num_edges_in_tree++;
          num_edge_sub ++;
        }
        if (num_edge_sub == n - 1)
          break;
      }
    }
  }

  ///////////////////////////////////
  // AFTER OTION/////////////////////
  ////// add edges via deadline slack
  for (int i = 0; i < pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]; i++)
  {
    int idx = idxs_sorted_by_deadline_slack[i];
    if (add_edge(tree, patterns[idx][1], patterns[idx][2]))
    {

      skeleton[num_edges_in_tree][0] = patterns[idx][1];
      skeleton[num_edges_in_tree][1] = patterns[idx][2];
      num_edges_in_tree++;
    }

    if (num_edges_in_tree == num_orders - 1)
      break;
  }

  free_tree(tree);
  return skeleton;
}

int get_min_cost_route_enum(int *orders, int n, int h)
{
  int result = -1;

  // check capacity
  int capa = 0;
  for (int i = 0; i < n; i++)
    capa += order_volume(orders[i]);

  if (capa > rider_capa(h) + 1e-5)
    return result;
  

  // check subset fsb
  bool subset_feasible = true;
  for (int i = 0; i < n - 1; i++)
  {
    if (!compat[h][orders[i]][orders[n - 1]])
    {
      subset_feasible = false;
      break;
    }
  }
  if (!subset_feasible)
    return result;
  

  // route
  int *perm, *d_perm, *p_perm;
  int *pickup_dists = malloc(factorial[n] * sizeof(int));
  int *pickup_times = malloc(factorial[n] * sizeof(int));
  int *delivery_dists = malloc(factorial[n] * sizeof(int));
  int *delivery_times = malloc(factorial[n] * sizeof(int));
  int *sorted_idxs_p = (int *)calloc(factorial[n], sizeof(int));
  int *sorted_idxs_d = (int *)calloc(factorial[n], sizeof(int));
  int *base_seq = malloc(n * sizeof(int));
  int min_last_pickup_time = INF;

  int min_deadline = order_deadline(orders[n - 1]); 
  int min_deadline_order = orders[n - 1];

  for (int i = 0; i < n - 1; i++)
  {
    min_deadline = (order_deadline(orders[i]) < min_deadline) ? order_deadline(orders[i]) : min_deadline;
    if (min_deadline == order_deadline(orders[i]))
      min_deadline_order = orders[i];
  }

  min_last_pickup_time = 1e9;
  for (int i = 0; i < n; i++)
    base_seq[i] = orders[i];

  int front = 0;
  int end = factorial[n] - 1;

  for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
  {
    perm = get_nth_permutation_of_size(seq_idx, n);
    pickup_dists[seq_idx] = 0;
    pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);

    if (pickup_times[seq_idx] > min_deadline)
    {
      sorted_idxs_p[end--] = seq_idx;
      pickup_dists[seq_idx] = 1e9;
      continue;
    }

    for (int i = 1; i < n; i++)
    {
      pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
      pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
      if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
      {
        pickup_dists[seq_idx] = 1e9;
        break;
      }
      pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
    }
    if (pickup_dists[seq_idx] >= 1e9)
    {
      sorted_idxs_p[end--] = seq_idx;
      continue;
    }

    int idx = 0;
    for (; idx < front; idx++)
    {
      if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
        break;
    }

    memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
    sorted_idxs_p[idx] = seq_idx;
    front += 1;
    min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
  }

  if (min_last_pickup_time >= 1e9)
  {
    free(pickup_dists);
    free(pickup_times);
    free(delivery_dists);
    free(delivery_times);
    free(base_seq);
    free(sorted_idxs_p);
    free(sorted_idxs_d);
    return result; // route infsb (pickup)
  }

  //////////////////////////////////////////////////////////////
  // DELIVERY//

  front = 0;
  end = factorial[n] - 1;

  for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
  {
    perm = get_nth_permutation_of_size(seq_idx, n);
    delivery_dists[seq_idx] = 0;
    delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);

    if (delivery_times[seq_idx] < min_last_pickup_time)
    {
      delivery_dists[seq_idx] = 1e9;
      sorted_idxs_d[end--] = seq_idx;
      continue;
    }

    for (int i = n - 1; i > 0; i--)
    {
      delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
      delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
      if (delivery_times[seq_idx] < min_last_pickup_time)
      {
        delivery_dists[seq_idx] = 1e9;
        break;
      }
      delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
    }

    if (delivery_dists[seq_idx] >= 1e9)
    {
      sorted_idxs_d[end--] = seq_idx;
      continue;
    }

    int idx = 0;
    for (; idx < front; idx++)
    {
      if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
        break;
    }
    memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
    sorted_idxs_d[idx] = seq_idx;
    front += 1;
  }

  //// Find best combination
  int min_dist_ = INF;
  int p_idx, d_idx;
  for (int i = 0; i < factorial[n]; i++)
  {
    p_idx = sorted_idxs_p[i];
    if (pickup_dists[p_idx] >= 1e9)
      break;
    
    p_perm = get_nth_permutation_of_size(p_idx, n);
    for (int j = 0; j < factorial[n]; j++)
    {
      d_idx = sorted_idxs_d[j];
      if (delivery_dists[d_idx] >= 1e9)
        break;
      if (pickup_dists[p_idx] + delivery_dists[d_idx] > min_dist_)
        continue;
      d_perm = get_nth_permutation_of_size(d_idx, n);
      if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[n - 1]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[n - 1]], base_seq[d_perm[0]] + num_orders) < min_dist_))
        min_dist_ = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[n - 1]], base_seq[d_perm[0]] + num_orders);
    }
  }
  if (min_dist_ >= INF)
  {
    free(pickup_dists);
    free(pickup_times);
    free(delivery_dists);
    free(delivery_times);
    free(base_seq);
    free(sorted_idxs_p);
    free(sorted_idxs_d);
    return result; // route infsb (delivery)
  }

  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  free(sorted_idxs_p);
  free(sorted_idxs_d);

  // cost as result
  result = 100 * rider_fixed_cost(h) + rider_var_cost(h) * min_dist_;
  return result;
}
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
//
//                                       SOLVER CODE
//
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////

// Structure to hold element and its index
// Swap function for heap operations
void swap(Element *a, Element *b)
{
  Element temp = *a;
  *a = *b;
  *b = temp;
}

// Heapify function to maintain the max-heap property
void heapify(Element heap[], int n, int i)
{
  int largest = i;
  int left = 2 * i + 1;
  int right = 2 * i + 2;

  if (left < n && heap[left].rcost > heap[largest].rcost)
    largest = left;

  if (right < n && heap[right].rcost > heap[largest].rcost)
    largest = right;

  if (largest != i)
  {
    swap(&heap[i], &heap[largest]);
    heapify(heap, n, largest);
  }
}

// Function to build a max-heap
void buildHeap(Element heap[], int n)
{
  for (int i = n / 2 - 1; i >= 0; i--)
    heapify(heap, n, i);
}
// END OF HEAP CODE

// Comparison function for sorting in ascending order
int compare(const void *a, const void *b)
{
  if (((Element *)a)->rcost < ((Element *)b)->rcost)
    return -1;
  else if (((Element *)a)->rcost > ((Element *)b)->rcost)
    return 1;
  else
    return 0;
}
// END OF qsort CODE

// solve lp for tree patterns
double *solve_tree()
{
  // clock_gettime(CLOCK_MONOTONIC, &finish);

  // setup initial restricted master problem
  XPRBprob prob = XPRBnewprob("TREE-LP");
  XPRBvar x[MAX_COL_FIN];
  XPRBctr assign[num_orders], cardi[num_riders];
  XPRBctr obj;
  int x_idx[MAX_COL_FIN];
  double objval;
  double *dual = (double *)malloc(sizeof(double) * (num_orders + num_riders));

  obj = XPRBnewctr(prob, "obj", XPRB_N); // XPRB_N indicate this is for objective
  for (int i = 0; i < num_orders; i++)   // iterate over orders
  {
    assign[i] = XPRBnewctr(prob, XPRBnewname("assign_%d", i), XPRB_E);
    XPRBaddterm(assign[i], NULL, 1);
  }
  for (int i = 0; i < num_riders; i++) // iterate over riders
  {
    cardi[i] = XPRBnewctr(prob, XPRBnewname("cardi_%d", i), XPRB_L);
    XPRBaddterm(cardi[i], NULL, rider_avail_num(i));
  }
  for (int i = 0; i < tree_pat_h_n_idxs[0][1][0]; i++) // iterate over length 1 patterns
  {
    x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    x_idx[i] = i;
    XPRBaddterm(obj, x[i], ((double)tree_patterns[i][pattern_upto + 1]) / (num_orders * 100));
    XPRBaddterm(assign[tree_patterns[i][1]], x[i], 1);
    XPRBaddterm(cardi[tree_patterns[i][pattern_upto + 2]], x[i], 1);
  }

  for (int i = tree_pat_h_n_idxs[0][1][0]; i < tree_pat_idx; i++) // iterate over length 1 patterns
  {
    x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    x_idx[i] = i;
    XPRBaddterm(obj, x[i], ((double)tree_patterns[i][pattern_upto + 1]) / (num_orders * 100));
    for (int j = 1; j < tree_patterns[i][0] + 1; j++)
      XPRBaddterm(assign[tree_patterns[i][j]], x[i], 1);
    XPRBaddterm(cardi[tree_patterns[i][pattern_upto + 2]], x[i], 1);
  }

  XPRBsetobj(prob, obj);
  XPRBsetmsglevel(prob, 0);
  XPRBlpoptimize(prob, "");
  objval = XPRBgetobjval(prob);
  for (int i = 0; i < num_orders; i++)
    dual[i] = XPRBgetdual(assign[i]);
  for (int i = 0; i < num_riders; i++)
    dual[num_orders + i] = XPRBgetdual(cardi[i]);

  printf("obj %.3f  ", objval);
  print_time("");

  if (objval < best_obj - 1e-9) // objval improved !
  { 
    first_not_improved = 0;
    best_obj = objval;
    best_pat_idx = tree_pat_idx;
    memcpy(&best_patterns[0][0], &tree_patterns[0][0], tree_pat_idx * (pattern_upto + 3) * sizeof(int));
  }
  else
    first_not_improved++;
  
  num_tree_sol = 0;
  for (int i = 0; i < tree_pat_idx; i++)
  {
    if (XPRBgetsol(x[i]) > 1e-9)
    {
      int idx = x_idx[i];
      tree_sol_idx[num_tree_sol] = idx;
      num_tree_sol++;
    }
  }
  XPRBdelprob(prob);
  return dual;
}


void solve()  // TODO: 이제 이거 안쓰는듯?
{
  // clock_gettime(CLOCK_MONOTONIC, &finish);
  double final_ip_reserved = 1;

  // setup initial restricted master problem
  XPRBprob prob_f = XPRBnewprob("RMP_final");
  XPRBvar x_f[MAX_COL_FIN];
  int x_idx_f[MAX_COL_FIN];
  XPRBctr assign_f[num_orders], cardi_f[num_riders];
  XPRBctr obj_f;

  int num_x_f = pat_h_n_idxs[0][1][0];
  XPRBbasis basis_f;
  double objval_f, dual_assign[num_orders], dual_cardi[num_riders];

  //// initial RMP with length-1 patterns
  obj_f = XPRBnewctr(prob_f, "obj", XPRB_N); // XPRB_N indicate this is for objective
  for (int i = 0; i < num_orders; i++)       // iterate over orders
  {
    assign_f[i] = XPRBnewctr(prob_f, XPRBnewname("assign_f_%d", i), XPRB_E);
    XPRBaddterm(assign_f[i], NULL, 1);
  }
  for (int i = 0; i < num_riders; i++) // iterate over riders
  {
    cardi_f[i] = XPRBnewctr(prob_f, XPRBnewname("cardi_f_%d", i), XPRB_L);
    XPRBaddterm(cardi_f[i], NULL, rider_avail_num(i));
  }
  for (int i = 0; i < pat_h_n_idxs[0][1][0]; i++) // iterate over length 1 patterns
  {
    x_f[i] = XPRBnewvar(prob_f, XPRB_BV, XPRBnewname("x_f_%d", i), 0, 1);
    x_idx_f[i] = i;
    XPRBaddterm(obj_f, x_f[i], ((double)best_patterns[i][pattern_upto + 1]) / (num_orders * 100));
    XPRBaddterm(assign_f[best_patterns[i][1]], x_f[i], 1);
    XPRBaddterm(cardi_f[best_patterns[i][pattern_upto + 2]], x_f[i], 1);
  }
  XPRBsetobj(prob_f, obj_f);
  XPRBsetmsglevel(prob_f, 0);

  // column generation
  int it = 0;
  while (true)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if ((finish.tv_sec - start.tv_sec) > time_limit - final_ip_reserved)
      break;

    // solving RMP
    XPRBlpoptimize(prob_f, "");
    basis_f = XPRBsavebasis(prob_f);
    objval_f = XPRBgetobjval(prob_f);
    for (int i = 0; i < num_orders; i++)
      dual_assign[i] = XPRBgetdual(assign_f[i]);
    for (int i = 0; i < num_riders; i++)
      dual_cardi[i] = XPRBgetdual(cardi_f[i]);

    // check profitable columns
    int num_added = 0;

    // final version
    int it_pat_max = (it < EARLY_ITER) ? IT_PAT_MAX_EARLY : IT_PAT_MAX;
    int n_profitable = 0;
    Element *sorted_idxs = (Element *)malloc((best_pat_idx - pat_h_n_idxs[0][1][0] + 1) * sizeof(Element));
    for (int i = best_pat_idx; i >= pat_h_n_idxs[0][1][0]; i--)
    {
      double cost = ((double)best_patterns[i][pattern_upto + 1]) / (num_orders * 100);
      double reduced_cost = cost - dual_cardi[best_patterns[i][pattern_upto + 2]];
      for (int j = 1; j < best_patterns[i][0] + 1; j++)
        reduced_cost -= dual_assign[best_patterns[i][j]];
      if (reduced_cost < -1e-5)
      {
        sorted_idxs[n_profitable].index = i;
        sorted_idxs[n_profitable].cost = cost;
        sorted_idxs[n_profitable].rcost = reduced_cost;
        n_profitable += 1;
      }
    }
    qsort(sorted_idxs, n_profitable, sizeof(Element), compare);
    it_pat_max = (n_profitable < it_pat_max) ? n_profitable : it_pat_max;
    for (int idx = 0; idx < it_pat_max; idx++)
    {
      if (sorted_idxs[idx].rcost > -1e-5)
        break;
      int i = sorted_idxs[idx].index;
      double cost = sorted_idxs[idx].cost;
      x_f[num_x_f] = XPRBnewvar(prob_f, XPRB_BV, XPRBnewname("x_f_%d", num_x_f), 0, 1);
      x_idx_f[num_x_f] = i;
      XPRBaddterm(obj_f, x_f[num_x_f], cost);
      for (int j = 1; j < best_patterns[i][0] + 1; j++)
        XPRBaddterm(assign_f[best_patterns[i][j]], x_f[num_x_f], 1);
      XPRBaddterm(cardi_f[best_patterns[i][pattern_upto + 2]], x_f[num_x_f], 1);
      num_x_f++;
      num_added++;
    }
    free(sorted_idxs);

    if (num_added == 0)
    {
      XPRBdelbasis(basis_f);
      break;
    }
    XPRBloadmat(prob_f);
    XPRBloadbasis(basis_f);
    XPRBdelbasis(basis_f);
  }

  // solving final R-IP
  //// gather low reduced cost patterns at the last iteration
  Element *sorted_idxs = (Element *)malloc((best_pat_idx) * sizeof(Element));
  for (int i = 0; i < best_pat_idx; i++)
  {
    double cost = ((double)best_patterns[i][pattern_upto + 1]) / (num_orders * 100);
    double reduced_cost = cost - dual_cardi[best_patterns[i][pattern_upto + 2]];
    for (int j = 1; j < best_patterns[i][0] + 1; j++)
      reduced_cost -= dual_assign[best_patterns[i][j]];
    sorted_idxs[i].index = i;
    sorted_idxs[i].cost = cost;
    sorted_idxs[i].rcost = reduced_cost;
  }
  qsort(sorted_idxs, best_pat_idx, sizeof(Element), compare);
  for (int idx = 0; idx < ((10000 > best_pat_idx) ? best_pat_idx : 10000); idx++)
  {
    int i = sorted_idxs[idx].index;
    double cost = sorted_idxs[idx].cost;
    x_f[num_x_f] = XPRBnewvar(prob_f, XPRB_BV, XPRBnewname("x_f_%d", num_x_f), 0, 1);
    x_idx_f[num_x_f] = i;
    XPRBaddterm(obj_f, x_f[num_x_f], cost);
    for (int j = 1; j < best_patterns[i][0] + 1; j++)
      XPRBaddterm(assign_f[best_patterns[i][j]], x_f[num_x_f], 1);
    XPRBaddterm(cardi_f[best_patterns[i][pattern_upto + 2]], x_f[num_x_f], 1);
    num_x_f += 1;
  }
  free(sorted_idxs);

  //// solve
  XPRSprob opt_prob = XPRBgetXPRSprob(prob_f);
  clock_gettime(CLOCK_MONOTONIC, &finish);
  XPRSsetintcontrol(opt_prob, XPRS_MAXTIME, -((int)time_limit - (finish.tv_sec - start.tv_sec)));

#if FIRST_IP_OPTION == 1
  XPRSsetintcontrol(opt_prob, XPRS_HEURSTRATEGY_EXTENSIVE, 3);
  // XPRSsetintcontrol(opt_prob, XPRS_CUTSTRATEGY, 3);
#elif FIRST_IP_OPTION == 2
  for (int i = pat_h_n_idxs[0][1][0]; i < num_x_f; i++)
  {
    if (XPRBgetsol(x_f[i]) > FIXING_THRD)
      XPRBfixvar(x_f[i], 1);
  }
#elif FIRST_IP_OPTION == 3
  for (int i = pat_h_n_idxs[0][1][0]; i < num_x_f; i++)
  {
    if (XPRBgetsol(x_f[i]) > FIXING_THRD)
      XPRBfixvar(x_f[i], 1);
  }
  XPRSsetintcontrol(opt_prob, XPRS_HEURSTRATEGY_EXTENSIVE, 3);
  // XPRSsetintcontrol(opt_prob, XPRS_CUTSTRATEGY, 3);
#endif

  XPRBmipoptimize(prob_f, "c");
  objval_f = XPRBgetobjval(prob_f);
  printf("IP   obj %.3f   stat %d   ", objval_f, XPRBgetmipstat(prob_f));
  print_time("");

  if (XPRBgetmipstat(prob_f) != XPRB_MIP_SOLUTION && XPRBgetmipstat(prob_f) != XPRB_MIP_OPTIMAL)
  {
    XPRBdelprob(prob_f);
    return;
  }

  bool ip_obj_improved = false;
  if (objval_f < best_ip_obj - 1e-9)
  {
    ip_obj_improved = true;
    best_ip_obj = objval_f;
  }

  // post-processing
  if (ip_obj_improved)
  {
    num_x_sol = 0;
    for (int i = 0; i < num_x_f; i++)
    {
      if (XPRBgetsol(x_f[i]) > 0.5)
      {
        int idx = x_idx_f[i];
        memcpy(&(solution_2d[num_x_sol][0]), &(best_patterns[idx][0]), (pattern_upto + 3) * sizeof(int));
        num_x_sol++;
      }
    }
    get_sequenced_solution();
  }
  XPRBdelprob(prob_f);
  XPRBfree();
}


void solve_all() // IN PROGRESS : SOLVE IP using patterns from all tree
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  double final_ip_reserved = FINAL_IP_RESERVED * (time_limit - (finish.tv_sec - start.tv_sec)); 

  // setup initial restricted master problem
  XPRBprob prob_f = XPRBnewprob("RMP_final");
  XPRBvar x_f[MAX_COL_FIN];
  int x_idx_f[MAX_COL_FIN];
  XPRBctr assign_f[num_orders], cardi_f[num_riders];
  XPRBctr obj_f;

  int num_x_f = pat_h_n_idxs[0][1][0];
  XPRBbasis basis_f;
  double objval_f, dual_assign[num_orders], dual_cardi[num_riders];

  //// initial RMP with length-1 patterns
  obj_f = XPRBnewctr(prob_f, "obj", XPRB_N); // XPRB_N indicate this is for objective
  for (int i = 0; i < num_orders; i++)       // iterate over orders
  {
    assign_f[i] = XPRBnewctr(prob_f, XPRBnewname("assign_f_%d", i), XPRB_E);
    XPRBaddterm(assign_f[i], NULL, 1);
  }
  for (int i = 0; i < num_riders; i++) // iterate over riders
  {
    cardi_f[i] = XPRBnewctr(prob_f, XPRBnewname("cardi_f_%d", i), XPRB_L);
    XPRBaddterm(cardi_f[i], NULL, rider_avail_num(i));
  }
  for (int i = 0; i < pat_h_n_idxs[0][1][0]; i++) // iterate over length 1 patterns
  {
    x_f[i] = XPRBnewvar(prob_f, XPRB_BV, XPRBnewname("x_f_%d", i), 0, 1);
    x_idx_f[i] = i;
    XPRBaddterm(obj_f, x_f[i], ((double)patterns[i][pattern_upto + 1]) / (num_orders * 100));
    XPRBaddterm(assign_f[patterns[i][1]], x_f[i], 1);
    XPRBaddterm(cardi_f[patterns[i][pattern_upto + 2]], x_f[i], 1);
  }
  XPRBsetobj(prob_f, obj_f);
  XPRBsetmsglevel(prob_f, 0);

  // TODO: best incombent를 넣고 시작
  for (int i = 0; i < num_x_sol; i++)
  {
    double cost = ((double) solution_2d[i][pattern_upto + 1]) / (num_orders * 100);
    memcpy(&(patterns[i+hash_idx][0]), &(solution_2d[i][0]), (pattern_upto + 3) * sizeof(int));
    x_f[num_x_f] = XPRBnewvar(prob_f, XPRB_BV, XPRBnewname("x_f_%d", num_x_f), 0, 1);
    x_idx_f[num_x_f] = i+hash_idx;
    XPRBaddterm(obj_f, x_f[num_x_f], cost);
    for (int j = 1; j < solution_2d[i][0] + 1; j++)
      XPRBaddterm(assign_f[solution_2d[i][j]], x_f[num_x_f], 1);
    XPRBaddterm(cardi_f[solution_2d[i][pattern_upto + 2]], x_f[num_x_f], 1);
    num_x_f++;
  }

  // column generation
  int it = 0;
  while (true)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if ((finish.tv_sec - start.tv_sec) > time_limit - final_ip_reserved)
      break;

    // solving RMP
    XPRBlpoptimize(prob_f, "");
    basis_f = XPRBsavebasis(prob_f);
    objval_f = XPRBgetobjval(prob_f);
    for (int i = 0; i < num_orders; i++)
      dual_assign[i] = XPRBgetdual(assign_f[i]);
    for (int i = 0; i < num_riders; i++)
      dual_cardi[i] = XPRBgetdual(cardi_f[i]);

    // check profitable columns
    int num_added = 0;

    // final version
    int it_pat_max = (it < EARLY_ITER) ? IT_PAT_MAX_EARLY : IT_PAT_MAX;
    int n_profitable = 0;
    Element *sorted_idxs = (Element *)malloc((hash_idx - pat_idx + 1) * sizeof(Element));
    for (int i = hash_idx-1; i >= pat_idx; i--)  // TODO: hash_idx-1 이 맞지 않을까?
    {
      double cost = ((double)patterns[i][pattern_upto + 1]) / (num_orders * 100);
      double reduced_cost = cost - dual_cardi[patterns[i][pattern_upto + 2]];
      for (int j = 1; j < patterns[i][0] + 1; j++)
        reduced_cost -= dual_assign[patterns[i][j]];
      if (reduced_cost < -1e-5)
      {
        sorted_idxs[n_profitable].index = i;
        sorted_idxs[n_profitable].cost = cost;
        sorted_idxs[n_profitable].rcost = reduced_cost;
        n_profitable += 1;
      }
    }
    qsort(sorted_idxs, n_profitable, sizeof(Element), compare);
    it_pat_max = (n_profitable < it_pat_max) ? n_profitable : it_pat_max;
    for (int idx = 0; idx < it_pat_max; idx++)
    {
      if (sorted_idxs[idx].rcost > -1e-5)
        break;
      int i = sorted_idxs[idx].index;
      double cost = sorted_idxs[idx].cost;
      x_f[num_x_f] = XPRBnewvar(prob_f, XPRB_BV, XPRBnewname("x_f_%d", num_x_f), 0, 1);
      x_idx_f[num_x_f] = i;
      XPRBaddterm(obj_f, x_f[num_x_f], cost);
      for (int j = 1; j < patterns[i][0] + 1; j++)
        XPRBaddterm(assign_f[patterns[i][j]], x_f[num_x_f], 1);
      XPRBaddterm(cardi_f[patterns[i][pattern_upto + 2]], x_f[num_x_f], 1);
      num_x_f++;
      num_added++;
    }
    free(sorted_idxs);

    if (num_added == 0)
    {
      XPRBdelbasis(basis_f);
      break;
    }
    XPRBloadmat(prob_f);
    XPRBloadbasis(basis_f);
    XPRBdelbasis(basis_f);
  }

  // solving final R-IP
  //// gather low reduced cost patterns at the last iteration

  clock_gettime(CLOCK_MONOTONIC, &finish);
  if ((finish.tv_sec - start.tv_sec) < time_limit - final_ip_reserved)
  {
    Element *sorted_idxs = (Element *)malloc((hash_idx) * sizeof(Element)); // TODO: 전체 패턴에서 넣는게 목적이면 hash_idx, tree 중에서만 하면 아래 for문에서 수정 필요
    for (int i = 0; i <hash_idx; i++)
    {
      double cost = ((double)patterns[i][pattern_upto + 1]) / (num_orders * 100);
      double reduced_cost = cost - dual_cardi[patterns[i][pattern_upto + 2]];
      for (int j = 1; j < patterns[i][0] + 1; j++) //TODO: best_patterns
        reduced_cost -= dual_assign[patterns[i][j]];
      sorted_idxs[i].index = i;
      sorted_idxs[i].cost = cost;
      sorted_idxs[i].rcost = reduced_cost;
    }
    qsort(sorted_idxs, hash_idx, sizeof(Element), compare); // TODO: 위에 맞추어 수정
    for (int idx = 0; idx < ((10000 > hash_idx) ? hash_idx : 10000); idx++)  // TODO: 위에 맞추어 수정
    {
      // if (sorted_idxs[idx].rcost > 1 -1e-5) // 마지막이니까 reduced cost 넉넉하게..
      //   break; // TODO: 이거 넣을까?
      int i = sorted_idxs[idx].index;
      double cost = sorted_idxs[idx].cost;
      x_f[num_x_f] = XPRBnewvar(prob_f, XPRB_BV, XPRBnewname("x_f_%d", num_x_f), 0, 1);
      x_idx_f[num_x_f] = i;
      XPRBaddterm(obj_f, x_f[num_x_f], cost);
      for (int j = 1; j < patterns[i][0] + 1; j++) 
        XPRBaddterm(assign_f[patterns[i][j]], x_f[num_x_f], 1);
      XPRBaddterm(cardi_f[patterns[i][pattern_upto + 2]], x_f[num_x_f], 1);
      num_x_f += 1;
    }
    free(sorted_idxs);
  }

  // TODO: set best incumbent sol as solver incumbent sol
  XPRBsol sol = XPRBnewsol(prob_f);
  for (int i = 0; i < num_x_sol; i++)
  {
    int sol_idx = pat_h_n_idxs[0][1][0] + i;
    XPRBsetsolvar(sol, x_f[sol_idx], 1);
  }
  XPRBaddmipsol(prob_f, sol, "incumbent");

  //// solve
  XPRSprob opt_prob = XPRBgetXPRSprob(prob_f);
  clock_gettime(CLOCK_MONOTONIC, &finish);
  XPRSsetintcontrol(opt_prob, XPRS_MAXTIME, -((int)time_limit - (finish.tv_sec - start.tv_sec))); // TODO: 끝나고 다시 while 할거면 여기 조정 필요할듯!

#if FIRST_IP_OPTION == 1
  XPRSsetintcontrol(opt_prob, XPRS_HEURSTRATEGY_EXTENSIVE, 3);
  // XPRSsetintcontrol(opt_prob, XPRS_CUTSTRATEGY, 3);
#elif FIRST_IP_OPTION == 2
  // for (int i = pat_h_n_idxs[0][1][0]; i < num_x_f; i++)
  // {
  //   if (XPRBgetsol(x_f[i]) > FIXING_THRD)
  //     XPRBfixvar(x_f[i], 1);
  // } // TODO: fixing might interfere with the incumbent solution
#elif FIRST_IP_OPTION == 3
  // for (int i = pat_h_n_idxs[0][1][0]; i < num_x_f; i++)
  // {
  //   if (XPRBgetsol(x_f[i]) > FIXING_THRD)
  //     XPRBfixvar(x_f[i], 1);
  // }
  XPRSsetintcontrol(opt_prob, XPRS_HEURSTRATEGY_EXTENSIVE, 3);
  // XPRSsetintcontrol(opt_prob, XPRS_CUTSTRATEGY, 3);
#endif

  printf("ALL-IP   setup done   ");
  print_time("");
  XPRBmipoptimize(prob_f, "c");
  objval_f = XPRBgetobjval(prob_f);
  printf("ALL-IP   obj %.3f   stat %d   ", objval_f, XPRBgetmipstat(prob_f));
  print_time("");

  if (XPRBgetmipstat(prob_f) != XPRB_MIP_SOLUTION && XPRBgetmipstat(prob_f) != XPRB_MIP_OPTIMAL)
  {
    XPRBdelprob(prob_f);
    return;
  }

  bool ip_obj_improved = false;
  if (objval_f < best_ip_obj - 1e-9)
  {
    ip_obj_improved = true;
    best_ip_obj = objval_f;
  }

  // post-processing
  if (ip_obj_improved)
  {
    num_x_sol = 0;
    for (int i = 0; i < num_x_f; i++)
    {
      if (XPRBgetsol(x_f[i]) > 0.5)
      {
        int idx = x_idx_f[i];
        memcpy(&(solution_2d[num_x_sol][0]), &(patterns[idx][0]), (pattern_upto + 3) * sizeof(int)); // TODO: best_patterns가 아니라 patterns 아닌가? 뭔가 큰일 날것 같이 생겼는데.. 
        num_x_sol++;
      }
    }
    get_sequenced_solution();
  }
  XPRBdelsol(sol);
  XPRBdelprob(prob_f);
  XPRBfree();
}

int num_x;

double *getdual_first(XPRBprob *prob, XPRBvar *x, int *x_idx, XPRBctr *assign, XPRBctr *cardi, XPRBctr *obj, XPRBbasis *basis)
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  double *dual = (double *)malloc((num_orders + num_riders) * sizeof(double)); 

  //// initial RMP with length-1 patterns
  *obj = XPRBnewctr(*prob, "obj", XPRB_N); // XPRB_N indicate this is for objective

  for (int i = 0; i < num_orders; i++) // iterate over orders
  {
    assign[i] = XPRBnewctr(*prob, XPRBnewname("assign_%d", i), XPRB_E);
    XPRBaddterm(assign[i], NULL, 1);
  }
  for (int i = 0; i < num_riders; i++) // iterate over riders
  {
    cardi[i] = XPRBnewctr(*prob, XPRBnewname("cardi_%d", i), XPRB_L);
    XPRBaddterm(cardi[i], NULL, rider_avail_num(i));
  }

  for (int i = 0; i < pat_h_n_idxs[2][0][1]; i++) // iterate over length 1 order
  {
    x[i] = XPRBnewvar(*prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    x_idx[i] = i;
    XPRBaddterm(*obj, x[i], ((double)patterns[i][pattern_upto + 1]) / (num_orders * 100));
    XPRBaddterm(assign[patterns[i][1]], x[i], 1);
    XPRBaddterm(cardi[patterns[i][pattern_upto + 2]], x[i], 1);
  }
  num_x = pat_h_n_idxs[2][0][1];

  XPRBsetobj(*prob, *obj);
  XPRBsetmsglevel(*prob, 0);

  int it = 0;
  while (true)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if (time_limit_exceeded_init())
      break;

    // solving RMP
    XPRBlpoptimize(*prob, "");
    *basis = XPRBsavebasis(*prob);
    for (int i = 0; i < num_orders; i++)
      dual[i] = XPRBgetdual(assign[i]);
    for (int i = 0; i < num_riders; i++)
      dual[num_orders + i] = XPRBgetdual(cardi[i]);

    // check profitable columns
    int num_added = 0;

    // final version
    int it_pat_max = (it < EARLY_ITER) ? IT_PAT_MAX_EARLY : IT_PAT_MAX;
    int n_profitable = 0;

    Element *sorted_idxs = (Element *)malloc((pat_idx - pat_h_n_idxs[0][1][0] + 1) * sizeof(Element));
    for (int i = pat_idx; i >= pat_h_n_idxs[0][1][0]; i--)
    {
      double cost = ((double)patterns[i][pattern_upto + 1]) / (num_orders * 100);
      double reduced_cost = cost - dual[num_orders + patterns[i][pattern_upto + 2]];
      for (int j = 1; j < patterns[i][0] + 1; j++)
        reduced_cost -= dual[patterns[i][j]];
      if (reduced_cost < -1e-5)
      {
        sorted_idxs[n_profitable].index = i;
        sorted_idxs[n_profitable].cost = cost;
        sorted_idxs[n_profitable].rcost = reduced_cost;
        n_profitable += 1;
      }
    }

    qsort(sorted_idxs, n_profitable, sizeof(Element), compare);
    it_pat_max = (n_profitable < it_pat_max) ? n_profitable : it_pat_max;
    for (int idx = 0; idx < it_pat_max; idx++)
    {
      if (sorted_idxs[idx].rcost > -1e-5)
        break;
      int i = sorted_idxs[idx].index;
      double cost = sorted_idxs[idx].cost;
      x[num_x] = XPRBnewvar(*prob, XPRB_BV, XPRBnewname("x_f_%d", num_x), 0, 1);
      x_idx[num_x] = i;
      XPRBaddterm(*obj, x[num_x], cost);
      for (int j = 1; j < patterns[i][0] + 1; j++)
        XPRBaddterm(assign[patterns[i][j]], x[num_x], 1);
      XPRBaddterm(cardi[patterns[i][pattern_upto + 2]], x[num_x], 1);
      num_x += 1;
      num_added += 1;
    }
    free(sorted_idxs);

    if (num_added == 0)
    {
      XPRBdelbasis(*basis);
      break;
    }
    XPRBloadmat(*prob);
    XPRBloadbasis(*basis);
    XPRBdelbasis(*basis);
  }
  XPRBlpoptimize(*prob, "");

  for (int i = 0; i < num_orders; i++)
    dual[i] = XPRBgetdual(assign[i]);
  for (int i = 0; i < num_riders; i++)
    dual[num_orders + i] = XPRBgetdual(cardi[i]);
  
  return dual;
}

int pattern_enum_n(int n, int max_element, double *duals)
{
  int num_added = 0;
  for (int h = 0; h < num_riders; h++)
  {
    pat_h_n_idxs[h][n - 1][0] = pat_idx;

    for (int i = 0; i < NUM_THREADS; i++)
    {
      struct th_data_n *data = (struct th_data_n *)malloc(sizeof(struct th_data_n));
      data->th_id = i;
      data->n = n;
      data->h = h;
      data->idx_from = pat_h_n_idxs[h][n - 2][0];
      data->idx_to = pat_h_n_idxs[h][n - 2][1];
      data->p_pat_idx = &(p_pat_idxs[i]);
      data->duals = duals;
      int stat = pthread_create(&pthread[i], NULL, p_enum_n, (void *)data);
      if (stat != 0)
      {
        printf("pthread_create error\n");
        fflush(stdout);
      }
    }

    for (int i = 0; i < NUM_THREADS; i++)
      pthread_join(pthread[i], NULL);

    for (int i = 0; i < NUM_THREADS; i++)
    {
      memcpy(&(patterns[pat_idx][0]), &(th_patterns[i][0][0]), p_pat_idxs[i] * (pattern_upto + 3) * sizeof(int));
      pat_idx += p_pat_idxs[i];
    }
    pat_h_n_idxs[h][n - 1][1] = pat_idx;
    if (n == 2)
    {
      for (int idx = pat_h_n_idxs[h][n - 1][0]; idx < pat_h_n_idxs[h][n - 1][1]; idx++)
        compat[h][patterns[idx][1]][patterns[idx][2]] = true;
    }

    printf("    n %d  h %d  : %8d", n, h, pat_h_n_idxs[h][n - 1][1] - pat_h_n_idxs[h][n - 1][0]);
    print_time("");
    if (pat_idx == max_element)
      break;
  }

  num_added = pat_h_n_idxs[2][n - 1][1] - pat_h_n_idxs[0][n - 1][0];
  return num_added;
}

// add patterns of order n and get dual
double *getdual_from(int n, XPRBprob *prob, XPRBvar *x, int *x_idx, XPRBctr *assign, XPRBctr *cardi, XPRBctr *obj, XPRBbasis *basis) 
{

  double *dual = (double *)malloc((num_orders + num_riders) * sizeof(double));
  double objval;
  double *costs = (double *)malloc(pat_idx * sizeof(double));
  for (int i = 0; i < pat_idx; i++)
    costs[i] = ((double)patterns[i][pattern_upto + 1]) / (num_orders * 100);
  

  int it = 0;
  int num_obj_not_improved = 0;
  int best_obj_cg = 1e9;
  Element *sorted_idxs_n = (Element *)malloc((pat_idx) * sizeof(Element));
  while (true)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if (time_limit_exceeded_init())
      break;

    // solving RMP
    XPRBlpoptimize(*prob, "");
    *basis = XPRBsavebasis(*prob);
    objval = XPRBgetobjval(*prob);
    for (int i = 0; i < num_orders; i++)
      dual[i] = XPRBgetdual(assign[i]);
    for (int i = 0; i < num_riders; i++)
      dual[num_orders + i] = XPRBgetdual(cardi[i]);

    if (objval < best_obj_cg - 1e-9) // objval improved by cg
    {
      best_obj_cg = objval; // objval not improved
    }
    else
    {
      num_obj_not_improved++;
    }

    fflush(stdout);

    if (num_obj_not_improved > THRESHOLD_DUAL)
      break;

    // check profitable columns
    int num_added = 0;
    int it_pat_max = (it < EARLY_ITER) ? IT_PAT_MAX_EARLY_ENUM : IT_PAT_MAX;
    int n_profitable = 0;

    for (int i = pat_idx; i >= pat_h_n_idxs[0][1][0]; i--)
    {
      double reduced_cost = costs[i] - dual[num_orders + patterns[i][pattern_upto + 2]];

      for (int j = 1; j < patterns[i][0] + 1; j++)
        reduced_cost -= dual[patterns[i][j]];

      if (reduced_cost < -1e-5)
      {
        sorted_idxs_n[n_profitable].index = i;
        sorted_idxs_n[n_profitable].rcost = reduced_cost;
        n_profitable += 1;
      }
    }

    qsort(sorted_idxs_n, n_profitable, sizeof(Element), compare);
    it_pat_max = (n_profitable < it_pat_max) ? n_profitable : it_pat_max;
    for (int idx = 0; idx < it_pat_max; idx++)
    {
      if (sorted_idxs_n[idx].rcost > -1e-5)
        break;
      int i = sorted_idxs_n[idx].index;
      x[num_x] = XPRBnewvar(*prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
      x_idx[num_x] = i;
      XPRBaddterm(*obj, x[num_x], costs[i]);
      for (int j = 1; j < patterns[i][0] + 1; j++)
        XPRBaddterm(assign[patterns[i][j]], x[num_x], 1);
      XPRBaddterm(cardi[patterns[i][pattern_upto + 2]], x[num_x], 1);
      num_x += 1;
      num_added += 1;
    }

    if (num_added == 0)
    {
      XPRBdelbasis(*basis);
      break;
    }
    XPRBloadmat(*prob);
    XPRBloadbasis(*basis);
    XPRBdelbasis(*basis);
  }

  for (int i = 0; i < pat_idx; i++)
  {
    double reduced_cost = costs[i] - dual[num_orders + patterns[i][pattern_upto + 2]];
    for (int j = 1; j < patterns[i][0] + 1; j++)
      reduced_cost -= dual[patterns[i][j]];
    sorted_idxs_n[i].index = i;
    sorted_idxs_n[i].rcost = reduced_cost;
  }

  qsort(sorted_idxs_n, pat_idx, sizeof(Element), compare);

  for (int idx = 0; idx < NUM_DUAL_CG_COLS; idx++)
  {
    int i = sorted_idxs_n[idx].index;
    x[num_x] = XPRBnewvar(*prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
    x_idx[num_x] = i;
    XPRBaddterm(*obj, x[num_x], costs[i]);
    for (int j = 1; j < patterns[i][0] + 1; j++)
      XPRBaddterm(assign[patterns[i][j]], x[num_x], 1);
    XPRBaddterm(cardi[patterns[i][pattern_upto + 2]], x[num_x], 1);
    num_x += 1;
  }

  for (int i = 0; i < pat_h_n_idxs[0][1][0]; i++) // iterate over length 1 patterns
  {
    x[num_x + i] = XPRBnewvar(*prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    x_idx[num_x + i] = num_x + i;
    XPRBaddterm(*obj, x[num_x + i], costs[num_x + i]);
    XPRBaddterm(assign[patterns[num_x + i][1]], x[num_x + i], 1);
    XPRBaddterm(cardi[patterns[num_x + i][pattern_upto + 2]], x[num_x + i], 1);
  }

  free(sorted_idxs_n);

  return dual;
}

void dual_pattern_enum(int max_element, int from_n, int to_n)
{
  // printf("\n dual_pattern_enum is called"); fflush(stdout);
  XPRBprob prob = XPRBnewprob("RMP_for_2");
  XPRBvar x[MAX_COL];
  XPRBctr assign[num_orders], cardi[num_riders];
  XPRBctr obj;
  XPRBbasis basis;
  int x_idx[MAX_COL];
  double *dual = getdual_first(&prob, x, x_idx, assign, cardi, &obj, &basis);
  double objval;
  int num = 0;
  printf("[log] after getdual_first");
  print_time("");

  for (int n = from_n; n < to_n + 1; n++)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if (time_limit_exceeded_init())
      break;

    num = pattern_enum_n(n, max_element, dual);
    free(dual);
    if (num == 0)
      break;
    
    dual = getdual_from(n, &prob, x, x_idx, assign, cardi, &obj, &basis);
    printf("    ----\n");
    printf("[log] get_dual_from_n %d", n);
    print_time("");
  }

  //// solve
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  XPRSprob opt_prob = XPRBgetXPRSprob(prob);
  clock_gettime(CLOCK_MONOTONIC, &finish);
  XPRSsetintcontrol(opt_prob, XPRS_MAXTIME, -(time_limit * ENUM_IP_TIME));
  XPRBmipoptimize(prob, "c");
  objval = XPRBgetobjval(prob);
  printf("IP   obj %.3f   stat %d   ", objval, XPRBgetmipstat(prob));
  print_time("");

  if (objval < best_obj - 1e-9)
    best_obj = objval;
  if (objval < best_ip_obj - 1e-9)
    best_ip_obj = objval;

  // post-processing
  solution = (int *)calloc(num_orders * (pattern_upto + 3), sizeof(int));
  solution_2d = (int **)calloc(num_orders, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
  for (int i = 0; i < num_orders; i++)
  {
    solution_2d[i] = solution + i * (pattern_upto + 3);
  }

  num_dual_sol = 0;

  for (int i = 0; i < num_x; i++)
  {
    if (XPRBgetsol(x[i]) > 1e-3)
    {
      dual_sol_idx[num_dual_sol] = x_idx[i];
      memcpy(&(solution_2d[num_dual_sol][0]), &(patterns[x_idx[i]][0]), (pattern_upto + 3) * sizeof(int));
      num_dual_sol += 1;
    }
  }

  num_x_sol = num_dual_sol;
  get_sequenced_solution();

  XPRBdelprob(prob);
  XPRBfree();
  return;
}

int *get_best_sequence(int *pattern, int *min_dist, int h)
{
  int n = pattern[0];
  int *perm, *d_perm, *p_perm;
  int *sequence = (int *)malloc((n * 2) * sizeof(int));
  int *pickup_dists = malloc(factorial[n] * sizeof(int));
  int *pickup_times = malloc(factorial[n] * sizeof(int));
  int *delivery_dists = malloc(factorial[n] * sizeof(int));
  int *delivery_times = malloc(factorial[n] * sizeof(int));
  int *sorted_idxs_p = (int *)calloc(factorial[n], sizeof(int));
  int *sorted_idxs_d = (int *)calloc(factorial[n], sizeof(int));
  int *base_seq = malloc(n * sizeof(int));
  int min_last_pickup_time = INF;
  int min_deadline = order_deadline(pattern[1]);
  int min_deadline_order = pattern[1];

  for (int i = 1; i < pattern[0]; i++)
  {
    min_deadline = (order_deadline(pattern[i + 1]) < min_deadline) ? order_deadline(pattern[i + 1]) : min_deadline;
    if (min_deadline == order_deadline(pattern[i + 1]))
      min_deadline_order = pattern[i + 1];
  }
 
  for (int i = 0; i < n; i++)
    base_seq[i] = pattern[i + 1];

  //// pickup sequence calculation
  int front = 0;
  int end = factorial[n] - 1;
  for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
  {
    perm = get_nth_permutation_of_size(seq_idx, n);
    pickup_dists[seq_idx] = 0;
    pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);
    if (pickup_times[seq_idx] > min_deadline)
    {
      sorted_idxs_p[end--] = seq_idx;
      pickup_dists[seq_idx] = 1e9;
      continue;
    }

    for (int i = 1; i < n; i++)
    {
      pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
      pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
      if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
      {
        pickup_dists[seq_idx] = 1e9;
        break;
      }
      pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
    }
    if (pickup_dists[seq_idx] >= 1e9)
    {
      sorted_idxs_p[end--] = seq_idx;
      continue;
    }
    int idx = 0;
    for (; idx < front; idx++)
    {
      if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
        break;
    }
    memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
    sorted_idxs_p[idx] = seq_idx;
    front += 1;
    min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
  }

  if (min_last_pickup_time >= 1e9)
  {
    free(pickup_dists);
    free(pickup_times);
    free(delivery_dists);
    free(delivery_times);
    free(base_seq);
    free(sorted_idxs_p);
    free(sorted_idxs_d);
    return NULL;
  }

  //// delivery sequence calculation
  front = 0;
  end = factorial[n] - 1;
  for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
  {
    perm = get_nth_permutation_of_size(seq_idx, n);
    delivery_dists[seq_idx] = 0;
    delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);
    if (delivery_times[seq_idx] < min_last_pickup_time)
    {
      delivery_dists[seq_idx] = 1e9;
      sorted_idxs_d[end--] = seq_idx;
      continue;
    }
    for (int i = n - 1; i > 0; i--)
    {
      delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
      delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
      if (delivery_times[seq_idx] < min_last_pickup_time)
      {
        delivery_dists[seq_idx] = 1e9;
        break;
      }
      delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
    }
    if (delivery_dists[seq_idx] >= 1e9)
    {
      sorted_idxs_d[end--] = seq_idx;
      continue;
    }
    int idx = 0;
    for (; idx < front; idx++)
    {
      if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
        break;
    }
    memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
    sorted_idxs_d[idx] = seq_idx;
    front += 1;
  }


  //// Find best combination
  int min_dist_ = 1e9;
  int p_idx, d_idx;
  int best_p_idx, best_d_idx;
  for (int i = 0; i < factorial[n]; i++)
  {
    p_idx = sorted_idxs_p[i];
    if (pickup_dists[p_idx] >= 1e9)
      break;

    p_perm = get_nth_permutation_of_size(p_idx, n);
    for (int j = 0; j < factorial[n]; j++)
    {
      d_idx = sorted_idxs_d[j];
      if (delivery_dists[d_idx] >= 1e9)
        break;
      if (pickup_dists[p_idx] + delivery_dists[d_idx] > min_dist_)
        continue;
      
      d_perm = get_nth_permutation_of_size(d_idx, n);
      if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[n - 1]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[n - 1]], base_seq[d_perm[0]] + num_orders) < min_dist_))
      {
        min_dist_ = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[n - 1]], base_seq[d_perm[0]] + num_orders);
        best_p_idx = p_idx;
        best_d_idx = d_idx;
      }
    }
  }

  if (min_dist_ >= 1e9)
  {
    free(pickup_dists);
    free(pickup_times);
    free(delivery_dists);
    free(delivery_times);
    free(base_seq);
    free(sorted_idxs_p);
    free(sorted_idxs_d);
    return NULL;
  }

  p_perm = get_nth_permutation_of_size(best_p_idx, n);
  d_perm = get_nth_permutation_of_size(best_d_idx, n);
  for (int i = 0; i < n; i++)
  {
    sequence[i] = base_seq[p_perm[i]];
    sequence[i + n] = base_seq[d_perm[i]];
  }

  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  free(sorted_idxs_p);
  free(sorted_idxs_d);

  *min_dist = min_dist_;
  return sequence;
}

void get_sequenced_solution()
{
  if (seq_solution == NULL)
  {
    seq_solution = (int *)calloc(num_orders * (2 * pattern_upto + 3), sizeof(int));
    seq_solution_2d = (int **)calloc(num_orders, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
    for (int i = 0; i < num_orders; i++)
      seq_solution_2d[i] = seq_solution + i * (2 * pattern_upto + 3);
  }

  for (int i = 0; i < num_x_sol; i++)
  {
    int temp;
    int *sequence = get_best_sequence(solution_2d[i], &temp, solution_2d[i][pattern_upto + 2]);

    if (sequence != NULL)
    {
      memcpy(seq_solution_2d[i] + 1, sequence, 2 * solution_2d[i][0] * sizeof(int));
      seq_solution_2d[i][0] = solution_2d[i][0];
      seq_solution_2d[i][2 * pattern_upto + 1] = solution_2d[i][pattern_upto + 1];
      seq_solution_2d[i][2 * pattern_upto + 2] = solution_2d[i][pattern_upto + 2];
    }
    else
    {
      printf("Error in getting sequence\n");
    }
  }
}

int **tree_improve_first(int **skeleton, int change_rcost)
{

  Tree *new_tree = create_tree(num_orders);
  double *dual = solve_tree();
  int new_num_edges_in_tree = 0;
  int **new_skeleton;
  new_skeleton = (int **)malloc(num_orders * sizeof(int *));
  for (int i = 0; i < num_orders; i++)
  {
    new_skeleton[i] = (int *)malloc(2 * sizeof(int));
  }

  // keep edges used for optimal subtrees
  for (int i = 0; i < num_tree_sol; i++)
  {
    if (tree_patterns[tree_sol_idx[i]][0] == 1) // pass using 1 orders
      continue;

    int u, v, num_edges_this_sol = 0;

    for (int n = 2; n < tree_patterns[tree_sol_idx[i]][0] + 1; n++)
    {
      v = tree_patterns[tree_sol_idx[i]][n];
      for (int idx = 0; idx < num_edges_in_tree; idx++)
      {
        if ((v == skeleton[idx][0]) || (v == skeleton[idx][1]))
        {
          for (int j = 1; j < n; j++)
          {
            u = tree_patterns[tree_sol_idx[i]][j]; // candidate order id
            if ((u == skeleton[idx][0]) || (u == skeleton[idx][1]))
            {

              if (add_edge(new_tree, u, v))
              {
                new_skeleton[new_num_edges_in_tree][0] = u;
                new_skeleton[new_num_edges_in_tree][1] = v;
                new_num_edges_in_tree++;
              }

              num_edges_this_sol += 1;
            }
          }
          if (num_edges_this_sol >= tree_patterns[tree_sol_idx[i]][0] - 1)
            break;
        }
      }
      if (num_edges_this_sol >= tree_patterns[tree_sol_idx[i]][0] - 1)
        break;
    }
  }

  int n_profitable = 0;
  Element *sorted_idxs = (Element *)malloc((pat_idx - pat_h_n_idxs[0][1][0] + 1) * sizeof(Element));
  for (int i = pat_h_n_idxs[0][1][0]; i < pat_h_n_idxs[2][1][1]; i++)
  {
    double cost = ((double)patterns[i][pattern_upto + 1]) / (num_orders * 100);
    double reduced_cost = cost - dual[num_orders + patterns[i][pattern_upto + 2]];
    for (int j = 1; j < patterns[i][0] + 1; j++)
      reduced_cost -= dual[patterns[i][j]];
    if (reduced_cost < -1e-5)
    {
      sorted_idxs[n_profitable].index = i;
      sorted_idxs[n_profitable].cost = cost;
      sorted_idxs[n_profitable].rcost = reduced_cost;
      n_profitable += 1;
    }
  }

  bool if_add_edge = true;
  if (n_profitable > 0)
  {
    qsort(sorted_idxs, n_profitable, sizeof(Element), compare);
    for (int idx = 0; idx < (change_rcost < n_profitable ? change_rcost: n_profitable); idx++)
    {
      int i = sorted_idxs[idx].index;
      int u = patterns[i][1];
      int v = patterns[i][2];
      if (add_edge(new_tree, u, v))
      {
        new_skeleton[new_num_edges_in_tree][0] = u;
        new_skeleton[new_num_edges_in_tree][1] = v;
        new_num_edges_in_tree++;
      }

      if (new_num_edges_in_tree == num_orders - 1)
      {
        if_add_edge = false;
        break;
      }
    }
  }
  
  ////// add edges via deadline slack
  for (int i = 0; if_add_edge && i < pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]; i++)
  {
    int idx = idxs_sorted_by_deadline_slack[i];
    if (add_edge(new_tree, patterns[idx][1], patterns[idx][2]))
    {
      new_skeleton[new_num_edges_in_tree][0] = patterns[idx][1]; // TODO: new_ 붙임
      new_skeleton[new_num_edges_in_tree][1] = patterns[idx][2];
      new_num_edges_in_tree++;
    }

    if (new_num_edges_in_tree == num_orders - 1)
    {
      if_add_edge = false;
      break;
    }
  }


  num_edges_in_tree = new_num_edges_in_tree;
  for (int i = 0; i < num_orders; i++)
    free(skeleton[i]);
  free(skeleton);

  return new_skeleton;
}

void tree_enum(int **skeleton)
{

  // Create tree
  struct hashmap *map = hashmap_new(sizeof(struct pattern), 0, 0, 0,
                                    pattern_hash, pattern_compare, pattern_free, NULL);
  tree = create_tree(num_orders);
  for (int idx = 0; idx < num_edges_in_tree; idx++)
    add_edge(tree, skeleton[idx][0], skeleton[idx][1]);
  

  tree_pat_idx = tree_pat_h_n_idxs[2][0][1];
  char *temp_id;
  int *temp_pat;
  int *temp_new_pat = malloc((pattern_upto + 3) * sizeof(int));

  // pattern for order 2, using only skeleton
  for (int h = 0; h < num_riders; h++)
  {

    tree_pat_h_n_idxs[h][1][0] = tree_pat_idx;
    for (int idx = 0; idx < num_edges_in_tree; idx++)
    {
      // if (time_limit_exceeded())
      //   break; // 여기서 걸리면 tree_patterns 수정하다가 중간에 멈춤

      int result = get_min_cost_route_enum(skeleton[idx], 2, h);

      temp_new_pat[0] = 2;
      temp_new_pat[1] = skeleton[idx][0];
      temp_new_pat[2] = skeleton[idx][1];
      temp_new_pat[pattern_upto + 1] = result;
      temp_new_pat[pattern_upto + 2] = h;

      if (result != -1)
      {

        memcpy(tree_patterns[tree_pat_idx], temp_new_pat, (pattern_upto + 3) * sizeof(int));
        struct pattern *p = create_pattern(temp_new_pat, 1);
        hashmap_set(map, (void *)p);
        free(p);
        tree_pat_idx++;
      }
      else
      {
        struct pattern *p = create_pattern(temp_new_pat, -1);
        hashmap_set(map, (void *)p);
        free(p);
      }
    }
    tree_pat_h_n_idxs[h][1][1] = tree_pat_idx;
    fflush(stdout);
  }

  // pattern enum for n >= 3 using tree
  for (int n = 3; n <= pattern_upto; n++)
  {
    // clock_gettime(CLOCK_MONOTONIC, &finish);
    // if (time_limit_exceeded())
    //   break;
    for (int h = 0; h < num_riders; h++)
    {
      // clock_gettime(CLOCK_MONOTONIC, &finish);
      // if (time_limit_exceeded())
      //   break;

      tree_pat_h_n_idxs[h][n - 1][0] = tree_pat_idx;

      for (int i = tree_pat_h_n_idxs[h][n - 2][0]; i < tree_pat_h_n_idxs[h][n - 2][1]; i++)
      {
        // clock_gettime(CLOCK_MONOTONIC, &finish);
        // if (time_limit_exceeded())
        //   break;

        temp_pat = tree_patterns[i]; // pattern to extend

        memcpy(temp_new_pat, temp_pat, (pattern_upto + 3) * sizeof(int));

        temp_new_pat[0]++;

        for (int j = 1; j < temp_pat[0] + 1; j++)
        {
          // clock_gettime(CLOCK_MONOTONIC, &finish);
          // if (time_limit_exceeded())
          //   break;

          int tg = temp_pat[j];
          adj_list_node *neighbor = tree->adj_list[tg];

          while (neighbor)
          {
            bool checker = false;
            for (int k = 1; k < temp_pat[0] + 1; k++)
            {
              if (temp_pat[k] == neighbor->id)
              {
                checker = true;
                break;
              }
            }

            if (checker)
            {
              neighbor = neighbor->next;
              continue;
            }

            // start checking temp_new_pat(= temp_pat + neighbor->id) is feasible
            temp_new_pat[temp_new_pat[0]] = neighbor->id;
            temp_id = get_id(temp_new_pat);
            if (!hashmap_get(pat_map, &(struct pattern){.id = temp_id}))
            {
              int ords[temp_new_pat[0]];
              for (int nn = 0; nn < temp_new_pat[0]; nn++)
                ords[nn] = temp_new_pat[nn + 1];

              int result = get_min_cost_route_enum(ords, n, h);
              if (result == -1) // infsb
              {
                struct pattern *p = create_pattern(temp_new_pat, -1);
                hashmap_set(map, (void *)p);
                free(p);
                p = create_pattern(temp_new_pat, -1);
                hashmap_set(pat_map, (void *)p);
                free(p);
              }
              else
              {
                temp_new_pat[pattern_upto + 1] = result;
                memcpy(tree_patterns[tree_pat_idx], temp_new_pat, (pattern_upto + 3) * sizeof(int));
                memcpy(&patterns[hash_idx][0], &temp_new_pat[0], (pattern_upto + 3) * sizeof(int));

                struct pattern *p = create_pattern(temp_new_pat, 1);
                hashmap_set(map, (void *)p);
                free(p);

                p = create_pattern(temp_new_pat, hash_idx);
                hashmap_set(pat_map, (void *)p);
                free(p);

                tree_pat_idx++;
                hash_idx++;
              }
            }
            else if (!hashmap_get(map, &(struct pattern){.id = temp_id}))
            {
              struct pattern *temp = (struct pattern *)hashmap_get(pat_map, &(struct pattern){.id = temp_id});
              struct pattern *p = malloc(sizeof(struct pattern));
              p->id = malloc((5 * n + 2) * sizeof(char));
              strcpy(p->id, temp->id);
              hashmap_set(map, (void *)p);
              free(p);

              if (temp->idx >= 0)
              {
                memcpy(tree_patterns[tree_pat_idx], patterns[temp->idx], (pattern_upto + 3) * sizeof(int));
                tree_pat_idx += 1;
              }
            }

            free(temp_id);
            temp_id = NULL;
            neighbor = neighbor->next;
          }
        }
      }
      tree_pat_h_n_idxs[h][n - 1][1] = tree_pat_idx;
      fflush(stdout);
    }

    int made_num = tree_pat_h_n_idxs[2][n - 1][1] - tree_pat_h_n_idxs[0][n - 1][0];
    if (made_num == 0)
      break;
  }
  free_tree(tree);
  hashmap_free(map);

  return;
}

int **loop_tree_improve_first(int iter_num, int threshold, int **skeleton, int change_rcost)
{
  first_not_improved = 0;

  for (int tree_it = 0; (tree_it < iter_num) && (first_not_improved < threshold); tree_it++)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if (time_limit_exceeded())
      break;

    tree_enum(skeleton);
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if (time_limit_exceeded())
      break;
    printf("Solve tree: it = %d  : ", tree_it);
    skeleton = tree_improve_first(skeleton, change_rcost);
  }
  return skeleton;
}

bool check_capa_feasibility(int *pattern)
{
  int n = pattern[0];
  int h = pattern[pattern_upto + 2];

  int capa = 0;
  for (int i = 1; i <= n; i++)
  {
    capa += order_volume(pattern[i]);
  }
  return (capa <= rider_capa(h) + 1e-5);
}

int compare_qsort(const void *a, const void *b)
{
  return (*(int *)a - *(int *)b);
}

bool binary_search(int arr[], int size, int value)
{
  int left = 0, right = size - 1;
  while (left <= right)
  {
    int mid = left + (right - left) / 2;
    if (arr[mid] == value)
    {
      return true;
    }
    else if (arr[mid] < value)
    {
      left = mid + 1;
    }
    else
    {
      right = mid - 1;
    }
  }
  return false;
}

int **resolve_small_instance(int **skeleton, int size, int option) // option == loop_it  // TODO: 이제 안쓰는 듯
{

  // COLLECT SMALL SIZE SOLUTION ////////////////////////////

  int *target_idxs = malloc(num_x_sol * sizeof(int));
  int *nontarget_idxs = malloc(num_x_sol * sizeof(int));
  int *target_orders = malloc(num_orders * sizeof(int));
  int num_target_seqs = 0;
  int num_nontarget_seqs = 0;
  int num_target_orders = 0;
  int count = 0;

  ///////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////
  // OPTION 1 -> RANDOM FOR <= 3
  if (option % 3 == 0)
  {
    for (int i = 0; i < num_x_sol; i++)
    {
      if (seq_solution_2d[i][0] <= 3) // order s.t. n <= 3
      {
        target_idxs[num_target_seqs] = i; // target solution idx
        num_target_seqs += 1;             // num of target solution
        count += seq_solution_2d[i][0];   // num of collected orders
        if (count > size)
          break;
        // order num collected exceeded SMALL_PROB_SIZE, break !
      }
    }
  }
  ///////////////////////////////////////////////////////////
  // OPTION 2 -> LOW AVG COST
  else if (option % 3 == 1)
  {
    Element *sorted_idxs = malloc(num_x_sol * sizeof(Element));
    for (int i = 0; i < num_x_sol; i++)
    {
      sorted_idxs[i].index = i;
      sorted_idxs[i].rcost = -((double)solution_2d[i][pattern_upto + 1]) / solution_2d[i][0];
    }
    qsort(sorted_idxs, num_x_sol, sizeof(Element), compare);

    for (int idx = 0; idx < num_x_sol; idx++)
    {
      int i = sorted_idxs[idx].index;
      {
        target_idxs[num_target_seqs] = i;
        num_target_seqs += 1;
        count += seq_solution_2d[i][0];
        if (count > size)
          break;
      }
    }
    free(sorted_idxs);
  }
  ///////////////////////////////////////////////////////////
  // OPTION 3 -> DEADLINE SLACK
  else if (option % 3 == 2)
  {
    // printf("here 1 \n"); fflush(stdout);
    //  SORT BY DEADLINE SLACK
    int *sol_idx_slack = (int *)malloc(num_x_sol * sizeof(int));
    Element *sol_slacks = (Element *)malloc(num_x_sol * sizeof(Element));
    for (int i = 0; i < num_x_sol; i++)
    {
      int h = seq_solution_2d[i][2 * pattern_upto + 2];
      int n = seq_solution_2d[i][0];
      // 1st pickup ord -> move to 2nd pickup ord
      int seq_time = order_ready_time(seq_solution_2d[i][1]);
      // PICKUP SEQUENCE
      for (int j = 1; j < n; j++)
      {
        seq_time += +rider_time[h][seq_solution_2d[i][j]][seq_solution_2d[i][j + 1]];
        seq_time = (seq_time > order_ready_time(seq_solution_2d[i][j + 1])) ? seq_time : order_ready_time(seq_solution_2d[i][j + 1]);
      }
      // LAST PICKUP -> FIRST DELIVERY
      seq_time += rider_time[h][seq_solution_2d[i][n]][seq_solution_2d[i][n + 1] + num_orders];
      int slack = order_deadline(seq_solution_2d[i][n + 1]) - seq_time;
      // DELIVERY SEQUENCE
      for (int j = 1; j < n; j++)
      {
        seq_time += rider_time[h][seq_solution_2d[i][n + j] + num_orders][seq_solution_2d[i][n + j + 1] + num_orders];
        slack = (order_deadline(seq_solution_2d[i][n + j + 1]) - seq_time < slack) ? order_deadline(seq_solution_2d[i][n + j + 1]) - seq_time : slack;
      }

      sol_slacks[i].index = i;
      sol_slacks[i].rcost = -slack;
    }

    qsort(sol_slacks, num_x_sol, sizeof(Element), compare);
    for (int i = 0; i < num_x_sol; i++)
      sol_idx_slack[i] = sol_slacks[i].index;

    for (int i = 0; i < num_x_sol; i++)
    {
      // COLLECT ORDERS
      target_idxs[num_target_seqs] = sol_idx_slack[i]; // target solution idx
      num_target_seqs += 1;                            // num of target solution
      count += seq_solution_2d[i][0];                  // num of collected orders
      if (count > size)
        break;
      // order num collected exceeded SMALL_PROB_SIZE, break !
    }
    free(sol_idx_slack);
    free(sol_slacks);
  }

  /////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////
  // TARGET SOLUTIONS -> TARGET ORDERS & TARGET IDXS///////////////////////

  double cost = 0;
  for (int i = 0; i < num_target_seqs; i++) // for target solutions
  {
    for (int j = 0; j < seq_solution_2d[target_idxs[i]][0]; j++)
      target_orders[num_target_orders + j] = seq_solution_2d[target_idxs[i]][j + 1];
    
    cost += seq_solution_2d[target_idxs[i]][2 * pattern_upto + 1];
    num_target_orders += seq_solution_2d[target_idxs[i]][0];
  }
  cost = cost / (num_orders * 100);
  printf("SMALL INSTANCE ORIGIN    obj %.3f     ", cost);
  print_time("");
  int rider_slack[num_riders];

  for (int i = 0; i < num_riders; i++)
    rider_slack[i] = rider_avail_num(i);

  for (int i = 0; i < num_x_sol; i++)
    rider_slack[seq_solution_2d[i][2 * pattern_upto + 2]]--;

  for (int i = 0; i < num_target_seqs; i++)
  {
    rider_slack[seq_solution_2d[target_idxs[i]][2 * pattern_upto + 2]]++;
  }

  // ENUM PATTERNS FOR SMALL INSTANCES //////////////////////////////////////
  int *temp_tree_patterns, **temp_tree_patterns_2d, ***tree_pat_idxs_n_h_ft, temp_tree_pat_idx;
  temp_tree_patterns = (int *)calloc(MAX_PAT_IMPROVE * (3 + pattern_upto), sizeof(int)); 
  temp_tree_patterns_2d = (int **)calloc(MAX_PAT_IMPROVE, sizeof(int *));
  for (int i = 0; i < MAX_PAT_IMPROVE; i++)
  {
    temp_tree_patterns_2d[i] = temp_tree_patterns + i * (3 + pattern_upto);
  }
  tree_pat_idxs_n_h_ft = (int ***)calloc(pattern_upto, sizeof(int **));
  for (int i = 0; i < pattern_upto; i++)
  {
    tree_pat_idxs_n_h_ft[i] = (int **)calloc(num_riders, sizeof(int *));
    for (int j = 0; j < num_riders; j++)
    {
      tree_pat_idxs_n_h_ft[i][j] = (int *)calloc(2, sizeof(int));
    }
  }


  //// length-1 patterns
  temp_tree_pat_idx = 0;
  for (int h = 0; h < num_riders; h++)
  {
    tree_pat_idxs_n_h_ft[0][h][0] = temp_tree_pat_idx;

    for (int i = 0; i < num_target_orders; i++)
    {
      if ((order_volume(target_orders[i]) <= rider_capa(h)) && (order_ready_time(target_orders[i]) + rider_time[h][target_orders[i]][target_orders[i] + num_orders] <= order_deadline(target_orders[i])))
      {
        temp_tree_patterns_2d[temp_tree_pat_idx][0] = 1;
        temp_tree_patterns_2d[temp_tree_pat_idx][1] = target_orders[i];
        temp_tree_patterns_2d[temp_tree_pat_idx][pattern_upto + 1] = 100 * rider_fixed_cost(h) + rider_var_cost(h) * dist(target_orders[i], target_orders[i] + num_orders);
        temp_tree_patterns_2d[temp_tree_pat_idx][pattern_upto + 2] = h;
        temp_tree_pat_idx += 1;
      }
    }
    tree_pat_idxs_n_h_ft[0][h][1] = temp_tree_pat_idx;
  }

  char *temp_id;
  for (int n = 2; n <= pattern_upto - 1; n++) 
  {
    if (time_limit_exceeded())
    {
      printf("time limit exceeded n %d:  %d\n", n, temp_tree_pat_idx);
      free(target_idxs);
      free(target_orders);
      free(temp_tree_patterns);
      free(temp_tree_patterns_2d);
      for (int i = 0; i < pattern_upto; i++)
      {
        for (int j = 0; j < num_riders; j++)
          free(tree_pat_idxs_n_h_ft[i][j]);
        free(tree_pat_idxs_n_h_ft[i]);
      }
      free(tree_pat_idxs_n_h_ft);
      return skeleton;
    }

    for (int h = 0; h < num_riders; h++)
    {
      if (time_limit_exceeded())
      {
        printf("time limit exceeded n %d h %d:  %d\n", n, h, temp_tree_pat_idx);
        free(target_idxs);
        free(target_orders);
        free(temp_tree_patterns);
        free(temp_tree_patterns_2d);
        for (int i = 0; i < pattern_upto; i++)
        {
          for (int j = 0; j < num_riders; j++)
            free(tree_pat_idxs_n_h_ft[i][j]);
          free(tree_pat_idxs_n_h_ft[i]);
        }
        free(tree_pat_idxs_n_h_ft);
        return skeleton;
      }

      tree_pat_idxs_n_h_ft[n - 1][h][0] = temp_tree_pat_idx;
      for (int i = tree_pat_idxs_n_h_ft[n - 2][h][0]; i < tree_pat_idxs_n_h_ft[n - 2][h][1]; i++)
      {
        if (time_limit_exceeded())
        {
          printf("time limit exceeded n %d h %d i %d:  %d\n", n, h, i - tree_pat_idxs_n_h_ft[n - 2][h][0], temp_tree_pat_idx);
          free(target_idxs);
          free(target_orders);
          free(temp_tree_patterns);
          free(temp_tree_patterns_2d);
          for (int i = 0; i < pattern_upto; i++)
          {
            for (int j = 0; j < num_riders; j++)
            {
              free(tree_pat_idxs_n_h_ft[i][j]);
            }
            free(tree_pat_idxs_n_h_ft[i]);
          }
          free(tree_pat_idxs_n_h_ft);
          return skeleton;
        }

        int *temp_pat = malloc((pattern_upto + 3) * sizeof(int));
        memcpy(temp_pat, temp_tree_patterns_2d[i], (pattern_upto + 3) * sizeof(int));
        temp_pat[0] += 1;

        for (int j = 0; j < num_target_orders; j++)
        {
          bool already_in = false;
          for (int k = 1; k < temp_pat[0] - 1; k++)
          {
            if (temp_pat[k] == target_orders[j])
            {
              already_in = true;
              break;
            }
          }
          if (already_in)
            continue;
          bool subset_feasible = true;
          for (int k = 0; k < temp_pat[0] - 1; k++)
          {
            if (!compat[h][temp_pat[k + 1]][target_orders[j]])
            {
              subset_feasible = false;
              break;
            }
          }

          if (!subset_feasible)
            continue;

          temp_pat[temp_pat[0]] = target_orders[j]; // add ord
          temp_id = get_id(temp_pat);

          struct pattern *p = (struct pattern *)hashmap_get(pat_map, &(struct pattern){.id = temp_id});
          if (p != NULL) // existing pat
          {
            if (p->idx >= 0) // fsb
            {
              memcpy(temp_tree_patterns_2d[temp_tree_pat_idx], patterns[p->idx], (pattern_upto + 3) * sizeof(int));
              temp_tree_pat_idx++;
            }
          }

          else // non-existing pat
          {
            if (!check_capa_feasibility(temp_pat)) // infsb - capa
            {
              struct pattern *pp = create_pattern(temp_pat, -1);
              hashmap_set(pat_map, (void *)pp);
              free(pp);
              free(temp_id);
              continue;
            }

            int order_list[temp_pat[0]];
            for (int i = 0; i < temp_pat[0]; i++)
              order_list[i] = temp_pat[i + 1];
            
            int result = get_min_cost_route_enum(order_list, temp_pat[0], h);
            if (result != -1) // fsb
            {
              temp_pat[pattern_upto + 1] = result;
              memcpy(temp_tree_patterns_2d[temp_tree_pat_idx], temp_pat, (3 + pattern_upto) * sizeof(int));
              memcpy(&patterns[hash_idx][0], &temp_pat[0], (3 + pattern_upto) * sizeof(int));
              struct pattern *pp = create_pattern(temp_pat, hash_idx);
              hashmap_set(pat_map, (void *)pp);
              free(pp);
              temp_tree_pat_idx++;
              hash_idx++;
            }
            else
            {
              struct pattern *pp = create_pattern(temp_pat, -1);
              hashmap_set(pat_map, (void *)pp);
              free(pp);
            }
          }
          free(temp_id);
        }
        free(temp_pat);
      }
      tree_pat_idxs_n_h_ft[n - 1][h][1] = temp_tree_pat_idx;
    }
  }

  // solve IP////////////////////////////////////////////////////////////////////////
  Tree *new_tree = create_tree(num_orders);
  int **new_skeleton = (int **)malloc(num_orders * sizeof(int *));
  for (int i = 0; i < num_orders; i++)
  {
    new_skeleton[i] = (int *)malloc(2 * sizeof(int));
  }
  int new_num_edges_in_tree = 0;

  // clock_gettime(CLOCK_MONOTONIC, &finish);
  double tree_ip_reserved = TREE_IP_TIME * (TREE_TIME * time_limit - (finish.tv_sec - start.tv_sec));
  double objval = 1e9;
  XPRBprob prob = XPRBnewprob("resolve-IP");
  XPRBvar x[MAX_COL_FIN];
  int x_idx[MAX_COL_FIN];
  XPRBctr assign[num_orders], cardi[num_riders];
  XPRBctr obj;
  int num_x = tree_pat_idxs_n_h_ft[1][0][0]; // 1 order lengths
  XPRBbasis basis;
  double dual_assign[num_orders], dual_cardi[num_riders];
  fflush(stdout);

  if (temp_tree_pat_idx <= MAX_COL_FIN)
  {
    obj = XPRBnewctr(prob, "obj", XPRB_N);      // XPRB_N indicate this is for objective
    for (int i = 0; i < num_target_orders; i++) // iterate over orders
    {
      assign[target_orders[i]] = XPRBnewctr(prob, XPRBnewname("assign_%d", target_orders[i]), XPRB_E);
      XPRBaddterm(assign[target_orders[i]], NULL, 1);
    }

    for (int i = 0; i < num_riders; i++) // iterate over riders
    {
      cardi[i] = XPRBnewctr(prob, XPRBnewname("cardi_%d", i), XPRB_L);
      XPRBaddterm(cardi[i], NULL, rider_slack[i]);
    }

    for (int i = 0; i < temp_tree_pat_idx; i++) // iterate over solution
    {
      x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
      XPRBaddterm(obj, x[i], ((double)temp_tree_patterns_2d[i][pattern_upto + 1]) / (num_orders * 100));
      for (int j = 1; j < temp_tree_patterns_2d[i][0] + 1; j++)
        XPRBaddterm(assign[temp_tree_patterns_2d[i][j]], x[i], 1);
      XPRBaddterm(cardi[temp_tree_patterns_2d[i][pattern_upto + 2]], x[i], 1);
    }
    XPRBsetobj(prob, obj);
    XPRBsetmsglevel(prob, 0);

    XPRSprob opt_prob = XPRBgetXPRSprob(prob);
    clock_gettime(CLOCK_MONOTONIC, &finish);
    int this_time_limit = ((int)time_limit * TREE_TIME - (finish.tv_sec - start.tv_sec) - 1);
    if (this_time_limit <= 0)
    {
      free(target_idxs);
      free(target_orders);
      free(temp_tree_patterns);
      free(temp_tree_patterns_2d);
      for (int i = 0; i < pattern_upto; i++)
      {
        for (int j = 0; j < num_riders; j++)
          free(tree_pat_idxs_n_h_ft[i][j]);
        free(tree_pat_idxs_n_h_ft[i]);
      }
      free(tree_pat_idxs_n_h_ft);
      XPRBdelprob(prob);
      XPRBfree();
      for (int i = 0; i < num_orders; i++)
        free(new_skeleton[i]);
      free(new_skeleton);
      return skeleton;
    }

    XPRSsetintcontrol(opt_prob, XPRS_MAXTIME, -this_time_limit);

    XPRBmipoptimize(prob, "");
    objval = XPRBgetobjval(prob);
    printf("SMALL INSTANCE IP   obj %.3f   stat %d   ", objval, XPRBgetmipstat(prob));
    print_time("");

    // NOT INTEGRAL OR COST WORSEN FOR SMALL INSTANCE
    if ((XPRBgetmipstat(prob) != XPRB_MIP_SOLUTION && XPRBgetmipstat(prob) != XPRB_MIP_OPTIMAL) || (objval > cost + 1e-9))
    {

      second_not_improved = true;
      free(target_idxs);
      free(target_orders);
      free(temp_tree_patterns);
      free(temp_tree_patterns_2d);
      for (int i = 0; i < pattern_upto; i++)
      {
        for (int j = 0; j < num_riders; j++)
        {
          free(tree_pat_idxs_n_h_ft[i][j]);
        }
        free(tree_pat_idxs_n_h_ft[i]);
      }
      free(tree_pat_idxs_n_h_ft);
      XPRBdelprob(prob);
      XPRBfree();
      free_tree(new_tree);
      for (int i = 0; i < num_orders; i++)
        free(new_skeleton[i]);
      free(new_skeleton);
      return skeleton;
    }
    else // IMPROVED
    {
      new_num_edges_in_tree = 0;
      for (int i = 0; i < temp_tree_pat_idx; i++)
      {
        if (XPRBgetsol(x[i]) > 0.5)
        {

          int temp;
          int *seq = get_best_sequence(temp_tree_patterns_2d[i], &temp, temp_tree_patterns_2d[i][pattern_upto + 2]);
          int n = temp_tree_patterns_2d[i][0];
          for (int j = n; j < 2 * n - 1; j++)
          {
            int u = seq[j];
            int v = seq[j + 1];
            if (add_edge(new_tree, u, v))
            {
              new_skeleton[new_num_edges_in_tree][0] = u;
              new_skeleton[new_num_edges_in_tree][1] = v;
              new_num_edges_in_tree += 1;
            }
          }
        }
      }
    }
  }
  else // TOO MANY PATTERNS -> CG
  {
    obj = XPRBnewctr(prob, "obj", XPRB_N);      // XPRB_N indicate this is for objective
    for (int i = 0; i < num_target_orders; i++) // iterate over orders
    {
      assign[target_orders[i]] = XPRBnewctr(prob, XPRBnewname("assign_%d", target_orders[i]), XPRB_E);
      XPRBaddterm(assign[target_orders[i]], NULL, 1);
    }
    for (int i = 0; i < num_riders; i++) // iterate over riders
    {
      cardi[i] = XPRBnewctr(prob, XPRBnewname("cardi_%d", i), XPRB_L);
      XPRBaddterm(cardi[i], NULL, rider_slack[i]);
    }

    for (int i = 0; i < tree_pat_idxs_n_h_ft[1][0][0]; i++) // iterate over length 1 patterns
    {
      x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
      XPRBaddterm(obj, x[i], ((double)temp_tree_patterns_2d[i][pattern_upto + 1]) / (num_orders * 100));
      for (int j = 1; j < temp_tree_patterns_2d[i][0] + 1; j++)
        XPRBaddterm(assign[temp_tree_patterns_2d[i][j]], x[i], 1);
      XPRBaddterm(cardi[temp_tree_patterns_2d[i][pattern_upto + 2]], x[i], 1);
    }

    XPRBsetobj(prob, obj);
    XPRBsetmsglevel(prob, 0);

    // column generation
    int it = 0;
    while (true)
    {
      clock_gettime(CLOCK_MONOTONIC, &finish);
      if ((finish.tv_sec - start.tv_sec) > time_limit - tree_ip_reserved)
        break;

      // solving RMP
      XPRBlpoptimize(prob, "");
      basis = XPRBsavebasis(prob);
      objval = XPRBgetobjval(prob);
      for (int i = 0; i < num_target_orders; i++)
        dual_assign[target_orders[i]] = XPRBgetdual(assign[target_orders[i]]);
      for (int i = 0; i < num_riders; i++)
        dual_cardi[i] = XPRBgetdual(cardi[i]);

      // check profitable columns
      int num_added = 0;
      int it_pat_max = (it < EARLY_ITER) ? IT_PAT_MAX_EARLY : IT_PAT_MAX;
      int n_profitable = 0;

      Element *sorted_idxs = (Element *)malloc((temp_tree_pat_idx - tree_pat_idxs_n_h_ft[1][0][0] + 1) * sizeof(Element));
      for (int i = temp_tree_pat_idx; i >= tree_pat_idxs_n_h_ft[1][0][0]; i--)
      {
        double cost = ((double)temp_tree_patterns_2d[i][pattern_upto + 1]) / (num_orders * 100);
        double reduced_cost = cost - dual_cardi[temp_tree_patterns_2d[i][pattern_upto + 2]];
        for (int j = 1; j < temp_tree_patterns_2d[i][0] + 1; j++)
          reduced_cost -= dual_assign[temp_tree_patterns_2d[i][j]];
        if (reduced_cost < -1e-5)
        {
          sorted_idxs[n_profitable].index = i;
          sorted_idxs[n_profitable].cost = cost;
          sorted_idxs[n_profitable].rcost = reduced_cost;
          n_profitable += 1;
        }
      }
      qsort(sorted_idxs, n_profitable, sizeof(Element), compare);

      it_pat_max = (n_profitable < it_pat_max) ? n_profitable : it_pat_max;
      for (int idx = 0; idx < it_pat_max; idx++)
      {
        // printf("%f ", sorted_idxs[idx].rcost);
        if (sorted_idxs[idx].rcost > -1e-5)
          break;
        int i = sorted_idxs[idx].index;
        double cost = sorted_idxs[idx].cost;
        x[num_x] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
        x_idx[num_x] = i;
        XPRBaddterm(obj, x[num_x], cost);
        for (int j = 1; j < temp_tree_patterns_2d[i][0] + 1; j++)
          XPRBaddterm(assign[temp_tree_patterns_2d[i][j]], x[num_x], 1);
        XPRBaddterm(cardi[temp_tree_patterns_2d[i][pattern_upto + 2]], x[num_x], 1);
        num_x++;
        num_added++;
      }
      free(sorted_idxs);
      if (num_added == 0)
      {
        XPRBdelbasis(basis);
        break;
      }
      XPRBloadmat(prob);
      XPRBloadbasis(basis);
      XPRBdelbasis(basis);
    }

    // solving final R-IP
    //// gather low reduced cost patterns at the last iteration
    Element *sorted_idxs = (Element *)malloc((temp_tree_pat_idx) * sizeof(Element));
    for (int i = 0; i < temp_tree_pat_idx; i++)
    {
      double cost = ((double)temp_tree_patterns_2d[i][pattern_upto + 1]) / (num_orders * 100);
      double reduced_cost = cost - dual_cardi[temp_tree_patterns_2d[i][pattern_upto + 2]];
      for (int j = 1; j < temp_tree_patterns_2d[i][0] + 1; j++)
        reduced_cost -= dual_assign[temp_tree_patterns_2d[i][j]];
      sorted_idxs[i].index = i;
      sorted_idxs[i].cost = cost;
      sorted_idxs[i].rcost = reduced_cost;
    }

    qsort(sorted_idxs, temp_tree_pat_idx, sizeof(Element), compare);
    for (int idx = 0; idx < ((10000 > temp_tree_pat_idx) ? temp_tree_pat_idx : 10000); idx++)
    {
      int i = sorted_idxs[idx].index;
      double cost = sorted_idxs[idx].cost;
      x[num_x] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
      x_idx[num_x] = i;
      XPRBaddterm(obj, x[num_x], cost);
      for (int j = 1; j < temp_tree_patterns_2d[i][0] + 1; j++)
        XPRBaddterm(assign[temp_tree_patterns_2d[i][j]], x[num_x], 1);
      XPRBaddterm(cardi[temp_tree_patterns_2d[i][pattern_upto + 2]], x[num_x], 1);
      num_x += 1;
    }

    free(sorted_idxs);

    //// solve
    XPRSprob opt_prob = XPRBgetXPRSprob(prob);
    clock_gettime(CLOCK_MONOTONIC, &finish);
    int this_time_limit = ((int)time_limit * TREE_TIME - (finish.tv_sec - start.tv_sec) - 1);
    if (this_time_limit <= 0)
    {

      free(target_idxs);
      free(target_orders);
      free(temp_tree_patterns);
      free(temp_tree_patterns_2d);
      for (int i = 0; i < pattern_upto; i++)
      {
        for (int j = 0; j < num_riders; j++)
        {
          free(tree_pat_idxs_n_h_ft[i][j]);
        }
        free(tree_pat_idxs_n_h_ft[i]);
      }
      free(tree_pat_idxs_n_h_ft);
      XPRBdelprob(prob);
      XPRBfree();
      free_tree(new_tree);
      for (int i = 0; i < num_orders; i++)
        free(new_skeleton[i]);
      free(new_skeleton);
      return skeleton;
    }

    XPRSsetintcontrol(opt_prob, XPRS_MAXTIME, -this_time_limit);

#if FIRST_IP_OPTION == 1
    XPRSsetintcontrol(opt_prob, XPRS_HEURSTRATEGY_EXTENSIVE, 3);
    // XPRSsetintcontrol(opt_prob, XPRS_CUTSTRATEGY, 3);
#elif FIRST_IP_OPTION == 2
    for (int i = tree_pat_idxs_n_h_ft[1][0][0]; i < num_x; i++)
    {
      if (XPRBgetsol(x[i]) > FIXING_THRD)
        XPRBfixvar(x[i], 1);
    }
#elif FIRST_IP_OPTION == 3
    for (int i = tree_pat_idxs_n_h_ft[1][0][0]; i < num_x; i++)
    {
      if (XPRBgetsol(x[i]) > FIXING_THRD)
        XPRBfixvar(x[i], 1);
    }
    XPRSsetintcontrol(opt_prob, XPRS_HEURSTRATEGY_EXTENSIVE, 3);
#endif

    XPRBmipoptimize(prob, "c");
    objval = XPRBgetobjval(prob);
    printf("SMALL INSTANCE IP   obj %.3f   stat %d   ", objval, XPRBgetmipstat(prob));
    print_time("");
    
    // NOT INTEGRAL OR COST WORSEN FOR SMALL INSTANCE
    if ((XPRBgetmipstat(prob) != XPRB_MIP_SOLUTION && XPRBgetmipstat(prob) != XPRB_MIP_OPTIMAL) || (objval > cost + 1e-9))
    {
      second_not_improved = true;

      free(target_idxs);
      free(target_orders);
      free(temp_tree_patterns);
      free(temp_tree_patterns_2d);
      for (int i = 0; i < pattern_upto; i++)
      {
        for (int j = 0; j < num_riders; j++)
        {
          free(tree_pat_idxs_n_h_ft[i][j]);
        }
        free(tree_pat_idxs_n_h_ft[i]);
      }
      free(tree_pat_idxs_n_h_ft);
      XPRBdelprob(prob);
      XPRBfree();
      free_tree(new_tree);
      for (int i = 0; i < num_orders; i++)
        free(new_skeleton[i]);
      free(new_skeleton);

      return skeleton;
    }
    else // IMPROVED
    {
      new_num_edges_in_tree = 0;

      for (int i = 0; i < num_x; i++)
      {
        if (XPRBgetsol(x[i]) > 0.5)
        {
          int idx = x_idx[i];
          int temp;
          int *seq = get_best_sequence(temp_tree_patterns_2d[idx], &temp, temp_tree_patterns_2d[idx][pattern_upto + 2]);
          int n = temp_tree_patterns_2d[idx][0];

          for (int j = n; j < 2 * n - 1; j++)
          {
            int u = seq[j];
            int v = seq[j + 1];
            if (add_edge(new_tree, u, v))
            {
              new_skeleton[new_num_edges_in_tree][0] = u;
              new_skeleton[new_num_edges_in_tree][1] = v;
              new_num_edges_in_tree += 1;
            }
          }
        }
      }
    }
  }

  // FINISH SOLVE SMALL INSTANCE
  //// AND ADD EDGE TO NEW TREE FROM
  ///////////////////////////////////////////////////////

  // OPTION 1
  /////////////////////////////////////////////////////////////
  // ADD FROM PREVIOUS TREE /////////////////////////////////
  // except target order

  for (int i = 0; i < num_x_sol; i++)
  {
    bool is_target = false;
    for (int j = 0; j < num_target_seqs; j++)
    {
      if (i == target_idxs[j])
      {
        is_target = true;
        break;
      }
    }
    if (!is_target)
    {
      nontarget_idxs[num_nontarget_seqs] = i;
      num_nontarget_seqs++;
    }
  }

  for (int i = 0; i < num_nontarget_seqs; i++)
  {
    int idx = nontarget_idxs[i];
    for (int j = 0; j < seq_solution_2d[idx][0] - 1; j++)
    {
      if (add_edge(new_tree, seq_solution_2d[idx][seq_solution_2d[idx][0] + j + 1], seq_solution_2d[idx][seq_solution_2d[idx][0] + j + 2]))
      {
        new_skeleton[new_num_edges_in_tree][0] = seq_solution_2d[idx][seq_solution_2d[idx][0] + j + 1];
        new_skeleton[new_num_edges_in_tree][1] = seq_solution_2d[idx][seq_solution_2d[idx][0] + j + 2];
        new_num_edges_in_tree += 1;
      }
    }
  }

  ////// add edges via deadline slack
  for (int i = 0; i < pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]; i++)
  {
    int idx = idxs_sorted_by_deadline_slack[i];
    if (add_edge(new_tree, patterns[idx][1], patterns[idx][2]))
    {

      new_skeleton[new_num_edges_in_tree][0] = patterns[idx][1];
      new_skeleton[new_num_edges_in_tree][1] = patterns[idx][2];
      new_num_edges_in_tree++;
    }
    if (new_num_edges_in_tree == num_orders - 1)
      break; 
  }

  ////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////
  num_edges_in_tree = new_num_edges_in_tree;

  for (int i = 0; i < pattern_upto; i++)
  {
    for (int j = 0; j < num_riders; j++)
    {
      free(tree_pat_idxs_n_h_ft[i][j]);
    }
    free(tree_pat_idxs_n_h_ft[i]);
  }
  free(tree_pat_idxs_n_h_ft);
  free(temp_tree_patterns_2d);
  free(temp_tree_patterns);

  XPRBdelprob(prob);
  XPRBfree();

  free_tree(new_tree);
  free(target_orders);
  free(target_idxs);
  for (int i = 0; i < num_orders; i++)
    free(skeleton[i]);
  free(skeleton);
  free(nontarget_idxs);
  // printf("\nSKELETON UPDATED, now %d\n", num_edges_in_tree);
  return new_skeleton;
}

void solve_tree_ip()
{
  // clock_gettime(CLOCK_MONOTONIC, &finish);

  // setup initial restricted master problem
  XPRBprob prob = XPRBnewprob("TREE-IP");
  XPRBvar x[MAX_COL_FIN];
  XPRBctr assign[num_orders], cardi[num_riders];
  XPRBctr obj;
  double objval;

  obj = XPRBnewctr(prob, "obj", XPRB_N); // XPRB_N indicate this is for objective
  for (int i = 0; i < num_orders; i++)   // iterate over orders
  {
    assign[i] = XPRBnewctr(prob, XPRBnewname("assign_%d", i), XPRB_E);
    XPRBaddterm(assign[i], NULL, 1);
  }
  for (int i = 0; i < num_riders; i++) // iterate over riders
  {
    cardi[i] = XPRBnewctr(prob, XPRBnewname("cardi_%d", i), XPRB_L);
    XPRBaddterm(cardi[i], NULL, rider_avail_num(i));
  }
  for (int i = 0; i < tree_pat_h_n_idxs[0][1][0]; i++) // iterate over length 1 patterns
  {
    x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    XPRBaddterm(obj, x[i], ((double)tree_patterns[i][pattern_upto + 1]) / (num_orders * 100));
    XPRBaddterm(assign[tree_patterns[i][1]], x[i], 1);
    XPRBaddterm(cardi[tree_patterns[i][pattern_upto + 2]], x[i], 1);
  }

  for (int i = tree_pat_h_n_idxs[0][1][0]; i < tree_pat_idx; i++) // iterate over length 1 patterns
  {
    x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    XPRBaddterm(obj, x[i], ((double)tree_patterns[i][pattern_upto + 1]) / (num_orders * 100));
    for (int j = 1; j < tree_patterns[i][0] + 1; j++)
      XPRBaddterm(assign[tree_patterns[i][j]], x[i], 1);
    XPRBaddterm(cardi[tree_patterns[i][pattern_upto + 2]], x[i], 1);
  }

  XPRBsetobj(prob, obj);
  XPRBsetmsglevel(prob, 0);
  XPRSprob opt_prob = XPRBgetXPRSprob(prob);
  clock_gettime(CLOCK_MONOTONIC, &finish);
  XPRSsetintcontrol(opt_prob, XPRS_MAXTIME, -time_limit * TREE_IP_TIME); // TODO: time limit 전체 남은 시간도 보도록 // 지금까지 문제된적 없는걸봐서 괜찮을지도? 

  XPRBmipoptimize(prob, "c");
  objval = XPRBgetobjval(prob);
  printf("IP   obj %.3f   stat %d   ", objval, XPRBgetmipstat(prob));
  print_time("");

  if (XPRBgetmipstat(prob) != XPRB_MIP_SOLUTION && XPRBgetmipstat(prob) != XPRB_MIP_OPTIMAL)
  {
    XPRBdelprob(prob);
    return;
  }

  bool ip_obj_improved = false;
  if (objval < best_ip_obj - 1e-9)
  {
    ip_obj_improved = true;
    best_ip_obj = objval;
    best_pat_idx = tree_pat_idx;
    memcpy(&best_patterns[0][0], &tree_patterns[0][0], tree_pat_idx * (pattern_upto + 3) * sizeof(int));
  }

  if (ip_obj_improved)
  {
    num_x_sol = 0;
    for (int i = 0; i < tree_pat_idx; i++)
    {
      if (XPRBgetsol(x[i]) > 1e-9)
      {
        memcpy(&(solution_2d[num_x_sol][0]), &(best_patterns[i][0]), (pattern_upto + 3) * sizeof(int));
        num_x_sol++;
      }
    }
    get_sequenced_solution();
  }
  XPRBdelprob(prob);

  return;
}
