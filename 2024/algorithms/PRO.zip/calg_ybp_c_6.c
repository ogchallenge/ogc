/* This version trying to improve incumbent solution */
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>
#include "xprb.h"
#include "xprs.h"
#include "hashmap.h"

#define NUM_THREADS 4
#define MAX_TH_PATTERNS 4000000

#define ENUM_PAT_AVG_COST_THSD 1.5
#define ENUM_PAT_HEUR_FROM 7
#define ENUM_PAT_HEUR_ADD_THSD 0.05
#define TREE_ENUM_SEVEN_THSD 1

#define MAX_COL 500000
#define IT_PAT_MAX 200
#define EARLY_ITER 0
#define IT_PAT_MAX_EARLY 2100

#define FIRST_ENUM_TIMELIMIT 0.6 // enum_time = timelimit * FIRST_ENUM_TIMELIMIT
#define FIRST_IP_RESERVED 0.07     // ip_time = timelimit * FIRST_IP_RESERVED
#define IMPROVE_RESERVED 0.2     // improve_time = timelimit * IMPROVE_RESERVED
#define NUM_FINAL_CG_COLS 10000

#define MAX_ORDER_IN_PATT 8
#define MAX_PAT_IMPROVE 10000000
#define NUM_IMPROVE_ITER 100
#define SMALL_PROB_SIZE 75
#define IMP_OBJ_STEADY_LIMIT 10


/* Initial CG and IP related */
XPRBprob prob;
XPRBvar x[MAX_COL];
XPRBctr *assign, *cardi, obj;
XPRBbasis basis;
int *x_idx, num_x;
double *dual_assign, *dual_cardi, objval;

void initialize_solve();
void add_pattern_greedy(int n);
void solve_lp_get_duals(int n);
void solve();
void cleanup_solve();
int *get_best_sequence(int *pattern, int *min_dist, int h);
void get_sequenced_solution();

/* Last Improve related */
int imp_obj_steady;
void initialize_improve();
void improve();
void cleanup_improve();

inline double rider_capa(int rider_type);
inline double rider_var_cost(int rider_type);
inline double rider_fixed_cost(int rider_type);
inline double rider_speed(int rider_type);
inline double rider_service_time(int rider_type);
inline double rider_avail_num(int rider_type);
inline int order_ready_time(int order_num);
inline int order_deadline(int order_num);
inline int order_volume(int order_num);
inline int dist(int i, int j);

// for hashmap
// struct pattern {
//     char *id;
//     int dist;
// };
// int pattern_compare(const void *a, const void *b, void *udata);
// bool pattern_iter(const void *item, void *udata);
// void pattern_free(void *item);
// uint64_t pattern_hash(const void *item, uint64_t seed0, uint64_t seed1);
// char *get_id(int *pattern);
// struct pattern* create_pattern(int* pattern);

// utility functions
struct timespec start, finish;
int time_limit;
void print_time(char *msg)
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  printf("  %s %.4f\n", msg, (double)(finish.tv_sec - start.tv_sec) + (double)(finish.tv_nsec - start.tv_nsec) / 1000000000);
}
bool time_limit_exceeded() // only used to check enumeration time_limit
{
  clock_gettime(CLOCK_MONOTONIC, &finish);
  return (finish.tv_sec - start.tv_sec) > (time_limit * FIRST_ENUM_TIMELIMIT);
}
const int factorial[] = {1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800};
int ***nth_permutation_of_size;
void free_permutations()
{
  if (nth_permutation_of_size != NULL)
  {
    for (int i = 0; i < 11; i++)
    {
      if (nth_permutation_of_size[i] != NULL)
      {
        for (int j = 0; j < factorial[i]; j++)
        {
          if (nth_permutation_of_size[i][j] != NULL)
          {
            free(nth_permutation_of_size[i][j]);
          }
        }
        free(nth_permutation_of_size[i]);
      }
    }
    free(nth_permutation_of_size);
  }
}
void generate_permutations(int max_size)
{
  if (nth_permutation_of_size == NULL)
  {
    nth_permutation_of_size = (int ***)calloc(11, sizeof(int **));
    nth_permutation_of_size[1] = (int **)calloc(1, sizeof(int *));
    nth_permutation_of_size[1][0] = (int *)calloc(1, sizeof(int));
    nth_permutation_of_size[1][0][0] = 0;
  }
  for (int size = 2; size <= max_size; size++)
  {
    nth_permutation_of_size[size] = (int **)calloc(factorial[size], sizeof(int *));
    for (int n = 0; n < factorial[size]; n++)
    {
      nth_permutation_of_size[size][n] = (int *)calloc(size, sizeof(int));
      int q = n / factorial[size - 1];
      int d = n % factorial[size - 1];
      for (int i = 0; i < size; i++)
      {
        if (i < q)
          nth_permutation_of_size[size][n][i] = nth_permutation_of_size[size - 1][d][i];
        else if (i == q)
          nth_permutation_of_size[size][n][i] = size - 1;
        else
          nth_permutation_of_size[size][n][i] = nth_permutation_of_size[size - 1][d][i - 1];
      }
    }
  }
}
int *get_nth_permutation_of_size(int n, int size)
{
  return nth_permutation_of_size[size][n];
}
int *get_nth_permutation_of_size_heur(int n, int size)
{
  int* perm = (int*) malloc(size * sizeof(int));
  for (int i = 0; i < n; i++)
  {
    perm[i] = i;
  }
  perm[n] = size - 1;
  for (int i = n + 1; i < size; i++)
  {
    perm[i] = i - 1;
  }
  return perm;
}
struct th_data
{
  int th_id;
  int n;
  int h;
  int idx_from;
  int idx_to;
  int *p_pat_idx;
};
void *p_enum(void *data);
int extend(int th_id, int n, int h, int idx_from, int idx_to);
int extend_using_dual(int th_id, int n, int h, int idx_from, int idx_to);
int extend_using_dual_heur(int th_id, int n, int h, int idx_from, int idx_to);
// free functions
void free_patterns();

// global variables
int **order_arr, num_orders, num_riders, ***rider_time, *trt, **patterns, pattern_upto, ***pat_h_n_idxs, ***th_patterns, **th_patterns_data, *th_num_patterns, pat_idx, *solution, **solution_2d, num_x_sol, *seq_solution, **seq_solution_2d;
int64_t *dist_arr;
double **rider_arr, *costs;
bool ***compat;

// main function
int *pattern_enum(int **order_array,
                  double **rider_array,
                  int64_t *dist_array,
                  int order_num,
                  int pattern_upto_,
                  int max_element,
                  int *num_gen_patts,
                  int _time_limit)
{
  clock_gettime(CLOCK_MONOTONIC, &start);
  // INITIALIZATION
  time_limit = _time_limit;
  // enumeration related
  pattern_upto = pattern_upto_;
  num_riders = 3;
  rider_arr = rider_array; // capa, var_cost, fixed_cost, speed, service_time
  order_arr = order_array; // ready_time, deadline, volume
  dist_arr = dist_array;
  num_orders = order_num;

  // calculate rider time takes less than 0.1 second for 1000 orders and 3 riders
  rider_time = (int ***)calloc(num_riders, sizeof(int **));
  for (int h = 0; h < num_riders; h++)
  {
    rider_time[h] = (int **)calloc(2 * order_num, sizeof(int *));
    for (int j = 0; j < 2 * order_num; j++)
    {
      rider_time[h][j] = (int *)calloc(2 * order_num, sizeof(int));
      for (int jj = 0; jj < 2 * order_num; jj++)
      {
        rider_time[h][j][jj] = round(dist(j, jj) / rider_speed(h) + rider_service_time(h));
      }
    }
  }

  // pairwise compatibility check related
  compat = (bool ***)calloc(num_riders, sizeof(bool **));
  for (int h = 0; h < num_riders; h++)
  {
    compat[h] = (bool **)calloc(num_orders, sizeof(bool *));
    for (int i = 0; i < num_orders; i++)
    {
      compat[h][i] = (bool *)calloc(num_orders, sizeof(bool));
    }
  }

  // return related
  trt = (int *)calloc(max_element * (2 * pattern_upto + 3), sizeof(int));
  patterns = (int **)calloc(max_element, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
  for (int i = 0; i < max_element; i++)
  {
    patterns[i] = trt + i * (2 * pattern_upto + 3);
  }

  // thread related
  pthread_t pthread[NUM_THREADS];
  th_patterns_data = (int **)calloc(NUM_THREADS, sizeof(int *));
  th_patterns = (int ***)calloc(NUM_THREADS, sizeof(int **));
  for (int i = 0; i < NUM_THREADS; i++)
  {
    th_patterns_data[i] = (int *)calloc(MAX_TH_PATTERNS * (2 * pattern_upto + 3), sizeof(int));
    th_patterns[i] = (int **)calloc(MAX_TH_PATTERNS, sizeof(int *));
    for (int j = 0; j < MAX_TH_PATTERNS; j++)
    {
      th_patterns[i][j] = th_patterns_data[i] + (j * (2 * pattern_upto + 3));
    }
  }
  th_num_patterns = (int *)calloc(NUM_THREADS, sizeof(int));
  generate_permutations(MAX_ORDER_IN_PATT);
  print_time("Initialization : ");
  // INITIALIZATION END

  // // TEST INPUTS
  printf("time_limit: %d\n", time_limit);
  printf("num_orders: %d\n", num_orders);
  // printf("num_riders: %d\n", num_riders);
  printf("pattern_upto: %d\n", pattern_upto);
  // printf("max_element: %d\n", max_element);

  // printf("rider_capa(0): %f\n", rider_capa(0));
  // printf("rider_capa(2): %f\n", rider_capa(2));

  // printf("dist(2, 3): %d\n", dist(2, 3));
  // printf("dist(100, 200): %d\n", dist(100, 200));

  // printf("r.T[0][0][1]: %d\n", rider_time[0][0][1]);
  // printf("r.T[2][700][1500]: %d\n", rider_time[2][700][1500]);
  // printf("order_ready_time(0): %d\n", order_ready_time(0));
  // printf("order_deadline(10): %d\n", order_deadline(10));
  // printf("order_volume(30): %d\n", order_volume(30));
  // // TEST INPUTS END

  // PATTERN ENUMERATION
  pat_idx = 0;
  pat_h_n_idxs = (int ***)calloc(num_riders, sizeof(int **));
  for (int h = 0; h < num_riders; h++)
  {
    pat_h_n_idxs[h] = (int **)calloc(pattern_upto, sizeof(int *));
    for (int n = 0; n < pattern_upto; n++)
    {
      pat_h_n_idxs[h][n] = (int *)calloc(2, sizeof(int));
    }
  }

  // pattern with 1 order
  printf("    ----\n");
  for (int h = 0; h < num_riders; h++)
  {
    pat_h_n_idxs[h][0][0] = pat_idx;
    for (int i = 0; i < num_orders; i++)
    {
      if ((order_volume(i) <= rider_capa(h)) && (order_ready_time(i) + rider_time[h][i][i + num_orders] <= order_deadline(i)))
      {
        patterns[pat_idx][0] = 1;
        patterns[pat_idx][1] = i;
        patterns[pat_idx][2] = i;
        patterns[pat_idx][2 * pattern_upto + 1] = 100 * rider_fixed_cost(h) + rider_var_cost(h) * dist(i, i + num_orders);
        patterns[pat_idx][2 * pattern_upto + 2] = h;
        pat_idx += 1;
      }
    }
    pat_h_n_idxs[h][0][1] = pat_idx;
    printf("    n %d  h %d  : %8d", 1, h, pat_h_n_idxs[h][0][1] - pat_h_n_idxs[h][0][0]);
    print_time("");
  }
  printf("    ----\n");

  /* ENUM - CG - and so on */
  // multi-threaded pattern enumeration
  int *p_pat_idxs = (int *)calloc(NUM_THREADS, sizeof(int));
  costs = (double *)malloc(max_element * sizeof(double));
  initialize_solve();

  // n = 2
  //// enum all for n = 2
  for (int n = 2; n <= 2; n++)
  {
    for (int h = 0; h < num_riders; h++)
    {
      pat_h_n_idxs[h][n - 1][0] = pat_idx;

      int num_patts_for_each_thread = (pat_h_n_idxs[h][n - 2][1] - pat_h_n_idxs[h][n - 2][0]) / NUM_THREADS;

      for (int i = 0; i < NUM_THREADS; i++)
      {
        struct th_data *data = (struct th_data *)malloc(sizeof(struct th_data));
        data->th_id = i;
        data->n = n;
        data->h = h;
        data->idx_from = pat_h_n_idxs[h][n - 2][0] + i * num_patts_for_each_thread;
        data->idx_to = (i == (NUM_THREADS - 1)) ? pat_h_n_idxs[h][n - 2][1] : pat_h_n_idxs[h][n - 2][0] + (i + 1) * num_patts_for_each_thread;
        data->p_pat_idx = &(p_pat_idxs[i]);
        int stat = pthread_create(&pthread[i], NULL, p_enum, (void *)data);
        if (stat != 0)
        {
          printf("pthread_create error\n");
          fflush(stdout);
        }
      }
      for (int i = 0; i < NUM_THREADS; i++)
      {
        pthread_join(pthread[i], NULL);
      }
      // print_time("");
      for (int i = 0; i < NUM_THREADS; i++)
      {
        memcpy(&(patterns[pat_idx][0]), &(th_patterns[i][0][0]), p_pat_idxs[i] * (2 * pattern_upto + 3) * sizeof(int));
        pat_idx += p_pat_idxs[i];
      }
      pat_h_n_idxs[h][n - 1][1] = pat_idx;
      if (n == 2)
      {
        for (int idx = pat_h_n_idxs[h][n - 1][0]; idx < pat_h_n_idxs[h][n - 1][1]; idx++)
        {
          compat[h][patterns[idx][1]][patterns[idx][2]] = true;
          compat[h][patterns[idx][2]][patterns[idx][1]] = true;
        }
      }

      printf("    n %d  h %d  : %8d", n, h, pat_h_n_idxs[h][n - 1][1] - pat_h_n_idxs[h][n - 1][0]);
      print_time("");
      if (pat_idx == max_element)
        break;
    }
    printf("    ----\n");
    if (pat_idx == max_element)
      break;
  }

  //// solve CG-LP for n = 2
  solve_lp_get_duals(2);

  // n = 3
  //// enum all for n = 3
  printf("    ----\n");
  for (int n = 3; n <= 3; n++)
  {
    for (int h = 0; h < num_riders; h++)
    {
      pat_h_n_idxs[h][n - 1][0] = pat_idx;

      int num_patts_for_each_thread = (pat_h_n_idxs[h][n - 2][1] - pat_h_n_idxs[h][n - 2][0]) / NUM_THREADS;

      for (int i = 0; i < NUM_THREADS; i++)
      {
        struct th_data *data = (struct th_data *)malloc(sizeof(struct th_data));
        data->th_id = i;
        data->n = n;
        data->h = h;
        data->idx_from = pat_h_n_idxs[h][n - 2][0] + i * num_patts_for_each_thread;
        data->idx_to = (i == (NUM_THREADS - 1)) ? pat_h_n_idxs[h][n - 2][1] : pat_h_n_idxs[h][n - 2][0] + (i + 1) * num_patts_for_each_thread;
        data->p_pat_idx = &(p_pat_idxs[i]);
        int stat = pthread_create(&pthread[i], NULL, p_enum, (void *)data); // TODO:
        if (stat != 0)
        {
          printf("pthread_create error\n");
          fflush(stdout);
        }
      }
      for (int i = 0; i < NUM_THREADS; i++)
      {
        pthread_join(pthread[i], NULL);
      }
      // print_time("");
      for (int i = 0; i < NUM_THREADS; i++)
      {
        memcpy(&(patterns[pat_idx][0]), &(th_patterns[i][0][0]), p_pat_idxs[i] * (2 * pattern_upto + 3) * sizeof(int));
        pat_idx += p_pat_idxs[i];
      }
      pat_h_n_idxs[h][n - 1][1] = pat_idx;

      printf("    n %d  h %d  : %8d", n, h, pat_h_n_idxs[h][n - 1][1] - pat_h_n_idxs[h][n - 1][0]);
      print_time("");
      if (pat_idx == max_element)
        break;
    }
    printf("    ----\n");
    if (pat_idx == max_element)
      break;
  }
  //// solve CG-LP for n = 3
  solve_lp_get_duals(3);

  // n >= 4
  for (int nn = 4; nn <= pattern_upto; nn++)
  {
    printf("    ----\n");
    for (int n = nn; n <= nn; n++)
    {
      for (int h = 0; h < num_riders; h++)
      {
        pat_h_n_idxs[h][n - 1][0] = pat_idx;

        int num_patts_for_each_thread = (pat_h_n_idxs[h][n - 2][1] - pat_h_n_idxs[h][n - 2][0]) / NUM_THREADS;

        for (int i = 0; i < NUM_THREADS; i++)
        {
          struct th_data *data = (struct th_data *)malloc(sizeof(struct th_data));
          data->th_id = i;
          data->n = n;
          data->h = h;
          data->idx_from = pat_h_n_idxs[h][n - 2][0] + i * num_patts_for_each_thread;
          data->idx_to = (i == (NUM_THREADS - 1)) ? pat_h_n_idxs[h][n - 2][1] : pat_h_n_idxs[h][n - 2][0] + (i + 1) * num_patts_for_each_thread;
          data->p_pat_idx = &(p_pat_idxs[i]);
          int stat = pthread_create(&pthread[i], NULL, p_enum, (void *)data); // TODO:
          if (stat != 0)
          {
            printf("pthread_create error\n");
            fflush(stdout);
          }
        }
        for (int i = 0; i < NUM_THREADS; i++)
        {
          pthread_join(pthread[i], NULL);
        }
        // print_time("");
        for (int i = 0; i < NUM_THREADS; i++)
        {
          memcpy(&(patterns[pat_idx][0]), &(th_patterns[i][0][0]), p_pat_idxs[i] * (2 * pattern_upto + 3) * sizeof(int));
          pat_idx += p_pat_idxs[i];
        }
        pat_h_n_idxs[h][n - 1][1] = pat_idx;

        printf("    n %d  h %d  : %8d", n, h, pat_h_n_idxs[h][n - 1][1] - pat_h_n_idxs[h][n - 1][0]); 
        print_time("");
        // printf("%d %d\n", pat_h_n_idxs[h][n - 1][0], pat_h_n_idxs[h][n - 1][1]);
        if (pat_idx == max_element)
          break;
      }
      printf("    ----\n");
      if (pat_idx == max_element)
        break;
    }
    //// solve CG-LP
    if (pat_h_n_idxs[0][nn - 1][0] == pat_h_n_idxs[2][nn - 1][1])
      break;
    solve_lp_get_duals(nn);
  }
  /*  END of ENUM - CG */

  /* FIRST IP */
  cleanup_solve();
  initialize_solve();
  solve();
  cleanup_solve();

  get_sequenced_solution();

  /* IMPROVE */
  initialize_improve();
  for (int i = 0; i < NUM_IMPROVE_ITER; i++)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if ((finish.tv_sec - start.tv_sec) > time_limit - 0.5 || imp_obj_steady > IMP_OBJ_STEADY_LIMIT)
      break;
    improve();
  }
  cleanup_improve();

  // FREE MEMORY
  free(p_pat_idxs);
  for (int i = 0; i < num_riders; i++)
  {
    for (int j = 0; j < 2 * num_orders; j++)
    {
      free(rider_time[i][j]);
    }
    free(rider_time[i]);
  }
  free(rider_time);
  free(patterns);
  // hashmap_free(map);
  free_permutations();
  for (int h = 0; h < num_riders; h++)
  {
    for (int n = 0; n < pattern_upto; n++)
    {
      free(pat_h_n_idxs[h][n]);
    }
    free(pat_h_n_idxs[h]);
  }
  free(pat_h_n_idxs);
  free(th_num_patterns);
  for (int i = 0; i < NUM_THREADS; i++)
  {
    free(th_patterns_data[i]);
    free(th_patterns[i]);
    // pthread_cancel(pthread[i]);
  }
  free(th_patterns);
  free(th_patterns_data);
  free(trt);
  free(costs);
  // FREE MEMORY END

  num_gen_patts[0] = num_x_sol;
  num_gen_patts[1] = MAX_ORDER_IN_PATT;
  // trt = (int *)realloc(trt, pat_idx * (2 * pattern_upto+3) * sizeof(int));
  return seq_solution;
}

void free_patterns()
{
  free(trt);
}

inline double rider_capa(int rider_type)
{
  return rider_arr[rider_type][0];
}
inline double rider_var_cost(int rider_type)
{
  return rider_arr[rider_type][1];
}
inline double rider_fixed_cost(int rider_type)
{
  return rider_arr[rider_type][2];
}
inline double rider_speed(int rider_type)
{
  return rider_arr[rider_type][3];
}
inline double rider_service_time(int rider_type)
{
  return rider_arr[rider_type][4];
}
inline double rider_avail_num(int rider_type)
{
  return rider_arr[rider_type][5];
}
inline int order_ready_time(int order_num)
{
  return order_arr[order_num][0];
}
inline int order_deadline(int order_num)
{
  return order_arr[order_num][1];
}
inline int order_volume(int order_num)
{
  return order_arr[order_num][2];
}
inline int dist(int i, int j)
{
  return dist_arr[i * (2 * num_orders) + j];
}

void *p_enum(void *data) // TODO:
{
  // pid_t pid = getpid();
  // pthread_t tid = pthread_self();
  struct th_data *th_data = (struct th_data *)data;
  // printf("th %d  pid %d  tid %d  running\n", th_data->th_id, pid, tid);
  // printf("  n %d  h %d  idx_from %d  idx_to %d\n", th_data->n, th_data->h, th_data->idx_from, th_data->idx_to);
  if (th_data->n == 2)
  {
    *(th_data->p_pat_idx) = extend(th_data->th_id, th_data->n, th_data->h, th_data->idx_from, th_data->idx_to);
  }
  else if (th_data->n < ENUM_PAT_HEUR_FROM)
  {
    *(th_data->p_pat_idx) = extend_using_dual(th_data->th_id, th_data->n, th_data->h, th_data->idx_from, th_data->idx_to);
  }
  else
  {
    *(th_data->p_pat_idx) = extend_using_dual_heur(th_data->th_id, th_data->n, th_data->h, th_data->idx_from, th_data->idx_to);
  }
  // printf("--------------------------------------\n");
  return NULL;
}

int extend(int th_id, int n, int h, int idx_from, int idx_to)
{
  // printf("th %d  n %d  h %d\n", th_id, n, h);
  // printf("th%d called ", th_id); print_time("");
  int th_pat_idx = 0;
  int min_last_pickup_time = 1e9;
  int *pickup_dists = malloc(factorial[n] * sizeof(int));
  int *pickup_times = malloc(factorial[n] * sizeof(int));
  int *delivery_dists = malloc(factorial[n] * sizeof(int));
  int *delivery_times = malloc(factorial[n] * sizeof(int));
  int *base_seq = malloc(n * sizeof(int));
  // char *temp_id; // to check pattern with id is in hashmap
  int *perm, *d_perm, *p_perm;
  int front, end;
  int *sorted_idxs_p = (int *)calloc(factorial[n], sizeof(int));
  int *sorted_idxs_d = (int *)calloc(factorial[n], sizeof(int));
  // printf("th%d init \n", th_id);
  for (int idx = idx_from; idx < idx_to; idx++)
  {
    // printf("th %d idx %d  here\n", th_id, idx);
    int *base_pat = patterns[idx];
    int max_order = -1;
    for (int i = 1; i <= n - 1; i++)
      max_order = (base_pat[i] > max_order) ? base_pat[i] : max_order;
    int base_pat_volume = 0;
    for (int i = 1; i <= n - 1; i++)
      base_pat_volume += order_volume(base_pat[i]);
    for (int k = max_order + 1; k < num_orders; k++)
    {
      // printf("th %d idx %d k %d  here\n", th_id, idx, k);
      // check capacity
      if (order_volume(k) + base_pat_volume > rider_capa(h) + 1e-5)
        continue;

      // check subset feasibility
      bool subset_feasible = true;
      if (n > 2)
      {
        for (int i = 1; i < n; i++)
        {
          if (!compat[h][base_pat[i]][k])
          {
            subset_feasible = false;
            break;
          }
        }
      }
      if (!subset_feasible)
        continue;

      // check route feasibility
      int min_deadline = order_deadline(k);
      int min_deadline_order = k;
      for (int i = 1; i < n; i++)
      {
        min_deadline = (order_deadline(base_pat[i]) < min_deadline) ? order_deadline(base_pat[i]) : min_deadline;
        if (min_deadline == order_deadline(base_pat[i]))
          min_deadline_order = base_pat[i];
      }
      min_last_pickup_time = 1e9;
      for (int i = 1; i <= n; i++)
        base_seq[i - 1] = base_pat[i];
      base_seq[n - 1] = k;

      //// pickup sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        pickup_dists[seq_idx] = 0;
        pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);
        if (pickup_times[seq_idx] > min_deadline)
        {
          sorted_idxs_p[end--] = seq_idx;
          pickup_dists[seq_idx] = 1e9;
          continue;
        }
        for (int i = 1; i < n; i++)
        {
          pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
          pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
          if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
          {
            pickup_dists[seq_idx] = 1e9;
            break;
          }
          pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
        }
        if (pickup_dists[seq_idx] >= 1e9)
        {
          sorted_idxs_p[end--] = seq_idx;
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
            break;
        }
        memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
        sorted_idxs_p[idx] = seq_idx;
        front += 1;
        // sorted_idxs_p[front++] = seq_idx;
        min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
      }
      if (min_last_pickup_time >= 1e9)
        continue;

      //// delivery sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        delivery_dists[seq_idx] = 0;
        delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);
        if (delivery_times[seq_idx] < min_last_pickup_time)
        {
          delivery_dists[seq_idx] = 1e9;
          sorted_idxs_d[end--] = seq_idx;
          continue;
        }
        for (int i = n - 1; i > 0; i--)
        {
          delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
          delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
          if (delivery_times[seq_idx] < min_last_pickup_time)
          {
            delivery_dists[seq_idx] = 1e9;
            break;
          }
          delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
        }
        if (delivery_dists[seq_idx] >= 1e9)
        {
          sorted_idxs_d[end--] = seq_idx;
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
            break;
        }
        memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
        sorted_idxs_d[idx] = seq_idx;
        front += 1;
        // sorted_idxs_d[front++] = seq_idx;
      }

      //// Find best combination
      int min_dist = 1e9;
      int p_idx, d_idx, best_p_idx, best_d_idx;
      for (int i = 0; i < factorial[n]; i++)
      {
        p_idx = sorted_idxs_p[i];
        if (pickup_dists[p_idx] >= 1e9)
          break;
        // bool checker = false;
        p_perm = get_nth_permutation_of_size(p_idx, n);
        for (int j = 0; j < factorial[n]; j++)
        {
          d_idx = sorted_idxs_d[j];
          if (delivery_dists[d_idx] >= 1e9)
            break;
          if (pickup_dists[p_idx] + delivery_dists[d_idx] > min_dist)
          {
            // checker = true;
            break;
          }
          d_perm = get_nth_permutation_of_size(d_idx, n);
          if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[base_pat[0]]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders) < min_dist))
          {
            min_dist = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders);
            best_p_idx = p_idx;
            best_d_idx = d_idx;
          }
        }
        // if (checker)
        //   break;
      }

      //// add if feasible
      if (min_dist < 1e9)
      {
        th_patterns[th_id][th_pat_idx][0] = n;
        p_perm = get_nth_permutation_of_size(best_p_idx, n);
        d_perm = get_nth_permutation_of_size(best_d_idx, n);
        for (int i = 1; i <= n; i++)
        {
          th_patterns[th_id][th_pat_idx][i] = base_seq[p_perm[i - 1]];
          th_patterns[th_id][th_pat_idx][i + n] = base_seq[d_perm[i - 1]];
        }
        th_patterns[th_id][th_pat_idx][2 * pattern_upto + 1] = 100 * rider_fixed_cost(h) + rider_var_cost(h) * min_dist;
        th_patterns[th_id][th_pat_idx][2 * pattern_upto + 2] = h;
        th_pat_idx += 1;
      }
      if (th_pat_idx == MAX_TH_PATTERNS || time_limit_exceeded())
        break;
    }
    if (th_pat_idx == MAX_TH_PATTERNS || time_limit_exceeded())
      break;
  }
  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  // printf("th%d done gen %d ", th_id, th_pat_idx); print_time("");
  return th_pat_idx;
}

int extend_using_dual(int th_id, int n, int h, int idx_from, int idx_to)
{
  // printf("th %d  n %d  h %d\n", th_id, n, h);
  // printf("th%d called ", th_id); print_time("");
  int th_pat_idx = 0;
  int min_last_pickup_time = 1e9;
  int *pickup_dists = malloc(factorial[n] * sizeof(int));
  int *pickup_times = malloc(factorial[n] * sizeof(int));
  int *delivery_dists = malloc(factorial[n] * sizeof(int));
  int *delivery_times = malloc(factorial[n] * sizeof(int));
  int *base_seq = malloc(n * sizeof(int));
  // char *temp_id; // to check pattern with id is in hashmap
  int *perm, *d_perm, *p_perm;
  int front, end;
  int *sorted_idxs_p = (int *)calloc(factorial[n], sizeof(int));
  int *sorted_idxs_d = (int *)calloc(factorial[n], sizeof(int));
  // printf("th%d init \n", th_id);
  double dual_assign_max = -1e6;
  for (int i = 0; i < num_orders; i++)
    dual_assign_max = (dual_assign[i] > dual_assign_max) ? dual_assign[i] : dual_assign_max;
  for (int idx = idx_from; idx < idx_to; idx++)
  {
    // printf("th %d idx %d  here\n", th_id, idx);
    int *base_pat = patterns[idx];
    int max_order = -1;
    for (int i = 1; i <= n - 1; i++)
      max_order = (base_pat[i] > max_order) ? base_pat[i] : max_order;
    int base_pat_volume = 0;
    for (int i = 1; i <= n - 1; i++)
      base_pat_volume += order_volume(base_pat[i]);

    // check reduced cost feasibility
    double rc_lb = ((double)base_pat[2 * pattern_upto + 1]) / (100 * num_orders) - dual_cardi[h];
    for (int i = 1; i < n; i++)
      rc_lb -= dual_assign[base_pat[i]];
    if (rc_lb > dual_assign_max)
      continue;
    for (int k = max_order + 1; k < num_orders; k++)
    {
      if (rc_lb - dual_assign[k] > 0)
        continue;

      if (((double)base_pat[2 * pattern_upto + 1]) / (100 * num_orders) / n > (objval / num_orders) * ENUM_PAT_AVG_COST_THSD) // FIXME:
          continue; 

      // check capacity
      if (order_volume(k) + base_pat_volume > rider_capa(h) + 1e-5)
        continue;

      // check subset feasibility
      bool subset_feasible = true;
      if (n > 2)
      {
        for (int i = 1; i < n; i++)
        {
          if (!compat[h][base_pat[i]][k])
          {
            subset_feasible = false;
            break;
          }
        }
      }
      if (!subset_feasible)
        continue;

      // check route feasibility
      int min_deadline = order_deadline(k);
      int min_deadline_order = k;
      for (int i = 1; i < n; i++)
      {
        min_deadline = (order_deadline(base_pat[i]) < min_deadline) ? order_deadline(base_pat[i]) : min_deadline;
        if (min_deadline == order_deadline(base_pat[i]))
          min_deadline_order = base_pat[i];
      }
      min_last_pickup_time = 1e9;
      for (int i = 1; i <= n; i++)
        base_seq[i - 1] = base_pat[i];
      base_seq[n - 1] = k;

      //// pickup sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        pickup_dists[seq_idx] = 0;
        pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);
        if (pickup_times[seq_idx] > min_deadline)
        {
          sorted_idxs_p[end--] = seq_idx;
          pickup_dists[seq_idx] = 1e9;
          continue;
        }
        for (int i = 1; i < n; i++)
        {
          pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
          pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
          if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
          {
            pickup_dists[seq_idx] = 1e9;
            break;
          }
          pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
        }
        if (pickup_dists[seq_idx] >= 1e9)
        {
          sorted_idxs_p[end--] = seq_idx;
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
            break;
        }
        memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
        sorted_idxs_p[idx] = seq_idx;
        front += 1;
        // sorted_idxs_p[front++] = seq_idx;
        min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
      }
      if (min_last_pickup_time >= 1e9)
        continue;

      //// delivery sequence calculation
      front = 0;
      end = factorial[n] - 1;
      for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
      {
        perm = get_nth_permutation_of_size(seq_idx, n);
        delivery_dists[seq_idx] = 0;
        delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);
        if (delivery_times[seq_idx] < min_last_pickup_time)
        {
          delivery_dists[seq_idx] = 1e9;
          sorted_idxs_d[end--] = seq_idx;
          continue;
        }
        for (int i = n - 1; i > 0; i--)
        {
          delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
          delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
          if (delivery_times[seq_idx] < min_last_pickup_time)
          {
            delivery_dists[seq_idx] = 1e9;
            break;
          }
          delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
        }
        if (delivery_dists[seq_idx] >= 1e9)
        {
          sorted_idxs_d[end--] = seq_idx;
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
            break;
        }
        memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
        sorted_idxs_d[idx] = seq_idx;
        front += 1;
        // sorted_idxs_d[front++] = seq_idx;
      }

      //// Find best combination
      int min_dist = 1e9;
      int p_idx, d_idx, best_p_idx, best_d_idx;
      for (int i = 0; i < factorial[n]; i++)
      {
        p_idx = sorted_idxs_p[i];
        if (pickup_dists[p_idx] >= 1e9)
          break;
        // bool checker = false;
        p_perm = get_nth_permutation_of_size(p_idx, n);
        for (int j = 0; j < factorial[n]; j++)
        {
          d_idx = sorted_idxs_d[j];
          if (delivery_dists[d_idx] >= 1e9)
            break;
          if (pickup_dists[p_idx] + delivery_dists[d_idx] > min_dist)
          {
            // checker = true;
            break;
          }
          d_perm = get_nth_permutation_of_size(d_idx, n);
          if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[base_pat[0]]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders) < min_dist))
          {
            min_dist = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders);
            best_p_idx = p_idx;
            best_d_idx = d_idx;
          }
        }
        // if (checker)
        //   break;
      }

      //// add if feasible
      if (min_dist < 1e9)
      {
        int candiate_cost = 100 * rider_fixed_cost(h) + rider_var_cost(h) * min_dist;
        
        if (((double)candiate_cost) / (num_orders * 100) / n > (objval / num_orders) * ENUM_PAT_AVG_COST_THSD) // FIXME:
          continue; 

        double reduced_cost = candiate_cost / (num_orders * 100) - dual_cardi[h];
        for (int j = 1; j < n; j++)
        {
          reduced_cost -= dual_assign[base_pat[j]];
        }
        reduced_cost -= dual_assign[k];

        // printf("reduced_cost: %f\n", reduced_cost);

        if (reduced_cost < -1e-5)
        {
          th_patterns[th_id][th_pat_idx][0] = n;
          p_perm = get_nth_permutation_of_size(best_p_idx, n);
          d_perm = get_nth_permutation_of_size(best_d_idx, n);
          for (int i = 1; i <= n; i++)
          {
            th_patterns[th_id][th_pat_idx][i] = base_seq[p_perm[i - 1]];
            th_patterns[th_id][th_pat_idx][i + n] = base_seq[d_perm[i - 1]];
          }
          th_patterns[th_id][th_pat_idx][2 * pattern_upto + 1] = 100 * rider_fixed_cost(h) + rider_var_cost(h) * min_dist;
          th_patterns[th_id][th_pat_idx][2 * pattern_upto + 2] = h;
          th_pat_idx += 1;
        }
      }
      if (th_pat_idx == MAX_TH_PATTERNS || time_limit_exceeded())
        break;
    }
    if (th_pat_idx == MAX_TH_PATTERNS || time_limit_exceeded())
      break;
  }
  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  // printf("th%d done gen %d ", th_id, th_pat_idx); print_time("");
  return th_pat_idx;
}

int extend_using_dual_heur(int th_id, int n, int h, int idx_from, int idx_to)
{
  // printf("th %d  n %d  h %d\n", th_id, n, h);
  // printf("th%d called ", th_id); print_time("");
  int th_pat_idx = 0;
  int min_last_pickup_time = 1e9;
  int *pickup_dists = malloc((n+1) * sizeof(int));
  int *pickup_times = malloc((n+1) * sizeof(int));
  int *delivery_dists = malloc((n+1) * sizeof(int));
  int *delivery_times = malloc((n+1) * sizeof(int));
  int *base_seq = malloc(n * sizeof(int));
  // char *temp_id; // to check pattern with id is in hashmap
  int *perm, *d_perm, *p_perm;
  int front, end;
  int *sorted_idxs_p = (int *)calloc((n+1), sizeof(int));
  int *sorted_idxs_d = (int *)calloc((n+1), sizeof(int));
  // printf("th%d init \n", th_id);
  double dual_assign_max = -1e6;
  for (int i = 0; i < num_orders; i++)
    dual_assign_max = (dual_assign[i] > dual_assign_max) ? dual_assign[i] : dual_assign_max;
  for (int idx = idx_from; idx < idx_to; idx++)
  {
    // printf("th %d idx %d  here\n", th_id, idx);
    int *base_pat = patterns[idx];
    int max_order = -1;
    for (int i = 1; i <= n - 1; i++)
      max_order = (base_pat[i] > max_order) ? base_pat[i] : max_order;
    int base_pat_volume = 0;
    for (int i = 1; i <= n - 1; i++)
      base_pat_volume += order_volume(base_pat[i]);

    // check reduced cost feasibility
    double rc_lb = ((double)base_pat[2 * pattern_upto + 1]) / (100 * num_orders) - dual_cardi[h];
    for (int i = 1; i < n; i++)
      rc_lb -= dual_assign[base_pat[i]];
    if (rc_lb > dual_assign_max)
      continue;
    for (int k = max_order + 1; k < num_orders; k++)
    {
      if (rc_lb - dual_assign[k] > 10 * ENUM_PAT_HEUR_ADD_THSD)
        continue;

      if (((double)base_pat[2 * pattern_upto + 1]) / (100 * num_orders) / n > (objval / num_orders) * (ENUM_PAT_AVG_COST_THSD + ENUM_PAT_HEUR_ADD_THSD)) // FIXME:
          continue; 

      // check capacity
      if (order_volume(k) + base_pat_volume > rider_capa(h) + 1e-5)
        continue;

      // check subset feasibility
      bool subset_feasible = true;
      if (n > 2)
      {
        for (int i = 1; i < n; i++)
        {
          if (!compat[h][base_pat[i]][k])
          {
            subset_feasible = false;
            break;
          }
        }
      }
      if (!subset_feasible)
        continue;

      // check route feasibility
      int min_deadline = order_deadline(k);
      int min_deadline_order = k;
      for (int i = 1; i < n; i++)
      {
        min_deadline = (order_deadline(base_pat[i]) < min_deadline) ? order_deadline(base_pat[i]) : min_deadline;
        if (min_deadline == order_deadline(base_pat[i]))
          min_deadline_order = base_pat[i];
      }
      min_last_pickup_time = 1e9;
      for (int i = 1; i <= n; i++)
        base_seq[i - 1] = base_pat[i];
      base_seq[n - 1] = k;
      
      //// pickup sequence calculation
      front = 0;
      end = (n+1) - 1;
      for (int seq_idx = 0; seq_idx < (n); seq_idx++)
      {
        perm = get_nth_permutation_of_size_heur(seq_idx, n);
        pickup_dists[seq_idx] = 0;
        pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);
        if (pickup_times[seq_idx] > min_deadline)
        {
          sorted_idxs_p[end--] = seq_idx;
          pickup_dists[seq_idx] = 1e9;
          free(perm);
          continue;
        }
        for (int i = 1; i < n; i++)
        {
          pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
          pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
          if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
          {
            pickup_dists[seq_idx] = 1e9;
            break;
          }
          pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
        }
        if (pickup_dists[seq_idx] >= 1e9)
        {
          sorted_idxs_p[end--] = seq_idx;
          free(perm);
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
            break;
        }
        memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
        sorted_idxs_p[idx] = seq_idx;
        front += 1;
        // sorted_idxs_p[front++] = seq_idx;
        min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
        free(perm);
      }
      if (min_last_pickup_time >= 1e9)
        continue;

      //// delivery sequence calculation
      front = 0;
      end = (n+1) - 1;
      for (int seq_idx = 0; seq_idx < (n); seq_idx++)
      {
        perm = get_nth_permutation_of_size_heur(seq_idx, n);
        delivery_dists[seq_idx] = 0;
        delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);
        if (delivery_times[seq_idx] < min_last_pickup_time)
        {
          delivery_dists[seq_idx] = 1e9;
          sorted_idxs_d[end--] = seq_idx;
          free(perm);
          continue;
        }
        for (int i = n - 1; i > 0; i--)
        {
          delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
          delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
          if (delivery_times[seq_idx] < min_last_pickup_time)
          {
            delivery_dists[seq_idx] = 1e9;
            break;
          }
          delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
        }
        if (delivery_dists[seq_idx] >= 1e9)
        {
          sorted_idxs_d[end--] = seq_idx;
          free(perm);
          continue;
        }
        int idx = 0;
        for (; idx < front; idx++)
        {
          if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
            break;
        }
        memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
        sorted_idxs_d[idx] = seq_idx;
        front += 1;
        free(perm);
        // sorted_idxs_d[front++] = seq_idx;
      }

      //// Find best combination
      int min_dist = 1e9;
      int p_idx, d_idx, best_p_idx, best_d_idx;
      for (int i = 0; i < (n+1); i++)
      {
        p_idx = sorted_idxs_p[i];
        if (pickup_dists[p_idx] >= 1e9)
          break;
        // bool checker = false;
        p_perm = get_nth_permutation_of_size_heur(p_idx, n);
        for (int j = 0; j < (n+1); j++)
        {
          d_idx = sorted_idxs_d[j];
          if (delivery_dists[d_idx] >= 1e9)
            break;
          if (pickup_dists[p_idx] + delivery_dists[d_idx] > min_dist)
          {
            // checker = true;
            break;
          }
          d_perm = get_nth_permutation_of_size_heur(d_idx, n);
          if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[base_pat[0]]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders) < min_dist))
          {
            min_dist = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[base_pat[0]]], base_seq[d_perm[0]] + num_orders);
            best_p_idx = p_idx;
            best_d_idx = d_idx;
          }
          free(d_perm);
        }
        free(p_perm);
        // if (checker)
        //   break;
      }

      //// add if feasible
      if (min_dist < 1e9)
      {
        int candiate_cost = 100 * rider_fixed_cost(h) + rider_var_cost(h) * min_dist;
        
        if (((double)candiate_cost) / (num_orders * 100) / n > (objval / num_orders) * (ENUM_PAT_AVG_COST_THSD + ENUM_PAT_HEUR_ADD_THSD)) // FIXME:
          continue; 

        double reduced_cost = candiate_cost / (num_orders * 100) - dual_cardi[h];
        for (int j = 1; j < n; j++)
        {
          reduced_cost -= dual_assign[base_pat[j]];
        }
        reduced_cost -= dual_assign[k];

        // printf("reduced_cost: %f\n", reduced_cost);

        if (reduced_cost < ENUM_PAT_HEUR_ADD_THSD * 10 - 1e-5) // FIXME:
        {
          th_patterns[th_id][th_pat_idx][0] = n;
          p_perm = get_nth_permutation_of_size_heur(best_p_idx, n);
          d_perm = get_nth_permutation_of_size_heur(best_d_idx, n);
          for (int i = 1; i <= n; i++)
          {
            th_patterns[th_id][th_pat_idx][i] = base_seq[p_perm[i - 1]];
            th_patterns[th_id][th_pat_idx][i + n] = base_seq[d_perm[i - 1]];
          }
          th_patterns[th_id][th_pat_idx][2 * pattern_upto + 1] = 100 * rider_fixed_cost(h) + rider_var_cost(h) * min_dist;
          th_patterns[th_id][th_pat_idx][2 * pattern_upto + 2] = h;
          th_pat_idx += 1;
          free(p_perm);
          free(d_perm);
        }
        // else
        // {
        //   printf("%f\n", reduced_cost);
        // }
      }
      if (th_pat_idx == MAX_TH_PATTERNS || time_limit_exceeded())
        break;
    }
    if (th_pat_idx == MAX_TH_PATTERNS || time_limit_exceeded())
      break;
  }
  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  // printf("th%d done gen %d ", th_id, th_pat_idx); print_time("");
  return th_pat_idx;
}
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
//
//                                       SOLVER CODE
//
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////

// Structure to hold element and its index
typedef struct
{
  // double cost;
  double rcost;
  int index;
} Element;

// Swap function for heap operations
void swap(Element *a, Element *b)
{
  Element temp = *a;
  *a = *b;
  *b = temp;
}

// Heapify function to maintain the max-heap property
void heapify(Element heap[], int n, int i)
{
  int largest = i;
  int left = 2 * i + 1;
  int right = 2 * i + 2;

  if (left < n && heap[left].rcost > heap[largest].rcost)
    largest = left;

  if (right < n && heap[right].rcost > heap[largest].rcost)
    largest = right;

  if (largest != i)
  {
    swap(&heap[i], &heap[largest]);
    heapify(heap, n, largest);
  }
}

// Function to build a max-heap
void buildHeap(Element heap[], int n)
{
  for (int i = n / 2 - 1; i >= 0; i--)
    heapify(heap, n, i);
}
// END OF HEAP CODE

// Comparison function for sorting in ascending order
int compare(const void *a, const void *b)
{
  // return ((Element *)a)->rcost - ((Element *)b)->rcost;
  if (((Element *)a)->rcost < ((Element *)b)->rcost)
    return -1;
  else if (((Element *)a)->rcost > ((Element *)b)->rcost)
    return 1;
  else
    return 0;
}
// END OF qsort CODE

// TODO:
void initialize_solve()
{
  // setup initial restricted master problem
  x_idx = (int *)malloc(MAX_COL * sizeof(int));
  num_x = 0;

  prob = XPRBnewprob("RMP");
  assign = malloc(num_orders * sizeof(XPRBctr));
  cardi = malloc(num_riders * sizeof(XPRBctr));

  dual_assign = (double *)malloc(num_orders * sizeof(double));
  dual_cardi = (double *)malloc(num_riders * sizeof(double));

  //// initial RMP with dlength-1 patterns
  obj = XPRBnewctr(prob, "obj", XPRB_N); // XPRB_N indicate this is for objective
  for (int i = 0; i < num_orders; i++)   // iterate over orders
  {
    assign[i] = XPRBnewctr(prob, XPRBnewname("assign_%d", i), XPRB_E);
    XPRBaddterm(assign[i], NULL, 1);
  }
  for (int i = 0; i < num_riders; i++) // iterate over riders
  {
    cardi[i] = XPRBnewctr(prob, XPRBnewname("cardi_%d", i), XPRB_L);
    XPRBaddterm(cardi[i], NULL, rider_avail_num(i));
  }
  XPRBsetobj(prob, obj);

  for (int i = pat_h_n_idxs[0][0][0]; i < pat_h_n_idxs[2][0][1]; i++)
  {
    costs[i] = ((double)patterns[i][2 * pattern_upto + 1]) / (num_orders * 100);
    // printf("costs[%d] = %f\n", i, costs[i]);
  }

  for (int i = 0; i < pat_h_n_idxs[0][1][0]; i++) // iterate over length 1 patterns
  {
    x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    x_idx[i] = i;
    XPRBaddterm(obj, x[i], costs[i]);
    XPRBaddterm(assign[patterns[i][1]], x[i], 1);
    XPRBaddterm(cardi[patterns[i][2 * pattern_upto + 2]], x[i], 1);
    num_x += 1;
  }
}

void cleanup_solve()
{
  XPRBdelprob(prob);
  free(assign);
  free(cardi);
  free(dual_assign);
  free(dual_cardi);
  free(x_idx);
}

void add_pattern_greedy(int n)
{
  /* Option 1 */
  // Element* sorted_idxs = (Element *)malloc((pat_h_n_idxs[2][n - 1][1] - pat_h_n_idxs[0][n - 1][0]) * sizeof(Element));

  // for (int i = pat_h_n_idxs[0][n - 1][0]; i < pat_h_n_idxs[2][n - 1][1]; i++)
  // {
  //   sorted_idxs[i - pat_h_n_idxs[0][n - 1][0]].index = i;
  //   sorted_idxs[i - pat_h_n_idxs[0][n - 1][0]].rcost = costs[i];
  // }
  // qsort(sorted_idxs, pat_h_n_idxs[2][n - 1][1] - pat_h_n_idxs[0][n - 1][0], sizeof(Element), compare);

  // for (int i = 0; i < 1000; i++)
  // {
  //   int idx = sorted_idxs[i].index;
  //   x[num_x] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
  //   x_idx[num_x] = idx;
  //   XPRBaddterm(obj, x[num_x], costs[idx]);
  //   for (int j = 1; j < patterns[idx][0] + 1; j++)
  //     XPRBaddterm(assign[patterns[idx][j]], x[num_x], 1);
  //   XPRBaddterm(cardi[patterns[idx][2 * pattern_upto + 2]], x[num_x], 1);
  //   num_x += 1;
  // }

  // free(sorted_idxs);

  /* Option 2 */
  int is_added[num_orders];
  int num_used[num_riders];
  for (int i = 0; i < num_orders; i++)
    is_added[i] = 0;
  for (int i = 0; i < num_riders; i++)
    num_used[i] = 0;

  Element *sorted_idxs = (Element *)malloc((pat_idx) * sizeof(Element));

  // for (int i = pat_h_n_idxs[0][n - 1][0]; i < pat_h_n_idxs[2][n - 1][1]; i++)
  for (int i = 0; i < pat_idx; i++)
  {
    sorted_idxs[i].index = i;
    sorted_idxs[i].rcost = costs[i] / patterns[i][0];
  }
  qsort(sorted_idxs, pat_idx, sizeof(Element), compare);

  double temp_objval = 0;
  int itercount = 1;
  for (int iter = 0; iter < itercount; iter++)
  {
    for (int i = 0; i < (pat_idx / (itercount - iter)); i++)
    {
      int idx = sorted_idxs[i].index;
      // printf("idxn %d:  %f  %f  %f\n", idx, costs[idx], costs[idx]/ patterns[idx][0], sorted_idxs[i].rcost);
      if (num_used[patterns[idx][2 * pattern_upto + 2]] >= rider_avail_num(patterns[idx][2 * pattern_upto + 2]))
        continue;

      bool is_feasible = true;
      for (int j = 1; j <= patterns[idx][0]; j++)
      {
        if (is_added[patterns[idx][j]] == 1)
        {
          is_feasible = false;
          break;
        }
      }
      if (!is_feasible)
        continue;

      // printf("n %d:  %f  %f\n   ", patterns[idx][0], costs[idx], sorted_idxs[i].rcost);
      // for (int j = 0; j < 2 * pattern_upto + 3; j++)
      //   printf("%d ", patterns[idx][j]);
      // printf("\n");
      temp_objval += costs[idx];

      x[num_x] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
      x_idx[num_x] = idx;
      XPRBaddterm(obj, x[num_x], costs[idx]);
      for (int j = 1; j <= patterns[idx][0]; j++)
        XPRBaddterm(assign[patterns[idx][j]], x[num_x], 1);
      XPRBaddterm(cardi[patterns[idx][2 * pattern_upto + 2]], x[num_x], 1);
      num_x += 1;

      for (int j = 1; j <= patterns[idx][0]; j++)
        is_added[patterns[idx][j]] = 1;
      num_used[patterns[idx][2 * pattern_upto + 2]] += 1;
    }
  }
  printf("Temp objval: %f\n", temp_objval);

  for (int j = 0; j < num_orders; j++)
    if (is_added[j] == 0)
      printf("order %d: %d\n", j, is_added[j]);
  // for (int j = 0; j < num_riders; j++)
  //   printf("rider %d: %d  <  %f\n", j, num_used[j], rider_avail_num(j));

  free(sorted_idxs);
}

void solve_lp_get_duals(int n)
{
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  printf("Start CG for n = %d", n);
  print_time("");
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  // calculate costs
  for (int i = pat_h_n_idxs[0][n - 1][0]; i < pat_h_n_idxs[2][n - 1][1]; i++)
  {
    costs[i] = ((double)patterns[i][2 * pattern_upto + 1]) / (num_orders * 100);
    // printf("costs[%d] = %f\n", i, costs[i]);
  }

  if (time_limit_exceeded())
    return;

  // re-declare XPRBprob with last optimal columns
  if (n >= 3)
  {
    int *temp_x_idx = (int *)malloc(MAX_COL * sizeof(int));
    int temp_num_x = 0;
    for (int i = 0; i < num_x; i++)
    {
      if (XPRBgetsol(x[i]) > 1e-5)
      {
        temp_x_idx[temp_num_x] = x_idx[i];
        temp_num_x += 1;
      }
    }
    free(x_idx);
    x_idx = temp_x_idx;
    num_x = temp_num_x;

    XPRBdelprob(prob);
    free(assign);
    free(cardi);

    prob = XPRBnewprob("RMP");
    assign = malloc(num_orders * sizeof(XPRBctr));
    cardi = malloc(num_riders * sizeof(XPRBctr));

    dual_assign = (double *)malloc(num_orders * sizeof(double));
    dual_cardi = (double *)malloc(num_riders * sizeof(double));

    //// initial RMP with dlength-1 patterns
    obj = XPRBnewctr(prob, "obj", XPRB_N); // XPRB_N indicate this is for objective
    for (int i = 0; i < num_orders; i++)   // iterate over orders
    {
      assign[i] = XPRBnewctr(prob, XPRBnewname("assign_%d", i), XPRB_E);
      XPRBaddterm(assign[i], NULL, 1);
    }
    for (int i = 0; i < num_riders; i++) // iterate over riders
    {
      cardi[i] = XPRBnewctr(prob, XPRBnewname("cardi_%d", i), XPRB_L);
      XPRBaddterm(cardi[i], NULL, rider_avail_num(i));
    }
    XPRBsetobj(prob, obj);

    for (int i = 0; i < num_x; i++)
    {
      x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
      XPRBaddterm(obj, x[i], costs[x_idx[i]]);
      for (int j = 1; j < patterns[x_idx[i]][0] + 1; j++)
        XPRBaddterm(assign[patterns[x_idx[i]][j]], x[i], 1);
      XPRBaddterm(cardi[patterns[x_idx[i]][2 * pattern_upto + 2]], x[i], 1);
    }

    for (int i = 0; i < pat_h_n_idxs[0][1][0]; i++) // iterate over length 1 patterns
    {
      x[num_x] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
      x_idx[num_x] = i;
      XPRBaddterm(obj, x[num_x], costs[i]);
      XPRBaddterm(assign[patterns[i][1]], x[num_x], 1);
      XPRBaddterm(cardi[patterns[i][2 * pattern_upto + 2]], x[num_x], 1);
      num_x += 1;
    }
  }
  if (time_limit_exceeded())
    return;

  // add columns heuristically
  add_pattern_greedy(n);
  if (time_limit_exceeded())
    return;
  
  // column generation
  int it = 0;
  Element *sorted_idxs = (Element *)malloc((pat_idx) * sizeof(Element));
  while (true)
  {
    if (time_limit_exceeded())
      break;

    // solving RMP
    XPRBsetmsglevel(prob, 0);
    XPRBlpoptimize(prob, "");
    basis = XPRBsavebasis(prob);
    objval = XPRBgetobjval(prob);
    for (int i = 0; i < num_orders; i++)
      dual_assign[i] = XPRBgetdual(assign[i]);
    for (int i = 0; i < num_riders; i++)
      dual_cardi[i] = XPRBgetdual(cardi[i]);
    printf("%3d  obj %.3f   #c %d   ", it++, objval, num_x);
    print_time("");

    // check profitable columns
    int num_added = 0;
    int it_pat_max = (it < EARLY_ITER) ? IT_PAT_MAX_EARLY : IT_PAT_MAX;
    int n_profitable = 0;
    // printf("pat_dx %d\n", pat_idx);
    for (int i = pat_idx - 1; i >= pat_h_n_idxs[0][n - 1][0]; i--)
    {
      double reduced_cost = costs[i] - dual_cardi[patterns[i][2 * pattern_upto + 2]];
      for (int j = 1; j < patterns[i][0] + 1; j++)
        reduced_cost -= dual_assign[patterns[i][j]];
      if (reduced_cost < -1e-5)
      {
        sorted_idxs[n_profitable].index = i;
        sorted_idxs[n_profitable].rcost = reduced_cost;
        n_profitable += 1;
      }
    }
    qsort(sorted_idxs, n_profitable, sizeof(Element), compare);
    it_pat_max = (n_profitable < it_pat_max) ? n_profitable : it_pat_max;
    for (int idx = 0; idx < it_pat_max; idx++)
    {
      if (sorted_idxs[idx].rcost > -1e-5)
        break;
      int i = sorted_idxs[idx].index;
      x[num_x] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
      x_idx[num_x] = i;
      XPRBaddterm(obj, x[num_x], costs[i]);
      for (int j = 1; j < patterns[i][0] + 1; j++)
        XPRBaddterm(assign[patterns[i][j]], x[num_x], 1);
      XPRBaddterm(cardi[patterns[i][2 * pattern_upto + 2]], x[num_x], 1);
      num_x += 1;
      num_added += 1;
    }

    // report stats
    printf("     #nc %d   time", num_added);
    print_time("");
    if (num_added == 0)
    {
      XPRBdelbasis(basis);
      break;
    }
    XPRBloadmat(prob);
    XPRBloadbasis(basis);
    XPRBdelbasis(basis);
  }
  free(sorted_idxs);
}

// FIXME:
void solve()
{
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  printf("Start solving");
  print_time("");
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  num_x = pat_h_n_idxs[0][1][0];
  // XPRSchgobjsense(prob, XPRS_OBJ_MINIMIZE);
  // XPRBprintprob(prob);

  // add_pattern_greedy(pattern_upto); // Seems like this is not necessary

  // add 1-order patterns
  for (int i = 0; i < pat_h_n_idxs[0][1][0]; i++) // iterate over length 1 patterns
  {
    x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    x_idx[i] = i;
    XPRBaddterm(obj, x[i], costs[i]);
    XPRBaddterm(assign[patterns[i][1]], x[i], 1);
    XPRBaddterm(cardi[patterns[i][2 * pattern_upto + 2]], x[i], 1);
  }

  // column generation
  int it = 0;
  Element *sorted_idxs = (Element *)malloc((pat_idx) * sizeof(Element));
  while (true)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if ((finish.tv_sec - start.tv_sec) > time_limit * (1 - FIRST_IP_RESERVED - IMPROVE_RESERVED))
      break;

    // solving RMP
    XPRBsetmsglevel(prob, 0);
    XPRBlpoptimize(prob, "");
    basis = XPRBsavebasis(prob);
    objval = XPRBgetobjval(prob);
    for (int i = 0; i < num_orders; i++)
      dual_assign[i] = XPRBgetdual(assign[i]);
    for (int i = 0; i < num_riders; i++)
      dual_cardi[i] = XPRBgetdual(cardi[i]);
    printf("%3d  obj %.3f   #c %d   ", it++, objval, num_x);
    print_time("");

    // check profitable columns
    int num_added = 0;
    int it_pat_max = (it < EARLY_ITER) ? IT_PAT_MAX_EARLY : IT_PAT_MAX;
    int n_profitable = 0;
    for (int i = pat_idx - 1; i >= pat_h_n_idxs[0][1][0]; i--)
    {
      double reduced_cost = costs[i] - dual_cardi[patterns[i][2 * pattern_upto + 2]];
      for (int j = 1; j < patterns[i][0] + 1; j++)
        reduced_cost -= dual_assign[patterns[i][j]];
      if (reduced_cost < -1e-5)
      {
        sorted_idxs[n_profitable].index = i;
        sorted_idxs[n_profitable].rcost = reduced_cost;
        n_profitable += 1;
      }
    }
    qsort(sorted_idxs, n_profitable, sizeof(Element), compare);
    it_pat_max = (n_profitable < it_pat_max) ? n_profitable : it_pat_max;
    for (int idx = 0; idx < it_pat_max; idx++)
    {
      if (sorted_idxs[idx].rcost > -1e-5)
        break;
      int i = sorted_idxs[idx].index;
      x[num_x] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
      x_idx[num_x] = i;
      XPRBaddterm(obj, x[num_x], costs[i]);
      for (int j = 1; j < patterns[i][0] + 1; j++)
        XPRBaddterm(assign[patterns[i][j]], x[num_x], 1);
      XPRBaddterm(cardi[patterns[i][2 * pattern_upto + 2]], x[num_x], 1);
      num_x += 1;
      num_added += 1;
    }

    // report stats
    printf("     #nc %d   time", num_added);
    print_time("");
    if (num_added == 0)
    {
      XPRBdelbasis(basis);
      break;
    }
    XPRBloadmat(prob);
    XPRBloadbasis(basis);
    XPRBdelbasis(basis);
  }

  // solving final R-IP
  //// fix variables that has high value in last CG iteration
  for (int i = pat_h_n_idxs[0][1][0]; i < num_x; i++)
  {
    if (XPRBgetsol(x[i]) > 0.75)
      XPRBfixvar(x[i], 1);
  }

  //// gather low reduced cost patterns at the last iteration
  for (int i = 0; i < pat_idx; i++)
  {
    double reduced_cost = costs[i] - dual_cardi[patterns[i][2 * pattern_upto + 2]];
    for (int j = 1; j < patterns[i][0] + 1; j++)
      reduced_cost -= dual_assign[patterns[i][j]];
    sorted_idxs[i].index = i;
    sorted_idxs[i].rcost = reduced_cost;
  }
  qsort(sorted_idxs, pat_idx, sizeof(Element), compare);
  for (int idx = 0; idx < NUM_FINAL_CG_COLS; idx++)
  {
    if (idx >= pat_idx)
      break;
    int i = sorted_idxs[idx].index;
    x[num_x] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", num_x), 0, 1);
    x_idx[num_x] = i;
    XPRBaddterm(obj, x[num_x], costs[i]);
    for (int j = 1; j < patterns[i][0] + 1; j++)
      XPRBaddterm(assign[patterns[i][j]], x[num_x], 1);
    XPRBaddterm(cardi[patterns[i][2 * pattern_upto + 2]], x[num_x], 1);
    num_x += 1;
  }
  free(sorted_idxs);

  //// solve
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  XPRSprob opt_prob = XPRBgetXPRSprob(prob);
  clock_gettime(CLOCK_MONOTONIC, &finish);
  XPRSsetintcontrol(opt_prob, XPRS_MAXTIME, -((int)(time_limit * (1 - IMPROVE_RESERVED) - (finish.tv_sec - start.tv_sec))));

  XPRBsetmsglevel(prob, 0);
  XPRBmipoptimize(prob, "c");
  objval = XPRBgetobjval(prob);
  printf("IP   obj %.3f   stat %d   ", objval, XPRBgetmipstat(prob));
  print_time("");

  // post-processing
  solution = (int *)calloc(num_orders * (2 * pattern_upto + 3), sizeof(int));
  solution_2d = (int **)calloc(num_orders, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
  for (int i = 0; i < num_orders; i++)
  {
    solution_2d[i] = solution + i * (2 * pattern_upto + 3);
  }
  num_x_sol = 0;
  for (int i = 0; i < num_x; i++)
  {
    if (XPRBgetsol(x[i]) > 0.5)
    {
      int idx = x_idx[i];
      memcpy(&(solution_2d[num_x_sol][0]), &(patterns[idx][0]), (2 * pattern_upto + 3) * sizeof(int));
      // printf("%d   ", patterns[idx][pattern_upto + 2]);
      // for (int j = 1; j < patterns[idx][0] + 1; j++)
      // {
      //   printf("%3d ", patterns[idx][j]);
      // }
      // printf("\n");
      num_x_sol += 1;
    }
  }
}

////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
//
//                                       IMPROVE CODE
//
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////

// Define the structure for tree
/* START of Union-Find CODES (union-find is used to check connectivity among nodes) */
// Define the structure for Union-Find
typedef struct
{
  int *parent;
  int *rank;
  int size;
} UnionFind;
// Function to create a new Union-Find structure
UnionFind *create_union_find(int size)
{
  UnionFind *uf = (UnionFind *)malloc(sizeof(UnionFind));
  uf->parent = (int *)malloc(size * sizeof(int));
  uf->rank = (int *)malloc(size * sizeof(int));
  uf->size = size;
  for (int i = 0; i < size; i++)
  {
    uf->parent[i] = i;
    uf->rank[i] = 0;
  }
  return uf;
}
// Function to find the root of an element
int find(UnionFind *uf, int x)
{
  if (uf->parent[x] != x)
  {
    uf->parent[x] = find(uf, uf->parent[x]); // Path compression
  }
  return uf->parent[x];
}
// Function to union two sets
void union_sets(UnionFind *uf, int rootX, int rootY)
{
  if (uf->rank[rootX] > uf->rank[rootY])
  {
    uf->parent[rootY] = rootX;
  }
  else if (uf->rank[rootX] < uf->rank[rootY])
  {
    uf->parent[rootX] = rootY;
  }
  else
  {
    uf->parent[rootY] = rootX;
    uf->rank[rootX]++;
  }
}
// Function to free the Union-Find structure
void free_union_find(UnionFind *uf)
{
  free(uf->parent);
  free(uf->rank);
  free(uf);
}
/* END OF UNION-FIND CODE */

// Define the structure for adjacency list node
typedef struct adj_list_node adj_list_node;
struct adj_list_node
{
  int id;
  adj_list_node *next;
};
// Tree is represented as an adjacency list
typedef struct
{
  adj_list_node **adj_list;
  int size;
  UnionFind *uf;
} Tree;
// Function to create a new tree structure
Tree *create_tree(int size)
{
  Tree *tree = (Tree *)malloc(sizeof(Tree));
  tree->adj_list = (adj_list_node **)malloc(size * sizeof(adj_list_node *));
  tree->size = size;
  for (int i = 0; i < size; i++)
  {
    tree->adj_list[i] = NULL;
  }
  tree->uf = create_union_find(size);
  return tree;
}
// Function to add an edge to the tree
bool add_edge(Tree *tree, int x, int y)
{
  int rootX = find(tree->uf, x);
  int rootY = find(tree->uf, y);
  if (rootX != rootY)
  {
    union_sets(tree->uf, rootX, rootY);
    adj_list_node *node = (adj_list_node *)malloc(sizeof(adj_list_node));
    node->id = y;
    node->next = tree->adj_list[x];
    tree->adj_list[x] = node;
    node = (adj_list_node *)malloc(sizeof(adj_list_node));
    node->id = x;
    node->next = tree->adj_list[y];
    tree->adj_list[y] = node;
    return true;
  }
  return false;
}
// Function to free the tree structure
void free_tree(Tree *tree)
{
  for (int i = 0; i < tree->size; i++)
  {
    adj_list_node *temp = tree->adj_list[i];
    while (temp != NULL)
    {
      adj_list_node *next = temp->next;
      free(temp);
      temp = next;
    }
  }
  free(tree->adj_list);
  free_union_find(tree->uf);
  free(tree);
}

/* hashmap codes */
struct pattern
{
  char *id;
  int idx;
  // bool is_feasible;
};
int pattern_compare(const void *a, const void *b, void *udata)
{
  const struct pattern *ua = a;
  const struct pattern *ub = b;
  return strcmp(ua->id, ub->id);
}
bool pattern_iter(const void *item, void *udata)
{
  const struct pattern *pattern = item;
  printf("%s (is_feas=%d)\n", pattern->id, pattern > 0);
  return true;
}
uint64_t pattern_hash(const void *item, uint64_t seed0, uint64_t seed1)
{
  const struct pattern *pattern = item;
  return hashmap_sip(pattern->id, strlen(pattern->id), seed0, seed1);
}
char *get_id(int *pattern)
{
  char *id = malloc((5 * pattern[0] + 2) * sizeof(char)); // order당 5글자 vehicle에 2글자
  Element *sorted_orders = malloc((pattern[0]) * sizeof(Element));
  for (int i = 1; i < pattern[0] + 1; i++)
  {
    sorted_orders[i - 1].index = pattern[i];
    sorted_orders[i - 1].rcost = pattern[i];
  }
  qsort(sorted_orders, pattern[0], sizeof(Element), compare);
  sprintf(id, "%d", sorted_orders[0].index);
  for (int i = 1; i < pattern[0]; i++)
  {
    sprintf(id, "%s_%d", id, sorted_orders[i].index);
  }
  free(sorted_orders);
  sprintf(id, "%s-%d", id, pattern[2 * MAX_ORDER_IN_PATT + 2]);
  return id;
}
struct pattern *create_pattern(int *pattern, int idx)
{
  struct pattern *patt = (struct pattern *)malloc(sizeof(struct pattern));
  patt->id = get_id(pattern);
  patt->idx = idx;
  return patt;
}
void pattern_free(void *item)
{
  struct pattern *pattern = (struct pattern *)item;
  free(pattern->id);
  pattern->id = NULL;
}
/* end of hashmap codes */

bool check_capa_feasibility(int *pattern)
{
  int n = pattern[0];
  int h = pattern[2 * MAX_ORDER_IN_PATT + 2];
  int capa = 0;
  for (int i = 1; i <= n; i++)
  {
    capa += order_volume(pattern[i]);
  }
  return (capa <= rider_capa(h) + 1e-5);
}

int *get_best_sequence(int *pattern, int *min_dist, int h)
{
  int n = pattern[0];

  bool subset_feasible = true;
  for (int i = 0; i < n - 1; i++)
  {
    if (!compat[h][pattern[i + 1]][pattern[n]])
    {
      subset_feasible = false;
      break;
    }
  }
  if (!subset_feasible)
    return NULL;

  int *perm, *d_perm, *p_perm;
  int *sequence = (int *)malloc((n * 2) * sizeof(int));
  int *pickup_dists = malloc(factorial[n] * sizeof(int));
  int *pickup_times = malloc(factorial[n] * sizeof(int));
  int *delivery_dists = malloc(factorial[n] * sizeof(int));
  int *delivery_times = malloc(factorial[n] * sizeof(int));
  int *sorted_idxs_p = (int *)calloc(factorial[n], sizeof(int));
  int *sorted_idxs_d = (int *)calloc(factorial[n], sizeof(int));
  int *base_seq = malloc(n * sizeof(int));

  int min_last_pickup_time = 1e9;

  int min_deadline = order_deadline(pattern[1]);
  int min_deadline_order = pattern[1];
  for (int i = 1; i < n; i++)
  {
    min_deadline = (order_deadline(pattern[i + 1]) < min_deadline) ? order_deadline(pattern[i + 1]) : min_deadline;
    if (min_deadline == order_deadline(pattern[i + 1]))
      min_deadline_order = pattern[i + 1];
  }

  for (int i = 0; i < n; i++)
    base_seq[i] = pattern[i + 1];

  //// pickup sequence calculation
  int front = 0;
  int end = factorial[n] - 1;
  for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
  {
    perm = get_nth_permutation_of_size(seq_idx, n);
    pickup_dists[seq_idx] = 0;
    pickup_times[seq_idx] = order_ready_time(base_seq[perm[0]]);
    if (pickup_times[seq_idx] > min_deadline)
    {
      sorted_idxs_p[end--] = seq_idx;
      pickup_dists[seq_idx] = 1e9;
      continue;
    }
    for (int i = 1; i < n; i++)
    {
      pickup_times[seq_idx] += rider_time[h][base_seq[perm[i - 1]]][base_seq[perm[i]]];
      pickup_times[seq_idx] = (pickup_times[seq_idx] > order_ready_time(base_seq[perm[i]])) ? pickup_times[seq_idx] : order_ready_time(base_seq[perm[i]]);
      if (pickup_times[seq_idx] + rider_time[h][base_seq[perm[i]]][min_deadline_order + num_orders] > min_deadline)
      {
        pickup_dists[seq_idx] = 1e9;
        break;
      }
      pickup_dists[seq_idx] += dist(base_seq[perm[i - 1]], base_seq[perm[i]]);
    }
    if (pickup_dists[seq_idx] >= 1e9)
    {
      sorted_idxs_p[end--] = seq_idx;
      continue;
    }
    int idx = 0;
    for (; idx < front; idx++)
    {
      if (pickup_dists[seq_idx] < pickup_dists[sorted_idxs_p[idx]])
        break;
    }
    memcpy(&(sorted_idxs_p[idx + 1]), &(sorted_idxs_p[idx]), (front - idx) * sizeof(int));
    sorted_idxs_p[idx] = seq_idx;
    front += 1;
    // sorted_idxs_p[front++] = seq_idx;
    min_last_pickup_time = (pickup_times[seq_idx] < min_last_pickup_time) ? pickup_times[seq_idx] : min_last_pickup_time;
  }
  if (min_last_pickup_time >= 1e9)
  {
    free(pickup_dists);
    free(pickup_times);
    free(delivery_dists);
    free(delivery_times);
    free(base_seq);
    free(sorted_idxs_p);
    free(sorted_idxs_d);
    return NULL;
  }

  //// delivery sequence calculation
  front = 0;
  end = factorial[n] - 1;
  for (int seq_idx = 0; seq_idx < factorial[n]; seq_idx++)
  {
    perm = get_nth_permutation_of_size(seq_idx, n);
    delivery_dists[seq_idx] = 0;
    delivery_times[seq_idx] = order_deadline(base_seq[perm[n - 1]]);
    if (delivery_times[seq_idx] < min_last_pickup_time)
    {
      delivery_dists[seq_idx] = 1e9;
      sorted_idxs_d[end--] = seq_idx;
      continue;
    }
    for (int i = n - 1; i > 0; i--)
    {
      delivery_times[seq_idx] -= rider_time[h][base_seq[perm[i - 1]] + num_orders][base_seq[perm[i]] + num_orders];
      delivery_times[seq_idx] = (delivery_times[seq_idx] < order_deadline(base_seq[perm[i - 1]])) ? delivery_times[seq_idx] : order_deadline(base_seq[perm[i - 1]]);
      if (delivery_times[seq_idx] < min_last_pickup_time)
      {
        delivery_dists[seq_idx] = 1e9;
        break;
      }
      delivery_dists[seq_idx] += dist(base_seq[perm[i - 1]] + num_orders, base_seq[perm[i]] + num_orders);
    }
    if (delivery_dists[seq_idx] >= 1e9)
    {
      sorted_idxs_d[end--] = seq_idx;
      continue;
    }
    int idx = 0;
    for (; idx < front; idx++)
    {
      if (delivery_dists[seq_idx] < delivery_dists[sorted_idxs_d[idx]])
        break;
    }
    memcpy(&(sorted_idxs_d[idx + 1]), &(sorted_idxs_d[idx]), (front - idx) * sizeof(int));
    sorted_idxs_d[idx] = seq_idx;
    front += 1;
    // sorted_idxs_d[front++] = seq_idx;
  }

  //// Find best combination
  int min_dist_ = 1e9;
  int p_idx, d_idx;
  int best_p_idx, best_d_idx;
  for (int i = 0; i < factorial[n]; i++)
  {
    p_idx = sorted_idxs_p[i];
    // printf("%d %d  %d\n", i, p_idx, pickup_dists[p_idx]);
    if (pickup_dists[p_idx] >= 1e9)
      break;
    // bool checker = false;
    p_perm = get_nth_permutation_of_size(p_idx, n);
    for (int j = 0; j < factorial[n]; j++)
    {
      d_idx = sorted_idxs_d[j];
      if (delivery_dists[d_idx] >= 1e9)
        break;
      if (pickup_dists[p_idx] + delivery_dists[d_idx] > min_dist_)
      {
        // checker = true;
        break;
      }
      d_perm = get_nth_permutation_of_size(d_idx, n);
      if ((pickup_times[p_idx] + rider_time[h][base_seq[p_perm[n - 1]]][base_seq[d_perm[0]] + num_orders] <= delivery_times[d_idx]) && (pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[n - 1]], base_seq[d_perm[0]] + num_orders) < min_dist_))
      {
        min_dist_ = pickup_dists[p_idx] + delivery_dists[d_idx] + dist(base_seq[p_perm[n - 1]], base_seq[d_perm[0]] + num_orders);
        best_p_idx = p_idx;
        best_d_idx = d_idx;
      }
    }
    // if (checker)
    //   break;
  }
  // printf("\n");
  if (min_dist_ >= 1e9)
  {
    free(pickup_dists);
    free(pickup_times);
    free(delivery_dists);
    free(delivery_times);
    free(base_seq);
    free(sorted_idxs_p);
    free(sorted_idxs_d);
    return NULL;
  }

  p_perm = get_nth_permutation_of_size(best_p_idx, n);
  d_perm = get_nth_permutation_of_size(best_d_idx, n);
  for (int i = 0; i < n; i++)
  {
    sequence[i] = base_seq[p_perm[i]];
    sequence[i + n] = base_seq[d_perm[i]];
  }

  free(pickup_dists);
  free(pickup_times);
  free(delivery_dists);
  free(delivery_times);
  free(base_seq);
  free(sorted_idxs_p);
  free(sorted_idxs_d);

  *min_dist = min_dist_;
  return sequence;
}

void get_sequenced_solution()
{
  seq_solution = (int *)calloc(num_orders * (2 * MAX_ORDER_IN_PATT + 3), sizeof(int));
  seq_solution_2d = (int **)calloc(num_orders, sizeof(int *)); // [num_order_in_patt, order1, order2, ..., dist, vehicle_type]
  for (int i = 0; i < num_orders; i++)
  {
    seq_solution_2d[i] = seq_solution + i * (2 * MAX_ORDER_IN_PATT + 3);
  }
  for (int i = 0; i < num_x_sol; i++)
  {
    int temp;
    int *sequence = get_best_sequence(solution_2d[i], &temp, solution_2d[i][2 * pattern_upto + 2]);
    if (sequence != NULL)
    {
      memcpy(seq_solution_2d[i] + 1, sequence, 2 * solution_2d[i][0] * sizeof(int));
      // printf("here22b n%d\n", n); fflush(stdout);
      seq_solution_2d[i][0] = solution_2d[i][0];
      seq_solution_2d[i][2 * MAX_ORDER_IN_PATT + 1] = solution_2d[i][2 * pattern_upto + 1];
      seq_solution_2d[i][2 * MAX_ORDER_IN_PATT + 2] = solution_2d[i][2 * pattern_upto + 2];
    }
    else
    {
      printf("Error in getting sequence\n");
    }
  }
  free(solution);
  free(solution_2d);
}

/* IMPROVE MAIN COES*/
int *tree_patterns, **tree_patterns_2d, ***tree_pat_idxs_n_h_ft, *iter_patts_idxs, tree_pat_idx;
double tree_objval;
int improve_option, improve_iter;
int *idxs_sorted_by_deadline_slack;
int ***slack_mat;

struct hashmap *map;

void initialize_improve()
{
  improve_iter = -1;
  improve_option = 0;
  imp_obj_steady = 0;

  iter_patts_idxs = malloc(MAX_PAT_IMPROVE * sizeof(int));

  map = hashmap_new(sizeof(struct pattern), 0, 0, 0,
                    pattern_hash, pattern_compare, pattern_free, NULL);

  tree_patterns = (int *)calloc(MAX_PAT_IMPROVE * (3 + 2 * MAX_ORDER_IN_PATT), sizeof(int));
  tree_patterns_2d = (int **)calloc(MAX_PAT_IMPROVE, sizeof(int *));
  for (int i = 0; i < MAX_PAT_IMPROVE; i++)
  {
    tree_patterns_2d[i] = tree_patterns + i * (3 + 2 * MAX_ORDER_IN_PATT);
  }
  tree_pat_idxs_n_h_ft = (int ***)calloc(MAX_ORDER_IN_PATT, sizeof(int **));
  for (int i = 0; i < MAX_ORDER_IN_PATT; i++)
  {
    tree_pat_idxs_n_h_ft[i] = (int **)calloc(num_riders, sizeof(int *));
    for (int j = 0; j < num_riders; j++)
    {
      tree_pat_idxs_n_h_ft[i][j] = (int *)calloc(2, sizeof(int));
    }
  }

  // length-1 patterns
  for (int i = 0; i < pat_h_n_idxs[0][1][0]; i++)
  {
    tree_patterns_2d[i][0] = 1;
    tree_patterns_2d[i][1] = patterns[i][1];
    tree_patterns_2d[i][2] = patterns[i][1];
    tree_patterns_2d[i][2 * MAX_ORDER_IN_PATT + 1] = patterns[i][2 * pattern_upto + 1]; // non-averaged cost
    tree_patterns_2d[i][2 * MAX_ORDER_IN_PATT + 2] = patterns[i][2 * pattern_upto + 2]; // vehicle type

    iter_patts_idxs[i] = i;
    struct pattern *p = create_pattern(tree_patterns_2d[i], i);
    hashmap_set(map, (void *)p);
    free(p);
  }
  for (int h = 0; h < num_riders; h++)
  {
    tree_pat_idxs_n_h_ft[0][h][0] = pat_h_n_idxs[h][0][0];
    tree_pat_idxs_n_h_ft[0][h][1] = pat_h_n_idxs[h][0][1];
  }
  tree_pat_idx = pat_h_n_idxs[2][1][1]; // Since length 1 patters are always in the tree

  // length-2 patterns, and also calculate slacks
  idxs_sorted_by_deadline_slack = (int *)malloc((pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]) * sizeof(int));
  Element *slacks = (Element *)malloc((pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]) * sizeof(Element));
  slack_mat = (int ***)calloc(num_riders, sizeof(int **));
  for (int h = 0; h < num_riders; h++)
  {
    slack_mat[h] = (int **)calloc(num_orders, sizeof(int *));
    for (int i = 0; i < num_orders; i++)
    {
      slack_mat[h][i] = (int *)calloc(num_orders, sizeof(int));
    }
  }
  for (int idx = pat_h_n_idxs[0][1][0]; idx < pat_h_n_idxs[2][1][1]; idx++)
  {
    tree_patterns_2d[idx][0] = 2;
    tree_patterns_2d[idx][1] = patterns[idx][1];
    tree_patterns_2d[idx][2] = patterns[idx][2];
    tree_patterns_2d[idx][2 * MAX_ORDER_IN_PATT + 1] = patterns[idx][2 * pattern_upto + 1];
    tree_patterns_2d[idx][2 * MAX_ORDER_IN_PATT + 2] = patterns[idx][2 * pattern_upto + 2];
    int h = patterns[idx][2 * pattern_upto + 2];
    int temp, seq_time;
    int *seq = get_best_sequence(tree_patterns_2d[idx], &temp, h);
    memcpy(&tree_patterns_2d[idx][1], seq, 4 * sizeof(int));

    struct pattern *p = create_pattern(tree_patterns_2d[idx], idx);
    hashmap_set(map, (void *)p);
    free(p);

    int slack = 1e7;
    if (seq != NULL)
    {
      seq_time = order_ready_time(seq[0]) + rider_time[h][seq[0]][seq[1]];
      seq_time = (seq_time > order_ready_time(seq[1])) ? seq_time : order_ready_time(seq[1]);
      seq_time += rider_time[h][seq[1]][seq[2] + num_orders];
      slack = order_deadline(seq[2]) - seq_time;
      seq_time += rider_time[h][seq[2] + num_orders][seq[3] + num_orders];
      slack = (order_deadline(seq[3]) - seq_time < slack) ? order_deadline(seq[3]) - seq_time : slack;
    }
    slacks[idx - pat_h_n_idxs[0][1][0]].index = idx;
    slacks[idx - pat_h_n_idxs[0][1][0]].rcost = -slack;
    slack_mat[h][tree_patterns_2d[idx][1]][tree_patterns_2d[idx][2]] = slack;
  }
  qsort(slacks, pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0], sizeof(Element), compare);
  for (int i = 0; i < pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]; i++)
  {
    idxs_sorted_by_deadline_slack[i] = slacks[i].index;
  }

  // calculate length-2 paths in 2-pattern graph
}

void cleanup_improve()
{
  free(tree_patterns);
  free(tree_patterns_2d);
  for (int i = 0; i < MAX_ORDER_IN_PATT; i++)
  {
    for (int j = 0; j < num_riders; j++)
    {
      free(tree_pat_idxs_n_h_ft[i][j]);
    }
    free(tree_pat_idxs_n_h_ft[i]);
  }
  free(tree_pat_idxs_n_h_ft);
  hashmap_free(map);
  for (int h = 0; h < num_riders; h++)
  {
    for (int i = 0; i < num_orders; i++)
    {
      free(slack_mat[h][i]);
    }
    free(slack_mat[h]);
  }
  free(slack_mat);
}

void print_solution(int *solution)
{
  printf("%d  %d %d %d %d %d %d %d %d %d %d %d %d  %d %d\n", solution[0], solution[1], solution[2], solution[3], solution[4], solution[5], solution[6], solution[7], solution[8], solution[9], solution[10], solution[11], solution[12], solution[13], solution[14]);
}

void print_solutions_stat()
{
  printf("total %d:  ", num_x_sol);
  int nums[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  for (int i = 0; i < num_x_sol; i++)
  {
    nums[seq_solution_2d[i][0] - 1] += 1;
  }
  for (int i = 0; i < MAX_ORDER_IN_PATT; i++)
  {
    printf(" %d", nums[i]);
  }
  printf("\n");
}

void resolve_small_problem(Tree *tree, int *p_num_edges)
{
  int *target_idxs = malloc(num_x_sol * sizeof(int));
  int num_target_seqs = 0;
  int count = 0;

  // FIXME:
  if (improve_iter % 3 == 0)
  {
    Element *sorted_idxs = malloc(num_x_sol * sizeof(Element));
    for (int i = 0; i < num_x_sol; i++)
    {
      sorted_idxs[i].index = i;
      sorted_idxs[i].rcost = -((double)seq_solution_2d[i][2 * MAX_ORDER_IN_PATT + 1]) / seq_solution_2d[i][0];
    }
    qsort(sorted_idxs, num_x_sol, sizeof(Element), compare);

    for (int idx = 0; idx < num_x_sol; idx++)
    {
      int i = sorted_idxs[idx].index;
      // if (seq_solution_2d[i][0] <= 3)
      {
        target_idxs[num_target_seqs] = i;
        num_target_seqs += 1;
        count += seq_solution_2d[i][0];
        if (count > SMALL_PROB_SIZE)
          break;
      }
    }
    free(sorted_idxs);
  }
  else if (improve_iter % 3 == 1)
  {
    for (int i = 0; i < num_x_sol; i++)
    {
      if (seq_solution_2d[i][0] <= 1)
      {
        target_idxs[num_target_seqs] = i;
        num_target_seqs += 1;
        count += seq_solution_2d[i][0];
        if (count > SMALL_PROB_SIZE)
          break;
      }
    }
    for (int i = 0; i < num_x_sol; i++)
    {
      if (count > SMALL_PROB_SIZE)
        break;
      if (seq_solution_2d[i][0] == 2)
      {
        target_idxs[num_target_seqs] = i;
        num_target_seqs += 1;
        count += seq_solution_2d[i][0];
        if (count > SMALL_PROB_SIZE)
          break;
      }
    }
    for (int i = 0; i < num_x_sol; i++)
    {
      if (count > SMALL_PROB_SIZE)
        break;
      if (seq_solution_2d[i][0] == 3)
      {
        target_idxs[num_target_seqs] = i;
        num_target_seqs += 1;
        count += seq_solution_2d[i][0];
        if (count > SMALL_PROB_SIZE)
          break;
      }
    }
  }
  else 
  {
    for (int i = 0; i < num_x_sol; i++)
    {
      if (seq_solution_2d[i][0] <= 3)
      {
        target_idxs[num_target_seqs] = i;
        num_target_seqs += 1;
        count += seq_solution_2d[i][0];
        if (count > SMALL_PROB_SIZE)
          break;
      }
    }
  }

  int num_target_orders = 0;
  int *target_orders = malloc(num_orders * sizeof(int));
  for (int i = 0; i < num_target_seqs; i++)
  {
    // printf("%d :", target_idxs[i]);
    for (int j = 0; j < seq_solution_2d[target_idxs[i]][0]; j++)
    {
      // printf(" %d", seq_solution_2d[target_idxs[i]][j+1]);
      target_orders[num_target_orders + j] = seq_solution_2d[target_idxs[i]][j + 1];
    }
    // printf("\n");
    num_target_orders += seq_solution_2d[target_idxs[i]][0];
  }
  // printf("\n");

  // enum patterns
  int num_patts = 0;
  int *patt_idxs = malloc(1e6 * sizeof(int));
  int ***resolve_idxs_n_h_ft = (int ***)calloc(MAX_ORDER_IN_PATT, sizeof(int **));
  for (int i = 0; i < MAX_ORDER_IN_PATT; i++)
  {
    resolve_idxs_n_h_ft[i] = (int **)calloc(num_riders, sizeof(int *));
    for (int j = 0; j < num_riders; j++)
    {
      resolve_idxs_n_h_ft[i][j] = (int *)calloc(2, sizeof(int));
    }
  }
  //// length-1 patterns
  for (int h = 0; h < num_riders; h++)
  {
    resolve_idxs_n_h_ft[0][h][0] = num_patts;
    for (int ii = 0; ii < num_target_orders; ii++)
    {
      int i = target_orders[ii];
      for (int j = tree_pat_idxs_n_h_ft[0][h][0]; j < tree_pat_idxs_n_h_ft[0][h][1]; j++)
      {
        if (tree_patterns_2d[j][1] == i)
        {
          patt_idxs[num_patts++] = j;
          // printf("%d ", tree_patterns_2d[j][0]);
          break;
        }
      }
    }
    resolve_idxs_n_h_ft[0][h][1] = num_patts;
    // printf("n %d  h %d :  %d\n", 1, h, resolve_idxs_n_h_ft[0][h][1] - resolve_idxs_n_h_ft[0][h][0]);
  }
  char *temp_id;
  for (int n = 2; n <= MAX_ORDER_IN_PATT; n++)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if ((finish.tv_sec - start.tv_sec) > time_limit)
      return;
    // printf(" start %d %d %d\n", n); fflush(stdout);
    for (int h = 0; h < num_riders; h++)
    {
      clock_gettime(CLOCK_MONOTONIC, &finish);
      if ((finish.tv_sec - start.tv_sec) > time_limit)
        return;
      resolve_idxs_n_h_ft[n - 1][h][0] = num_patts;
      // printf("  start %d %d %d\n", n, h); fflush(stdout);
      for (int i = resolve_idxs_n_h_ft[n - 2][h][0]; i < resolve_idxs_n_h_ft[n - 2][h][1]; i++)
      {
        clock_gettime(CLOCK_MONOTONIC, &finish);
        if ((finish.tv_sec - start.tv_sec) > time_limit)
          return;
        // printf("   start %d %d %d  %d\n", n, h, i, patt_idxs[i]); fflush(stdout);
        int *temp_pat = malloc((3 + 2 * MAX_ORDER_IN_PATT) * sizeof(int));
        memcpy(temp_pat, tree_patterns_2d[patt_idxs[i]], (3 + 2 * MAX_ORDER_IN_PATT) * sizeof(int));
        temp_pat[0] += 1;
        // if (n != temp_pat[0])
        // {
        //   printf("%d %d\n", n, temp_pat[0]);
        // for (int k = 0; k < 3 + 2 * MAX_ORDER_IN_PATT; k++)
        //   printf("%d ", temp_pat[k]); fflush(stdout);
        // printf("\n"); fflush(stdout);
        //   exit(1);
        // }
        for (int j = 0; j < num_target_orders; j++)
        {
          // printf("%d / %d\n", j, num_target_orders); fflush(stdout);
          if (target_orders[j] <= temp_pat[temp_pat[0] - 1])
            continue;
          // printf("%s %d\n", get_id(tree_patterns_2d[patt_idxs[i]]), target_orders[j]); fflush(stdout);
          bool subset_feasible = true;
          for (int k = 0; k < temp_pat[0] - 1; k++)
          {
            if (!compat[h][temp_pat[k + 1]][target_orders[j]])
            {
              subset_feasible = false;
              break;
            }
          }
          if (!subset_feasible)
            continue;
          // printf("  %d %d %d\n", n, h, i); fflush(stdout);
          temp_pat[temp_pat[0]] = target_orders[j];
          temp_id = get_id(temp_pat);
          // printf("%s\n", temp_id); fflush(stdout);
          struct pattern *p = (struct pattern *)hashmap_get(map, &(struct pattern){.id = temp_id});
          if (p != NULL)
          {
            if (p->idx >= 0)
              patt_idxs[num_patts++] = p->idx;
          }
          else
          {
            if (!check_capa_feasibility(temp_pat))
            {
              struct pattern *pp = create_pattern(temp_pat, -1);
              hashmap_set(map, (void *)pp);
              free(pp);
              free(temp_id);
              continue;
            }
            int min_dist;
            int *sequence = get_best_sequence(temp_pat, &min_dist, h);
            if (sequence != NULL)
            {
              // for (int k = 0; k < 2 * MAX_ORDER_IN_PATT + 3; k++)
              //   printf("%d ", temp_pat[k]);
              // printf("\n");
              // for (int k = 0; k < 2 * temp_pat[0]; k++)
              //   printf("%d ", sequence[k]);
              // printf("\n\n");

              memcpy(&temp_pat[1], sequence, 2 * temp_pat[0] * sizeof(int));
              struct pattern *pp = create_pattern(temp_pat, tree_pat_idx);
              hashmap_set(map, (void *)pp);
              free(pp);
              temp_pat[2 * MAX_ORDER_IN_PATT + 1] = min_dist * rider_var_cost(temp_pat[2 * MAX_ORDER_IN_PATT + 2]) + 100 * rider_fixed_cost(temp_pat[2 * MAX_ORDER_IN_PATT + 2]);
              ;
              memcpy(tree_patterns_2d[tree_pat_idx], temp_pat, (3 + 2 * MAX_ORDER_IN_PATT) * sizeof(int));
              patt_idxs[num_patts++] = tree_pat_idx++;
            }
            else
            {
              struct pattern *pp = create_pattern(temp_pat, -1);
              hashmap_set(map, (void *)pp);
              free(pp);
            }
          }
          // printf("%s\n", temp_id); fflush(stdout);
          free(temp_id);
        }
        free(temp_pat);
        // printf("done j\n"); fflush(stdout);
      }
      // printf(" start %d %d\n", n, h); fflush(stdout);
      resolve_idxs_n_h_ft[n - 1][h][1] = num_patts;
      // printf("n %d  h %d :  %d\n", n, h, resolve_idxs_n_h_ft[n - 1][h][1] - resolve_idxs_n_h_ft[n - 1][h][0]);
    }
    // printf(" done %d\n", n); fflush(stdout);
  }

  // solve IP
  XPRBprob prob = XPRBnewprob("resolve-IP");
  XPRBvar x[MAX_COL];
  XPRBctr assign[num_orders], cardi[num_riders];
  XPRBctr obj;

  obj = XPRBnewctr(prob, "obj", XPRB_N);      // XPRB_N indicate this is for objective
  for (int i = 0; i < num_target_orders; i++) // iterate over orders
  {
    assign[target_orders[i]] = XPRBnewctr(prob, XPRBnewname("assign_%d", target_orders[i]), XPRB_E);
    XPRBaddterm(assign[target_orders[i]], NULL, 1);
  }
  for (int i = 0; i < num_riders; i++) // iterate over riders
  {
    cardi[i] = XPRBnewctr(prob, XPRBnewname("cardi_%d", i), XPRB_L);
    XPRBaddterm(cardi[i], NULL, rider_avail_num(i));
  }
  for (int i = 0; i < resolve_idxs_n_h_ft[MAX_ORDER_IN_PATT - 1][2][1]; i++) // iterate over solution
  {
    x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
    XPRBaddterm(obj, x[i], ((double)tree_patterns_2d[patt_idxs[i]][2 * MAX_ORDER_IN_PATT + 1]) / (num_orders * 100));
    for (int j = 1; j < tree_patterns_2d[patt_idxs[i]][0] + 1; j++)
      XPRBaddterm(assign[tree_patterns_2d[patt_idxs[i]][j]], x[i], 1);
    XPRBaddterm(cardi[tree_patterns_2d[patt_idxs[i]][2 * MAX_ORDER_IN_PATT + 2]], x[i], 1);
  }
  XPRBsetobj(prob, obj);
  XPRBsetmsglevel(prob, 0);
  // XPRBprintprob(prob);
  XPRSprob opt_prob = XPRBgetXPRSprob(prob);
  XPRSsetintcontrol(opt_prob, XPRS_MAXTIME, -(1));

  XPRBmipoptimize(prob, "");
  // basis = XPRBsavebasis(prob);
  double objval = XPRBgetobjval(prob);
  printf(" re12  obj %.3f   #c %d   st %d   ", objval, resolve_idxs_n_h_ft[MAX_ORDER_IN_PATT - 1][2][1], XPRBgetlpstat(prob));
  print_time("");

  // add edges to the tree as in resolve-solution
  Element* sorted_idxs = (Element*) malloc(45 * sizeof(Element));
  int num_edges;
  for (int i = 0; i < resolve_idxs_n_h_ft[MAX_ORDER_IN_PATT - 1][2][1]; i++)
  {
    if (XPRBgetsol(x[i]) > 0.5)
    {
      // for (int j = 0; j < 2 * MAX_ORDER_IN_PATT+3; j++)
      //   printf("%d ", tree_patterns_2d[patt_idxs[i]][j]);
      // printf("\n");

      // delivery sequence
      // for (int j = 0; j < tree_patterns_2d[patt_idxs[i]][0] - 1; j++)
      // {
      //   if (add_edge(tree, tree_patterns_2d[patt_idxs[i]][j + 1 + tree_patterns_2d[patt_idxs[i]][0]], tree_patterns_2d[patt_idxs[i]][j + 2 + tree_patterns_2d[patt_idxs[i]][0]]))
      //     *p_num_edges += 1;
      // }

      // in order of slack
      num_edges = 0;
      for (int j = 1; j <= tree_patterns_2d[patt_idxs[i]][0]; j++)
      {
        for (int k = j+1; k <= tree_patterns_2d[patt_idxs[i]][0]; k++)
        {
          if (compat[tree_patterns_2d[patt_idxs[i]][2 * MAX_ORDER_IN_PATT + 2]][tree_patterns_2d[patt_idxs[i]][j]][tree_patterns_2d[patt_idxs[i]][k]])
          {
            sorted_idxs[num_edges].index = j * 10000 + k;
            sorted_idxs[num_edges].rcost = -slack_mat[tree_patterns_2d[patt_idxs[i]][2 * MAX_ORDER_IN_PATT + 2]][tree_patterns_2d[patt_idxs[i]][j]][tree_patterns_2d[patt_idxs[i]][k]];
            num_edges += 1;
          }
        }
      }
      qsort(sorted_idxs, num_edges, sizeof(Element), compare);
      for (int k = 0; k < num_edges; k++)
      {
        int j = sorted_idxs[k].index / 10000;
        int l = sorted_idxs[k].index % 10000;
        if (add_edge(tree, tree_patterns_2d[patt_idxs[i]][j], tree_patterns_2d[patt_idxs[i]][l]))
          *p_num_edges += 1;
      }
    }
  }

  free(target_idxs);
  free(patt_idxs);
  free(target_orders);
  for (int i = 0; i < MAX_ORDER_IN_PATT; i++)
  {
    for (int j = 0; j < num_riders; j++)
    {
      free(resolve_idxs_n_h_ft[i][j]);
    }
    free(resolve_idxs_n_h_ft[i]);
  }
  free(resolve_idxs_n_h_ft);
}

void improve()
{
  improve_iter += 1;
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  printf("Start improving");
  print_time("");
  printf("- - - - - - - - - - - - - - - - - - - - \n");
  print_solutions_stat();

  struct hashmap *iter_map = hashmap_new(sizeof(struct pattern), 0, 0, 0,
                                         pattern_hash, pattern_compare, pattern_free, NULL);

  // Create tree
  Tree *tree = create_tree(num_orders);
  int num_edges = 0;
  int min_dist = 0;

  // solve 50-order subproblem and add edges accordingly
  if (improve_option % 2 == 0) // also add edges via slacks later on
    resolve_small_problem(tree, &num_edges);

  //// initial forest with IP solution
  // in order of slack
  if ((improve_option / 2) % 2 == 0)
  {
    Element* sorted_idxs = (Element*) malloc(45 * sizeof(Element));
    for (int i = 0; i < num_x_sol; i++)
    {
      int num = 0;
      for (int j = 1; j <= seq_solution_2d[i][0]; j++)
      {
        for (int k = j+1; k <= seq_solution_2d[i][0]; k++)
        {
          if (compat[seq_solution_2d[i][2 * MAX_ORDER_IN_PATT + 2]][seq_solution_2d[i][j]][seq_solution_2d[i][k]])
          {
            sorted_idxs[num].index = j * 10000 + k;
            sorted_idxs[num].rcost = -slack_mat[seq_solution_2d[i][2 * MAX_ORDER_IN_PATT + 2]][seq_solution_2d[i][j]][seq_solution_2d[i][k]];
            num += 1;
          }
        }
      }
      qsort(sorted_idxs, num, sizeof(Element), compare);
      for (int k = 0; k < num; k++)
      {
        int j = sorted_idxs[k].index / 10000;
        int l = sorted_idxs[k].index % 10000;
        if (add_edge(tree, seq_solution_2d[i][j], seq_solution_2d[i][l]))
          num_edges += 1;
      }
    }
    free(sorted_idxs);
  }
  else 
  {
    ////// add edges as in delivery sequence
    for (int i = 0; i < num_x_sol; i++)
    {
      // if (seq_solution_2d[i][2*MAX_PAT_IMPROVE+1] > tree_objval * 100 + 75)
      //   continue;
      // print_solution(seq_solution_2d[i]);
      for (int j = 0; j < seq_solution_2d[i][0] - 1; j++)
      {
        if (add_edge(tree, seq_solution_2d[i][j + 1 + seq_solution_2d[i][0]], seq_solution_2d[i][j + 2 + seq_solution_2d[i][0]]))
          num_edges += 1;
      }
    }
  }
  // else if (improve_option % 2 == 1)
  // {
  //   ////// add edges as in pickup sequence
  //   for (int i = 0; i < num_x_sol; i++)
  //   {
  //     for (int j = 0; j < seq_solution_2d[i][0] - 1; j++)
  //     {
  //       if (add_edge(tree, seq_solution_2d[i][j + 1], seq_solution_2d[i][j + 2]))
  //         num_edges += 1;
  //     }
  //   }
  // }

  //// add edges
  if (improve_option % 2 == 1)
  {
    ////// add edges via reduced costs
    XPRBprob prob = XPRBnewprob("RMP");
    XPRBvar x[MAX_COL];
    int x_idx[MAX_COL];
    XPRBctr assign[num_orders], cardi[num_riders];
    XPRBctr obj;

    int num_x = num_x_sol;
    // XPRBbasis basis;
    double dual_assign[num_orders], dual_cardi[num_riders];

    obj = XPRBnewctr(prob, "obj", XPRB_N); // XPRB_N indicate this is for objective
    for (int i = 0; i < num_orders; i++)   // iterate over orders
    {
      assign[i] = XPRBnewctr(prob, XPRBnewname("assign_%d", i), XPRB_E);
      XPRBaddterm(assign[i], NULL, 1);
    }
    for (int i = 0; i < num_riders; i++) // iterate over riders
    {
      cardi[i] = XPRBnewctr(prob, XPRBnewname("cardi_%d", i), XPRB_L);
      XPRBaddterm(cardi[i], NULL, rider_avail_num(i));
    }
    for (int i = 0; i < num_x; i++) // iterate over solution
    {
      x[i] = XPRBnewvar(prob, XPRB_BV, XPRBnewname("x_%d", i), 0, 1);
      x_idx[i] = i;
      XPRBaddterm(obj, x[i], ((double)seq_solution_2d[i][2 * MAX_ORDER_IN_PATT + 1]) / (num_orders * 100));
      for (int j = 1; j < seq_solution_2d[i][0] + 1; j++)
        XPRBaddterm(assign[seq_solution_2d[i][j]], x[i], 1);
      XPRBaddterm(cardi[seq_solution_2d[i][2 * MAX_ORDER_IN_PATT + 2]], x[i], 1);
    }
    XPRBsetobj(prob, obj);
    XPRBsetmsglevel(prob, 0);
    // XPRBprintprob(prob);

    XPRBlpoptimize(prob, "");
    // basis = XPRBsavebasis(prob);
    tree_objval = XPRBgetobjval(prob);
    for (int i = 0; i < num_orders; i++)
      dual_assign[i] = XPRBgetdual(assign[i]);
    for (int i = 0; i < num_riders; i++)
      dual_cardi[i] = XPRBgetdual(cardi[i]);
    printf("%3d  obj %.3f   #c %d   st %d   ", 0, tree_objval, num_x, XPRBgetlpstat(prob));
    print_time("");

    //// calculate reduced costs of length-2 patterns than sort
    Element *sorted_idxs = (Element *)malloc((pat_idx) * sizeof(Element));
    int num_added = 0;
    for (int i = pat_h_n_idxs[0][1][0]; i < pat_h_n_idxs[2][1][1]; i++)
    {
      double reduced_cost = costs[i] - dual_cardi[patterns[i][2 * pattern_upto + 2]];
      for (int j = 1; j < patterns[i][0] + 1; j++)
        reduced_cost -= dual_assign[patterns[i][j]];
      sorted_idxs[num_added].index = i;
      sorted_idxs[num_added].rcost = reduced_cost;
      num_added += 1;
    }
    qsort(sorted_idxs, num_added, sizeof(Element), compare);

    //// add edges to tree
    for (int idx = 0; idx < num_added; idx++)
    {
      int i = sorted_idxs[idx].index;
      if (add_edge(tree, patterns[i][1], patterns[i][2]))
        num_edges += 1;
      if (num_edges == num_orders - 1)
        break;
    }
    printf("num_edges %d\n", num_edges);
    XPRBdelprob(prob);
    XPRBfree();
    free(sorted_idxs);
  }
  else if (improve_option % 2 == 0)
  {
    ////// add edges via deadline slack
    for (int i = 0; i < pat_h_n_idxs[2][1][1] - pat_h_n_idxs[0][1][0]; i++)
    {
      int idx = idxs_sorted_by_deadline_slack[i];
      if (add_edge(tree, patterns[idx][1], patterns[idx][2]))
        num_edges += 1;
      if (num_edges == num_orders - 1)
        break;
    }
  }

  // Pricing on the tree
  //// enumeratre over subtrees of the tree
  ////// length 1 is already treated in the initialize_improve()
  int iter_pat_idx = tree_pat_idxs_n_h_ft[0][2][1];
  // printf("iter_pat_idx %d\n", iter_pat_idx);
  ////// length >= 2
  char *temp_id;
  int *temp_pat;
  int *temp_new_pat = malloc((2 * MAX_ORDER_IN_PATT + 3) * sizeof(int));
  for (int n = 2; n <= MAX_ORDER_IN_PATT; n++)
  {
    clock_gettime(CLOCK_MONOTONIC, &finish);
    if ((finish.tv_sec - start.tv_sec) > time_limit)
      break;
    for (int h = 0; h < num_riders; h++)
    {
      if (tree_pat_idxs_n_h_ft[n - 2][h][1] - tree_pat_idxs_n_h_ft[n - 2][h][0] == 0)
        continue;
      clock_gettime(CLOCK_MONOTONIC, &finish);
      if ((finish.tv_sec - start.tv_sec) > time_limit)
        break;
      tree_pat_idxs_n_h_ft[n - 1][h][0] = iter_pat_idx;
      for (int i = tree_pat_idxs_n_h_ft[n - 2][h][0]; i < tree_pat_idxs_n_h_ft[n - 2][h][1]; i++)
      {
        clock_gettime(CLOCK_MONOTONIC, &finish);
        if ((finish.tv_sec - start.tv_sec) > time_limit)
          break;
        temp_pat = tree_patterns_2d[iter_patts_idxs[i]];
        memcpy(temp_new_pat, temp_pat, (3 + 2 * MAX_ORDER_IN_PATT) * sizeof(int));
        temp_new_pat[0] += 1;

        //FIXME: 
        if (n >= 7 && ((double) temp_new_pat[2 * MAX_ORDER_IN_PATT + 1] / 100 /num_orders / temp_new_pat[0]) > tree_objval / num_orders * TREE_ENUM_SEVEN_THSD)
        {
          // printf("%f %f\n", ((double) temp_new_pat[2 * MAX_ORDER_IN_PATT + 1] / 100 / num_orders / temp_new_pat[0]), tree_objval / num_orders);
          continue;
        }

        for (int j = 1; j < temp_pat[0] + 1; j++)
        {
          clock_gettime(CLOCK_MONOTONIC, &finish);
          if ((finish.tv_sec - start.tv_sec) > time_limit)
            break;
          int tg = temp_pat[j];
          adj_list_node *neighbor = tree->adj_list[tg];
          while (neighbor)
          {
            clock_gettime(CLOCK_MONOTONIC, &finish);
            if ((finish.tv_sec - start.tv_sec) > time_limit)
              break;
            // check whether neighbor is already in temp_pat
            bool checker = false;
            for (int k = 1; k < temp_pat[0] + 1; k++)
            {
              if (temp_pat[k] == neighbor->id)
              {
                checker = true;
                break;
              }
            }
            if (checker)
            {
              neighbor = neighbor->next;
              continue;
            }
            // start checking temp_new_pat(= temp_pat + neighbor->id) is feasible
            temp_new_pat[temp_new_pat[0]] = neighbor->id;
            // for (int ii =0; ii < 3 + 2 * MAX_ORDER_IN_PATT; ii++)
            //   printf("%d ", temp_new_pat[ii]);
            // printf("\n");fflush(stdout);
            temp_id = get_id(temp_new_pat);
            if (!hashmap_get(map, &(struct pattern){.id = temp_id}))
            {
              // printf("not yet tested\n");fflush(stdout);
              if (!check_capa_feasibility(temp_new_pat))
              {
                struct pattern *p = create_pattern(temp_new_pat, -1);
                hashmap_set(map, (void *)p);
                free(p);
                p = create_pattern(temp_new_pat, -1);
                hashmap_set(iter_map, (void *)p);
                free(p);
              }
              else
              {
                int *sequence = get_best_sequence(temp_new_pat, &min_dist, temp_new_pat[2 * MAX_ORDER_IN_PATT + 2]);
                if (sequence == NULL)
                {
                  struct pattern *p = create_pattern(temp_new_pat, -1);
                  hashmap_set(map, (void *)p);
                  free(p);
                  p = create_pattern(temp_new_pat, -1);
                  hashmap_set(iter_map, (void *)p);
                  free(p);
                }
                else
                {
                  memcpy(tree_patterns_2d[tree_pat_idx] + 1, sequence, 2 * n * sizeof(int));
                  tree_patterns_2d[tree_pat_idx][0] = n;
                  tree_patterns_2d[tree_pat_idx][2 * MAX_ORDER_IN_PATT + 1] = min_dist * rider_var_cost(temp_new_pat[2 * MAX_ORDER_IN_PATT + 2]) + 100 * rider_fixed_cost(temp_new_pat[2 * MAX_ORDER_IN_PATT + 2]);
                  tree_patterns_2d[tree_pat_idx][2 * MAX_ORDER_IN_PATT + 2] = temp_new_pat[2 * MAX_ORDER_IN_PATT + 2];
                  struct pattern *p = create_pattern(temp_new_pat, tree_pat_idx);
                  hashmap_set(map, (void *)p);
                  free(p);
                  p = create_pattern(temp_new_pat, tree_pat_idx);
                  hashmap_set(iter_map, (void *)p);
                  free(p);
                  iter_patts_idxs[iter_pat_idx] = tree_pat_idx;
                  iter_pat_idx += 1;
                  tree_pat_idx += 1;
                  free(sequence);
                }
              }
            }
            else if (!hashmap_get(iter_map, &(struct pattern){.id = temp_id}))
            {
              // printf("already gened!\n"); fflush(stdout);
              struct pattern *temp = (struct pattern *)hashmap_get(map, &(struct pattern){.id = temp_id});
              // printf("already gened! %s %d\n", temp->id, temp->idx); fflush(stdout);
              struct pattern *p = malloc(sizeof(struct pattern));
              p->id = malloc((5 * n + 2) * sizeof(char));
              strcpy(p->id, temp->id);
              hashmap_set(iter_map, (void *)p);
              free(p);

              if (temp->idx > 0)
              {
                iter_patts_idxs[iter_pat_idx] = temp->idx;
                iter_pat_idx += 1;
              }
            }
            free(temp_id);
            neighbor = neighbor->next;
          }
        }
      }
      tree_pat_idxs_n_h_ft[n - 1][h][1] = iter_pat_idx;
      if (tree_pat_idxs_n_h_ft[n - 1][h][1] - tree_pat_idxs_n_h_ft[n - 1][h][0] > 0)
      {
        printf("    n %d  h %d  : %8d", n, h, tree_pat_idxs_n_h_ft[n - 1][h][1] - tree_pat_idxs_n_h_ft[n - 1][h][0]);
        print_time("");
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &finish);
  if ((finish.tv_sec - start.tv_sec) > time_limit)
    return;
  printf("- - - - - - - - - - - - - - - - - - - - \n");

  // calculate tree patterns' costs
  double *tree_costs = (double *)malloc(pat_idx * sizeof(double));
  for (int i = 0; i < iter_pat_idx; i++)
  {
    tree_costs[i] = ((double)(tree_patterns_2d[iter_patts_idxs[i]][2 * MAX_ORDER_IN_PATT + 1])) / (num_orders * 100);
    // printf("tree_costs[%d]  %d  %.3f\n", i, tree_patterns_2d[i][0], tree_costs[i]);
  }

  // Solve IP with new columns
  XPRBprob tree_prob = XPRBnewprob("Tree-IP");
  XPRBvar x[MAX_COL];
  XPRBctr assign[num_orders], cardi[num_riders];
  XPRBctr obj;

  obj = XPRBnewctr(tree_prob, "obj", XPRB_N); // XPRB_N indicate this is for objective
  for (int i = 0; i < num_orders; i++)        // iterate over orders
  {
    assign[i] = XPRBnewctr(tree_prob, XPRBnewname("assign_%d", i), XPRB_E);
    XPRBaddterm(assign[i], NULL, 1);
  }
  for (int i = 0; i < num_riders; i++) // iterate over riders
  {
    cardi[i] = XPRBnewctr(tree_prob, XPRBnewname("cardi_%d", i), XPRB_L);
    XPRBaddterm(cardi[i], NULL, rider_avail_num(i));
  }
  for (int i = 0; i < iter_pat_idx; i++) // iterate over solution
  {
    int idx = iter_patts_idxs[i];
    x[i] = XPRBnewvar(tree_prob, XPRB_BV, XPRBnewname("x_%d", idx), 0, 1);
    XPRBaddterm(obj, x[i], tree_costs[i]);
    for (int j = 1; j < tree_patterns_2d[idx][0] + 1; j++)
      XPRBaddterm(assign[tree_patterns_2d[idx][j]], x[i], 1);
    XPRBaddterm(cardi[tree_patterns_2d[idx][2 * MAX_ORDER_IN_PATT + 2]], x[i], 1);
  }
  XPRBsetobj(tree_prob, obj);
  XPRBsetmsglevel(tree_prob, 0);
  // XPRBprintprob(tree_prob);

  XPRBmipoptimize(tree_prob, "");
  double tree_new_objval = XPRBgetobjval(tree_prob);
  printf("Imp %d  obj %.3f  #c %d  st %d ", improve_iter, tree_new_objval, iter_pat_idx, XPRBgetmipstat(tree_prob));
  print_time("");
  if (tree_new_objval - tree_objval < 1e-3 && tree_new_objval - tree_objval > -1e-3)
  {
    improve_option += 1;
    imp_obj_steady += 1;
    printf("Option changed! %d\n", improve_option);
  }
  else
  {
    imp_obj_steady = 0;
  }

  tree_objval = tree_new_objval;

  // post-processing
  num_x_sol = 0;
  for (int i = 0; i < iter_pat_idx; i++)
  {
    int idx = iter_patts_idxs[i];
    if (XPRBgetsol(x[i]) > 0.5)
    {
      memcpy(&(seq_solution_2d[num_x_sol][0]), &(tree_patterns_2d[idx][0]), (2 * MAX_ORDER_IN_PATT + 3) * sizeof(int));
      // print_solution(seq_solution_2d[num_x_sol]);
      num_x_sol += 1;
    }
  }
  print_solutions_stat();

  // free
  XPRBdelprob(tree_prob);
  XPRBfree();
  free_tree(tree);
  free(tree_costs);
  hashmap_free(iter_map);
}