from util import *

from calg_ybp_1 import calg as calg_1
from calg_ybp_2 import calg as calg_2
from calg_ybp_34 import calg as calg_3
from calg_ybp_34 import calg as calg_4
from calg_ybp_5 import calg as calg_5
from calg_ybp_6 import calg as calg_6
from calg_ybp_7 import calg as calg_7
from calg_ybp_8 import calg as calg_8
from calg_ybp_9 import calg as calg_9
from calg_ybp_10  import calg as calg_10




def algorithm(K, all_orders, all_riders, dist_mat, timelimit=60):

    start_time = time.time()

    for r in all_riders:
        r.T = np.round(dist_mat / r.speed + r.service_time)

    # A solution is a list of bundles
    solution = []

    # ------------- Custom algorithm code starts from here --------------#
    
    ## set parameters
    
    ## enumerating initial patterns
    if K >= 1500 and  timelimit <= 400: 
      solution = calg_1(10, all_orders, all_riders, dist_mat, timelimit-4)

    elif K >= 1500 and timelimit > 400: 
      solution = calg_2(7, all_orders, all_riders, dist_mat, timelimit-10)
    
    elif 800 <= K < 1500 and timelimit <= 70: 
      solution = calg_3(10, all_orders, all_riders, dist_mat, timelimit )
    
    elif 800 <= K < 1500 and 70 < timelimit  <= 200: 
      solution = calg_4(10, all_orders, all_riders, dist_mat, timelimit -1)

    elif 800 <= K < 1500 and timelimit > 200: 
      solution = calg_5(7, all_orders, all_riders, dist_mat, timelimit -2)

    elif 550 <= K < 800 and timelimit < 45: 
      solution = calg_6(10, all_orders, all_riders, dist_mat, timelimit )

    elif 550 <= K < 800 and timelimit >= 45: 
      solution = calg_7(7, all_orders, all_riders, dist_mat, timelimit -1)

    elif 350 <= K < 550 and timelimit <20: 
      solution = calg_8(7, all_orders, all_riders, dist_mat, timelimit )

    elif 350 <= K < 550 and timelimit >= 20: 
      solution = calg_9(6, all_orders, all_riders, dist_mat, timelimit -1)
      
    else: 
      solution = calg_10(8, all_orders, all_riders, dist_mat, timelimit )

    # solution = [
    #     # rider type, shop_seq, dlv_seq
    #     [bundle.rider.type, bundle.shop_seq, bundle.dlv_seq]
    #     for bundle in all_bundles
    # ]

    # ------------- End of custom algorithm code--------------#

    return solution
