import ctypes
import os, subprocess
import time
import numpy as np
from math import factorial
from itertools import permutations


NUM_MAX_PATTERNS = 50000000

def calg_desc():
    return "C enum + C alg(CG->IP) + refinement"

#################################################################################
TARGET_SO_FILE = "libcalg_ybp_10.so"

def compile_c_file(): # FIXME: should not included in the submitted version
    target_c_file = "calg_ybp_c_10.c"
    cwd = os.path.dirname(os.path.abspath(__file__))
    subprocess.run(["gcc", "-c", "-pthread", "-fPIC", "-Wall", "-fno-strict-aliasing", "-O2", "-fwrapv", os.path.join(cwd, target_c_file), "-o", os.path.join(cwd, "temp_enum.o")])
    subprocess.run(["gcc", "-c", "-pthread", "-fPIC", "-Wall", "-fno-strict-aliasing", "-O2", "-fwrapv", os.path.join(cwd, "hashmap.c"), "-o", os.path.join(cwd, "temp_hashmap.o")])
    subprocess.run(["gcc", "-shared", "-lm", os.path.join(cwd, "libxprs.so"), os.path.join(cwd, "temp_enum.o"), os.path.join(cwd, "temp_hashmap.o"), "-o", os.path.join(cwd, TARGET_SO_FILE)]) #f"-L{XPRESSDIR}/lib", "-lxprs", 
##################################################################################



def calg(pattern_upto, ALL_ORDERS, ALL_RIDERS, DIST, time_limit): 
    # preprocess input data
    start_time = time.time()
    num_ALL_ORDERS = len(ALL_ORDERS)
    order_list = [[i.ready_time, i.deadline, i.volume] for i in ALL_ORDERS]
    num_cols_order_list = len(order_list[0])  

    num_ALL_RIDERS = len(ALL_RIDERS)
    rider_list = [[rider.capa, rider.var_cost, rider.fixed_cost, rider.speed, rider.service_time, rider.available_number] for rider in ALL_RIDERS]
    num_cols_rider_list = len(rider_list[0])
        
    # cytypes of input data (orders_array: 2d list, dist_array: 2d numpy array, rider_array: 2d list)
    order_array_type = ctypes.POINTER(ctypes.c_int) * num_ALL_ORDERS
    order_array = order_array_type()
    for i in range(num_ALL_ORDERS):
        order_array[i] = (ctypes.c_int * num_cols_order_list)(*order_list[i])
        
    rider_array_type = ctypes.POINTER(ctypes.c_double) * num_ALL_RIDERS
    rider_array = rider_array_type()
    for h in range(num_ALL_RIDERS):
        rider_array[h] = (ctypes.c_double * num_cols_rider_list)(*rider_list[h])

    dist_ptr = np.ctypeslib.ndpointer(dtype=np.int64, ndim=2, shape=DIST.shape, flags='C_CONTIGUOUS')
    
    # define ctypes container for output data
    num_gen_patts = np.array([0]).ctypes.data_as(ctypes.POINTER(ctypes.c_int))

    # set up IO of C-written function  
    ctypes.cdll.LoadLibrary(f'./libxprl.so')
    ctypes.CDLL(f'./libxprs.so', mode= ctypes.RTLD_GLOBAL)
    cpartload = ctypes.CDLL(f'./{TARGET_SO_FILE}')
    cpartload.pattern_enum.argtypes = [ctypes.POINTER(ctypes.POINTER(ctypes.c_int)), 
                                       ctypes.POINTER(ctypes.POINTER(ctypes.c_double)), 
                                       dist_ptr, 
                                       ctypes.c_int,
                                       ctypes.c_int,
                                       ctypes.c_int,
                                       ctypes.POINTER(ctypes.c_int),
                                       ctypes.c_int]
    cpartload.pattern_enum.restype = ctypes.POINTER(ctypes.c_int)  # return will be 1d array of int
    
    print(f"preprocessing time :  {time.time() - start_time:.4f}")
    print('- ' * 20)
    
    # call C-written function 
    c_enum_start = time.time()
    pat_ptr = cpartload.pattern_enum(order_array, 
                                     rider_array, 
                                     DIST, 
                                     num_ALL_ORDERS, 
                                     pattern_upto, 
                                     NUM_MAX_PATTERNS,
                                     num_gen_patts,
                                     int(time_limit)-1)
    print('- ' * 20)
    print(f"#patts  : {num_gen_patts[0]}")
    print(f"C time  : {time.time() - c_enum_start:.4f}")
    
    # postprocess output data
    pat_list = np.ctypeslib.as_array(pat_ptr, shape=(num_ALL_ORDERS, 2 * pattern_upto + 3))[:num_gen_patts[0]]
    # print(pat_list[:num_gen_patts[0]+1])

    # post-processing
    trt = []
    for idx in range(num_gen_patts[0]):
        pat = pat_list[idx,:]
        num_order = pat[0]
        vehicle_type = pat[-1] 
        permut = [pat[1:num_order+1], pat[num_order+1:2*num_order+1]]
        permut = [[int(val) for val in sub] for sub in permut]
        trt.append([ALL_RIDERS[vehicle_type].type, permut[0], permut[1]])
        
    # close the shared library
    dlclose_func = ctypes.cdll.LoadLibrary(None).dlclose
    dlclose_func.argtypes = [ctypes.c_void_p]
    handle = cpartload._handle
    del cpartload
    dlclose_func(handle)
    del pat_ptr, pat_list
    
    return  trt

if __name__ == '__main__':
    from util import Order, Rider
    import json
          
    # 300: ['STAGE1_5.json', 'STAGE1_6.json', 'STAGE1_11.json', 'STAGE1_12.json', 'STAGE1_17.json', 'STAGE1_18.json', 'STAGE2_TEST_3.json'], 
    # 500: ['STAGE2_1.json', 'STAGE2_3.json', 'STAGE2_5.json', 'STAGE2_TEST_4.json', 'STAGE2_TEST_5.json'], 
    # 750: ['STAGE2_TEST_6.json'],
    # 1000: ['STAGE2_2.json', 'STAGE2_4.json', 'STAGE2_TEST_1.json', 'STAGE2_TEST_2.json', 'STAGE2_6.json'], 
    # 2000: ['STAGE3_1.json', 'STAGE3_2.json', 'STAGE3_3.json']
    problem_file = './instances/STAGE1_TEST_1.json'
    with open(problem_file, 'r') as f:
        prob = json.load(f)

    K = prob['K']
    ALL_ORDERS = [Order(order_info) for order_info in prob['ORDERS']]
    ALL_RIDERS = [Rider(rider_info) for rider_info in prob['RIDERS']]
    DIST = np.array(prob['DIST'])
    for r in ALL_RIDERS:
        r.T = np.round(DIST / r.speed + r.service_time)


    
    print("="*40)
    print(problem_file)
    print(f'#orders: {K}')
    print('-' * 40)
    
    start_time = time.time()
    try: 
        compile_c_file()
    except Exception as e:
        print(e)
    print(f"compile time: {time.time() - start_time:.4f}")
    print('-' * 40)

    # main part start here
    pattern_upto = 8
    time_limit = 15
    
    start_time = time.time()
    # pat_list = 
    solution = calg(pattern_upto, ALL_ORDERS, ALL_RIDERS, DIST, time_limit)
    
    print("-"*40)
    print(f"total time : {time.time() - start_time:.3f}")

    from util import solution_check
    checked_solution = solution_check(K, ALL_ORDERS, ALL_RIDERS, DIST, solution)
    print(f"cost       : {checked_solution['avg_cost']:.3f}\nfeasible   : {checked_solution['feasible']}\ninfeasible : {checked_solution['infeasibility']}")
    print("="*40)
    
    def get_min_cost_route_enum(orders, vehicle_type):
        K = len(ALL_ORDERS)
        num_orders = len(orders)
        ready_times = {order: ALL_ORDERS[order].ready_time for order in orders}
        deadlines = {order: ALL_ORDERS[order].deadline for order in orders}
        fixed_cost = ALL_RIDERS[vehicle_type].fixed_cost
        var_cost = ALL_RIDERS[vehicle_type].var_cost

        dp_all = [None for _ in range(factorial(num_orders))]
        tp_all = [None for _ in range(factorial(num_orders))]
        tp_last_min = 1e7
        for p_idx, p_perm in enumerate(permutations(orders)):
            dp_all[p_idx] = 0
            tp_all[p_idx] = [0 for _ in range(num_orders)]
            tp_all[p_idx][0] = ready_times[p_perm[0]]
            for i in range(1, num_orders):
                tp_all[p_idx][i] = max(
                    tp_all[p_idx][i - 1] + ALL_RIDERS[vehicle_type].T[p_perm[i - 1]][p_perm[i]],
                    ALL_ORDERS[p_perm[i]].ready_time,
                )
                dp_all[p_idx] += DIST[p_perm[i - 1]][p_perm[i]]
            if tp_all[p_idx][-1] < tp_last_min:
                tp_last_min = tp_all[p_idx][-1]
            
        dd_all = [None for _ in range(factorial(num_orders))]
        td_all = [None for _ in range(factorial(num_orders))]
        d_perm_infeas = [False for _ in range(factorial(num_orders))]
        for d_idx, d_perm in enumerate(permutations(orders)):
            dd_all[d_idx] = 0
            td_all[d_idx] = [0 for _ in range(num_orders)]
            
            td_all[d_idx][-1] = deadlines[d_perm[-1]] 
            for i in range(num_orders-1):
                td_all[d_idx][-2-i] = min(
                    td_all[d_idx][-1-i] - ALL_RIDERS[vehicle_type].T[d_perm[-2-i] + K][d_perm[-1-i] + K],
                    deadlines[d_perm[-2-i]]
                )
                dd_all[d_idx] += DIST[d_perm[-2-i] + K][d_perm[-1-i] + K]
                if tp_last_min > td_all[d_idx][-2-i]:
                    d_perm_infeas[d_idx] = True
                    continue
            
        min_dist, best_pd_perms = 1e9, []
        for d_idx, d_perm in enumerate(permutations(orders)):
            if d_perm_infeas[d_idx]:
                continue
            for p_idx, p_perm in enumerate(permutations(orders)):
                if tp_all[p_idx][-1] + ALL_RIDERS[vehicle_type].T[p_perm[-1]][d_perm[0] + K]  > td_all[d_idx][0]:
                    continue
                dist = dp_all[p_idx] + DIST[p_perm[-1]][d_perm[0] + K] + dd_all[d_idx]
                if dist < min_dist:
                    min_dist = dist
                    best_pd_perms = [p_perm, d_perm]

        if min_dist == 1e9:
            return False, [], 0
        return True, best_pd_perms, 1 / K * (fixed_cost + min_dist / 100 * var_cost)
    # end of get_min_cost_route_enum

    # post-processing
    vehicle_types = {ALL_RIDERS[h].type:h for h in range(3)}
    trt = []
    for idx in range(len(solution)):
        orders = solution[idx][1]
        # print(orders)
        if (len(orders) == 1):
            permut = [[orders[0]], [orders[0]]]
        else:
            tf, permut, cost = get_min_cost_route_enum(orders, vehicle_types[solution[idx][0]])
        permut = [[int(val) for val in sub] for sub in permut]
        trt.append([solution[idx][0], permut[0], permut[1]])
        
    checked_solution = solution_check(K, ALL_ORDERS, ALL_RIDERS, DIST, trt)
    print(f"cost       : {checked_solution['avg_cost']:.3f}\nfeasible   : {checked_solution['feasible']}\ninfeasible : {checked_solution['infeasibility']}")
    print("="*40)