import ctypes
import os, subprocess
import time
import numpy as np
from math import factorial
from itertools import permutations


NUM_MAX_PATTERNS = 50000000

def calg_desc():
    return "C enum + C alg(CG->IP) + refinement"

#################################################################################
TARGET_SO_FILE = "libcalg_ybp_8.so"

def compile_c_file(): # FIXME: should not included in the submitted version
    target_c_file = "calg_ybp_c_8.c"
    cwd = os.path.dirname(os.path.abspath(__file__))
    subprocess.run(["gcc", "-c", "-pthread", "-fPIC", "-Wall", "-fno-strict-aliasing", "-O2", "-fwrapv", os.path.join(cwd, target_c_file), "-o", os.path.join(cwd, "temp_enum.o")])
    subprocess.run(["gcc", "-c", "-pthread", "-fPIC", "-Wall", "-fno-strict-aliasing", "-O2", "-fwrapv", os.path.join(cwd, "hashmap.c"), "-o", os.path.join(cwd, "temp_hashmap.o")])
    subprocess.run(["gcc", "-shared", "-lm", os.path.join(cwd, "libxprs.so"), os.path.join(cwd, "temp_enum.o"), os.path.join(cwd, "temp_hashmap.o"), "-o", os.path.join(cwd, TARGET_SO_FILE)]) #f"-L{XPRESSDIR}/lib", "-lxprs", 
##################################################################################



def calg(pattern_upto, all_orders, all_riders, dist_mat, time_limit): 
    # preprocess input data
    start_time = time.time()
    num_all_orders = len(all_orders)
    order_list = [[i.ready_time, i.deadline, i.volume] for i in all_orders]
    num_cols_order_list = len(order_list[0])  

    num_all_riders = len(all_riders)
    rider_list = [[rider.capa, rider.var_cost, rider.fixed_cost, rider.speed, rider.service_time, rider.available_number] for rider in all_riders]
    num_cols_rider_list = len(rider_list[0])
        
    # cytypes of input data (orders_array: 2d list, dist_array: 2d numpy array, rider_array: 2d list)
    order_array_type = ctypes.POINTER(ctypes.c_int) * num_all_orders
    order_array = order_array_type()
    for i in range(num_all_orders):
        order_array[i] = (ctypes.c_int * num_cols_order_list)(*order_list[i])
        
    rider_array_type = ctypes.POINTER(ctypes.c_double) * num_all_riders
    rider_array = rider_array_type()
    for h in range(num_all_riders):
        rider_array[h] = (ctypes.c_double * num_cols_rider_list)(*rider_list[h])

    dist_ptr = np.ctypeslib.ndpointer(dtype=np.int64, ndim=2, shape=dist_mat.shape, flags='C_CONTIGUOUS')
    
    # define ctypes container for output data
    num_gen_patts = np.array([0]).ctypes.data_as(ctypes.POINTER(ctypes.c_int))

    # set up IO of C-written function  
    ctypes.cdll.LoadLibrary(f'./libxprl.so')
    ctypes.CDLL(f'./libxprs.so', mode= ctypes.RTLD_GLOBAL)
    cpartload = ctypes.CDLL(f'./{TARGET_SO_FILE}')
    cpartload.pattern_enum.argtypes = [ctypes.POINTER(ctypes.POINTER(ctypes.c_int)), 
                                       ctypes.POINTER(ctypes.POINTER(ctypes.c_double)), 
                                       dist_ptr, 
                                       ctypes.c_int,
                                       ctypes.c_int,
                                       ctypes.c_int,
                                       ctypes.POINTER(ctypes.c_int),
                                       ctypes.c_int]
    cpartload.pattern_enum.restype = ctypes.POINTER(ctypes.c_int)  # return will be 1d array of int
    
    print(f"preprocessing time :  {time.time() - start_time:.4f}")
    print('- ' * 20)
    
    # call C-written function 
    c_enum_start = time.time()
    pat_ptr = cpartload.pattern_enum(order_array, 
                                     rider_array, 
                                     dist_mat, 
                                     num_all_orders, 
                                     pattern_upto, 
                                     NUM_MAX_PATTERNS,
                                     num_gen_patts,
                                     int(time_limit)-1)
    print('- ' * 20)
    print(f"#patts  : {num_gen_patts[0]}")
    print(f"C time  : {time.time() - c_enum_start:.4f}")
    
    # postprocess output data
    pat_list = np.ctypeslib.as_array(pat_ptr, shape=(num_all_orders, 2 * pattern_upto + 3))[:num_gen_patts[0]]
    # print(pat_list[:num_gen_patts[0]+1])

    # post-processing
    trt = []
    for idx in range(num_gen_patts[0]):
        pat = pat_list[idx,:]
        num_order = pat[0]
        vehicle_type = pat[-1] 
        permut = [pat[1:num_order+1], pat[num_order+1:2*num_order+1]]
        permut = [[int(val) for val in sub] for sub in permut]
        trt.append([all_riders[vehicle_type].type, permut[0], permut[1]])
        
    # close the shared library
    dlclose_func = ctypes.cdll.LoadLibrary(None).dlclose
    dlclose_func.argtypes = [ctypes.c_void_p]
    handle = cpartload._handle
    del cpartload
    dlclose_func(handle)
    del pat_ptr, pat_list
    
    return  trt

if __name__ == '__main__':
    from util import Order, Rider
    import json
          
    # 300: ['STAGE1_5.json', 'STAGE1_6.json', 'STAGE1_11.json', 'STAGE1_12.json', 'STAGE1_17.json', 'STAGE1_18.json', 'STAGE2_TEST_3.json'], 
    # 500: ['STAGE2_1.json', 'STAGE2_3.json', 'STAGE2_5.json', 'STAGE2_TEST_4.json', 'STAGE2_TEST_5.json'], 
    # 750: ['STAGE2_TEST_6.json'],
    # 1000: ['STAGE2_2.json', 'STAGE2_4.json', 'STAGE2_TEST_1.json', 'STAGE2_TEST_2.json', 'STAGE2_6.json'], 
    # 2000: ['STAGE3_1.json', 'STAGE3_2.json', 'STAGE3_3.json']
    problem_file = './instances/STAGE3_1.json'
    with open(problem_file, 'r') as f:
        prob = json.load(f)

    K = prob['K']
    ALL_ORDERS = [Order(order_info) for order_info in prob['ORDERS']]
    ALL_RIDERS = [Rider(rider_info) for rider_info in prob['RIDERS']]
    DIST = np.array(prob['DIST'])
    for r in ALL_RIDERS:
        r.T = np.round(DIST / r.speed + r.service_time)


    
    print("="*40)
    print(problem_file)
    print(f'#orders: {K}')
    print('-' * 40)
    
    start_time = time.time()
    try: 
        compile_c_file()
    except Exception as e:
        print(e)
    print(f"compile time: {time.time() - start_time:.4f}")
    print('-' * 40)

    # main part start here
    pattern_upto = 7
    time_limit = 60
    
    start_time = time.time()
    # pat_list = 
    solution = calg(pattern_upto, ALL_ORDERS, ALL_RIDERS, DIST, time_limit)
    
    print("-"*40)
    print(f"total time : {time.time() - start_time:.3f}")

    from util import solution_check
    checked_solution = solution_check(K, ALL_ORDERS, ALL_RIDERS, DIST, solution)
    print(f"cost       : {checked_solution['avg_cost']:.3f}\nfeasible   : {checked_solution['feasible']}\ninfeasible : {checked_solution['infeasibility']}")
    print("="*40)