from util import *
from myalgorithm import algorithm

problem_dir = './instances'

configs = [
    ['STAGE3_2.json', 300], 
    ['STAGE3_2.json', 480], 
    ['STAGE2_4.json', 60], 
    ['STAGE2_4.json', 180], 
    ['STAGE2_4.json', 300], 
    ['STAGE2_TEST_6.json', 30], 
    ['STAGE2_2.json', 30],
    ['STAGE2_TEST_6.json', 60], 
    ['STAGE2_3.json', 15],
    ['STAGE2_3.json', 30],
    ['STAGE1_5.json', 15] 
    ]

num = 0
for file, timelimit in configs:
    num += 1
    print('='*40)
    problem_file = f'./{problem_dir}/{file}'
    print(file, timelimit)
    print('-'*40)
    with open(problem_file, 'r') as f:
        prob = json.load(f)

    K = prob['K']

    ALL_ORDERS = [Order(order_info) for order_info in prob['ORDERS']]
    ALL_RIDERS = [Rider(rider_info) for rider_info in prob['RIDERS']]

    DIST = np.array(prob['DIST'])
    for r in ALL_RIDERS:
        r.T = np.round(DIST/r.speed + r.service_time)

    alg_start_time = time.time()

    exception = None

    solution = None

    solution = algorithm(K, ALL_ORDERS, ALL_RIDERS, DIST, timelimit)

    alg_end_time = time.time()

    with open(problem_file, 'r') as f:
        prob = json.load(f)

    K = prob['K']

    ALL_ORDERS = [Order(order_info) for order_info in prob['ORDERS']]
    ALL_RIDERS = [Rider(rider_info) for rider_info in prob['RIDERS']]

    DIST = np.array(prob['DIST'])
    for r in ALL_RIDERS:
        r.T = np.round(DIST/r.speed + r.service_time)

    checked_solution = solution_check(K, ALL_ORDERS, ALL_RIDERS, DIST, solution)

    checked_solution['time'] = alg_end_time - alg_start_time
    checked_solution['timelimit_exception'] = (alg_end_time - alg_start_time) > timelimit + 1 # allowing additional 1 second!
    checked_solution['exception'] = exception

    checked_solution['prob_name'] = prob['name']
    checked_solution['prob_file'] = problem_file
    
    print('-'*40)
    print(f'{num} :  {file}    {timelimit} sec')
    print(f"cost       : {checked_solution['avg_cost']:.3f}\nfeasible   : {checked_solution['feasible']}\ninfeasible : {checked_solution['infeasibility']}")
    print('='*40)