from util import *
import itertools
import ctypes
import sys

def pattern_enum_RH_new(orders,riders,dist_mat, k,KK, HO, SL,sort_ind, each_pat_num, timelimit):
    orders_list = [[i.id, i.ready_time,i.deadline,i.volume] for i in orders]
    orders_col = len(orders_list[0])

    orders_array_type = ctypes.POINTER(ctypes.c_int) * KK
    orders_array = orders_array_type()
    
    for i in range(KK):
        orders_array[i] = (ctypes.c_int * orders_col)(*orders_list[i])

    rider_list = []
    for rider in riders:
        rider_list += [rider.capa,rider.speed,rider.service_time, rider.var_cost, rider.fixed_cost, rider.available_number]

    rider_array = (ctypes.c_double * 18)(*rider_list)

    HOSL_list = [HO,SL]
    HOSL_array = (ctypes.c_int * 2)(*HOSL_list)

    dist_array = dist_mat.ctypes.data_as(ctypes.POINTER(ctypes.c_int))
    #print("done")
    
    

    total_pattern_num = np.array(each_pat_num,dtype=np.float64)
    total_pat_num = total_pattern_num.ctypes.data_as(ctypes.POINTER(ctypes.c_int))

    #cpartload=ctypes.CDLL('./pattern_gen_RH_matrix.so')
    #cpartload=ctypes.CDLL('./pattern_gen_RH_multi2opt_post.so')
    #cpartload=ctypes.CDLL('./pattern_gen_RH_R.so')

    cpartload=ctypes.CDLL('./pattern_gen_RH_adaptive_g.so')

    cpartload.pattern_enum_RH_new.argtypes = [ctypes.POINTER(ctypes.POINTER(ctypes.c_int)), ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_int), ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.POINTER(ctypes.c_int),ctypes.POINTER(ctypes.c_int),ctypes.c_int,ctypes.c_int]
    cpartload.pattern_enum_RH_new.restype = ctypes.POINTER(ctypes.POINTER(ctypes.c_int))
    pat_ptr = cpartload.pattern_enum_RH_new(orders_array,rider_array, dist_array, KK,orders_col, k,total_pat_num,HOSL_array,sort_ind,timelimit)
    each_pat_num[0] = total_pat_num[0]
    pat_list = np.zeros((each_pat_num[0],2*k+2),dtype=np.int64)
    for i in range(each_pat_num[0]):
        pat_list[i, :] = np.ctypeslib.as_array(pat_ptr[i], shape=(2*k+2,))

    #sys.setrecursionlimit(10**7)

    #after_pat_num = total_pat_num[0] + total_pat_num[1] + total_pat_num[2]
    
    
    #pat_list = []
    #pat_list = [convert_to_list(pat_ptr,jj,k) for jj in range(1,after_pat_num+1)]
    # pattern_enum_cpart()
    #print("pat_num:",total_pattern_num)
    #cpartload.free_2d_array(pat_ptr,after_pat_num)
    return pat_list#pat_ptr

