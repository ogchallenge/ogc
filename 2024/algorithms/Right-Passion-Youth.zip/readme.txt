so 파일은 다음의 명령어로 compile합니다.

gcc -shared -fPIC -o pattern_gen_RH_adaptive_g.so pattern_gen_RH_adaptive_g.c -I/opt/gurobi1101/linux64/include -L/opt/gurobi1101/linux64/lib -lgurobi110 -I/opt/xpressmp/include -L/opt/xpressmp/lib -lxprs -fopenmp


