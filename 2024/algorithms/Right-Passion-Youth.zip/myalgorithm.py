from util import *
import itertools
import ctypes
import time
import sys
import xpress as xp
import math
#from optimization_0719 import opt_model, opt_parameter, opt_constraint, opt_objective
from patgen_R import *
from scipy.sparse import csr_matrix

def algorithm(K, all_orders, all_riders, dist_mat_origin, timelimit=60):

    start_time = time.time()

    # A solution is a list of bundles
    solution = []

    #------------- Custom algorithm code starts from here --------------#
    dist_mat = dist_mat_origin.astype(np.float64)
    #print(dist_mat)
        
    test_inst = 0
    
    if(K==2000 and timelimit <=400): #P1
        max_bundle_size = 8
        test_inst = 1
    
    if(K==2000 and timelimit > 400): #P2
        max_bundle_size = 8
        test_inst = 1
    
    if(K==1000 and timelimit <= 70): #P3
        max_bundle_size = 8
        test_inst = 1

    if(K==1000 and timelimit < 200 and timelimit >= 75): #P4
        max_bundle_size = 8
        test_inst = 1
    
    if(K==1000 and timelimit >= 200): #P5
        max_bundle_size = 8
        test_inst = 1
    
    if(K==750 and timelimit <= 45): #P6
        max_bundle_size = 7
        test_inst = 1
    
    if(K==750 and timelimit >= 45): #P7
        max_bundle_size = 8
        test_inst = 1

    if(K==500 and timelimit <= 20): #P8
        max_bundle_size = 7
        test_inst = 1

    if(K==500 and timelimit >= 20): #P9
        max_bundle_size = 8
        test_inst = 1

    if(K==300 and timelimit <= 20): #P10
        max_bundle_size = 7
        test_inst = 1

    if(test_inst==0):
        max_bundle_size = 8

    #max_bundle_size  = 7

    HORI = K#1000#K#300#K-10#    
    SLID_HORIZON = max(K-HORI,1)
    SLID = 0#1000#50#math.ceil(SLID_HORIZON/(math.ceil(K/HORI)+0))
    sort_ind = 0
    
    #stand_time = 58

    # 거리 정보 입력
    bundle_num = [0]
    #rider_num = len(all_riders)
    ### 묶음 만들기

    
    #print("Bundle generation...")new
    bundle_gen_start_time = time.time()
    
    rider_bundle_list = pattern_enum_RH_new(all_orders, all_riders, dist_mat, max_bundle_size, K, HORI,SLID,sort_ind,bundle_num,timelimit)
    #rider_bundle_list = pattern_enum_once(all_orders, all_riders, dist_mat, max_bundle_size, K,sort_ind,bundle_num)
    #rider_bundle_list = pattern_enum_2opt_once(all_orders, all_riders, dist_mat, max_bundle_size, K,sort_ind,bundle_num)

    #print(rider_bundle_list[:,0])
    bundle_gen_end_time = time.time()
    bundle_gen_time = bundle_gen_end_time - bundle_gen_start_time
    print(f"Finished, Time elapsed: {bundle_gen_time}")
    


    for i in range(bundle_num[0]):
        each_length = (int)(rider_bundle_list[i,2*max_bundle_size+1])
        rider_ind = (int)(rider_bundle_list[i,2*max_bundle_size])
        #print(each_length)
        #print(rider_bundle_list[K+1:K+each_length+1,i])
        if(rider_ind==0):
            solution += [['BIKE',rider_bundle_list[i,:each_length].tolist(),rider_bundle_list[i,max_bundle_size:each_length+max_bundle_size].tolist()]]
        if(rider_ind==1):
            solution += [['WALK',rider_bundle_list[i,:each_length].tolist(),rider_bundle_list[i,max_bundle_size:each_length+max_bundle_size].tolist()]]
        if(rider_ind==2):
            solution += [['CAR',rider_bundle_list[i,:each_length].tolist(),rider_bundle_list[i,max_bundle_size:each_length+max_bundle_size].tolist()]]

    #print(solution)
    
    return solution