
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <malloc.h>
#include <time.h>
#include <unistd.h>
#include <error.h>
#include "xprb.h"
#include "xprs.h"
#include <omp.h>
#include "gurobi_c.h"

#define MAX_ELEMENT 10000000
#define MAX_HEAP_ELEMENT 10000000
#define epsilon 0.01
#define MIN_DIST_VAL 1000000
#define MAX_BUNDLE_NUM 100000


typedef struct{
    int arr_value;
    int arr_ind;
}int_arr_ind;

typedef struct{
    int classn;
    int item;
}var_list;

typedef struct{
    double arr_value;
    int arr_ind;
}double_arr_ind;


typedef struct{
    int prev;
    int next;
}order_matrix;

typedef struct {
	double_arr_ind heap[MAX_HEAP_ELEMENT];
	int heap_size;
} HeapType;

typedef struct {
	double_arr_ind heap[30];
	int heap_size;
} HeapType_SMALL;



typedef struct {
	int_arr_ind heap[MAX_HEAP_ELEMENT];
	int heap_size;
} HeapType_int_arr;


typedef struct {
	int heap[MAX_HEAP_ELEMENT];
	int heap_size;
} HeapType_int;

//Global variables, functions
int order_num, rider_num, **matrix_arr,pat_arr_length_each;
int **order_arr, ***pat_arr, ***each_pat_arr, *each_pat_num, ***pat_feas_arr, pat_size, *pat_num, **pat_capa, pat_arr_length, *each_pat_num_two; 
int *pat_buffer, **inst_pat_ind, *inst_pat_num, **next_pat_ind, *next_pat_num;
int *order_ordering;
int ***rider_time;
int HORIZON, SLIDE, HYBRID_CRIT, OPTNUM, FEAIND;
int slice_num, slice_num_sub,total_num, *total_num_cur;
int **selected_col, selected_num, **inter_selected_col, inter_selected_num;
int **sol_col,sol_num, MAX_TIME;
int **temp_pat_arr, **temp_each_pat_to, temp_pat_num, ***temp_each_pat_arr,*temp_each_pat_num, *temp_pat_capa, **temp_pat_feas_arr;
double **dist_mat, **rider_info, **rider_cost, **each_pat_cost, **temp_each_pat_cost;
double *temp_job_dual, *temp_rider_dual;
int MAX_COL_EACH;
int SLACK_TIME, MAX_COL, MODIFY_LIMIT, INTER_ONE_ITER_COL;
int num_threads;
double CUT_PARAM, HEUR_PARAM;
int MIPFOCU;
int test_inst;
int *MAX_COL_EACH_ARR;
omp_lock_t lock;
HeapType every_heap;
time_t Totaltime, Totalstart, Curend;


XPRBprob masterLP, masterMIP;
XPRBvar ***x, *y, z; 
//XPRBexpr *job_term, *rider_term, obj_term;
XPRBctr *job_const, *rider_const, obj_const;
XPRBctr *job_const_MIP, *rider_const_MIP, obj_const_MIP;

void initial_LP(void);
void inter_col_gen(int);
void col_selection(void);
void modelMIP(void);
void solveMIP(void);
void modelMIP_g(void);
//void solveMIP_g(void);
void cost_calculate(void);
void init_cost_calculate(void);
void temp_cost_calculate(void);
void cost_modify(int);
void cost_modify_after(void);
int pre_feas_check(int, int*, int,int);
int pre_feas_check_2opt(int, int*, int,int);
void swap(int*, int, int);
void generatePermutations(int*, int, int, int**, int*);
int factorial(int);
double optimal_route_check(int*, int, int*, int*,int);
int** permute(int*, int, int*);
double* pick_route_check(int*, int,int);
void deli_route_check(int*, double*, int, int*, double*, int*, int,int,int);
void pattern_gen_new(void);
void pattern_gen_new_0(int,int);
void init_sol_gen(int*, int, int*);
double feas_check(int* , int ,int);
double dist_check(int* , int , int);
int local_search_feas(int*, int , int);
int local_search_opt(int*, int,int);
static void init(HeapType *);
static void insert_max_heap(HeapType *, double_arr_ind );
static double_arr_ind delete_max_heap(HeapType *);
static void init_small(HeapType_SMALL *);
static void insert_max_heap_small(HeapType_SMALL *, double_arr_ind );
static double_arr_ind delete_max_heap_small(HeapType_SMALL *);



int** pattern_enum_RH_new(int** order_array, double* rider_array, double* dist_array, int KK, int cols, int pat_size_limit, int* total_pat_num, int* ho_sl, int ordering_param, int timelimit){
    //initialization
    
    time(&Totalstart);

    order_num = KK;
    rider_num = 3;
    pat_size = pat_size_limit;

    HORIZON = ho_sl[0];
    SLIDE = ho_sl[1];
    MAX_TIME = timelimit;

    num_threads = 4;
    omp_set_num_threads(num_threads);
    MAX_COL_EACH_ARR = (int*)calloc(5,sizeof(int));

    test_inst = 0;
    if(order_num == 2000 && MAX_TIME <= 400){ //P1
        HYBRID_CRIT = 5;
        INTER_ONE_ITER_COL = 10000;
        MAX_COL_EACH = 0;
        MAX_COL_EACH_ARR[0] = 50000;
        MAX_COL_EACH_ARR[1] = 50000;
        MAX_COL_EACH_ARR[2] = 50000;
        MAX_COL_EACH_ARR[3] = 20000;
        MAX_COL_EACH_ARR[4] = 20000;
        MAX_COL = 18000;
        SLACK_TIME = 4;
        MODIFY_LIMIT = 6;
        CUT_PARAM = -1;
        HEUR_PARAM = 0.05;
        MIPFOCU = 1;
        test_inst = 1;
    }

    if(order_num == 2000 && MAX_TIME >= 400){ //P2
        HYBRID_CRIT = 5;
        INTER_ONE_ITER_COL = 10000;
        MAX_COL_EACH = 0;
        MAX_COL_EACH_ARR[0] = 50000;
        MAX_COL_EACH_ARR[1] = 50000;
        MAX_COL_EACH_ARR[2] = 50000;
        MAX_COL_EACH_ARR[3] = 30000;
        MAX_COL_EACH_ARR[4] = 30000;
        MAX_COL = 50000;
        SLACK_TIME = 4;
        MODIFY_LIMIT = 6;
        CUT_PARAM = -1;
        HEUR_PARAM = 0.05;
        MIPFOCU = 1;
        test_inst = 1;
    }

    if(order_num == 1000 && MAX_TIME <= 70){ //P3
        HYBRID_CRIT = 2;
        INTER_ONE_ITER_COL = 10000;
        MAX_COL_EACH = 0;
        MAX_COL_EACH_ARR[0] = 20000;
        MAX_COL_EACH_ARR[1] = 20000;
        MAX_COL_EACH_ARR[2] = 15000;
        MAX_COL_EACH_ARR[3] = 10000;
        MAX_COL_EACH_ARR[4] = 10000;
        MAX_COL = 10000;
        SLACK_TIME = 1;
        MODIFY_LIMIT = 6;
        CUT_PARAM = -1;
        HEUR_PARAM = 0.05;
        MIPFOCU = 1;
        test_inst = 1;
    }

    if(order_num == 1000 && MAX_TIME <= 200 && MAX_TIME >= 75 ){ //P4
        HYBRID_CRIT = 4;
        INTER_ONE_ITER_COL = 10000;
        MAX_COL_EACH = 0;
        MAX_COL_EACH_ARR[0] = 30000;
        MAX_COL_EACH_ARR[1] = 30000;
        MAX_COL_EACH_ARR[2] = 20000;
        MAX_COL_EACH_ARR[3] = 20000;
        MAX_COL_EACH_ARR[4] = 20000;
        MAX_COL = 11000;
        SLACK_TIME = 2;
        MODIFY_LIMIT = 6;
        CUT_PARAM = -1;
        HEUR_PARAM = 0.05;
        MIPFOCU = 1;
        test_inst = 1;
    }

    if(order_num == 1000 && MAX_TIME >= 250){ //P5
        HYBRID_CRIT = 5;
        INTER_ONE_ITER_COL = 10000;
        MAX_COL_EACH = 0;
        MAX_COL_EACH_ARR[0] = 50000;
        MAX_COL_EACH_ARR[1] = 50000;
        MAX_COL_EACH_ARR[2] = 50000;
        MAX_COL_EACH_ARR[3] = 35000;
        MAX_COL_EACH_ARR[4] = 35000;
        MAX_COL = 10000;
        SLACK_TIME = 3;
        MODIFY_LIMIT = 6;
        CUT_PARAM = -1;
        HEUR_PARAM = 0.05;
        MIPFOCU = 1;
        test_inst = 1;
    }
    
    if(order_num == 750 && MAX_TIME<=45){ //P6
        HYBRID_CRIT = 2;
        INTER_ONE_ITER_COL = 10000;
        MAX_COL_EACH = 0;
        MAX_COL_EACH_ARR[0] = 25000;
        MAX_COL_EACH_ARR[1] = 25000;
        MAX_COL_EACH_ARR[2] = 25000;
        MAX_COL_EACH_ARR[3] = 12000;
        MAX_COL_EACH_ARR[4] = 12000;
        SLACK_TIME = 1;
        MAX_COL = 5000;
        MODIFY_LIMIT = 6;
        CUT_PARAM = -1;
        HEUR_PARAM = 0.05;
        MIPFOCU = 1;
        test_inst = 1;
    }

    if(order_num == 750 && MAX_TIME> 45 && MAX_TIME <= 75){ //P7
        HYBRID_CRIT = 5;
        INTER_ONE_ITER_COL = 10000;
        MAX_COL_EACH = 0;
        MAX_COL_EACH_ARR[0] = 40000;
        MAX_COL_EACH_ARR[1] = 40000;
        MAX_COL_EACH_ARR[2] = 40000;
        MAX_COL_EACH_ARR[3] = 20000;
        MAX_COL_EACH_ARR[4] = 20000;
        SLACK_TIME = 2;
        MAX_COL = 5000;
        MODIFY_LIMIT = 6;
        CUT_PARAM = -1;
        HEUR_PARAM = 0.05;
        MIPFOCU = 1;
        test_inst = 1;
    }

    if(order_num == 500 && MAX_TIME <= 20){ //P8
        HYBRID_CRIT = 1;
        INTER_ONE_ITER_COL = 4000;
        MAX_COL_EACH_ARR[0] = 12000;
        MAX_COL_EACH_ARR[1] = 10000;
        MAX_COL_EACH_ARR[2] = 12000;
        MAX_COL_EACH_ARR[3] = 5000;
        MAX_COL_EACH_ARR[4] = 5000;
        SLACK_TIME = 1;
        MAX_COL = 4000;
        MODIFY_LIMIT = 6;
        CUT_PARAM = -1;
        HEUR_PARAM = 0.05;
        MIPFOCU = 1;
        test_inst = 1;
    }

    if(order_num == 500 && MAX_TIME >= 20 && MAX_TIME <=45){ //P9
        HYBRID_CRIT = 2;
        INTER_ONE_ITER_COL = 4000;
        MAX_COL_EACH_ARR[0] = 40000;
        MAX_COL_EACH_ARR[1] = 20000;
        MAX_COL_EACH_ARR[2] = 40000;
        MAX_COL_EACH_ARR[3] = 17000;
        MAX_COL_EACH_ARR[4] = 17000;
        SLACK_TIME = 1;
        MAX_COL = 6000;
        MODIFY_LIMIT = 6;
        CUT_PARAM = -1;
        HEUR_PARAM = 0.05;
        MIPFOCU = 1;
        test_inst = 1;
    }

    if(order_num == 300 && MAX_TIME <= 20){ //P10
        HYBRID_CRIT = 5;
        INTER_ONE_ITER_COL = 10000;
        MAX_COL_EACH_ARR[0] = 35000;
        MAX_COL_EACH_ARR[1] = 20000;
        MAX_COL_EACH_ARR[2] = 35000;
        MAX_COL_EACH_ARR[3] = 20000;
        MAX_COL_EACH_ARR[4] = 20000;
        SLACK_TIME = 1;
        MAX_COL = 4000;
        MODIFY_LIMIT = 6;
        CUT_PARAM = -1;
        HEUR_PARAM = 0.05;
        MIPFOCU = 1;
        test_inst = 1;
    }

    if(test_inst==0){
        if(MAX_TIME >= 180){
            HYBRID_CRIT = 5;
            INTER_ONE_ITER_COL = 10000;
            MAX_COL_EACH = 0;
            MAX_COL_EACH_ARR[0] = 40000;
            MAX_COL_EACH_ARR[1] = 40000;
            MAX_COL_EACH_ARR[2] = 40000;
            MAX_COL_EACH_ARR[3] = 25000;
            MAX_COL_EACH_ARR[4] = 25000;
            MAX_COL = 10000;
            SLACK_TIME = 4;
            MODIFY_LIMIT = 6;
            CUT_PARAM = -1;
            HEUR_PARAM = 0.05;
            MIPFOCU = 1;
        }
        if(MAX_TIME < 180){
            if(order_num<=300){
                HYBRID_CRIT = 5;
            }else{
                HYBRID_CRIT = 4;
            }
            
            INTER_ONE_ITER_COL = 10000;
            MAX_COL_EACH = 0;
            MAX_COL_EACH_ARR[0] = 25000;
            MAX_COL_EACH_ARR[1] = 25000;
            MAX_COL_EACH_ARR[2] = 25000;
            MAX_COL_EACH_ARR[3] = 20000;
            MAX_COL_EACH_ARR[4] = 20000;
            MAX_COL = 10000;
            SLACK_TIME = 2;
            MODIFY_LIMIT = 6;
            CUT_PARAM = -1;
            HEUR_PARAM = 0.05;
            MIPFOCU = 1;
        }
        if(MAX_TIME < 45){
            if(order_num<=300){
                HYBRID_CRIT = 5;
            }else{
                HYBRID_CRIT = 4;
            }
            INTER_ONE_ITER_COL = 10000;
            MAX_COL_EACH = 0;
            MAX_COL_EACH_ARR[0] = 20000;
            MAX_COL_EACH_ARR[1] = 20000;
            MAX_COL_EACH_ARR[2] = 20000;
            MAX_COL_EACH_ARR[3] = 15000;
            MAX_COL_EACH_ARR[4] = 15000;
            MAX_COL = 5000;
            SLACK_TIME = 1;
            MODIFY_LIMIT = 6;
            CUT_PARAM = -1;
            HEUR_PARAM = 0.05;
            MIPFOCU = 1;
        }
        if(MAX_TIME < 20){
            HYBRID_CRIT = 2;
            INTER_ONE_ITER_COL = 10000;
            MAX_COL_EACH = 0;
            MAX_COL_EACH_ARR[0] = 20000;
            MAX_COL_EACH_ARR[1] = 15000;
            MAX_COL_EACH_ARR[2] = 20000;
            MAX_COL_EACH_ARR[3] = 10000;
            MAX_COL_EACH_ARR[4] = 10000;
            MAX_COL = 4000;
            SLACK_TIME = 1;
            MODIFY_LIMIT = 6;
            CUT_PARAM = -1;
            HEUR_PARAM = 0.05;
            MIPFOCU = 1;
        }
    }
    /*HYBRID_CRIT = 5;
    INTER_ONE_ITER_COL = 10000;
    //MAX_COL_EACH = 0;
    MAX_COL_EACH_ARR[0] = 40000;
    MAX_COL_EACH_ARR[1] = 20000;
    MAX_COL_EACH_ARR[2] = 40000;
    MAX_COL_EACH_ARR[3] = 15000;
    MAX_COL_EACH_ARR[4] = 15000;
    MAX_COL = 5000;
    SLACK_TIME = 1;
    MODIFY_LIMIT = 6;
    CUT_PARAM = -1;
    HEUR_PARAM = 0.05;
    MIPFOCU = 1;*/
    /*HYBRID_CRIT = 2;
    INTER_ONE_ITER_COL = 10000;
    MAX_COL_EACH_ARR[0] = 15000;
    MAX_COL_EACH_ARR[1] = 15000;
    MAX_COL_EACH_ARR[2] = 15000;
    MAX_COL_EACH_ARR[3] = 10000;
    MAX_COL_EACH_ARR[4] = 8000;
    SLACK_TIME = 1;
    MAX_COL = 5000;
    MODIFY_LIMIT = 6;
    CUT_PARAM = -1;
    HEUR_PARAM = 1.0;*/

    /*HYBRID_CRIT = 5;
    INTER_ONE_ITER_COL = 10000;
    //MAX_COL_EACH = 0;
    MAX_COL_EACH_ARR[0] = 25000;
    MAX_COL_EACH_ARR[1] = 25000;
    MAX_COL_EACH_ARR[2] = 25000;
    MAX_COL_EACH_ARR[3] = 12500;
    MAX_COL_EACH_ARR[4] = 12500;
    MAX_COL = 5000;
    SLACK_TIME = 1;
    MODIFY_LIMIT = 6;
    CUT_PARAM = -1;
    HEUR_PARAM = -1;*/
    //MAX_C
    //MAX_COL = order_num*20;
    

    /*if(order_num==500 && MAX_TIME<=75){
        HYBRID_CRIT =  2;
        MAX_COL_EACH = 25000;
    }
    if(order_num == 300){
        HYBRID_CRIT =  4;
    }*/
    
    OPTNUM = 4;
    FEAIND = 1;

    printf("HORIZON %d SLIDE %d \n",HORIZON, SLIDE);

    
    pat_buffer = (int*)calloc(pat_size,sizeof(int));
    int tot_buffer = order_num;

    pat_buffer[0] = order_num;
    if(pat_size>=2){
        pat_buffer[1] = 1000000;
        tot_buffer += 1000000;
        for(int i=2;i<pat_size;i++){
            pat_buffer[i] = MAX_ELEMENT; //(i-1)*
        }
    }
    tot_buffer = 3*MAX_ELEMENT; //(i-1)*

    
    //printf("here1 \n");




    pat_arr_length = pat_size +1;
    pat_arr_length_each = 2*pat_size +2;

    rider_info = (double**)calloc(rider_num,sizeof(double*)); //capa, speed, servicetime
    rider_cost = (double**)calloc(rider_num,sizeof(double*)); //capa, speed, servicetime

    for(int i=0;i<rider_num;i++){
        rider_info[i] = (double*)calloc(3,sizeof(double));
        for(int j=0;j<3;j++){
            rider_info[i][j] = rider_array[i*6+j];
        }
        rider_cost[i] = (double*)calloc(3,sizeof(double));
        for(int j=0;j<3;j++){
            rider_cost[i][j] = rider_array[i*6+j+3];
        }
    }

    if(ordering_param==0){
        order_arr = (int**)calloc((order_num),sizeof(int*));
        for(int i=0;i<order_num;i++){
            order_arr[i] = (int*)calloc((cols),sizeof(int));
            for(int j=0;j<cols;j++){
                order_arr[i][j] = order_array[i][j];
            }
        }
        
        dist_mat = (double**)calloc((2*order_num),sizeof(double*));
        for(int i=0;i<2*order_num;i++){
            dist_mat[i] = (double*)calloc((2*order_num),sizeof(double));
            for(int j=0;j<2*order_num;j++){
                dist_mat[i][j] = dist_array[i*(2*order_num)+j];
                //cout << i<< " " << j << " "<< dist_array[i*(2*order_num)+j] << " ";
            }
            //cout << endl;
        }
    }else{
        //HeapType seq_heap;
        double_arr_ind each_order;
        order_ordering = (int*)calloc(order_num,sizeof(int));
        
        init(&every_heap);
        for(int i=0;i<order_num;i++){
            each_order.arr_ind = i;
            each_order.arr_value = order_array[i][ordering_param];
            insert_max_heap(&every_heap,each_order);
        }

        for(int i=0;i<order_num;i++){
            order_ordering[order_num-1-i] =  delete_max_heap(&every_heap).arr_ind;
            //printf("%d %d\n", order_num-1-i, order_ordering[order_num-1-i]);
        }

        
        order_arr = (int**)calloc((order_num),sizeof(int*));
        for(int i=0;i<order_num;i++){
            order_arr[i] = (int*)calloc((cols),sizeof(int));
            for(int j=0;j<cols;j++){
                order_arr[i][j] = order_array[order_ordering[i]][j];
            }
        }

        //printf("here\n");

        dist_mat = (double**)calloc((2*order_num),sizeof(double*));
        for(int i=0;i<order_num;i++){
            dist_mat[i] = (double*)calloc((2*order_num),sizeof(double));
            dist_mat[i+order_num] = (double*)calloc((2*order_num),sizeof(double));
            for(int j=0;j<order_num;j++){
                
                dist_mat[i][j] = dist_array[order_ordering[i]*(2*order_num)+order_ordering[j]];
                //printf("%d %d\n",i,j);
                dist_mat[i][j+order_num] = dist_array[order_ordering[i]*(2*order_num)+order_ordering[j]+order_num];
                //printf("%d %d %d\n",i,j+order_num,(order_ordering[i]+order_num)*(2*order_num)+order_ordering[j]);
                dist_mat[i+order_num][j] = dist_array[(order_ordering[i]+order_num)*(2*order_num)+order_ordering[j]];
                //printf("%d %d\n",i+order_num,j);
                dist_mat[i+order_num][j+order_num] = dist_array[(order_ordering[i]+order_num)*(2*order_num)+order_ordering[j]+order_num];
                //printf("%d %d\n",i+order_num,j+order_num);
                //cout << i<< " " << j << " "<< dist_array[i*(2*order_num)+j] << " ";
            }
            //cout << endl;
        }
        //printf("here2 \n");
    }

    rider_time = (int***)calloc(rider_num,sizeof(int**));
    for(int i=0;i<rider_num;i++){
        rider_time[i] = (int**)calloc(2*order_num,sizeof(int*));
        for(int j=0;j<2*order_num;j++){
            rider_time[i][j] = (int*)calloc(2*order_num,sizeof(int));
            for(int jj=0;jj<2*order_num;jj++){
                rider_time[i][j][jj] = round(dist_mat[j][jj]/rider_info[i][1] + rider_info[i][2]);
            }   
        }
    }
    //printf("here2\n");



    pat_arr = (int***)calloc((pat_size-1),sizeof(int**));
    pat_feas_arr = (int***)calloc((pat_size-1),sizeof(int**));
    pat_capa = (int**)calloc((pat_size-1),sizeof(int*));
    pat_num = (int*)calloc((pat_size-1),sizeof(int));
    

    for(int i=0;i<pat_size-1;i++){
        pat_arr[i] = (int**)calloc(pat_buffer[i],sizeof(int*));
        pat_feas_arr[i] = (int**)calloc(pat_buffer[i],sizeof(int*));
        pat_capa[i] = (int*)calloc((pat_buffer[i]),sizeof(int));
    }
    temp_pat_arr = (int**)calloc((pat_buffer[pat_size-2]),sizeof(int*));
    temp_pat_feas_arr = (int**)calloc((pat_buffer[pat_size-2]),sizeof(int*));
    temp_pat_capa = (int*)calloc((pat_buffer[pat_size-2]),sizeof(int));

    
    each_pat_arr = (int***)calloc(rider_num,sizeof(int**));
    temp_each_pat_arr = (int***)calloc(rider_num,sizeof(int**));
    temp_each_pat_to = (int**)calloc(rider_num,sizeof(int*));
    for(int r_ind=0;r_ind<rider_num;r_ind++){
        temp_each_pat_arr[r_ind] = (int**)calloc((pat_buffer[pat_size-2]),sizeof(int*));
        temp_each_pat_to[r_ind] = (int*)calloc((pat_buffer[pat_size-2]),sizeof(int));
    }
    each_pat_num = (int*)calloc((rider_num),sizeof(int));
    temp_each_pat_num = (int*)calloc((rider_num),sizeof(int));
    each_pat_num_two = (int*)calloc((rider_num),sizeof(int));
    for(int i=0;i<rider_num;i++){
        each_pat_arr[i] = (int**)calloc((tot_buffer),sizeof(int*));
    }
    each_pat_cost = (double**)calloc(rider_num,sizeof(double*));
    for(int r_ind=0;r_ind<rider_num;r_ind++){
        each_pat_cost[r_ind] = (double*)calloc(pat_buffer[pat_size-2],sizeof(double));
    }
    temp_each_pat_cost = (double**)calloc(rider_num,sizeof(double*));
    for(int r_ind=0;r_ind<rider_num;r_ind++){
        temp_each_pat_cost[r_ind] = (double*)calloc(pat_buffer[pat_size-2],sizeof(double));
    }
    total_num_cur = (int*)calloc(3,sizeof(int));


    //printf("here3\n");
    
    /*pat_arr[pat_num] = (int*)calloc((pat_arr_length),sizeof(int));
    pat_capa[pat_num] = 0;
    pat_feas_arr[pat_num] = (int*)calloc((rider_num),sizeof(int));
    for(int i=0;i<rider_num;i++){
        pat_feas_arr[pat_num][i] = 1;
    }
    pat_num += 1;*/
    
    //initialization end

    //cout << "initial end" << endl;

    //pattern_gen_sub(order_num);

    slice_num_sub = ceil((double)(order_num-HORIZON)/SLIDE-epsilon*0.01);
    //printf("%d \n",slice_num_sub);
    /*if(slice_num_sub<0){
        slice_num = 1;
    }else{
        slice_num = slice_num_sub + 1;
    }*/
   slice_num = 1;
    //printf("slice %d\n",slice_num);
    
    if(slice_num<=1){
        //printf("%d here\n",slice_num);
        if(pat_size >=2){
            inst_pat_ind = (int**)calloc(slice_num,sizeof(int*));
            next_pat_ind = (int**)calloc(slice_num,sizeof(int*));
            for(int i=0;i<slice_num;i++){
                inst_pat_ind[i] = (int*)calloc(pat_buffer[pat_size-1],sizeof(int));
                next_pat_ind[i] = (int*)calloc(pat_buffer[pat_size-1],sizeof(int));
            }
            inst_pat_num = (int*)calloc(slice_num,sizeof(int));
            next_pat_num = (int*)calloc(slice_num,sizeof(int));
        }
        pattern_gen_new();    
    }else{
        if(pat_size >=2){
            inst_pat_ind = (int**)calloc(slice_num,sizeof(int*));
            next_pat_ind = (int**)calloc(slice_num,sizeof(int*));
            for(int i=0;i<slice_num;i++){
                inst_pat_ind[i] = (int*)calloc(pat_buffer[pat_size-1],sizeof(int));
                next_pat_ind[i] = (int*)calloc(pat_buffer[pat_size-1],sizeof(int));
            }
            inst_pat_num = (int*)calloc(slice_num,sizeof(int));
            next_pat_num = (int*)calloc(slice_num,sizeof(int));
        }
        
        pattern_gen_new();    

    }
    //pattern_gen_sub_2opt(order_num);
    time(&Curend);
    printf("%d %d %d generated new %f\n",each_pat_num[0],each_pat_num[1],each_pat_num[2],difftime(Curend,Totalstart));
    
    total_num_cur[0] = 0;
    for(int i=0;i<rider_num;i++){
        total_num += each_pat_num[i];
        if(i<rider_num-1){
            total_num_cur[i+1] = total_num;
        }
    }


    cost_calculate();
    //printf("final_check2\n");
    col_selection();
    
    printf("final_check\n");
    cost_modify(MODIFY_LIMIT);
    time(&Curend);
    printf("Col selection %f\n",difftime(Curend,Totalstart));
    //modelMIP();
    
    //time(&Curend);
    /*printf("before %f\n",difftime(Curend,Totalstart));
    XPRBexportprob(masterMIP, XPRB_LP,"exprob.lp");
    time(&Curend);
    printf("after %f\n",difftime(Curend,Totalstart));*/
    modelMIP_g();
    //time(&Curend);
    
    /*int res_time = MAX_TIME - SLACK_TIME - (int)(difftime(Curend,Totalstart));
    
    XPRSprob xprs_prob;
    xprs_prob = XPRBgetXPRSprob(masterMIP);

    printf("Start MIP for %d seconds\n", res_time);
    XPRSsetintcontrol(xprs_prob, XPRS_MAXTIME, res_time);
    XPRSsetintcontrol(xprs_prob, XPRS_CUTSTRATEGY, CUT_PARAM);
    XPRSsetintcontrol(xprs_prob, XPRS_HEUREMPHASIS, HEUR_PARAM);
    XPRSsetintcontrol(xprs_prob, XPRS_PRESOLVE, -1);
    XPRSsetintcontrol(xprs_prob, XPRS_HEURTHREADS, 4);*/
    //HEURTHREADS
    //XPRSsetintcontrol(xprs_prob, XPRS_HEURFORCESPECIALOBJ, 1);


    //printf("%d\n", res_time);
    //solveMIP();
    cost_modify_after();
    //Curend = clock();
    //printf("MIP %f\n",(float)(Curend-Totalstart)/CLOCKS_PER_SEC);

    //output_arr = (int**)calloc(total_num,sizeof(int*));
    time(&Curend);
    printf("Total %f seconds\n", difftime(Curend,Totalstart));
    total_pat_num[0] = sol_num;
    matrix_arr = (int**)calloc(sol_num,sizeof(int*)); //distance, proute, droute, num
    for(int i=0;i<sol_num;i++){
        matrix_arr[i] = (int*)calloc(2*pat_size+2,sizeof(int));
    }
    //printf("here1\n");
    int r_ind, col_ind;

    for(int i=0;i<sol_num;i++){
        r_ind = sol_col[0][i];
        col_ind = sol_col[1][i];

        if(ordering_param==0){
            for(int jj=0;jj<each_pat_arr[r_ind][col_ind][pat_arr_length_each-1];jj++){
                matrix_arr[i][jj] = each_pat_arr[r_ind][col_ind][jj];
                matrix_arr[i][jj+pat_size] = each_pat_arr[r_ind][col_ind][jj+pat_size];
                //printf("%d ", each_pat_arr[i][j][jj]);
            }
            //printf("\n");
            matrix_arr[i][2*pat_size] = r_ind;
            matrix_arr[i][2*pat_size+1] = each_pat_arr[r_ind][col_ind][pat_arr_length_each-1];
        }else{
            for(int jj=0;jj<each_pat_arr[r_ind][col_ind][pat_arr_length_each-1];jj++){
                matrix_arr[i][jj] = order_ordering[each_pat_arr[r_ind][col_ind][jj]];
                matrix_arr[i][jj+pat_size] = order_ordering[each_pat_arr[r_ind][col_ind][jj+pat_size]];
                //printf("%d ", each_pat_arr[i][j][jj]);
            }
            //printf("\n");
            matrix_arr[i][2*pat_size] = r_ind;
            matrix_arr[i][2*pat_size+1] = each_pat_arr[r_ind][col_ind][pat_arr_length_each-1];
        }
    }        //cout << "here" << endl;
    //printf("here2\n");
    /*int *checking_feasi = (int*)calloc(8,sizeof(int));
    checking_feasi[0] = 210;
    checking_feasi[1] = 163;
    checking_feasi[2] = 202;
    checking_feasi[3] = 248;
    checking_feasi[4] = 163;
    checking_feasi[5] = 202;
    checking_feasi[6] = 210;
    checking_feasi[7] = 248;

    double eval_clock,check_dist, inst_t;
    int ps, check_order ,ds;
    ps = checking_feasi[0];
    eval_clock = order_arr[ps][1];
    double eval_objective = 0;
    for(int i=1;i<4;i++){
        check_order = checking_feasi[i];
        check_dist = dist_mat[ps][check_order];
        inst_t = eval_clock + check_dist/rider_info[2][1] + rider_info[2][2];
        if((double)(order_arr[check_order][1]-epsilon) >= inst_t){
            eval_clock = order_arr[check_order][1];
        }else{
            eval_clock = inst_t;
        }
        ps = check_order;
    }
    
    ds = checking_feasi[4];
    check_dist = dist_mat[ps][ds+order_num];
    eval_clock += check_dist/rider_info[2][1] + rider_info[2][2];
    printf("Time: %d %f\n",order_arr[ds][2],eval_clock);
    if((double)(order_arr[ds][2] - eval_clock) < -epsilon){//infeasible
        eval_objective += (eval_clock - order_arr[ds][2]);
    }

    
    for(int i=1;i<4;i++){
        check_order = checking_feasi[4+i];
        check_dist = dist_mat[ds+order_num][check_order+order_num];
        eval_clock += check_dist/rider_info[2][1] + rider_info[2][2];
        printf("Time: %d %f\n",order_arr[check_order][2],eval_clock);
        if((double)(order_arr[check_order][2] - eval_clock) < -epsilon){//infeasible
            eval_objective += (eval_clock - order_arr[check_order][2]);
        }
        ds = check_order;
    }*/


    for(int i=0;i<order_num;i++){
        free(order_arr[i]);
    }
    for(int i=0;i<2*order_num;i++){
        free(dist_mat[i]);
    }
    for(int i=0;i<rider_num;i++){
        free(each_pat_cost[i]);
        free(temp_each_pat_cost[i]);
        for(int j=0;j<2*order_num;j++){
            free(rider_time[i][j]);
        }
        free(rider_time[i]);
    }
    free(rider_time);
    free(each_pat_cost);
    free(temp_each_pat_cost);
    //printf("here3\n");

    //printf("here\n");
    /*for(int j=0;j<pat_size;j++){
        printf("%d \n",pat_num[j]);
    }*/
    for(int j=0;j<pat_size-1;j++){
        for(int i=0;i<pat_num[j];i++){
            free(pat_feas_arr[j][i]);
            free(pat_arr[j][i]);
        }
        free(pat_feas_arr[j]);
        free(pat_arr[j]);
        free(pat_capa[j]);
    }
    //printf("here2 \n");
    for(int i=0;i<rider_num;i++){
        free(rider_info[i]);
        free(rider_cost[i]);
        for(int j=0;j<each_pat_num[i];j++){
            free(each_pat_arr[i][j]);
        }
        free(each_pat_arr[i]);
    }
    //printf("here4\n");

    for(int i=0;i<rider_num;i++){
        free(temp_each_pat_arr[i]);
        free(temp_each_pat_to[i]);
        //free(temp_pat_feas_arr[i]);
    }
    free(temp_pat_feas_arr);
    free(temp_pat_arr);
    free(temp_each_pat_to);

    //printf("here5\n");

    free(temp_each_pat_arr);
    free(temp_each_pat_num);
    free(temp_pat_capa);
    //printf("here6\n");

    free(each_pat_arr);
    free(each_pat_num);
    free(pat_feas_arr);
    if(ordering_param>0){
        free(order_ordering);
    }
    free(rider_info);
    free(rider_cost);
    free(pat_arr);
    free(order_arr);
    free(pat_capa);
    free(dist_mat);
    for(int i=0;i<slice_num;i++){
        free(next_pat_ind[i]);
        free(inst_pat_ind[i]);
    }
    //printf("here7\n");
    free(next_pat_ind);
    free(inst_pat_ind);
    free(next_pat_num);
    free(inst_pat_num);
    free(pat_buffer);

    free(job_const);
    free(rider_const);
    free(job_const_MIP);
    free(rider_const_MIP);
    free(y);
    for(int i=0;i<rider_num;i++){
        free(x[i]);
    }
    free(x);
    //printf("here8\n");
    free(sol_col[0]);
    free(sol_col[1]);
    free(sol_col);

    free(temp_job_dual);
    free(temp_rider_dual);
    free(selected_col[0]);
    free(selected_col[1]);
    free(selected_col);
    free(total_num_cur);
    free(inter_selected_col[0]);
    free(inter_selected_col[1]);
    free(inter_selected_col);

    return matrix_arr;//output_arr;
}

void free_2d_array(int** arr, int patt_num) {
    for (int i = 0; i < patt_num; i++) {
        free(arr[i]);
    }
    free(arr);
    //printf("Memory out\n");
}

void cost_calculate(){
    each_pat_cost = (double**)calloc(rider_num,sizeof(double*));
    for(int r_ind=0;r_ind<rider_num;r_ind++){
        each_pat_cost[r_ind] = (double*)calloc(each_pat_num[r_ind],sizeof(double));
        for(int j=0;j<each_pat_num[r_ind];j++){
            each_pat_cost[r_ind][j] = rider_cost[r_ind][1] + (double)(each_pat_arr[r_ind][j][pat_arr_length_each-2])/100*rider_cost[r_ind][0]; 
        }
    }
    //printf("%d %d %d \n",each_pat_num[0],each_pat_num[1],each_pat_num[2]);

    return;
}

void init_cost_calculate(){
    #pragma omp parallel for
    for(int r_ind=0;r_ind<rider_num;r_ind++){
        for(int j=0;j<each_pat_num[r_ind];j++){
            temp_each_pat_cost[r_ind][j] = rider_cost[r_ind][1] + (double)(each_pat_arr[r_ind][j][pat_arr_length_each-2])/100*rider_cost[r_ind][0]; 
        }
    }
}

void temp_cost_calculate(){
    #pragma omp parallel for
    for(int r_ind=0;r_ind<rider_num;r_ind++){
        for(int j=0;j<temp_each_pat_num[r_ind];j++){
            temp_each_pat_cost[r_ind][j] = rider_cost[r_ind][1] + (double)(temp_each_pat_arr[r_ind][j][pat_arr_length_each-2])/100*rider_cost[r_ind][0]; 
        }
    }
}


void initial_LP(){

    temp_job_dual = (double*)calloc(order_num,sizeof(double));
    temp_rider_dual = (double*)calloc(rider_num,sizeof(double));
    

    inter_selected_col = (int**)calloc(2,sizeof(int*));
    inter_selected_col[0] = (int*)calloc(MAX_COL_EACH_ARR[0],sizeof(int));
    inter_selected_col[1] = (int*)calloc(MAX_COL_EACH_ARR[0],sizeof(int));

    masterLP = XPRBnewprob("master");
    XPRBsetmsglevel(masterLP, 0);


    x = (XPRBvar***)calloc(pat_size,sizeof(XPRBvar**));
    x[0] =  (XPRBvar**)calloc(rider_num,sizeof(XPRBvar*));
    

    for(int i=0;i<rider_num;i++){
        x[0][i] = (XPRBvar*)calloc(each_pat_num[i],sizeof(XPRBvar));
    }


    job_const = (XPRBctr*)calloc(order_num,sizeof(XPRBctr));
    rider_const = (XPRBctr*)calloc(rider_num,sizeof(XPRBctr));
    
    for(int i=0;i<order_num;i++){
        job_const[i] = XPRBnewctr(masterLP,"jobcon",XPRB_E);
    }
    
    for(int i=0;i<rider_num;i++){
        rider_const[i] = XPRBnewctr(masterLP,"ridercon",XPRB_L);
    }
    obj_const = XPRBnewctr(masterLP,"obj",XPRB_N);


    //XPRBexpr infeasterm;
    z = XPRBnewvar(masterLP,XPRB_PL, XPRBnewname("z"), 0, XPRB_INFINITY);
    int var_num =0;
    for(int i=0; i<rider_num;i++){
        for(int j=0; j<each_pat_num[i];j++){
            x[0][i][j] = XPRBnewvar(masterLP,XPRB_PL, XPRBnewname("x_%d",var_num), 0, XPRB_INFINITY);
            var_num += 1;
        }
    }
    //printf("here4 %d\n", each_pat_num[0]);

    for(int r_ind=0;r_ind<rider_num;r_ind++){
        for(int j=0;j<each_pat_num[r_ind];j++){
            for(int jj=0;jj< each_pat_arr[r_ind][j][pat_arr_length_each-1];jj++){
                //printf("%d\n",each_pat_arr[r_ind][j][jj]);
                XPRBaddterm(job_const[each_pat_arr[r_ind][j][jj]], x[0][r_ind][j], 1);
            }
            XPRBaddterm(rider_const[r_ind], x[0][r_ind][j], 1);
            XPRBaddterm(obj_const, x[0][r_ind][j], temp_each_pat_cost[r_ind][j]/order_num);
        }
        XPRBaddterm(rider_const[r_ind], NULL, rider_cost[r_ind][2]);
        //printf("%f \n",rider_cost[r_ind][2]);
    }
    //printf("here3\n");

    for(int i=0;i<order_num;i++){
        XPRBaddterm(job_const[i], z, 1);
        XPRBaddterm(job_const[i], NULL, 1);
    }
    XPRBaddterm(obj_const, z, 100000);
    //printf("here5\n");

    XPRBsetobj(masterLP,obj_const);
    XPRBsetsense(masterLP,XPRB_MINIM);

    XPRBlpoptimize(masterLP,"");
    printf("LP %d: %f \n",0, XPRBgetobjval(masterLP));
    for(int i=0;i<order_num;i++){
        temp_job_dual[i] = XPRBgetdual(job_const[i]);
    }
    for(int i=0;i<rider_num;i++){
        temp_rider_dual[i] = XPRBgetdual(rider_const[i]);
    }
}

void inter_col_gen(int pat_cur){
    double prev_val, new_val;
    int stop_sign = 0;
    prev_val = 8000;

    if(pat_cur < 4){
        MAX_COL_EACH = MAX_COL_EACH_ARR[pat_cur];
    }else{
        MAX_COL_EACH = MAX_COL_EACH_ARR[4];
    }

    x[pat_cur] =  (XPRBvar**)calloc(rider_num,sizeof(XPRBvar*));
    
    for(int i=0;i<rider_num;i++){
        x[pat_cur][i] = (XPRBvar*)calloc(temp_each_pat_num[i],sizeof(XPRBvar));
        //printf("%d ",temp_each_pat_num[i]);
    }
    //printf("\n");

    total_num_cur[0] = 0;
    for(int i=0;i<rider_num-1;i++){
        total_num_cur[i+1] = total_num_cur[i] + temp_each_pat_num[i];
    }
    //printf("here2\n");

    double_arr_ind order_ind, get_ind;
    double **rcost_array;
    int target_r, target_pat_ind, target_ind;

    rcost_array = (double**)calloc(rider_num,sizeof(double*));
    for(int i=0;i<rider_num;i++){
        rcost_array[i] = (double*)calloc(temp_each_pat_num[i],sizeof(double));
    }

    
    int add_col_num, **add_col_info;
    
    add_col_info = (int**)calloc(2,sizeof(int*));
    add_col_info[0] = (int*)calloc(INTER_ONE_ITER_COL,sizeof(int));
    add_col_info[1] = (int*)calloc(INTER_ONE_ITER_COL,sizeof(int));

    
    while(true){
        init(&every_heap);
        add_col_num = 0;
        //printf("here3\n");

        #pragma omp parallel for
        for(int r_ind=0;r_ind<rider_num;r_ind++){
            for(int j=0;j<temp_each_pat_num[r_ind];j++){
                rcost_array[r_ind][j] = temp_each_pat_cost[r_ind][j]/order_num;
                for(int jj=0;jj<temp_each_pat_arr[r_ind][j][pat_arr_length_each-1];jj++){
                    rcost_array[r_ind][j] -= temp_job_dual[temp_each_pat_arr[r_ind][j][jj]];
                }
                rcost_array[r_ind][j] -= temp_rider_dual[r_ind];
                #pragma omp critical
                {
                    order_ind.arr_ind = total_num_cur[r_ind]+j;
                    order_ind.arr_value = -rcost_array[r_ind][j];
                //insert_max_heap(&every_heap,order_ind);
                
                    insert_max_heap(&every_heap, order_ind);
                }
            }
        }
        //printf("here4\n");


        int in_num = INTER_ONE_ITER_COL;
        if(temp_each_pat_num[0]+temp_each_pat_num[1]+temp_each_pat_num[2]<=in_num){
            in_num = temp_each_pat_num[0]+temp_each_pat_num[1]+temp_each_pat_num[2];
        }

        for(int i=0;i<in_num;i++){
            get_ind = delete_max_heap(&every_heap);
            /*if(i==0){
                printf("rcost %f\n",get_ind.arr_value);
            }*/
            if(get_ind.arr_value <= epsilon){
                target_ind = get_ind.arr_ind;
                if(target_ind>=total_num_cur[2]){
                    target_r = 2;
                    target_pat_ind = target_ind - total_num_cur[2];
                }else if(target_ind>=total_num_cur[1]){
                    target_r = 1;
                    target_pat_ind = target_ind - total_num_cur[1];
                }else{
                    target_r = 0;
                    target_pat_ind = target_ind; 
                }

                add_col_info[0][add_col_num] = target_r;
                add_col_info[1][add_col_num] = target_pat_ind;
                add_col_num += 1;
                break;
            }else{
                target_ind = get_ind.arr_ind;
                if(target_ind>=total_num_cur[2]){
                    target_r = 2;
                    target_pat_ind = target_ind - total_num_cur[2];
                }else if(target_ind>=total_num_cur[1]){
                    target_r = 1;
                    target_pat_ind = target_ind - total_num_cur[1];
                }else{
                    target_r = 0;
                    target_pat_ind = target_ind; 
                }

                add_col_info[0][add_col_num] = target_r;
                add_col_info[1][add_col_num] = target_pat_ind;
                add_col_num += 1;
            }
        }
        //printf("here5\n");

        if(add_col_num<=50 || stop_sign==1){
            inter_selected_num = 0;
            for(int i=0;i<add_col_num;i++){
                inter_selected_col[0][i] = add_col_info[0][i];
                inter_selected_col[1][i] = add_col_info[1][i];
                inter_selected_num += 1;
            }
            
            
            int rest_size = every_heap.heap_size;
            if(rest_size >MAX_COL_EACH-inter_selected_num){
                rest_size = MAX_COL_EACH-inter_selected_num;
            }

            for(int i=0;i<rest_size;i++){
                get_ind = delete_max_heap(&every_heap);    
                target_ind = get_ind.arr_ind;
                if(target_ind>=total_num_cur[2]){
                    target_r = 2;
                    target_pat_ind = target_ind - total_num_cur[2];
                }else if(target_ind>=total_num_cur[1]){
                    target_r = 1;
                    target_pat_ind = target_ind - total_num_cur[1];
                }else{
                    target_r = 0;
                    target_pat_ind = target_ind; 
                }

                inter_selected_col[0][inter_selected_num] = target_r;
                inter_selected_col[1][inter_selected_num] = target_pat_ind;
                inter_selected_num += 1;
            }
            
            break;
        }else{
            //printf("here6\n");

            for(int i=0;i<add_col_num;i++){
                x[pat_cur][add_col_info[0][i]][add_col_info[1][i]] = XPRBnewvar(masterLP,XPRB_PL, XPRBnewname("x"), 0, XPRB_INFINITY);
                for(int jj=0;jj< temp_each_pat_arr[add_col_info[0][i]][add_col_info[1][i]][pat_arr_length_each-1];jj++){
                    XPRBaddterm(job_const[temp_each_pat_arr[add_col_info[0][i]][add_col_info[1][i]][jj]], x[pat_cur][add_col_info[0][i]][add_col_info[1][i]], 1);
                }
                XPRBaddterm(rider_const[add_col_info[0][i]], x[pat_cur][add_col_info[0][i]][add_col_info[1][i]], 1);
                XPRBaddterm(obj_const, x[pat_cur][add_col_info[0][i]][add_col_info[1][i]], temp_each_pat_cost[add_col_info[0][i]][add_col_info[1][i]]/order_num);
            }

            XPRBlpoptimize(masterLP,"");
            new_val = XPRBgetobjval(masterLP);
            if(prev_val-new_val<=1){
                stop_sign = 0;
                //printf("%d \n", stop_sign);
            }else{
                prev_val = new_val;
            }
            printf("LP %d: %f \n",pat_cur, XPRBgetobjval(masterLP));
            for(int i=0;i<order_num;i++){
                temp_job_dual[i] = XPRBgetdual(job_const[i]);
            }
            for(int i=0;i<rider_num;i++){
                temp_rider_dual[i] = XPRBgetdual(rider_const[i]);
            }
        }

        
        //printf("here\n")
        
    }
    for(int i=0;i<rider_num;i++){
        free(rcost_array[i]);
    }
    free(rcost_array);
    free(add_col_info[0]);
    free(add_col_info[1]);
    free(add_col_info);
}

void modelMIP_g(){
    
    /*error_g = 0;

    error_g = GRBloadenv(&env, "myopt.log");
    if (error_g) {
        printf("Error: %s\n", GRBgeterrormsg(env));
        return 1;
    }
    
    // 모델 생성 (빈 모델)
    error_g = GRBnewmodel(env, &masterMIP_g, "myopt", 0, NULL, NULL, NULL, NULL, NULL);
    if (error_g) {
        printf("Error: %s\n", GRBgeterrormsg(env));
        return 1;
    }
    
    yy = (GRBvar*)calloc(selected_num,sizeof(GRBvar));
    job_const_MIP_g = (GRBLinExpr*)calloc(order_num,sizeof(GRBLinExpr));
    rider_const_MIP_g = (GRBLinExpr*)calloc(rider_num,sizeof(GRBLinExpr));

    

    

    int r_ind, col_ind;
    for (int i = 0; i < selected_num; i++) {
        // x[i]는 0 또는 1인 이진 변수
        r_ind = selected_col[0][i];
        col_ind = selected_col[1][i];
        error_g = GRBaddvar(masterMIP_g, 0.0, 1.0, each_pat_cost[r_ind][col_ind]/order_num, GRB_BINARY, NULL, &yy[i]);
        if (error_g) {
            printf("Error adding variable %d: %s\n", i, GRBgeterrormsg(env));
            return 1;
        }
        for(int jj=0;jj< each_pat_arr[r_ind][col_ind][pat_arr_length_each-1];jj++){
            job_const_MIP_g[each_pat_arr[r_ind][col_ind][jj]] += yy[i];
        }
        rider_const_MIP_g[r_ind] += y[i];
    }

    error_g = GRBupdatemodel(masterMIP_g);
    if (error_g) {
        printf("Error updating model: %s\n", GRBgeterrormsg(env));
        return 1;
    }

    error_g = GRBsetintattr(masterMIP_g, GRB_INT_ATTR_MODELSENSE, GRB_MINIMIZE);
    if (error_g) {
        printf("Error setting objective sense: %s\n", GRBgeterrormsg(env));
        return 1;
    }

    for (int i = 0; i < order_num; i++) {
        // x[i]는 0 또는 1인 이진 변수
        error_g = GRBaddconstr(masterMIP_g, job_const_MIP_g[i], GRB_EQUAL, 1, "orderlimit");
        if (error_g) {
            printf("Error adding volume constraint: %s\n", GRBgeterrormsg(env));
            return 1;
        }    
    }

    for (int i = 0; i < rider_num; i++) {
        // x[i]는 0 또는 1인 이진 변수
        error_g = GRBaddconstr(masterMIP_g, rider_const_MIP_g[i], GRB_LESS_EQUAL, 1, "riderlimit");
        if (error_g) {
            printf("Error adding volume constraint: %s\n", GRBgeterrormsg(env));
            return 1;
        }    
    }*/
    /*GRBenv *env = NULL;        // Gurobi 환경
    GRBmodel *model = NULL;    // Gurobi 모델
    int error;

    // 1. Gurobi 환경 생성
    error = GRBloadenv(&env, "gurobi.log");
    if (error) {
        printf("Error loading environment: %s\n", GRBgeterrormsg(env));
        return;
    }

    // 2. Gurobi 모델 생성
    error = GRBnewmodel(env, &model, "example_model", 0, NULL, NULL, NULL, NULL, NULL);
    if (error) {
        printf("Error creating model: %s\n", GRBgeterrormsg(env));
        GRBfreeenv(env);
        return;
    }

    // 3. 변수 추가 (각 변수에 대해 열 기반으로 제약식 계수 설정)
    // 각 변수는 두 개의 제약식에 포함됩니다.
    
    // x1: 제약식 1의 계수는 1, 제약식 2의 계수는 2
    int cind_x1[2] = {0, 1};          // 제약 조건 인덱스
    double cval_x1[2] = {1.0, 2.0};   // 계수
    error = GRBaddvar(model, 2, cind_x1, cval_x1, 0.0, 0.0, GRB_INFINITY, GRB_CONTINUOUS, "x1");
    if (error) {
        printf("Error adding variable x1: %s\n", GRBgeterrormsg(env));
        GRBfreemodel(model);
        GRBfreeenv(env);
        return;
    }

    // x2: 제약식 1의 계수는 2, 제약식 2의 계수는 1
    int cind_x2[2] = {0, 1};
    double cval_x2[2] = {2.0, 1.0};
    error = GRBaddvar(model, 2, cind_x2, cval_x2, 0.0, 0.0, GRB_INFINITY, GRB_CONTINUOUS, "x2");
    if (error) {
        printf("Error adding variable x2: %s\n", GRBgeterrormsg(env));
        GRBfreemodel(model);
        GRBfreeenv(env);
        return;
    }

    // x3: 제약식 1과 제약식 2 모두에서 계수가 3
    int cind_x3[2] = {0, 1};
    double cval_x3[2] = {3.0, 3.0};
    error = GRBaddvar(model, 2, cind_x3, cval_x3, 0.0, 0.0, GRB_INFINITY, GRB_CONTINUOUS, "x3");
    if (error) {
        printf("Error adding variable x3: %s\n", GRBgeterrormsg(env));
        GRBfreemodel(model);
        GRBfreeenv(env);
        return;
    }

    // 4. 모델 업데이트
    error = GRBupdatemodel(model);
    if (error) {
        printf("Error updating model: %s\n", GRBgeterrormsg(env));
        GRBfreemodel(model);
        GRBfreeenv(env);
        return;
    }

    // 5. 제약 조건 우변 및 방향 설정 (행 기반 설정)
    double rhs[2] = {4.0, 5.0};
    char sense[2] = {GRB_LESS_EQUAL, GRB_GREATER_EQUAL};
    
    error = GRBaddrangeconstrs(model, 2, rhs, rhs, sense, NULL);
    if (error) {
        printf("Error adding constraints: %s\n", GRBgeterrormsg(env));
        GRBfreemodel(model);
        GRBfreeenv(env);
        return;
    }

    // 6. 모델 최적화
    error = GRBoptimize(model);
    if (error) {
        printf("Error optimizing model: %s\n", GRBgeterrormsg(env));
        GRBfreemodel(model);
        GRBfreeenv(env);
        return;
    }

    // 7. 모델과 환경 해제
    GRBfreemodel(model);
    GRBfreeenv(env);
    return;*/

    /*GRBenv   *env   = NULL;
    GRBmodel *model = NULL;
    int error;
    double objjval;
    
    // 환경 설정 (로그 파일 설정)
    error = GRBloadenv(&env, "mip.log");
    if (error) {
        printf("Error: %s\n", GRBgeterrormsg(env));
        return;
    }

    // LP 파일로부터 모델 로드
    error = GRBreadmodel(env, "exprob.lp", &model);
    if (error) {
        printf("Error: %s\n", GRBgeterrormsg(env));
        return;
    }


    time(&Curend);
    int res_time = MAX_TIME - SLACK_TIME - (int)(difftime(Curend,Totalstart));


    // 제한 시간 300초 설정 (5분)
    error = GRBsetdblparam(env, GRB_DBL_PAR_TIMELIMIT, res_time);
    if (error) {
        printf("Error: %s\n", GRBgeterrormsg(env));
        return;
    }

    // MIP 문제 최적화
    error = GRBoptimize(model);
    if (error) {
        printf("Error during optimization: %s\n", GRBgeterrormsg(env));
        return;
    }

    // 최적화 상태 확인 (상태 코드가 GRB_OPTIMAL이어야 최적 해를 얻을 수 있음)
    int optimstatus;
    error = GRBgetintattr(model, GRB_INT_ATTR_STATUS, &optimstatus);
    if (error) {
        printf("Error retrieving optimization status: %s\n", GRBgeterrormsg(env));
        return;
    }

    //printf("Optimal objective: %.4e\n", objval);

    double inst_soly;
    sol_num = 0;
    sol_col = (int**)calloc(2,sizeof(int*));
    sol_col[0] = (int*)calloc(selected_num,sizeof(int));
    sol_col[1] = (int*)calloc(selected_num,sizeof(int));

    
    for(int i=0;i<selected_num;i++){
        error = GRBgetdblattrelement(model, GRB_DBL_ATTR_X, i, &inst_soly);
        if (error) {
            printf("Error retrieving solution value for variable %d: %s\n", i, GRBgeterrormsg(env));
            return;
        }
        if(inst_soly>=0.5){
            printf("%d ",i);

            sol_col[0][sol_num] = selected_col[0][i];
            sol_col[1][sol_num] = selected_col[1][i];
            sol_num += 1;
        }
    }
    printf("\n");
    // 모델 및 환경 해제
    GRBfreemodel(model);
    GRBfreeenv(env);

    return;*/

    GRBenv   *env   = NULL;
    GRBmodel *model = NULL;
    int       error = 0;
    int **row_sort_order,**row_sort_rider;
    int *row_sort_order_num,*row_sort_rider_num;
    
    double    *objj;
    char      *vtype;
    int       optimstatus;
    double    objjval;

    row_sort_order = (int**)calloc(order_num,sizeof(int*));
    row_sort_order_num = (int*)calloc(order_num,sizeof(int));
    for(int i=0;i<order_num;i++){
        row_sort_order[i] = (int*)calloc(selected_num,sizeof(int));
    }

    row_sort_rider = (int**)calloc(rider_num,sizeof(int*));
    row_sort_rider_num = (int*)calloc(rider_num,sizeof(int));
    for(int i=0;i<rider_num;i++){
        row_sort_rider[i] = (int*)calloc(selected_num,sizeof(int));
    }

    objj = (double*)calloc(selected_num,sizeof(double));
    vtype = (char*)calloc(selected_num,sizeof(char));
    
    /* Create environment */
    error = GRBemptyenv(&env);
    if (error) goto QUIT;

    //error = GRBsetstrparam(env, "LogFile", "mip1.log");
    //if (error) goto QUIT;

    error = GRBstartenv(env);
    if (error) goto QUIT;


    time(&Curend);
    double res_time = MAX_TIME - SLACK_TIME - (double)(difftime(Curend,Totalstart));
    error = GRBsetdblparam(env, "TimeLimit", res_time);
    if (error) goto QUIT;
    
    error = GRBsetdblparam(env, GRB_DBL_PAR_HEURISTICS, HEUR_PARAM);
    if (error) goto QUIT;
    
    error = GRBsetintparam(env, GRB_INT_PAR_MIPFOCUS, MIPFOCU);
    if (error) goto QUIT;

    error = GRBsetintparam(env, GRB_INT_PAR_OUTPUTFLAG, 0);  
    if (error) goto QUIT;


    /* Create an empty model */
    error = GRBnewmodel(env, &model, "mip1", 0, NULL, NULL, NULL, NULL, NULL);
    if (error) goto QUIT;

    int r_ind, col_ind, order_indd;
    for(int i=0;i<selected_num;i++){
        r_ind = selected_col[0][i];
        col_ind = selected_col[1][i];
        objj[i]=each_pat_cost[r_ind][col_ind]/order_num;
        vtype[i] = GRB_BINARY;
        for(int jj=0;jj< each_pat_arr[r_ind][col_ind][pat_arr_length_each-1];jj++){
            order_indd = each_pat_arr[r_ind][col_ind][jj];
            row_sort_order[order_indd][row_sort_order_num[order_indd]] = i;
            row_sort_order_num[order_indd] += 1;
        }
        row_sort_rider[r_ind][row_sort_rider_num[r_ind]] = i;
        row_sort_rider_num[r_ind] += 1;


    }
    /* Add variables */
    
    error = GRBaddvars(model, selected_num, 0, NULL, NULL, NULL, objj, NULL, NULL, vtype,NULL);
    if (error) goto QUIT;

    /* Change objective sense to maximization */
    error = GRBsetintattr(model, GRB_INT_ATTR_MODELSENSE, GRB_MINIMIZE);
    if (error) goto QUIT;

    for(int i=0;i<order_num;i++){
        int *ind;
        double *val;
        ind = (int*)calloc(row_sort_order_num[i],sizeof(int));
        val = (double*)calloc(row_sort_order_num[i],sizeof(double));
        for(int j=0;j<row_sort_order_num[i];j++){
            ind[j] = row_sort_order[i][j];
            val[j] = 1; 
        }
        error = GRBaddconstr(model, row_sort_order_num[i], ind, val, GRB_EQUAL, 1.0, NULL);
        if (error) goto QUIT;
        free(ind);
        free(val);
    }
    
    for(int i=0;i<rider_num;i++){
        int *ind;
        double *val;
        ind = (int*)calloc(row_sort_rider_num[i],sizeof(int));
        val = (double*)calloc(row_sort_rider_num[i],sizeof(double));
        for(int j=0;j<row_sort_rider_num[i];j++){
            ind[j] = row_sort_rider[i][j];
            val[j] = 1;
        }
        error = GRBaddconstr(model, row_sort_rider_num[i], ind, val, GRB_LESS_EQUAL, rider_cost[i][2], NULL);
        if (error) goto QUIT;
        free(ind);
        free(val);
    }
    
    /* Optimize model */

    // 제한 시간 300초 설정 (5분)
    
    error = GRBoptimize(model);
    if (error) goto QUIT;

    /* Write model to 'mip1.lp' */
    
    error = GRBgetdblattr(model, GRB_DBL_ATTR_OBJVAL, &objjval);
    if (error) goto QUIT;

    double inst_soly;
    sol_num = 0;
    sol_col = (int**)calloc(2,sizeof(int*));
    sol_col[0] = (int*)calloc(selected_num,sizeof(int));
    sol_col[1] = (int*)calloc(selected_num,sizeof(int));

    for(int i=0;i<selected_num;i++){
        error = GRBgetdblattrelement(model, GRB_DBL_ATTR_X, i, &inst_soly);
        if (error) goto QUIT;
        if(inst_soly>=0.5){
            //printf("%d ",i);
            sol_col[0][sol_num] = selected_col[0][i];
            sol_col[1][sol_num] = selected_col[1][i];
            sol_num += 1;
        }
    }
    //printf("\n");
    /* Free model */

    QUIT:

  /* Error reporting */
    if (error) {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(1);
    }


    free(objj);
    free(vtype);
    for(int i=0;i<order_num;i++){
        free(row_sort_order[i]);
    }
    for(int i=0;i<rider_num;i++){
        free(row_sort_rider[i]);
    }
    free(row_sort_order);
    free(row_sort_rider);
    free(row_sort_order_num);
    free(row_sort_rider_num);
    GRBfreemodel(model);

    /* Free environment */
    GRBfreeenv(env);

}


void modelMIP(){

    masterMIP = XPRBnewprob("master");
    //XPRBsetmsglevel(masterMIP, 0);

    y = (XPRBvar*)calloc(selected_num,sizeof(XPRBvar));

    job_const_MIP = (XPRBctr*)calloc(order_num,sizeof(XPRBctr));
    rider_const_MIP = (XPRBctr*)calloc(rider_num,sizeof(XPRBctr));
    
    for(int i=0;i<order_num;i++){
        job_const_MIP[i] = XPRBnewctr(masterMIP,"jobcon",XPRB_E);
    }
    
    for(int i=0;i<rider_num;i++){
        rider_const_MIP[i] = XPRBnewctr(masterMIP,"ridercon",XPRB_L);
    }
    obj_const_MIP = XPRBnewctr(masterMIP,"obj",XPRB_N);


    //XPRBexpr infeasterm;
    int var_num =0;
    for(int i=0; i<selected_num;i++){
        y[i] = XPRBnewvar(masterMIP,XPRB_BV, XPRBnewname("y_%d",var_num), 0, 1);
        var_num += 1;
    }
    int r_ind, col_ind;
    for(int i=0;i<selected_num;i++){
        r_ind = selected_col[0][i];
        col_ind = selected_col[1][i];
        for(int jj=0;jj< each_pat_arr[r_ind][col_ind][pat_arr_length_each-1];jj++){
            XPRBaddterm(job_const_MIP[each_pat_arr[r_ind][col_ind][jj]], y[i], 1);
        }
        XPRBaddterm(rider_const_MIP[r_ind], y[i], 1);
        XPRBaddterm(obj_const_MIP, y[i], each_pat_cost[r_ind][col_ind]/order_num);
        //printf("%f \n",rider_cost[r_ind][2]);
    }
    for(int i=0;i<order_num;i++){
        XPRBaddterm(job_const_MIP[i], NULL, 1);
    }
    for(int i=0;i<rider_num;i++){
        XPRBaddterm(rider_const_MIP[i], NULL, rider_cost[i][2]);
    }

    XPRBsetobj(masterMIP,obj_const_MIP);
    XPRBsetsense(masterMIP,XPRB_MINIM);
    
}

void solveMIP(){
    XPRBmipoptimize(masterMIP,"");
    printf("MIP: %f \n",XPRBgetobjval(masterMIP));
    sol_col = (int**)calloc(2,sizeof(int*));
    sol_col[0] = (int*)calloc(selected_num,sizeof(int));
    sol_col[1] = (int*)calloc(selected_num,sizeof(int));

    double inst_soly;
    sol_num = 0;
    for(int i=0;i<selected_num;i++){
        inst_soly = XPRBgetsol(y[i]);
        if(inst_soly>=0.5){
            printf("%d ",i);

            sol_col[0][sol_num] = selected_col[0][i];
            sol_col[1][sol_num] = selected_col[1][i];
            sol_num += 1;
        }
    }
    printf("\n");


}


/*void solveMIP_g(){
    error_g = GRBoptimize(masterMIP_g);
    if (error_g) {
        printf("Error optimizing: %s\n", GRBgeterrormsg(env));
        return 1;
    }
    
    double objj_val;

    error_g = GRBgetdblattr(masterMIP_g, GRB_DBL_ATTR_OBJVAL, &objj_val);
    if (error_g) {
        printf("Error retrieving objective value: %s\n", GRBgeterrormsg(env));
        return 1;
    }

    printf("MIP: %f \n",objj_val);
    sol_col = (int**)calloc(2,sizeof(int*));
    sol_col[0] = (int*)calloc(selected_num,sizeof(int));
    sol_col[1] = (int*)calloc(selected_num,sizeof(int));

    double inst_soly;
    sol_num = 0;
    for(int i=0;i<selected_num;i++){
        error_g = GRBgetdblattrelement(masterMIP_g, GRB_DBL_ATTR_X, i, &inst_soly);
        if (error_g) {
            printf("Error retrieving solution for variable %d: %s\n", i, GRBgeterrormsg(env));
            return 1;
        }
        
        if(inst_soly>=0.5){
            sol_col[0][sol_num] = selected_col[0][i];
            sol_col[1][sol_num] = selected_col[1][i];
            sol_num += 1;
        }
    }

}*/

void col_selection(){
    double_arr_ind order_ind, get_ind;
    //printf("here2\n");
    int target_r, target_pat_ind, target_ind;
    double **rcost_array;
    rcost_array = (double**)calloc(rider_num,sizeof(double*));
    for(int i=0;i<rider_num;i++){
        rcost_array[i] = (double*)calloc(each_pat_num[i],sizeof(double));
    }
    //printf("%d %d %d %f \n",each_pat_num[0],each_pat_num[1],each_pat_num[2],each_pat_cost[2][37413]);
    selected_col = (int**)calloc(2,sizeof(int*));
    selected_col[0] = (int*)calloc(MAX_COL+3*order_num,sizeof(int));
    selected_col[1] = (int*)calloc(MAX_COL+3*order_num,sizeof(int));
    //printf("here3\n");

    
    double *job_dual, *rider_dual;
    
    job_dual = (double*)calloc(order_num,sizeof(double));
    rider_dual = (double*)calloc(rider_num,sizeof(double));
    
    
    for(int i=0;i<order_num;i++){
        job_dual[i] = temp_job_dual[i];
    }
    for(int i=0;i<rider_num;i++){
        rider_dual[i] =  temp_rider_dual[i];
    }
    //printf("here4\n");

        //printf("here\n");
    init(&every_heap);
    #pragma omp parallel for
    for(int r_ind=0;r_ind<rider_num;r_ind++){
        for(int j=0;j<each_pat_num[r_ind];j++){
            //printf("rcost %d %d\n", r_ind, j);
            //printf("the cost %f ",rcost_array[r_ind][j]);
            //printf("the cost %f ",each_pat_cost[r_ind][j]);
            rcost_array[r_ind][j] = each_pat_cost[r_ind][j]/order_num;
            //printf("rcost %d %d end2\n", r_ind, j);
            //printf("rcossst %d \n", each_pat_arr[r_ind][j][pat_arr_length_each-1]);

            for(int jj=0;jj<each_pat_arr[r_ind][j][pat_arr_length_each-1];jj++){
                //printf("%d ", each_pat_arr[r_ind][j][jj]);
                rcost_array[r_ind][j] -= job_dual[each_pat_arr[r_ind][j][jj]];
            }
            //printf("rcost %d %d end\n", r_ind, j);
            rcost_array[r_ind][j] -= rider_dual[r_ind];
            #pragma omp critical
            {
                order_ind.arr_ind = total_num_cur[r_ind]+j;
                order_ind.arr_value = -rcost_array[r_ind][j];
            //insert_max_heap(&every_heap,order_ind);
            
                insert_max_heap(&every_heap, order_ind);
            }
        }
    }
        //printf("here5\n");

    
    //printf("final_check3\n");    
    selected_num = 0;
    
    int rest_size = every_heap.heap_size;
    if(rest_size >MAX_COL){
        rest_size = MAX_COL;
    }

    for(int i=0;i<rest_size;i++){
        get_ind = delete_max_heap(&every_heap);    
        target_ind = get_ind.arr_ind;
        if(target_ind>=total_num_cur[2]){
            target_r = 2;
            target_pat_ind = target_ind - total_num_cur[2];
        }else if(target_ind>=total_num_cur[1]){
            target_r = 1;
            target_pat_ind = target_ind - total_num_cur[1];
        }else{
            target_r = 0;
            target_pat_ind = target_ind; 
        }

        selected_col[0][selected_num] = target_r;
        selected_col[1][selected_num] = target_pat_ind;
        selected_num += 1;
    }
        //printf("here6\n");
    
    for(int r_ind=0;r_ind<rider_num;r_ind++){
        for(int j=0;j<each_pat_num_two[r_ind];j++){
            selected_col[0][selected_num] = r_ind;
            selected_col[1][selected_num] = j;
            selected_num += 1;
        }
    }

    for(int i=0;i<rider_num;i++){
        free(rcost_array[i]);
    }
    free(rcost_array);
    free(job_dual);
    free(rider_dual);
}

void cost_modify(int sizelimit){
    
    
    #pragma omp parallel for
    for(int route_ind=0;route_ind<selected_num;route_ind++){
        int r_ind = selected_col[0][route_ind];
        int col_ind = selected_col[1][route_ind];
        int inst_order_num = each_pat_arr[r_ind][col_ind][pat_arr_length_each-1];
        //printf("here %d %d \n",route_num,inst_order_num);
        int *inst_order_set;
        inst_order_set = (int*)calloc((pat_size),sizeof(int));

        if(inst_order_num>HYBRID_CRIT && inst_order_num<=sizelimit){
            for(int j=0;j<inst_order_num;j++){
                inst_order_set[j] = each_pat_arr[r_ind][col_ind][j];
                //printf("%d ", inst_order_set[j]);
            }
            double min_dist;
            int* inst_proute = (int*)calloc(inst_order_num, sizeof(int));
            int* inst_droute = (int*)calloc(inst_order_num, sizeof(int));
            //printf("here ");
            min_dist = optimal_route_check(inst_order_set, inst_order_num,inst_proute,inst_droute,r_ind);
            //printf("%f \n",min_dist);
            //printf("%d %f \n",each_pat_arr[r_ind][col_ind][pat_arr_length_each-2],min_dist);
            
            each_pat_arr[r_ind][col_ind][pat_arr_length_each-2] = min_dist;
            
            for(int j=0;j<inst_order_num;j++){
                each_pat_arr[r_ind][col_ind][j] = inst_proute[j];
                each_pat_arr[r_ind][col_ind][j+pat_size] = inst_droute[j];
                //pat_arr[pat_num][pat_size+j] = inst_proute[j];
                //pat_arr[pat_num][2*pat_size+j] = inst_droute[j];
                //printf("%d ",each_pat_arr[r_ind][each_pat_num[r_ind]][j]);
            }
            each_pat_cost[r_ind][col_ind] = rider_cost[r_ind][1] + (double)(each_pat_arr[r_ind][col_ind][pat_arr_length_each-2])/100*rider_cost[r_ind][0]; 
        
   
            //each_pat_arr[r_ind][col_ind][eac] = inst_order_num;
             
            free(inst_proute);
            free(inst_droute);
            //printf("here2\n ");

        }
        free(inst_order_set);
    }
}


void cost_modify_after(){
    #pragma omp parallel for
    for(int route_ind=0;route_ind<sol_num;route_ind++){
        int r_ind = sol_col[0][route_ind];
        int col_ind = sol_col[1][route_ind];
        int inst_order_num = each_pat_arr[r_ind][col_ind][pat_arr_length_each-1];
        //printf("here %d %d \n",route_num,inst_order_num);

        int *inst_order_set;
        inst_order_set = (int*)calloc((pat_size),sizeof(int));

        if(inst_order_num> MODIFY_LIMIT){
            for(int j=0;j<inst_order_num;j++){
                inst_order_set[j] = each_pat_arr[r_ind][col_ind][j];
                //printf("%d ", inst_order_set[j]);
            }
            double min_dist;
            int* inst_proute = (int*)calloc(inst_order_num, sizeof(int));
            int* inst_droute = (int*)calloc(inst_order_num, sizeof(int));
            //printf("here ");
            min_dist = optimal_route_check(inst_order_set, inst_order_num,inst_proute,inst_droute,r_ind);
            //printf("%f \n",min_dist);
            //printf("%d %f \n",each_pat_arr[r_ind][col_ind][pat_arr_length_each-2],min_dist);
            
            each_pat_arr[r_ind][col_ind][pat_arr_length_each-2] = min_dist;
            
            for(int j=0;j<inst_order_num;j++){
                each_pat_arr[r_ind][col_ind][j] = inst_proute[j];
                each_pat_arr[r_ind][col_ind][j+pat_size] = inst_droute[j];
                //pat_arr[pat_num][pat_size+j] = inst_proute[j];
                //pat_arr[pat_num][2*pat_size+j] = inst_droute[j];
                //printf("%d ",each_pat_arr[r_ind][each_pat_num[r_ind]][j]);
            }
            each_pat_cost[r_ind][col_ind] = rider_cost[r_ind][1] + (double)(each_pat_arr[r_ind][col_ind][pat_arr_length_each-2])/100*rider_cost[r_ind][0]; 
        
   
            //each_pat_arr[r_ind][col_ind][eac] = inst_order_num;
             
            free(inst_proute);
            free(inst_droute);
            //printf("here2\n ");

        }
        free(inst_order_set);

    }
}



void pattern_gen_new(){
    int start_ind, end_ind;
    int inst_order_num, order_start;
    for(int slice_ind=0;slice_ind<slice_num;slice_ind++){
        /*if(pat_size>=2){
            for(int cur_k=0;cur_k<pat_size-1;cur_k++){
                memcpy(inst_pat_ind[cur_k],next_pat_ind[cur_k],pat_buffer[cur_k]*sizeof(int));
            }

            memcpy(inst_pat_num,next_pat_num,(pat_size-1)*sizeof(int));
            
            for(int cur_k=0;cur_k<pat_size-1;cur_k++){
                next_pat_num[cur_k] = 0;    
            }
        }*/
        
            
        if(slice_ind==slice_num-1){
            start_ind = slice_ind*SLIDE;
            end_ind = order_num;
            //pattern_gen_new(i*SLIDE,order_num);    
        }else{
            //pattern_gen_new(i*SLIDE,i*SLIDE+HORIZON);
            //printf("size %d %d\n",pat_num[0],pat_num[1]);
            start_ind = slice_ind*SLIDE;
            end_ind = slice_ind*SLIDE+HORIZON;
        }
        if(slice_ind>0 && slice_ind<slice_num-1){
            for(int j=0;j<next_pat_num[slice_ind];j++){
                if(pat_arr[0][next_pat_ind[slice_ind][j]][0]>=start_ind+SLIDE){
                    next_pat_ind[slice_ind+1][next_pat_num[slice_ind+1]] = next_pat_ind[slice_ind][j];
                    next_pat_num[slice_ind+1] +=1;
                }
            }
        }
        
        //k=1 initialize
        order_start = start_ind+HORIZON - SLIDE;
        if(start_ind - SLIDE<=0){
            order_start = 0;
        }

        for(int cur_ind=order_start;cur_ind<end_ind;cur_ind++){
            int feas_sum = 0;
            int *inst_feas_check;
            inst_feas_check = (int*)calloc((rider_num),sizeof(int));
            //printf("%d\n", cur_ind);
            int *inst_order_set;
            inst_order_set = (int*)calloc((pat_size),sizeof(int));
            inst_order_set[0] = cur_ind;
            inst_order_num = 1;
            int inst_capa = order_arr[cur_ind][3];
            for(int r_ind=0;r_ind<rider_num;r_ind++){
                if(pre_feas_check(inst_capa, inst_order_set, inst_order_num,r_ind)==1){
                    feas_sum +=1;
                    
                    inst_feas_check[r_ind] = 1;
                    
                    each_pat_arr[r_ind][each_pat_num[r_ind]] = (int*)calloc((pat_arr_length_each),sizeof(int));
                    each_pat_arr[r_ind][each_pat_num[r_ind]][0] = cur_ind;
                    each_pat_arr[r_ind][each_pat_num[r_ind]][pat_size] = cur_ind;
                    //pat_arr[pat_num][pat_size] = cur_end_ind-1;
                    //pat_arr[pat_num][2*pat_size] = cur_end_ind-1;
                    each_pat_arr[r_ind][each_pat_num[r_ind]][pat_arr_length_each-1] = 1;
                    each_pat_arr[r_ind][each_pat_num[r_ind]][pat_arr_length_each-2] = dist_mat[cur_ind][cur_ind+order_num];
                    each_pat_num[r_ind] += 1;
                    /*if(pat_num%1000==0){
                        printf("%d \n",pat_num);
                    }*/
                
                }
            }
            //printf("here3.5\n");
            //printf("here2 %d \n",cur_ind);
            if(pat_size>=2){
                if(feas_sum > 0){
                    pat_arr[0][pat_num[0]] = (int*)calloc((pat_arr_length),sizeof(int));
                    pat_arr[0][pat_num[0]][0] = cur_ind;
                    //pat_arr[pat_num][pat_size] = cur_end_ind-1;
                    //pat_arr[pat_num][2*pat_size] = cur_end_ind-1;
                    pat_arr[0][pat_num[0]][pat_arr_length-1] = 1;
                    //pat_arr[pat_num][pat_arr_length-2] = dist_mat[cur_end_ind-1][cur_end_ind-1+order_num];
                    pat_capa[0][pat_num[0]] = inst_capa;
                    pat_feas_arr[0][pat_num[0]] = (int*)calloc((rider_num),sizeof(int));
                    memcpy(pat_feas_arr[0][pat_num[0]] , inst_feas_check, sizeof(int)*rider_num);

                    /*for(int jj=0;jj<pat_arr_length;jj++){
                        printf("%d ",pat_arr[pat_num][jj]);
                    }
                    printf(" AND ");
                    for(int jj=0;jj<3;jj++){
                        printf("%d ",pat_feas_arr[pat_num][jj]);
                    }
                    printf("\n");*/
                
                    if(pat_size>=2){
                        next_pat_ind[slice_ind][next_pat_num[slice_ind]] = pat_num[0];
                        next_pat_num[slice_ind] += 1;
                        if(slice_ind < slice_num-1){
                            if(inst_order_set[0]>=start_ind+SLIDE){
                                next_pat_ind[slice_ind+1][next_pat_num[slice_ind+1]] = pat_num[0];
                                next_pat_num[slice_ind+1] +=1;                
                            }
                        }
                    }

                    pat_num[0] += 1;
                }
            }
            free(inst_order_set);
            free(inst_feas_check);
        }
        //printf("Slice %d %d \n",slice_ind,next_pat_num[slice_ind]);
    }
    for(int r_ind=0;r_ind<rider_num;r_ind++){
        each_pat_num_two[r_ind] = each_pat_num[r_ind];
    }
        
    init_cost_calculate();

    initial_LP();

    //printf("Pat %d \n",pat_num[0]);
        //printf("here4\n");
    //###############################expand pattern size########################
    for(int cur_k=1;cur_k <= pat_size-1;cur_k++){
        if(pat_num[cur_k]>=pat_buffer[cur_k]){
            return;
        }
        for(int r_ind=0;r_ind<rider_num;r_ind++){
            temp_each_pat_num[r_ind] = 0;
        }
        temp_pat_num = 0;
        
        inst_order_num = cur_k+1;
        memcpy(inst_pat_num,next_pat_num,(slice_num)*sizeof(int));
        for(int slice_ind=0;slice_ind<slice_num;slice_ind++){
            for(int jj=0;jj<next_pat_num[slice_ind];jj++){
                inst_pat_ind[slice_ind][jj] = next_pat_ind[slice_ind][jj];
            }    
            //memcpy(inst_pat_ind[slice_ind],next_pat_ind[slice_ind],pat_buffer[pat_size-1]*sizeof(int));
            next_pat_num[slice_ind] = 0;    
        }

        //int pattern_explode = 0;
        
        for(int slice_ind=0;slice_ind<slice_num;slice_ind++){    
            int prev_pat_num = inst_pat_num[slice_ind];
            printf("here %d\n",prev_pat_num);
            if(slice_ind==slice_num-1){
                start_ind = slice_ind*SLIDE;
                end_ind = order_num;
                //pattern_gen_new(i*SLIDE,order_num);    
            }else{
                //pattern_gen_new(i*SLIDE,i*SLIDE+HORIZON);
                //printf("size %d %d\n",pat_num[0],pat_num[1]);
                start_ind = slice_ind*SLIDE;
                end_ind = slice_ind*SLIDE+HORIZON;
            }

            order_start = start_ind+HORIZON - SLIDE;
            if(start_ind - SLIDE<=0){
                order_start = 0;
            }
            
            /*if(slice_ind>0 && slice_ind<slice_num-1){
                for(int j=0;j<next_pat_num[slice_ind];j++){
                    if(pat_arr[cur_k][next_pat_ind[slice_ind][j]][0]>=start_ind+SLIDE){
                        next_pat_ind[slice_ind+1][next_pat_num[slice_ind+1]] = next_pat_ind[slice_ind][j];
                        next_pat_num[slice_ind+1] +=1;
                    }
                }
            }*/
            
            //printf("HERE \n");
            
             //shared(pattern_explode)
            #pragma omp parallel for
            for(int check_pat_ind=0;check_pat_ind<prev_pat_num;check_pat_ind++){
                /*if (pattern_explode) {
                    #pragma omp flush(pattern_explode)  // 패턴 폭발 상태 동기화
                    continue;
                }*/

                int check_pat_real_ind = inst_pat_ind[slice_ind][check_pat_ind];
                int fin_order = pat_arr[cur_k-1][check_pat_real_ind][cur_k-1];
                int here_order_start;

                if(fin_order+1>=order_start){
                    here_order_start = fin_order+1; 
                }else{
                    here_order_start = order_start;
                }
                
                for(int cur_ind=here_order_start;cur_ind<end_ind;cur_ind++){
                    int feas_sum = 0;
                    int *inst_feas_check;
                    inst_feas_check = (int*)calloc((rider_num),sizeof(int));
                    //printf("here2 %d %d %d\n", cur_k, check_pat_real_ind,cur_ind);

                    int inst_capa = pat_capa[cur_k-1][check_pat_real_ind] + order_arr[cur_ind][3];
                    int *inst_order_set;
                    inst_order_set = (int*)calloc((pat_size),sizeof(int));
                    
                    for(int j=0;j<inst_order_num-1;j++){
                        inst_order_set[j] = pat_arr[cur_k-1][check_pat_real_ind][j];
                        //printf("%d ", inst_order_set[j]);
                    }
                    inst_order_set[inst_order_num-1] = cur_ind;
                    //printf("%d %d %d %d \n", inst_order_set[inst_order_num-1], pat_feas_arr[cur_k-1][check_pat_real_ind][0],pat_feas_arr[cur_k-1][check_pat_real_ind][1],pat_feas_arr[cur_k-1][check_pat_real_ind][2]);
                    int cur_temp_ind=temp_pat_num;
                    for(int r_ind=0;r_ind<rider_num;r_ind++){
                        if(pat_feas_arr[cur_k-1][check_pat_real_ind][r_ind]==1){
                            if(inst_order_num <= HYBRID_CRIT){
                                if(pre_feas_check(inst_capa, inst_order_set, inst_order_num,r_ind)==1){
                                    double min_dist;
                                    int* inst_proute = (int*)calloc(inst_order_num, sizeof(int));
                                    int* inst_droute = (int*)calloc(inst_order_num, sizeof(int));
                                    min_dist = optimal_route_check(inst_order_set, inst_order_num,inst_proute,inst_droute,r_ind);
                                    
                                    if(min_dist <= MIN_DIST_VAL-1){
                                        feas_sum +=1;
                                        inst_feas_check[r_ind] = 1;
                                        //printf("%d ",r_ind);
                                        #pragma omp critical
                                        {
                                            //printf("%d \n",temp_each_pat_num[r_ind]);
                                            //#pragma omp flush(temp_each_pat_num)
                                            //printf("%d %f \n",inst_order_num,min_dist);
                                            if(feas_sum == 1){
                                                if(cur_k<=pat_size-2){
                                                        //#pragma omp flush(temp_pat_num)
                                                    temp_pat_arr[temp_pat_num] = (int*)calloc((pat_arr_length),sizeof(int));
                                                                    
                                                    for(int j=0;j<inst_order_num;j++){
                                                        temp_pat_arr[temp_pat_num][j] = inst_order_set[j];
                                                        //pat_arr[pat_num][pat_size+j] = inst_route[j];
                                                        //pat_arr[pat_num][2*pat_size+j] = inst_route[j+inst_order_num];
                                                    }
                                                    
                                                    //}
                                                    temp_pat_arr[temp_pat_num][pat_arr_length-1] = inst_order_num;
                                                    temp_pat_capa[temp_pat_num] = inst_capa; 
                                                    cur_temp_ind = temp_pat_num;

                                                    temp_pat_feas_arr[cur_temp_ind] = (int*)calloc((rider_num),sizeof(int));
                                                    //memcpy(temp_pat_feas_arr[cur_temp_ind] , inst_feas_check, sizeof(int)*rider_num);
                                                    //temp_pat_feas_arr[cur_temp_ind][r_ind] = 1;
                                                    temp_pat_num += 1;
                                                    //#pragma omp flush(temp_pat_num)
                                                //}
                                                    /*if(temp_pat_num >= pat_buffer[pat_size-2]){
                                                        //printf("Here! %d\n",cur_k);
                                                        //return;
                                                        //#pragma omp critical
                                                        //{
                                                            pattern_explode = 1;  // 작업 종료 플래그 설정
                                                            #pragma omp flush(pattern_explode)
                                                        //}
                                                    }*/
                                                
                                                    
                                                /*if(pat_num%1000==0){
                                                    printf("%d \n",pat_num);
                                                }*/
                                                }
                                            }
                                            if(cur_k<=pat_size-2){
                                                temp_pat_feas_arr[cur_temp_ind][r_ind] = 1;
                                            }

                                            temp_each_pat_arr[r_ind][temp_each_pat_num[r_ind]] = (int*)calloc((pat_arr_length_each),sizeof(int));
                                            for(int j=0;j<inst_order_num;j++){
                                                temp_each_pat_arr[r_ind][temp_each_pat_num[r_ind]][j] = inst_proute[j];
                                                temp_each_pat_arr[r_ind][temp_each_pat_num[r_ind]][pat_size+j] = inst_droute[j];
                                                //pat_arr[pat_num][pat_size+j] = inst_proute[j];
                                                //pat_arr[pat_num][2*pat_size+j] = inst_droute[j];
                                                //printf("%d ",each_pat_arr[r_ind][each_pat_num[r_ind]][j]);
                                            }
                                            
                                            //pat_arr[pat_num][pat_size] = cur_end_ind-1;
                                            //pat_arr[pat_num][2*pat_size] = cur_end_ind-1;
                                            temp_each_pat_arr[r_ind][temp_each_pat_num[r_ind]][pat_arr_length_each-1] = inst_order_num;
                                            temp_each_pat_arr[r_ind][temp_each_pat_num[r_ind]][pat_arr_length_each-2] = min_dist;
                                            temp_each_pat_to[r_ind][temp_each_pat_num[r_ind]] = cur_temp_ind;
                                            temp_each_pat_num[r_ind] += 1;


                                            /*if(pat_num%1000==0){
                                                printf("%d \n",pat_num);
                                            }*/
                                            //#pragma omp flush(temp_each_pat_num)
                                        }
                                    }
                                    free(inst_proute);
                                    free(inst_droute);
                                }
                            }
                            else{
                                if(pre_feas_check(inst_capa, inst_order_set, inst_order_num,r_ind)==1){
                                    int* inst_route = (int*)calloc(2*inst_order_num, sizeof(int));
                                    /*for(int j=0;j<inst_order_num;j++){
                                        printf("%d ",inst_order_set[j]);
                                    }*/
                                    //printf("\n");
                                    
                                    init_sol_gen(inst_order_set,inst_order_num,inst_route);
                                    
                                    int heuri_feas;
                                    int best_dist,prev_dist;
                                    prev_dist = MIN_DIST_VAL;
                                    for(int opt_ind=0;opt_ind<FEAIND;opt_ind++){
                                        heuri_feas = local_search_feas(inst_route, inst_order_num,r_ind);
                                        if(heuri_feas==1){
                                            break;
                                        }
                                    }
                                    
                                    if(heuri_feas ==1){
                                        for(int opt_ind=0;opt_ind<OPTNUM;opt_ind++){
                                            if(prev_dist == best_dist){
                                                break;
                                            }    
                                            best_dist = local_search_opt(inst_route,inst_order_num,r_ind);
                                            prev_dist = best_dist;
                                        }
                                        
                                        /*best_dist = local_search_opt(inst_route,inst_order_num,r_ind);
                                        best_dist = local_search_opt(inst_route,inst_order_num,r_ind);
                                        best_dist = local_search_opt(inst_route,inst_order_num,r_ind);
                                        best_dist = local_search_opt(inst_route,inst_order_num,r_ind);*/

                                        feas_sum +=1;
                                        inst_feas_check[r_ind] = 1;
                                        #pragma omp critical
                                        {
                                            //#pragma omp flush(temp_each_pat_num)
                                            //printf("%d %d %d\n",cur_ind, r_ind, temp_each_pat_num[r_ind]);
                                            
                                            /*if(pat_num%1000==0){
                                                printf("%d \n",pat_num);
                                            }*/
                                            if(feas_sum == 1){
                                                if(cur_k<=pat_size-2){
                                                        //#pragma omp flush(temp_pat_num)
                                                    temp_pat_arr[temp_pat_num] = (int*)calloc((pat_arr_length),sizeof(int));
                                                                    
                                                    for(int j=0;j<inst_order_num;j++){
                                                        temp_pat_arr[temp_pat_num][j] = inst_order_set[j];
                                                        //pat_arr[pat_num][pat_size+j] = inst_route[j];
                                                        //pat_arr[pat_num][2*pat_size+j] = inst_route[j+inst_order_num];
                                                    }
                                                    
                                                    //}
                                                    temp_pat_arr[temp_pat_num][pat_arr_length-1] = inst_order_num;
                                                    temp_pat_capa[temp_pat_num] = inst_capa; 
                                                    cur_temp_ind = temp_pat_num;

                                                    temp_pat_feas_arr[cur_temp_ind] = (int*)calloc((rider_num),sizeof(int));
                                                    //memcpy(temp_pat_feas_arr[cur_temp_ind] , inst_feas_check, sizeof(int)*rider_num);
                                                    temp_pat_num += 1;
                                                    //#pragma omp flush(temp_pat_num)
                                                //}
                                                    /*if(temp_pat_num >= pat_buffer[pat_size-2]){
                                                        //printf("Here! %d\n",cur_k);
                                                        //return;
                                                        //#pragma omp critical
                                                        //{
                                                            pattern_explode = 1;  // 작업 종료 플래그 설정
                                                            #pragma omp flush(pattern_explode)
                                                        //}
                                                    }*/
                                                
                                                    
                                                /*if(pat_num%1000==0){
                                                    printf("%d \n",pat_num);
                                                }*/
                                                }
                                            }
                                            if(cur_k<=pat_size-2){
                                                temp_pat_feas_arr[cur_temp_ind][r_ind] = 1;
                                            }
                                            temp_each_pat_arr[r_ind][temp_each_pat_num[r_ind]] = (int*)calloc((pat_arr_length_each),sizeof(int));
                                        
                                            for(int j=0;j<inst_order_num;j++){
                                                temp_each_pat_arr[r_ind][temp_each_pat_num[r_ind]][j] = inst_route[j];
                                                temp_each_pat_arr[r_ind][temp_each_pat_num[r_ind]][pat_size+j] = inst_route[inst_order_num+j];
                                                //pat_arr[pat_num][pat_size+j] = inst_proute[j];
                                                //pat_arr[pat_num][2*pat_size+j] = inst_droute[j];
                                            }
                                            //pat_arr[pat_num][pat_size] = cur_end_ind-1;
                                            //pat_arr[pat_num][2*pat_size] = cur_end_ind-1;
                                            temp_each_pat_arr[r_ind][temp_each_pat_num[r_ind]][pat_arr_length_each-1] = inst_order_num;
                                            temp_each_pat_arr[r_ind][temp_each_pat_num[r_ind]][pat_arr_length_each-2] = best_dist;
                                            temp_each_pat_to[r_ind][temp_each_pat_num[r_ind]] = cur_temp_ind;
  
                                            temp_each_pat_num[r_ind] += 1;
                                        
                                            //#pragma omp flush(temp_each_pat_num)
                                            //printf("%d \n",temp_each_pat_num[r_ind]);

                                            
                                        }
                                    }
                                    free(inst_route);
                                }
                            }                        
                        }
                    }

                    
                    free(inst_order_set);
                    free(inst_feas_check);
                }
            }
            //printf("%d %d %d %d\n",temp_pat_num, temp_each_pat_num[0], temp_each_pat_num[1],temp_each_pat_num[2]);
        }

        //printf("parallel end\n");

        
        //printf("here\n");

        time(&Curend);
        printf("Total %f seconds\n", difftime(Curend,Totalstart));
        temp_cost_calculate();
        //printf("here2\n");

        inter_col_gen(cur_k);
        printf("colgen end %d\n",inter_selected_num);
        double_arr_ind pat_arr_ind;
        int r_ind, col_ind, prev_ind, get_ind;
        init(&every_heap);
        for(int i=0;i<inter_selected_num;i++){
            r_ind = inter_selected_col[0][i];
            col_ind = inter_selected_col[1][i];
            //printf("%d %d \n",r_ind,col_ind);
            each_pat_arr[r_ind][each_pat_num[r_ind]] = (int*)calloc((pat_arr_length_each),sizeof(int));
            for(int j=0;j<inst_order_num;j++){
                each_pat_arr[r_ind][each_pat_num[r_ind]][j] = temp_each_pat_arr[r_ind][col_ind][j];
                each_pat_arr[r_ind][each_pat_num[r_ind]][pat_size+j] = temp_each_pat_arr[r_ind][col_ind][pat_size+j];
                //pat_arr[pat_num][pat_size+j] = inst_proute[j];
                //pat_arr[pat_num][2*pat_size+j] = inst_droute[j];
                /*if(cur_k==1){
                    printf("%d ",each_pat_arr[r_ind][each_pat_num[r_ind]][j]);
                }*/
            }
            
            //pat_arr[pat_num][pat_size] = cur_end_ind-1;
            //pat_arr[pat_num][2*pat_size] = cur_end_ind-1;
            each_pat_arr[r_ind][each_pat_num[r_ind]][pat_arr_length_each-1] = temp_each_pat_arr[r_ind][col_ind][pat_arr_length_each-1];
            each_pat_arr[r_ind][each_pat_num[r_ind]][pat_arr_length_each-2] = temp_each_pat_arr[r_ind][col_ind][pat_arr_length_each-2];
            /*if(cur_k==1){
                printf("\n");
            }*/
            /*if(pat_num%1000==0){
                printf("%d \n",pat_num);
            }*/
            each_pat_num[r_ind] += 1;
            if(cur_k<=pat_size-2){
                pat_arr_ind.arr_ind = temp_each_pat_to[r_ind][col_ind];
                pat_arr_ind.arr_value = temp_each_pat_to[r_ind][col_ind];
                insert_max_heap(&every_heap,pat_arr_ind);
            }
        }
        if(cur_k<=pat_size-2){
            prev_ind = temp_pat_num + 1;
            int first_order_ind, final_order_ind, slice_start, slice_end;
            for(int i=0;i<inter_selected_num;i++){
                get_ind = delete_max_heap(&every_heap).arr_ind;
                //printf("%d ",get_ind);    
                if(get_ind < prev_ind){
                    pat_arr[cur_k][pat_num[cur_k]] = (int*)calloc((pat_arr_length),sizeof(int));              
                    for(int j=0;j<inst_order_num;j++){
                        pat_arr[cur_k][pat_num[cur_k]][j] = temp_pat_arr[get_ind][j];
                        //pat_arr[pat_num][pat_size+j] = inst_route[j];
                        //pat_arr[pat_num][2*pat_size+j] = inst_route[j+inst_order_num];
                    }
                    
                    //}
                    pat_arr[cur_k][pat_num[cur_k]][pat_arr_length-1] = inst_order_num;
                    pat_capa[cur_k][pat_num[cur_k]] = temp_pat_capa[get_ind]; 
                    pat_feas_arr[cur_k][pat_num[cur_k]] = (int*)calloc((rider_num),sizeof(int));
                    memcpy(pat_feas_arr[cur_k][pat_num[cur_k]] , temp_pat_feas_arr[get_ind], sizeof(int)*rider_num);
                    
                    first_order_ind = pat_arr[cur_k][pat_num[cur_k]][0];
                    final_order_ind = pat_arr[cur_k][pat_num[cur_k]][inst_order_num-1];
                    for(int slice_ind=0;slice_ind<slice_num;slice_ind++){
                        slice_start = slice_ind*SLIDE;
                        slice_end = slice_ind*SLIDE+HORIZON;
                        
                        if(slice_start <= first_order_ind && slice_end>final_order_ind){
                            next_pat_ind[slice_ind][next_pat_num[slice_ind]] = pat_num[cur_k];
                            next_pat_num[slice_ind] += 1;
                        //printf("here3\n");
                        }
                    }
                        //printf("here3\n");
                    pat_num[cur_k] += 1;
                    if(pat_num[cur_k] >= pat_buffer[cur_k]){
                        //printf("Here! %d\n",cur_k);
                        return;
                    }
                }
                prev_ind = get_ind;
            }
            //printf("\n");
        }
        //printf("pat num: %d\n",pat_num[cur_k]);

        for(int r_ind=0;r_ind<rider_num;r_ind++){
            for(int arr_ind=0;arr_ind<temp_each_pat_num[r_ind];arr_ind++){
                free(temp_each_pat_arr[r_ind][arr_ind]);
            }
        }
        for(int arr_ind=0;arr_ind<temp_pat_num;arr_ind++){
            free(temp_pat_arr[arr_ind]);
            free(temp_pat_feas_arr[arr_ind]);
        }
    }
    
    return;
}

void pattern_gen_new_0(int start_ind, int end_ind){
    
    int *inst_order_set, inst_order_num, inst_capa, check_pat_real_ind,feas_sum, *inst_feas_check, order_start;
    inst_order_set = (int*)calloc((pat_size),sizeof(int));
    inst_feas_check = (int*)calloc((rider_num),sizeof(int));

    //k=1 initialize
    order_start = 0;

    for(int cur_ind=order_start;cur_ind<end_ind;cur_ind++){
        feas_sum = 0;
        for(int r_ind=0;r_ind<rider_num;r_ind++){
            inst_feas_check[r_ind] = 0;
        }
        //printf("%d\n", cur_ind);
        inst_order_set[0] = cur_ind;
        inst_order_num = 1;
        inst_capa = order_arr[cur_ind][3];
        for(int r_ind=0;r_ind<rider_num;r_ind++){
            if(pre_feas_check(inst_capa, inst_order_set, inst_order_num,r_ind)==1){
                feas_sum +=1;
                
                inst_feas_check[r_ind] = 1;
                
                each_pat_arr[r_ind][each_pat_num[r_ind]] = (int*)calloc((pat_arr_length_each),sizeof(int));
                each_pat_arr[r_ind][each_pat_num[r_ind]][0] = cur_ind;
                each_pat_arr[r_ind][each_pat_num[r_ind]][pat_size] = cur_ind;
                //pat_arr[pat_num][pat_size] = cur_end_ind-1;
                //pat_arr[pat_num][2*pat_size] = cur_end_ind-1;
                each_pat_arr[r_ind][each_pat_num[r_ind]][pat_arr_length_each-1] = 1;
                each_pat_arr[r_ind][each_pat_num[r_ind]][pat_arr_length_each-2] = dist_mat[cur_ind][cur_ind+order_num];
                each_pat_num[r_ind] += 1;
                /*if(pat_num%1000==0){
                    printf("%d \n",pat_num);
                }*/
            
            }
        }
        //printf("here3.5\n");
        //printf("here2 %d \n",cur_ind);
        if(pat_size>=2){
            if(feas_sum > 0){
                pat_arr[0][pat_num[0]] = (int*)calloc((pat_arr_length),sizeof(int));
                pat_arr[0][pat_num[0]][0] = cur_ind;
                //pat_arr[pat_num][pat_size] = cur_end_ind-1;
                //pat_arr[pat_num][2*pat_size] = cur_end_ind-1;
                pat_arr[0][pat_num[0]][pat_arr_length-1] = 1;
                //pat_arr[pat_num][pat_arr_length-2] = dist_mat[cur_end_ind-1][cur_end_ind-1+order_num];
                pat_capa[0][pat_num[0]] = inst_capa;
                pat_feas_arr[0][pat_num[0]] = (int*)calloc((rider_num),sizeof(int));
                memcpy(pat_feas_arr[0][pat_num[0]] , inst_feas_check, sizeof(int)*rider_num);

                /*for(int jj=0;jj<pat_arr_length;jj++){
                    printf("%d ",pat_arr[pat_num][jj]);
                }
                printf(" AND ");
                for(int jj=0;jj<3;jj++){
                    printf("%d ",pat_feas_arr[pat_num][jj]);
                }
                printf("\n");*/
            
                if(pat_size>=2){
                    next_pat_ind[0][next_pat_num[0]] = pat_num[0];
                    next_pat_num[0] += 1;
                }

                pat_num[0] += 1;
            }
        }
    }
    //printf("Slice %d \n",next_pat_num[0]);

    //printf("Pat %d \n",pat_num[0]);
        //printf("here4\n");
    //###############################expand pattern size########################
    int prev_pat_num, fin_order, here_order_start;
    for(int cur_k=1;cur_k <= pat_size-1;cur_k++){
        if(pat_num[cur_k]>=pat_buffer[cur_k]){
            return;
        }
        inst_order_num = cur_k+1;
        memcpy(inst_pat_num,next_pat_num,(slice_num)*sizeof(int));
        for(int jj=0;jj<next_pat_num[0];jj++){
            inst_pat_ind[0][jj] = next_pat_ind[0][jj];
        }    
        //memcpy(inst_pat_ind[slice_ind],next_pat_ind[slice_ind],pat_buffer[pat_size-1]*sizeof(int));
        next_pat_num[0] = 0;    
    
        
        prev_pat_num = inst_pat_num[0];

        order_start = 0;
        
        //printf("%d \n",prev_pat_num);

        for(int check_pat_ind=0;check_pat_ind<prev_pat_num;check_pat_ind++){
            check_pat_real_ind = inst_pat_ind[0][check_pat_ind];
            fin_order = pat_arr[cur_k-1][check_pat_real_ind][cur_k-1];
            
            if(fin_order+1>=order_start){
                here_order_start = fin_order+1; 
            }else{
                here_order_start = order_start;
            }
            
            for(int cur_ind=here_order_start;cur_ind<end_ind;cur_ind++){
                feas_sum = 0;
                for(int r_ind=0;r_ind<rider_num;r_ind++){
                    inst_feas_check[r_ind] = 0;
                }
                //printf("here2 %d %d %d\n", cur_k, check_pat_real_ind,cur_ind);

                inst_capa = pat_capa[cur_k-1][check_pat_real_ind] + order_arr[cur_ind][3];
                for(int j=0;j<inst_order_num-1;j++){
                    inst_order_set[j] = pat_arr[cur_k-1][check_pat_real_ind][j];
                    //printf("%d ", inst_order_set[j]);
                }
                inst_order_set[inst_order_num-1] = cur_ind;
                //printf("%d %d %d %d \n", inst_order_set[inst_order_num-1], pat_feas_arr[cur_k-1][check_pat_real_ind][0],pat_feas_arr[cur_k-1][check_pat_real_ind][1],pat_feas_arr[cur_k-1][check_pat_real_ind][2]);

                for(int r_ind=0;r_ind<rider_num;r_ind++){
                    if(pat_feas_arr[cur_k-1][check_pat_real_ind][r_ind]==1){
                        if(inst_order_num <= HYBRID_CRIT){
                            if(pre_feas_check(inst_capa, inst_order_set, inst_order_num,r_ind)==1){
                                double min_dist;
                                int* inst_proute = (int*)calloc(inst_order_num, sizeof(int));
                                int* inst_droute = (int*)calloc(inst_order_num, sizeof(int));

                                min_dist = optimal_route_check(inst_order_set, inst_order_num,inst_proute,inst_droute,r_ind);
                                
                                if(min_dist <= MIN_DIST_VAL-1){
                                    feas_sum +=1;
                                    inst_feas_check[r_ind] = 1;
                                    //printf("%d ",r_ind);
                                    each_pat_arr[r_ind][each_pat_num[r_ind]] = (int*)calloc((pat_arr_length_each),sizeof(int));
                                    for(int j=0;j<inst_order_num;j++){
                                        each_pat_arr[r_ind][each_pat_num[r_ind]][j] = inst_proute[j];
                                        each_pat_arr[r_ind][each_pat_num[r_ind]][pat_size+j] = inst_droute[j];
                                        //pat_arr[pat_num][pat_size+j] = inst_proute[j];
                                        //pat_arr[pat_num][2*pat_size+j] = inst_droute[j];
                                        //printf("%d ",each_pat_arr[r_ind][each_pat_num[r_ind]][j]);
                                    }
                                    
                                    //pat_arr[pat_num][pat_size] = cur_end_ind-1;
                                    //pat_arr[pat_num][2*pat_size] = cur_end_ind-1;
                                    each_pat_arr[r_ind][each_pat_num[r_ind]][pat_arr_length_each-1] = inst_order_num;
                                    each_pat_arr[r_ind][each_pat_num[r_ind]][pat_arr_length_each-2] = min_dist;
                                    //printf("%d %f \n",inst_order_num,min_dist);

                                    /*if(pat_num%1000==0){
                                        printf("%d \n",pat_num);
                                    }*/

                                    each_pat_num[r_ind] += 1;
                                    
                                }
                                free(inst_proute);
                                free(inst_droute);
                            }
                        }
                        else{
                            if(pre_feas_check(inst_capa, inst_order_set, inst_order_num,r_ind)==1){
                                int* inst_route = (int*)calloc(2*inst_order_num, sizeof(int));
                                /*for(int j=0;j<inst_order_num;j++){
                                    printf("%d ",inst_order_set[j]);
                                }*/
                                //printf("\n");
                                init_sol_gen(inst_order_set,inst_order_num,inst_route);
                                
                                int heuri_feas;
                                int best_dist,prev_dist;
                                prev_dist = MIN_DIST_VAL;
                                for(int opt_ind=0;opt_ind<FEAIND;opt_ind++){
                                    heuri_feas = local_search_feas(inst_route, inst_order_num,r_ind);
                                    if(heuri_feas==1){
                                        break;
                                    }
                                }
                                
                                if(heuri_feas ==1){
                                    for(int opt_ind=0;opt_ind<OPTNUM;opt_ind++){
                                        if(prev_dist == best_dist){
                                            break;
                                        }    
                                        best_dist = local_search_opt(inst_route,inst_order_num,r_ind);
                                        prev_dist = best_dist;
                                    }
                                    
                                    /*best_dist = local_search_opt(inst_route,inst_order_num,r_ind);
                                    best_dist = local_search_opt(inst_route,inst_order_num,r_ind);
                                    best_dist = local_search_opt(inst_route,inst_order_num,r_ind);
                                    best_dist = local_search_opt(inst_route,inst_order_num,r_ind);*/

                                    feas_sum +=1;
                                    inst_feas_check[r_ind] = 1;
                                    
                                    each_pat_arr[r_ind][each_pat_num[r_ind]] = (int*)calloc((pat_arr_length_each),sizeof(int));
                                    for(int j=0;j<inst_order_num;j++){
                                        each_pat_arr[r_ind][each_pat_num[r_ind]][j] = inst_route[j];
                                        each_pat_arr[r_ind][each_pat_num[r_ind]][pat_size+j] = inst_route[inst_order_num+j];
                                        //pat_arr[pat_num][pat_size+j] = inst_proute[j];
                                        //pat_arr[pat_num][2*pat_size+j] = inst_droute[j];
                                    }
                                    
                                    //pat_arr[pat_num][pat_size] = cur_end_ind-1;
                                    //pat_arr[pat_num][2*pat_size] = cur_end_ind-1;
                                    each_pat_arr[r_ind][each_pat_num[r_ind]][pat_arr_length_each-1] = inst_order_num;
                                    each_pat_arr[r_ind][each_pat_num[r_ind]][pat_arr_length_each-2] = best_dist;
                                    /*if(pat_num%1000==0){
                                        printf("%d \n",pat_num);
                                    }*/
                                    each_pat_num[r_ind] += 1;
                                }
                                free(inst_route);
                            }
                        }                        
                    }
                }
                if(feas_sum > 0){
                    if(cur_k<=pat_size-2){
                        pat_arr[cur_k][pat_num[cur_k]] = (int*)calloc((pat_arr_length),sizeof(int));
                                    
                        for(int j=0;j<inst_order_num;j++){
                            pat_arr[cur_k][pat_num[cur_k]][j] = inst_order_set[j];
                            //pat_arr[pat_num][pat_size+j] = inst_route[j];
                            //pat_arr[pat_num][2*pat_size+j] = inst_route[j+inst_order_num];
                        }
                        
                        //}
                        pat_arr[cur_k][pat_num[cur_k]][pat_arr_length-1] = inst_order_num;
                        pat_capa[cur_k][pat_num[cur_k]] = inst_capa; 
                        pat_feas_arr[cur_k][pat_num[cur_k]] = (int*)calloc((rider_num),sizeof(int));
                        memcpy(pat_feas_arr[cur_k][pat_num[cur_k]] , inst_feas_check, sizeof(int)*rider_num);
                        //printf("here4\n");

                        /*if(inst_order_num==pat_size){
                            for(int jj=0;jj<pat_arr_length;jj++){
                                printf("%d ",order_ordering[pat_arr[pat_num][jj]]);
                            }
                            for(int jj=0;jj<pat_arr_length;jj++){
                                printf("%d ",pat_arr[pat_num][jj]);
                            }
                            printf(" AND ");
                            for(int jj=0;jj<3;jj++){
                                printf("%d ",pat_feas_arr[pat_num][jj]);
                            }
                            printf("\n");
                        }*/
                        
                        
                        /*if(inst_order_set[0]>=start_ind+SLIDE){
                            next_pat_ind[next_pat_num] = pat_num;
                            next_pat_num +=1;
                        }*/
                        //printf("%d \n",inst_pat_num[cur_k]);

                            
                        next_pat_ind[0][next_pat_num[0]] = pat_num[cur_k];
                        next_pat_num[0] += 1;
                        //printf("here3\n");

                            //printf("here3\n");
                        pat_num[cur_k] += 1;
                        
                        if(pat_num[cur_k] >= pat_buffer[cur_k]){
                            //printf("Here! %d\n",cur_k);
                            return;
                        }
                    /*if(pat_num%1000==0){
                        printf("%d \n",pat_num);
                    }*/
                    }
                }
            }
        }
    }
    free(inst_order_set);
    free(inst_feas_check);
    return;
}


int pre_feas_check(int capa_value, int* order_set, int order_size, int rider_ind){
    //cout << rider_info[0] << " " << capa_value << endl;
    if(rider_info[rider_ind][0] < capa_value){
        return 0; //pre_feasibility check fail
    }else{
        int last_order_ind = order_set[order_size-1];
        for(int i=0;i<order_size-1;i++){
            if(rider_info[rider_ind][1]*(order_arr[last_order_ind][2] - order_arr[order_set[i]][1] - rider_info[rider_ind][2]) < dist_mat[order_set[i]][last_order_ind+order_num]){
                return 0;
            }
            if(rider_info[rider_ind][1]*(order_arr[order_set[i]][2] - order_arr[last_order_ind][1] - rider_info[rider_ind][2]) < dist_mat[last_order_ind][order_set[i]+order_num]){
                return 0;
            }
        }
        //cout << rider_info[1]*(order_arr[last_order_ind][2] - order_arr[last_order_ind][1] - rider_info[2]) << " " << dist_mat[last_order_ind][last_order_ind+order_num] << endl;

        if(rider_info[rider_ind][1]*(order_arr[last_order_ind][2] - order_arr[last_order_ind][1] - rider_info[rider_ind][2]) < dist_mat[last_order_ind][last_order_ind+order_num]){
            return 0;
        }
        return 1;
    }
}

int pre_feas_check_2opt(int capa_value, int* order_set, int order_size, int rider_ind){
    //cout << rider_info[0] << " " << capa_value << endl;
    if(rider_info[rider_ind][0] < capa_value){
        return 0; //pre_feasibility check fail
    }else{
        return 1;
    }
}

void init_sol_gen(int* order_set, int order_size, int* result_seq){
    //HeapType order_heap;
    HeapType_SMALL order_heap;
    double_arr_ind each_order;
    init_small(&order_heap);
    for(int i=0;i<order_size;i++){
        each_order.arr_ind = order_set[i];
        each_order.arr_value = order_arr[order_set[i]][1];
        insert_max_heap_small(&order_heap,each_order);
    }
    for(int i=0;i<order_size;i++){
        result_seq[order_size-1-i] =  delete_max_heap_small(&order_heap).arr_ind;
    }
    for(int i=0;i<order_size;i++){
        each_order.arr_ind = order_set[i];
        each_order.arr_value = order_arr[order_set[i]][2];
        insert_max_heap_small(&order_heap,each_order);
    }
    for(int i=0;i<order_size;i++){
        result_seq[2*order_size-1-i] =  delete_max_heap_small(&order_heap).arr_ind;
    }    
    return;
}

double feas_check(int* result_seq, int order_size, int rider_ind){
    double eval_clock,check_dist, inst_t;
    int ps, check_order ,ds;
    ps = result_seq[0];
    eval_clock = order_arr[ps][1];
    double eval_objective = 0;
    for(int i=1;i<order_size;i++){
        check_order = result_seq[i];
        check_dist = dist_mat[ps][check_order];
        inst_t = eval_clock + rider_time[rider_ind][ps][check_order];
        //round(check_dist/rider_info[rider_ind][1] + rider_info[rider_ind][2]);
        if((double)(order_arr[check_order][1]-epsilon) >= inst_t){
            eval_clock = order_arr[check_order][1];
        }else{
            eval_clock = inst_t;
        }
        ps = check_order;
    }
    
    ds = result_seq[order_size];
    check_dist = dist_mat[ps][ds+order_num];
    eval_clock += rider_time[rider_ind][ps][ds+order_num];
    //check_dist/rider_info[rider_ind][1] + rider_info[rider_ind][2];
    //printf("Time: %d %f\n",order_arr[ds][2],eval_clock);
    if((double)(order_arr[ds][2] - eval_clock) < -epsilon){//infeasible
        eval_objective += (eval_clock - order_arr[ds][2]);
    }
    
    for(int i=1;i<order_size;i++){
        check_order = result_seq[order_size+i];
        check_dist = dist_mat[ds+order_num][check_order+order_num];
        eval_clock += rider_time[rider_ind][ds+order_num][check_order+order_num];
        //round(check_dist/rider_info[rider_ind][1] + rider_info[rider_ind][2]);
        //printf("Time: %d %f\n",order_arr[check_order][2],eval_clock);
        if((double)(order_arr[check_order][2] - eval_clock) < -epsilon){//infeasible
            eval_objective += (eval_clock - order_arr[check_order][2]);
        }
        ds = check_order;
    }
    return eval_objective;

}

double dist_check(int* result_seq, int order_size,int rider_ind){
    double check_dist, inst_t, eval_result_clock, eval_result_dist;
    int ps, check_order ,ds;
    ps = result_seq[0];
    eval_result_clock = order_arr[ps][1];
    eval_result_dist = 0;
    double eval_objective = 0;
    for(int i=1;i<order_size;i++){
        check_order = result_seq[i];
        check_dist = dist_mat[ps][check_order];
        eval_result_dist += check_dist;
        inst_t = eval_result_clock + rider_time[rider_ind][ps][check_order];
        //round(check_dist/rider_info[rider_ind][1] + rider_info[rider_ind][2]);
        if(order_arr[check_order][1] >= inst_t){
            eval_result_clock = order_arr[check_order][1];
        }else{
            eval_result_clock = inst_t;
        }
        ps = check_order;
    }
    
    ds = result_seq[order_size];
    check_dist = dist_mat[ps][ds+order_num];
    eval_result_clock += rider_time[rider_ind][ps][ds+order_num];
    //round(check_dist/rider_info[rider_ind][1] + rider_info[rider_ind][2]);
    eval_result_dist += check_dist;
    if(order_arr[ds][2] - eval_result_clock < 0){//infeasible
        return MIN_DIST_VAL;
    }
    
    for(int i=1;i<order_size;i++){
        check_order = result_seq[order_size+i];
        check_dist = dist_mat[ds+order_num][check_order+order_num];
        eval_result_clock += rider_time[rider_ind][ds+order_num][check_order+order_num];
        //round(check_dist/rider_info[rider_ind][1] + rider_info[rider_ind][2]);
        eval_result_dist += check_dist;
        if(order_arr[check_order][2] - eval_result_clock < 0){//infeasible
            return MIN_DIST_VAL;
        }
        ds = check_order;
    }
    return eval_result_dist;

}

int local_search_feas(int* result_seq, int order_size, int rider_ind){
    int** init_location;
    init_location = (int**)calloc(2*order_size,sizeof(int*));
    for(int i=0; i< 2*order_size;i++){
        init_location[i] = (int*)calloc(2,sizeof(int));
        init_location[i][0] = result_seq[i];
        init_location[i][1] = i;
    }

    int feas_ind = 0;
    double feas_obj, inst_feas_obj;
    int temp_ind, temp_ind_loc;

    feas_obj = feas_check(result_seq,order_size,rider_ind);
    /*for(int jj=0;jj<2*order_size;jj++){
        printf("%d ", result_seq[jj]);
    }
    printf("obj: %f\n",feas_obj);*/
    if(feas_obj == 0){
        feas_ind = 1;
        return feas_ind;
    }else{
        for(int i=0;i<order_size;i++){
            for(int j=i+1;j<order_size;j++){
                temp_ind = result_seq[init_location[j][1]];
                result_seq[init_location[j][1]] = result_seq[init_location[i][1]];
                result_seq[init_location[i][1]] = temp_ind;
                inst_feas_obj = feas_check(result_seq,order_size,rider_ind);
                /*for(int jj=0;jj<2*order_size;jj++){
        printf("%d ", result_seq[jj]);
    }
    printf("obj: %f\n",feas_obj);*/

                if(inst_feas_obj == 0){
                    feas_ind = 1;
                    return feas_ind;
                }else{
                    if(feas_obj>inst_feas_obj){//improve
                        feas_obj = inst_feas_obj;
                        temp_ind_loc = init_location[j][1];
                        init_location[j][1] = init_location[i][1];
                        init_location[i][1] = temp_ind_loc;
                    }else{//not improved
                        result_seq[init_location[i][1]] = result_seq[init_location[j][1]];
                        result_seq[init_location[j][1]] = temp_ind;
                    }
                }

                temp_ind = result_seq[init_location[j+order_size][1]];
                result_seq[init_location[j+order_size][1]] = result_seq[init_location[i+order_size][1]];
                result_seq[init_location[i+order_size][1]] = temp_ind;
                inst_feas_obj = feas_check(result_seq,order_size,rider_ind);
                /*for(int jj=0;jj<2*order_size;jj++){
        printf("%d ", result_seq[jj]);
    }
    printf("obj: %f\n",feas_obj);*/

                if(inst_feas_obj == 0){
                    feas_ind = 1;
                    return feas_ind;
                }else{
                    if(feas_obj>inst_feas_obj){//improve
                        feas_obj = inst_feas_obj;
                        temp_ind_loc = init_location[j+order_size][1];
                        init_location[j+order_size][1] = init_location[i+order_size][1];
                        init_location[i+order_size][1] = temp_ind_loc;
                    }else{//not improved
                        result_seq[init_location[i+order_size][1]] = result_seq[init_location[j+order_size][1]];
                        result_seq[init_location[j+order_size][1]] = temp_ind;
                    }
                }
            }
        }
    }
    for(int i=0; i< 2*order_size;i++){
        free(init_location[i]);
    }
    free(init_location);
    return feas_ind;
}

int local_search_opt(int* result_seq, int order_size, int rider_ind){
    int** init_location;
    init_location = (int**)calloc(2*order_size,sizeof(int*));
    for(int i=0; i< 2*order_size;i++){
        init_location[i] = (int*)calloc(2,sizeof(int));
        init_location[i][0] = result_seq[i];
        init_location[i][1] = i;
    }

    int best_dist, inst_dist;
    int temp_ind, temp_ind_loc;

    best_dist = dist_check(result_seq,order_size,rider_ind);
    
    for(int i=0;i<order_size;i++){
        for(int j=i+1;j<order_size;j++){
            temp_ind = result_seq[init_location[j][1]];
            result_seq[init_location[j][1]] = result_seq[init_location[i][1]];
            result_seq[init_location[i][1]] = temp_ind;
            inst_dist = dist_check(result_seq,order_size,rider_ind);
            if(best_dist>inst_dist){//improve
                best_dist = inst_dist;
                temp_ind_loc = init_location[j][1];
                init_location[j][1] = init_location[i][1];
                init_location[i][1] = temp_ind_loc;
            }else{//not improved
                result_seq[init_location[i][1]] = result_seq[init_location[j][1]];
                result_seq[init_location[j][1]] = temp_ind;
            }

            temp_ind = result_seq[init_location[j+order_size][1]];
            result_seq[init_location[j+order_size][1]] = result_seq[init_location[i+order_size][1]];
            result_seq[init_location[i+order_size][1]] = temp_ind;
            inst_dist = dist_check(result_seq,order_size,rider_ind);
        
            if(best_dist>inst_dist){//improve
                best_dist = inst_dist;
                temp_ind_loc = init_location[j+order_size][1];
                init_location[j+order_size][1] = init_location[i+order_size][1];
                init_location[i+order_size][1] = temp_ind_loc;
            }else{//not improved
                result_seq[init_location[i+order_size][1]] = result_seq[init_location[j+order_size][1]];
                result_seq[init_location[j+order_size][1]] = temp_ind;
            }
        
        }
    }
    
    for(int i=0; i< 2*order_size;i++){
        free(init_location[i]);
    }
    free(init_location);

    return best_dist;
}




void swap(int* arr, int i, int j) {
    int temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}

// Recursive function to generate permutations
void generatePermutations(int* arr, int start, int end, int** result, int *index) {
    int ind_sub = *index;
    if (start == end) {
        memcpy(result[ind_sub], arr, (end + 1) * sizeof(int));
        ind_sub ++;
        *index = ind_sub;
    } else {
        for (int i = start; i <= end; i++) {
            swap(arr, start, i);
            generatePermutations(arr, start + 1, end, result, &ind_sub);
            swap(arr, start, i);  // Backtrack
        }
        *index = ind_sub;
    }
}

// Function to calculate factorial
int factorial(int n) {
    return (n == 1 || n == 0) ? 1 : n * factorial(n - 1);
}

// Function to generate all permutations of a list and return them
int** permute(int* nums, int size, int *perm_count) {
    int fcount = factorial(size);
    *perm_count = fcount; 
    int** result;
    result = (int**)calloc(fcount,sizeof(int*));
    for (int i = 0; i < fcount; ++i) {
        result[i] = (int*)calloc(size, sizeof(int));
    }

    int index = 0;
    generatePermutations(nums, 0, size - 1, result, &index);

    return result;
    
}

double optimal_route_check(int* order_set, int order_size, int* opt_pick_route, int* opt_deli_route, int rider_ind){
    //pick route enumeration
    int perm_count;
    int** proute_array;
    proute_array = permute(order_set, order_size, &perm_count);
    double* proute_result;
    proute_result = (double*)calloc(2,sizeof(double));
    //vector<vector<int>> pickroute = permuteSubset(order_set, order_size);
    /*for(int i=0;i<order_size;i++){
        printf("%d ", order_set[i]);
    }
    printf(" order \n ");*/

    double min_dist = MIN_DIST_VAL;
    //printf("count: %d \n",perm_count);    
    for(int i=0;i<perm_count;i++){
        double* each_min_dist = (double*)calloc(1,sizeof(double));
        each_min_dist[0] = MIN_DIST_VAL;
        int* each_deli_route = (int*)calloc(order_size,sizeof(int));
        int* current_deli = (int*)calloc(order_size,sizeof(int));
        proute_result = pick_route_check(proute_array[i], order_size, rider_ind);

        /*for(int j=0;j<order_size;j++){
            printf("%d ",proute_array[i][j] );
        }*/
        //printf("%f %f \n",proute_result[0],proute_result[1]);

        deli_route_check(proute_array[i],proute_result,order_size,current_deli,each_min_dist,each_deli_route,proute_array[i][order_size-1],order_size,rider_ind);
        
        /*for(int j=0;j<order_size;j++){
            printf("%d ",each_deli_route[j]);
        }
        printf("%f \n",each_min_dist[0]);*/
        if(min_dist>each_min_dist[0]){
            min_dist = each_min_dist[0];
            memcpy(opt_pick_route, proute_array[i], sizeof(int)*order_size);
            memcpy(opt_deli_route, each_deli_route, sizeof(int)*order_size);
        }

        free(each_deli_route);
        free(proute_array[i]); 
        free(each_min_dist);
        free(current_deli);
    }
    free(proute_array);
    proute_array = NULL;
    free(proute_result);

    return min_dist;

}

double* pick_route_check(int* proute, int order_size, int rider_ind){
    int prev_order;
    double add_dist,new_t, inst_t,*eval_result;
    eval_result = (double*)calloc(2,sizeof(int));

    for(int i=0;i<order_size;i++){
       if(i == 0){
            prev_order = proute[i];
            eval_result[0] = order_arr[prev_order][1];
            eval_result[1] = 0;
       }else{
            add_dist= dist_mat[prev_order][proute[i]];
            eval_result[1] += add_dist;
            inst_t = eval_result[0] + rider_time[rider_ind][prev_order][proute[i]];
            //round(add_dist/rider_info[rider_ind][1] + rider_info[rider_ind][2]);
            if(order_arr[proute[i]][1] >= inst_t){
                new_t = order_arr[proute[i]][1];
            }else{
                new_t = inst_t;
            }
            eval_result[0] = new_t;
            prev_order = proute[i];
       }
    }
    return eval_result;
}    


// Recursive function to generate permutations of increasing lengths
void deli_route_check(int* order_subset, double* cur_eval, int order_subset_num, int* current, double *min_dist, int* droute, int last_order,int origin_size, int rider_ind) {
    double eval_clock, eval_dist,add_dist;
    eval_clock = cur_eval[0];
    eval_dist = cur_eval[1];
    int pre_last_order = last_order;
    
    if(order_subset_num==origin_size){
        for (int i = 0; i < order_subset_num; i++) {
            current[0] = order_subset[i];
            //cout << last_order << " " <<order_subset[i] << endl;
            add_dist = dist_mat[last_order][order_subset[i]+order_num];
            cur_eval[1] += add_dist;
            cur_eval[0] += rider_time[rider_ind][last_order][order_subset[i]+order_num];
            //round(add_dist/rider_info[rider_ind][1] + rider_info[rider_ind][2]);
            if(cur_eval[0] <= order_arr[order_subset[i]][2]){
                int* order_subset_sub = (int*)calloc(order_subset_num-1,sizeof(int));
                //int* current_sub = (int*)calloc(origin_size,sizeof(int));
                int sub_ind = 0;
                last_order = order_subset[i];

                for(int j=0;j<order_subset_num;j++){
                    if(j != i){
                        order_subset_sub[sub_ind] = order_subset[j];
                        sub_ind += 1;
                    }
                }
                /*for(int j=0;j<=origin_size-order_subset_num;j++){
                    current_sub[j] = current[j];
                }*/
                deli_route_check(order_subset_sub,cur_eval, order_subset_num-1, current, min_dist, droute, last_order,origin_size,rider_ind);
                free(order_subset_sub);
                order_subset_sub = NULL;
                //free(current_sub);
            }
            last_order = pre_last_order;
            cur_eval[1] = eval_dist;
            cur_eval[0] = eval_clock;
        }
    }else{
        for (int i = 0; i < order_subset_num; i++) {
            current[origin_size-order_subset_num] = order_subset[i];
            add_dist = dist_mat[last_order+order_num][order_subset[i]+order_num];
            cur_eval[1] += add_dist;
            cur_eval[0] += rider_time[rider_ind][last_order+order_num][order_subset[i]+order_num];
            //round(add_dist/rider_info[rider_ind][1] + rider_info[rider_ind][2]);
            if(cur_eval[0] <= order_arr[order_subset[i]][2]){
                if (order_subset_num==1) {
                    if(min_dist[0] > cur_eval[1]){
                        min_dist[0] = cur_eval[1];
                        for (int j=0; j<origin_size;j++) {
                            droute[j] = current[j];
                        }
                        //printf("%f ", cur_eval[1]);
                    }
                    last_order = pre_last_order;
                    cur_eval[1] = eval_dist;
                    cur_eval[0] = eval_clock;
                    return;
                }else{
                    int* order_subset_sub = (int*)calloc(order_subset_num-1,sizeof(int));
                    //int* current_sub = (int*)calloc(origin_size,sizeof(int));

                    int sub_ind = 0;

                    last_order = order_subset[i];

                    for(int j=0;j<order_subset_num;j++){
                        if(j != i){
                            order_subset_sub[sub_ind] = order_subset[j];
                            sub_ind += 1;
                        }
                    }
                    /*for(int j=0;j<=origin_size-order_subset_num;j++){
                        current_sub[j] = current[j];
                    }*/
                    deli_route_check(order_subset_sub,cur_eval, order_subset_num-1, current, min_dist, droute, last_order,origin_size,rider_ind);
                    free(order_subset_sub);
                    order_subset_sub = NULL;

                    //free(current_sub);
                }
            }
            last_order = pre_last_order;
            cur_eval[1] = eval_dist;
            cur_eval[0] = eval_clock;
        }
    }
    return;
}




static void init(HeapType *h)
{
	h->heap_size = 0; 
}

static void init_small(HeapType_SMALL *h)
{
	h->heap_size = 0; 
}

//삽입 함수
static void insert_max_heap(HeapType *h, double_arr_ind gub_item) {
	int i;
	i = ++(h->heap_size);
	//트리를 거슬러 올라가면서 부모 노드와 비교하는 과정

	while ((i != 1) && (gub_item.arr_value > h->heap[i / 2].arr_value)) {
		h->heap[i] = h->heap[i / 2];
		i /= 2;
	}
	h->heap[i] = gub_item; // 새로운 노드를 삽입
}

static void insert_max_heap_small(HeapType_SMALL *h, double_arr_ind gub_item) {
	int i;
	i = ++(h->heap_size);
	//트리를 거슬러 올라가면서 부모 노드와 비교하는 과정

	while ((i != 1) && (gub_item.arr_value > h->heap[i / 2].arr_value)) {
		h->heap[i] = h->heap[i / 2];
		i /= 2;
	}
	h->heap[i] = gub_item; // 새로운 노드를 삽입
}


//삭제 알고리즘
static double_arr_ind delete_max_heap(HeapType *h)
{
	int parent, child;
	double_arr_ind item, temp;

	item = h->heap[1];
	temp = h->heap[(h->heap_size)--];
	parent = 1;
	child = 2;

	while (child <= h->heap_size) {
		//현재 노드의 자식 노드 중 더 큰 자식 노드를 찾는다.
		if ((child < h->heap_size) && (h->heap[child].arr_value) < h->heap[child + 1].arr_value){
            child++;
        }

		if (temp.arr_value >= h->heap[child].arr_value){
            break;
        } 
		//한 단계 아래로 이동

		h->heap[parent] = h->heap[child];
		parent = child;
		child *= 2;
	}
	h->heap[parent] = temp;
	return item;
}

static double_arr_ind delete_max_heap_small(HeapType_SMALL *h)
{
	int parent, child;
	double_arr_ind item, temp;

	item = h->heap[1];
	temp = h->heap[(h->heap_size)--];
	parent = 1;
	child = 2;

	while (child <= h->heap_size) {
		//현재 노드의 자식 노드 중 더 큰 자식 노드를 찾는다.
		if ((child < h->heap_size) && (h->heap[child].arr_value) < h->heap[child + 1].arr_value){
            child++;
        }

		if (temp.arr_value >= h->heap[child].arr_value){
            break;
        } 
		//한 단계 아래로 이동

		h->heap[parent] = h->heap[child];
		parent = child;
		child *= 2;
	}
	h->heap[parent] = temp;
	return item;
}